#ifndef _n_class_h_
#define _n_class_h_

class NClass
{
	bool m_fInit;
	public:
	NClass();
	~NClass();
	bool Init();
	void Destroy();
};

#endif