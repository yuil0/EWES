#include "main.h"

#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>

#include <time.h>
#include <Windowsx.h>
#include "..\\transman_srv\\str.h"

const int ci_len_sz_app = 64;
const int ci_max = 256; //const int ci_time_ms = 300;
bool g_fGet;

char g_szmapp[ci_len_sz_app] = "util\0";
wchar_t g_sz_app[ci_len_sz_app] = L"util\0";

HINSTANCE g_hInstance;

CWindow gWndMain;

CWinCtrl g_WinCtrl;  //UColor g_Color;

void MesBox(wchar_t *wsz_text) { MessageBox(0, wsz_text, g_sz_app,  0);  }

void MesBoxA(char *sz_text) { MessageBoxA(0, sz_text, g_szmapp, 0); }

void Destroy(HWND hwnd)
{                                 //KillTimer(gWndMain.GetHWND(), 1); //g_Color.Destroy();
	g_WinCtrl.Destroy();

	::CoUninitialize();

	DestroyWindow(hwnd);	
}

void WMClose(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	Destroy(hwnd);
}

void WMDestroy(WPARAM wParam, LPARAM lParam)
{
	ExitProcess(1);
}

void WMSize(WPARAM wParam, LPARAM lParam)
{
	int new_width = lParam & 0xFFFF; //The low - order word of lParam specifies the new width of the client area.	
	int new_height = (lParam >> 2) & 0xFFFF; //The high - order word of lParam specifies the new height of the client area.
}

void WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam) {}

void WM__COMMAND(WPARAM wParam, LPARAM lParam)
{
	/*
	Message Source	| wParam (high word)  | wParam (low word)       	        | lParam
	Menu	        |                 0   | 	Menu identifier (IDM_*)     	| 0
	Accelerator	    |                 1   |    Accelerator identifier (IDM_*)	| 0
	Control	        | Control-defined     | Control identifier	                | Handle to the control window      
	                | notification code	  |                                     |
	*/
	int iNotify = HIWORD(wParam);
	int id = LOWORD(wParam);
	HWND hwnd = (HWND)lParam;
	
	SCtrl* p_ctrl;

	bool fUse = false;

	/*if (g_WinCtrl.Find(id, &p_ctrl))
	{
		if (p_ctrl->name == "cb_get")
		{
			g_WinCtrl.OpCheckbox("cb_get", &g_fGet);

			fUse = true;
		}
	}*/
	
	if (fUse == false)
	{
		if (g_WinCtrl.OnCommand(iNotify, id, hwnd) == false)
		{
		}
	}
}

void SetColorFromCursor(POINT& pn)
{                                    //POINT pn; BOOL fGet = GetCursorPos(&pn); if (fGet == FALSE) { return; }	
	HWND hwnd = WindowFromPoint(pn); //gWndMain.GetHWND();

	if (hwnd == 0) { return; }

	HDC hdc = GetDC(hwnd);

	if (hdc== 0) { return; }

	RECT rc;

	if (GetWindowRect(hwnd, &rc) == FALSE) { return; }

	pn.x -= rc.left;
	pn.y -= rc.top; //int GetDeviceCaps(hdc, _In_ int nIndex	);

	COLORREF color = GetPixel(hdc, pn.x, pn.y);

	if (color == CLR_INVALID) { return; }

	SCtrl* p_ctrl;

	if (g_WinCtrl.Find("edit_color", &p_ctrl))
	{
		char sz_val[MAX_PATH + 1];

		sprintf(sz_val, "%X", color);

		g_WinCtrl.SendMes("edit_color", WM_SETTEXT, (WPARAM)0, (LPARAM)sz_val);
	}

	ReleaseDC(hwnd, hdc);
}

void WM__NCMOUSEMOVE(WPARAM wParam, LPARAM lParam)
{
	if (g_fGet)
	{
		/*RECT rc;
		RECT crc;

		if (GetWindowRect(gWndMain.GetHWND(), &rc) == FALSE) { return; }
		if (GetClientRect(gWndMain.GetHWND(), &crc) == FALSE) { return; }*/
		/*RECT crca;
		SCWindowAttr wa;
		if (CWindow::GetClientRectAbs(gWndMain.GetHWND(), crca, &wa) == false) { return; }
		*/


		POINT pn = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };

		/*pn.x += crca.left + wa.iThick;
		pn.y += crca.top + wa.iThick + wa.iCaption;*/

		SetColorFromCursor(pn);
	}
}

/*void WM__TIMER(WPARAM wParam, LPARAM lParam)
{
	if (g_fGet)
	{
		SetColorFromCursor();
	}
}*/

///////////////////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	bool fMapWnd = uMsg & (1 << 16);
	switch (uMsg)
	{
	case WM_CLOSE: WMClose(hwnd, wParam, lParam); break;
	case WM_DESTROY: WMDestroy(wParam, lParam); break;
	case WM_SIZE: WMSize(wParam, lParam); break;
	case WM_LBUTTONDOWN: WM__LBUTTONDOWN(wParam, lParam); break; //case WM_MOUSEMOVE: WM__MOUSEMOVE(wParam, lParam); break;
	case WM_NCMOUSEMOVE: WM__NCMOUSEMOVE(wParam, lParam); break;
	case WM_COMMAND: WM__COMMAND(wParam, lParam); break; //case WM_TIMER: WM__TIMER(wParam, lParam); break;
	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 1;
}

void Probe() 
{
	/*
	double d = 42981.5733832176;
	time_t t=time(0);
	struct tm  *tm=localtime((time_t*)&d);

	
	int fo = open("out.txt",  O_CREAT|O_WRONLY|O_BINARY, S_IREAD|S_IWRITE);
	if (fo >= 0)
	{
		char buf[MAX_PATH + 1];
		memcpy(buf, &d, 8);
		int iWritten = write(fo, buf, 8);
		close(fo);
	}*/
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void Init(HINSTANCE hInstance)
{
	if (FAILED(::CoInitialize(NULL)))
	{
		MessageBox(0, L"FAILED CoInitialize", g_sz_app, 0); return;
	}                                         //MinimizeAllWnd();

	g_hInstance = hInstance;

	//<q1 YUIL ��������� ����
	SWindowCreateParam wcp;

	wcp.hInstance = hInstance;
	wcp.wsz_name = g_sz_app;
	wcp.wndProc = WindowProc;
	wcp.fVisible = true;
	wcp.w = 1024;
	wcp.h = 768;
	wcp.fCalc_xy = true;

	gWndMain.Create(wcp);
	//>q1

	HWND hwnd = gWndMain.GetHWND();

	UINT uiRes=0;

	if (hwnd)
	{
		cr_main_ctrl(hInstance);

		g_WinCtrl.AdjustParentWnd(hwnd); ///uiRes = SetTimer(hwnd, 1, ci_time_ms, 0);
	}

	UpdateWindow(hwnd);

	if (hwnd) { chColorWnd(); }

	Probe();

}

void CallPaint()
{
	HWND hwnd = gWndMain.GetHWND();

	HDC hdc = GetDC(hwnd);
	
	HBRUSH hbrush = CreateSolidBrush(g_color);

	RECT rc;

	GetClientRect(hwnd, &rc);

	FillRect(hdc, &rc, hbrush);

	DeleteObject(hbrush);

	ReleaseDC(hwnd, hdc);

}

void ReadKeys()
{
	if (GetAsyncKeyState(VK_RETURN)&7)
	{
		//1. read  from edit_color
		char sz_val[MAX_PATH + 1];

		if (g_WinCtrl.SendMes("edit_color", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val))
		{
			//2. use color
			uchar part[3];

			ReadHexStr(sz_val, g_color, (uchar*)part);

			chColorWnd();
			
			//CallPaint();

			//Sleep(100); g_WinCtrl.ShowAllUpdate(true);
		}
	}
}

////////////////////////////////////////////////////////////////////
int CALLBACK WinMain(
	HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine,
	int       nCmdShow
)
{
	Init(hInstance);

	MSG msg;
	BOOL f_ret;
	while ((f_ret = GetMessage(&msg, 0, 0, 0)))
	{
		if (f_ret == -1)
		{
			//GetLastError.
			break;
		}
		else
		{
			ReadKeys();
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

}
