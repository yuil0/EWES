#ifndef _winctrl_h_
#define _winctrl_h_

#include <vector>
#include "..\\transman_srv\\std_str.h"
#include <windows.h>
#include "..\\transman\\win_e.h"


#pragma comment(lib, "User32.lib")

const int ci_height_font_edit = 14;

typedef void(*FN_HANDLER)(int iNotify, void* p_param);

typedef enum
{
	EGDIO_COMBOBOX_BUTTON=0,
	EGDIO_STATIC,
	EGDIO_BUTTON_UP,
	EGDIO_BUTTON_DOWN,
	EGDIO_STATIC_WIDTH_204,
	EGDIO_BUTTON_X_UP,
	EGDIO_BUTTON_X_DOWN,
	EGDIO_V_OFF,
	EGDIO_V_ON,
	EGDIO_PEN_BACK_GROUND,
	EGDIO_BRUSH_BACK_GROUND,
	EGDIO_FONT_EDIT,	
	//
	EGDIO_QUANTITY,
}EGDIObjects;

struct SGDI_objects
{
	bool m_fInit;
	HGDIOBJ h[EGDIO_QUANTITY];
	//
	void Open();
	void Close();
};

extern SGDI_objects g_sGDI_objects;

/*typedef enum
{
	EOG_COMMON=0,
	EOG_COMMON = 0,
}EOriginGroup;*/

struct SRect
{
	int x;

	int y;

	int w;

	int h;

	bool In(POINT& pn); // int xNew, int yNew);
};

struct SGroup : SRect
{
	std_string name;
	int h_caption;
	int m_i_row;
	void Clear();
	SGroup() {Clear();}
	void NewRows(int q_rows=1); //void IncRow(int q_rows=1) { m_i_row += q_rows; }
};

typedef enum
{
	ETC_STANDARD=0,
	ETC_WIN_E_EDIT,//ETC_WIN_E_COMBO_BOX,
	ETC_WIN_E_LIST_BOX,
}ETypeControl;

///////////////////////////////////////
struct SCtrl : SRect
//
{
	int row; //YUIL ���� ==0 �� ��� �����  , ������  �  ==1

	int col;

	std_string name;

	std_string classWnd;

	std_string textWnd;	

	HWND hwnd;

	DWORD styleAdd;

	FN_HANDLER handler;

	int x;

	int y;

	int w;

	int h;

	float mul_w; //YUIL � ����� �, �� � ��������
	
	float mul_h; //YUIL � ����� �, �� � ��������

	int id;

	bool f_no_calc_w;

	int index_group; // 1 + valid_index_group , 0 : not_used

	bool fPressed; //== checked == selected

	ETypeControl eType;

	void *p_obj; // win_e::SEdit edit_zone_new_name; //YUIL 2017-02-08

	bool fHide; //YUIL 2017-02-13

	bool f_no_calc_xy; //YUIL 2017-02-13
	
	bool fTop; //YUIL 2017-02-13 �������� ����
	
	int id_ctrl_open_by_left_button;

	bool fNeedDrawBackGround; //YUIL 2017-02-13

	int id_ctrl_set_text_by_select;  //YUIL 2017-02-13

	SCtrl();

	void Clear();

	int GetMaxX() { return x + w; }

	int GetMaxY() { return y + h; }

	void DrawStatic(HDC hdc, int i_mode=0);
	
	void DrawVLeft(HDC hdc);

	void DrawCheckbox(HDC hdc);

	void DrawButton(HDC hdc);

	void SetState(POINT& pn, bool fDown=false);

	bool GetSelected() { return fPressed; } //== checked == selected}
	bool GetChecked() { return fPressed; }
	bool GetPressed() { return fPressed; }
	char* GetText();
	
};

struct SWinCtrlParam
{                                   //int rowMax; int colMax;
	HINSTANCE hInstance;

	HWND hwndParent;

	int wCtrl;

	int hCtrl;
	
	int ident;

	int xOrigin;
	
	int yOrigin; //bool fHide;

	int width;

	int i_start_id;
	
	bool fOwnerDraw;

	SWinCtrlParam();
	
	void Clear();
};

class CWinCtrl
{
	bool m_fInit;

	std::vector<SCtrl> m_ctrlList; //int m_row; //YUIL . ������  �  ==1 //int m_col;

	std::vector<SGroup>  m_groupList;

	int m_row;

	int m_max_x;

	int m_stat_max_x;  //YUIL 2017-10-25 ����������. ���� x

	int m_stat_min_x;  //YUIL 2017-10-25 ����������. ���� x

	int m_stat_max_y;
	
	int m_id_ctrl_active;  //TAB

	HMENU  m_menu;

	bool m_fDrawTop; //YUIL 2017-02-13

	bool IsWndTab(HWND hwnd);

public:
	CWinCtrl();

	~CWinCtrl();

	SWinCtrlParam m_param;

	bool Init(const SWinCtrlParam& param);

	void Destroy();        //struct SAddParam	{int wCtrl;};

	SCtrl& operator[](int index) { return (SCtrl&)m_ctrlList[index]; }

	HWND Add(SCtrl& ctrl); // , SAddParam* p_add_param = 0);

	HWND Add(char *sz_name, char *sz_class_wnd, char *sz_text_wnd = 0, DWORD styleAdd = 0, int row = -1, int col = -1, FN_HANDLER handler = 0);

	bool AddMenuItemText(char* pData, int* p_id=0, UINT uAddFlags=0, SCtrl* *p_ctrl=0);

	bool Find(int id, SCtrl* *p_ctrl = 0);

	bool Find(char *name, SCtrl* *p_ctrl = 0);

	bool OnCommand(int iNotify, int id, void* p_param = 0);

	int SendMes(int id, UINT uMes, WPARAM wParam, LPARAM lParam);

	int SendMes(char *name, UINT uMes, WPARAM wParam, LPARAM lParam);

	void SendMesAll(UINT uMes, WPARAM wParam, LPARAM lParam);
	
	struct SIndexRange
	{
		int index_from;
		int index_to;
	};

	void ShowAll(bool fShow, std::vector<SIndexRange>* p_list_range=0);
	
	void ShowAllUpdate(bool fShow, std::vector<SIndexRange>* p_list_range=0);

	bool AdjustParentWnd(HWND hwndParent);

	void Update();

	void NewRow(char *sz_name_by_max_x = 0);
	
	void NewRows(int q_rows);

	int GetStatMaxX() {return m_stat_max_x;}
	
	int GetStatMinX() {return m_stat_min_x;}

	void SetFocus(char *name, bool f);

	int GetSize() { return m_ctrlList.size(); }

	SWinCtrlParam& GetParam() { return m_param; }
	
	void SetParam(SWinCtrlParam& param_n) { m_param=param_n; }

 void SetOrigin(int x, int y) 
	{ 
		m_param.xOrigin = x; 
		m_param.yOrigin = y; 
		ClearRow();
		ClearStat();
	}

	int GetOriginX() { return m_param.xOrigin; }
	int GetOriginY() { return m_param.yOrigin; }
	
	void IncOriginY(int delta) { m_param.yOrigin+=delta; }

	void ClearRow() {m_row=0;}
	
	void ClearStat() 
	{
		m_stat_max_x=0;

		m_stat_min_x=0;

		m_stat_max_y=0;
 }

	int GetStatMaxY() { return m_stat_max_y; }

	void SetMaxX(int x_new) { m_max_x=x_new; }	

	void NextFocusActive(); //void SetFocusActive();

	void SendMes_CB_RESETCONTENT(char *sz_name);

	void OpCheckbox(char  *sz_checkbox, bool* pfCheck=0);

	void SetCheckbox(char  *sz_checkbox, bool fCheck);

	bool GetCheckbox(char  *sz_checkbox);

	bool TrackMenu(HWND hwnd, POINT& pn);

	bool MarkMenuItem(int id, bool fMark); // bool SetMenuItem(int id, BOOL fByPositon, LPCMENUITEMINFOA lpmii);//bool AddGroup(SGroup& s_group);

	typedef enum
	{
		EAGD_RIGHT=0,
		EAGD_BOTTOM,
	}EAddGroupDirect;

	struct SAddGroupParam
	{
		int w;
		int h;
		int h_caption;
		int index_from;
		EAddGroupDirect eDirect;

		SAddGroupParam();
		void Clear();
	};

	bool AddGroup(char* sz_name, SAddGroupParam& param);
	void Draw(HDC hdc);
	void DrawOp(HDC hdc, bool fTop); //YUIL 2017-02-13
	void DrawGroups(HDC hdc);
	void DrawBackGroundByCtrl(HDC hdc, SCtrl& o);
	void GroupNewRows(int index, int q_rows=1);
	void CalcPosSizeNewElement(SCtrl& ctrl);
	bool FindByHWND(HWND hwnd, SCtrl* *pCtrl); //void WM__COMMAND(int id, int notify);//void WM__COMMAND_A(WPARAM wParam, LPARAM lParam);

	void SetState(HWND hwnd, POINT& pn, bool fDown);
	void ListBox_Draw(HDC hdc, win_e::SListBox& lb);
	
	bool GetGroup(int index, SGroup& g)
	{
		int q = m_groupList.size();

		if (index >=q) { return false; }
		
		g = m_groupList[index];

		return true;
	}

	bool KeyDown(int vk);
	
	bool WM__LBUTTONDOWN(POINT& pn, HWND hwnd = 0, SCtrl* *pFoundCtrl = 0); // , bool* pfNeedDrawBkGr = 0);
	bool WM__LBUTTONDOWN_op(POINT& pn, HWND hwnd, SCtrl* *pFoundCtrl, bool fTop);
	
	bool WM__RBUTTONDOWN(POINT& pn, HWND hwnd=0, SCtrl* *pFoundCtrl=0, win_e::SListBoxItem* *pItem=0);
	bool WM__RBUTTONDOWN_op(POINT& pn, HWND hwnd, SCtrl* *pFoundCtrl, win_e::SListBoxItem* *pItem, bool fTop);

	char* GetText(char* name);
	void SetText(char* name, char* sz_new);
	void ClearList(char* name, SCtrl* *pFoundCtrl=0);
	void AddToList(char* name, char* sz_new, bool fSelected=true, char* id_new = 0, char* name_new = 0, char *param_1_new = 0, void* p_ptr_1_new = 0);
	
	bool WM__MOUSEMOVE(POINT& pn, SCtrl* *pFoundCtrl=0);
	bool WM__MOUSEMOVE_op(POINT& pn, SCtrl* *pFoundCtrl, bool fTop);

	bool WM__LBUTTONUP(POINT& pn, HWND hwnd=0);
	bool WM__LBUTTONUP_op(POINT& pn, HWND hwnd, bool fTop);

	int GetCountSel(char* name, bool& fAll, std::vector<long>& list_index_sel);
	
	void SelectAll(char* name, bool fSel=true);
	bool GetSelItem(char* name, win_e::SListBoxItem* *p_item);
	bool SelByIndex(char* name, int index);

	void AddCombobox(char* name_edit, char* name_list, int w, int index_group=-1);
	void AddListbox(char* name, int w, int index_group=-1);
	void SetListBoxTextOp(win_e::SListBox* p, SCtrl& o);

	bool GetSelIndex(char* name, int& index);

	void Show(char* name, bool fShow, bool fActive=false);
};

#endif