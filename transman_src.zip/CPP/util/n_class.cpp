#include <memory.h>
#include "u_color.h"

NClass::NClass() {}

NClass::~NClass() {}

bool NClass::Init()
{
	m_fInit=false;
	
	memset(this, 0, sizeof(NClass));
	
	m_fInit=true;

	return m_fInit;
}

void NClass::Destroy()
{
	
}
