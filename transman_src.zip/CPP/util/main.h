#ifndef _main_h_
#define _main_h_

#include <windows.h>
#include "..\\transman\\window.h"
#include "winctrl.h"
#include "u_color.h"

extern const int ci_len_sz_app;

extern const int ci_max;

extern char g_szmapp[];
extern wchar_t g_sz_app[];

extern HINSTANCE g_hInstance;

extern CWindow gWndMain;

extern CWinCtrl g_WinCtrl;

extern bool g_fGet;


//extern UColor g_Color;

void MesBox(wchar_t *wsz_text);

void MesBoxA(char *sz_text);

void cr_main_ctrl(HINSTANCE hInstance);

#endif