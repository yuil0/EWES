#ifndef _ms_inet_h_
#define _ms_inet_h_

/*typedef enum
{
	EIB_MS_IE=0,
	EIB_MS_EDGE,
}EInternetBrowser;

const EInternetBrowser ceInternetBrowser=EIB_MS_EDGE;  //YUIL 2017-11-14*/

//#define DEF_BROWSER_MS_EDGE

//#ifndef DEF_BROWSER_MS_EDGE

#import "C:\\Windows\\SysWOW64\\ieframe.dll" 
typedef SHDocVw::IWebBrowser2Ptr BrowserPtr; 

//#endif

class CMSInet
{
	bool m_fInit;
	
	//#ifndef DEF_BROWSER_MS_EDGE
	BrowserPtr m_browser;
	//#endif

	public:
	CMSInet();
	~CMSInet();
	bool Open(HINSTANCE hInstance=0); 	
	bool Close(char *sz_part_text="openstreetmap.ru");
	bool GetHWND(HWND& hWnd, char *sz_part_text="openstreetmap.ru");
	HWND GetHWND(char *sz_part_text="openstreetmap.ru");
	bool GetLocationURL(wchar_t *wszLocationURL, int i_size_URL=MAX_PATH, char *sz_part_text="openstreetmap.ru");
};

bool MSInet_Open(char *sz_addr, bool f_top=false, void** p_browser=0);

#endif