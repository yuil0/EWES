#ifndef _fill_ctrl_h_
#define _fill_ctrl_h_

#include  <windows.h>
#include  <time.h>
#include "..\\transman_srv\\std_str.h"
#include "..\\util\\winctrl.h"
#include "mssql.h"
#include <vector>

struct SNameId
{
	std_string name;
	std_string id;
	SNameId();
};

struct SFillCtrl
{   
	typedef enum
	{
		ETB_COMBOBOX=0,
		ETB_LISTBOX,
	}ETypeBox;

	bool m_fInit;
	CWinCtrl* m_p_ctrls;
	std::vector<std_string> m_box_names; // std_string m_sz_box_name;
	std_string m_sz_edit;
	
	std::vector<std::vector<std_string>> m_rows;
	std::vector<int> m_col_chars;

	ETypeBox m_eTypeBox;
	SNameId m_name_fields;
	std::vector<SNameId>* m_p_list;
	int m_i_read_rows;
	SFillCtrl(CWinCtrl* p_ctrls);
	void fill_edit_from_db_add(FldsPtr fp);
	void fill_from_db_add(FldsPtr fp);
	void AddRowNames(FldsPtr fp);
	void AddRow(FldsPtr fp);
	void CalcColChars();
	void SetTextEdit();
	void AddTextItem(std_string& sz_text, const char *sz_item, int i_size_item, int i_size_item_max);
	//
	void fill_from_db(ETypeBox eTypeBox, std::vector<std_string>& box_names, char *sz_query, SNameId& name_fields, std::vector<SNameId>* p_list=0, int index_to_set=0); //char *sz_box_name	
	void SetPosByName(ETypeBox eTypeBox, char *sz_box_name, std::vector<SNameId>& list, char *sz_name);
	void SetPosById(ETypeBox eTypeBox, char *sz_box_name, std::vector<SNameId>& list, char *sz_id);
	int GetReadRows() { return m_i_read_rows; }
	bool fill_edit_from_db(char* sz_edit, char* sz_query);
	
};

bool FindInListByName(std::vector<SNameId>& list, char *sz_name, int* p_index);
bool FindInListById(std::vector<SNameId>& list, char *sz_id, int* p_index);

#endif