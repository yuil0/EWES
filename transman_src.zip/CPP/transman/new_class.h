#ifndef _new_h_
#define _new_h_

class CNew
{
	bool m_fInit;
	public:
	CNew();
	~CNew();
};

#endif