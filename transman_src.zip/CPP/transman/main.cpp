#include "main.h"
#include "MSSQL.h"
#include "FormMes.h"
#include "audio_device.h"
#include "MesWnd.h"
#include "car_zone.h"  
#include "ini_file.h"  
#include "BookMarks.h"
#include "login_wnd.h"

const char *csz_file_ms_wins= "C:\\transman\\ms_wins.txt";
const char* csz_log_draw_objects = "C:\\transman\\log_draw_objects.txt";

HINSTANCE g_hInstance;

HWND g_hWndMap;

CWindow gWndMain;

CMSInet gWndMap;

wchar_t g_wz_map_addr[MAX_PATH + 1]=L"";

CMapTimer gMapTimer;

CDrawWnd gDrawWnd;

CControlPanelWnd gControlPanelWnd;

int g_i_user_interface;

bool g_f_bitmap_interface;

bool g_f_log_draw_objects;

win_e::SMonitors gMonitors;


void InitSec();

void Destroy(HWND hwnd)
{
	win_e::ShowSysTray(true);

	TerminateProcessByClass("MicroSIP");

	CloseDestroyWindowByClass("IEFrame");

	win_e::ShowSysTray(true);

	CWindow::TerminateProcessByHWND(g_hWndMap);  //SendMessage(g_hWndMap, WM_DESTROY, 0, 0); ;//gWndHook.Close();

	gDrawWnd.Destroy();

	gMapTimer.Close(); //MesBox(L"Destroy()");

	gControlPanelWnd.Destroy();

	gFormMes.Close();

	gAudioDevice.Close();

	gMesWnd.Destroy();
	
	gCarZone.Close();

	gBookMarks.Close();

	gLoginWnd.Close();

	::CoUninitialize();

	DestroyWindow(hwnd);

	std_string_destroy();

	CloseDestroyWindowByClass("IEFrame");

	g_sGDI_objects.Close();

	win_e::DestroyPenBrush();
}

void DestroyExit()
{
	Destroy();

	Sleep(100);

	ExitProcess(1);

}

void WMClose(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	Destroy(hwnd);
}

void WMDestroy(WPARAM wParam, LPARAM lParam)
{
	ExitProcess(1);
}

void WMSize(WPARAM wParam, LPARAM lParam)
{
	int new_width = lParam & 0xFFFF; //The low - order word of lParam specifies the new width of the client area.	
	int new_height = (lParam >> 2) & 0xFFFF; //The high - order word of lParam specifies the new height of the client area.
}

void WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam) {}

void WM__NCLBUTTONDOWN(HWND hwnd, WPARAM wParam, LPARAM lParam) 
{
	if (wParam==HTCLOSE) {DefWindowProc(hwnd, WM_NCLBUTTONDOWN, wParam, lParam);}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_CLOSE: WMClose(hwnd, wParam, lParam); break;
	case WM_DESTROY: WMDestroy(wParam, lParam); break;
	case WM_SIZE: WMSize(wParam, lParam); break;
	case WM_LBUTTONDOWN: WM__LBUTTONDOWN(wParam, lParam); break;
	case WM_NCLBUTTONDOWN: WM__NCLBUTTONDOWN(hwnd, wParam, lParam); break; //case WM_PAINT: WM__PAINT(hwnd, wParam, lParam); break;
		
	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 1;
}

void ReadIni()
{
	//<q2
	g_i_user_interface = 0;

	CIniFile ini;
	char sz_buf[MAX_PATH + 1];
	if (ini.Get("C:\\transman\\transman.ini", "user_interface", sz_buf, MAX_PATH)) 
	{ g_i_user_interface = atoi(sz_buf); }

	if (ini.Get("c:\\transman\\transman.ini", "bitmap_interface", sz_buf, MAX_PATH))
	{
		g_f_bitmap_interface = atoi(sz_buf);
	}

	if (ini.Get("c:\\transman\\transman.ini", "log_draw_objects", sz_buf, MAX_PATH))
	{
		g_f_log_draw_objects = atoi(sz_buf);
	}

	
	//>q2
}

void CrMainWnd()
{
	unlink(csz_log_draw_objects);

	ReadIni();

	int w = GetSystemMetrics(SM_CXFULLSCREEN);
	int h = GetSystemMetrics(SM_CYFULLSCREEN);

	//<q1 YUIL ��������� ����
	SWindowCreateParam wcp;

	wcp.hInstance = g_hInstance;	
	wcp.wndProc = WindowProc;
	wcp.fVisible = false;

	const int ci_size=10;

	wcp.wsz_name = g_wz_name;
	wcp.w = ci_size; //sm.rc[1].right - sm.rc[1].left;
	wcp.h = ci_size; //sm.rc[1].bottom - sm.rc[1].top;
	wcp.x= -2*ci_size; //sm.rc[1].left;
	wcp.y= -2*ci_size; //sm.rc[1].top;

	if (gWndMain.Create(wcp)==false) {MessageBox(0, L"������ �������� �������� ����", g_sz_app, MB_OK | MB_ICONERROR); return;}
	//>q1
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void Init(HINSTANCE hInstance)
{
	if (FAILED(::CoInitialize(NULL))) 
	{ MessageBox(0, L"FAILED CoInitialize", g_sz_app, 0); return; }

	std_string_init();

	bool f_del_file=true;

	CloseDestroyWindowByClass("IEFrame"); //WindowsToFile(0, "C:\\transman\\explore\\wnds.txt", f_del_file);

	//MinimizeAllWnd();

	g_hInstance=hInstance;

	CrMainWnd();

	InitSec();//
}

void InitSec()
{
	win_e::CreatePenBrush();

	if (g_f_bitmap_interface)
	{
		g_sGDI_objects.Open();
	}

	win_e::SMonitors& sm = gMonitors;
		
	int i_res;
	int err;

	//TerminateProcessByClass("IEFrame");

	if (gWndMap.Open())
	{
		//FindThread();
		//WindowsToFile("C:\\transman\\explore\\wnds.txt");

		/*S_find_child_window_param s_param;
		s_param.sz_class = "TabWindowClass";
		s_param.sz_part_text = "openstreetmap.ru";

		HWND hwnd = find_child_window(s_param); */

		//g_hWndMap = find_window(0, "IEFrame"); 
		
		gWndMap.GetHWND(g_hWndMap);
			
		RECT  rc;

		gMesWnd.Create(g_hInstance, g_sz_app);

		if (g_i_user_interface==0) 
		{ 
			MoveWindow(g_hWndMap, 0, 0, 500, 500, TRUE); 

			win_e::RemoveWndStyle(g_hWndMap, WS_MAXIMIZEBOX);
		} else
		if (g_i_user_interface==1) 
		{ 
			win_e::ShowSysTray(false);

			MoveWindow(g_hWndMap, sm.rc[0].left, sm.rc[0].top, sm.rc[0].right - sm.rc[0].left, sm.rc[0].bottom - sm.rc[0].top, TRUE);

			win_e::RemoveWndStyle(g_hWndMap, WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_SYSMENU); 
				
			gBookMarks.Open();
		}

		bool fVisible = true;

		gDrawWnd.Create(g_hInstance, L"", gWndMain.GetHWND(), (HMENU)1, fVisible);
	}
	else
	{
		gMesWnd.Mes("������ �������� ���� �����"); //MessageBox(gWndMain.GetHWND(), L"1. ������ �������� ���� �����", g_sz_app, MB_OK | MB_ICONERROR);

		return;
	}

	if (g_i_user_interface==0) 
	{
		gControlPanelWnd.Create(g_hInstance, g_sz_app); // , gDrawWnd.GetHWND());

	}

	gMapTimer.Open();

	gFormMes.Open();

	gAudioDevice.Open();			

	gCarZone.Open();	

	CWindow::MouseOp(g_hWndMap);
	
	if (g_i_user_interface==1) 
	{
 	ShowLeftScr(SW_HIDE);

	 ShowRightScr(SW_HIDE);

  gLoginWnd.Open(); 
	}

}

void ShowLeftScr(int cmd_show)
{
	 ShowWindow(g_hWndMap, cmd_show);
		ShowWindow(gDrawWnd.GetHWND(), cmd_show);
}

void ShowRightScr(int cmd_show)
{
	ShowWindow(gBookMarks.GetHWND(), cmd_show);

	ShowWindow(gMesWnd.GetHWND(), cmd_show);
}

void ViewLogicalScreen(ELogicalScreen eScr)
{
	win_e::SMonitors& sm = gMonitors;
	
	int& i_monitor = sm.i_monitor;

	if (eScr == ELS_MAP)
	{
		MoveWindow(g_hWndMap, sm.rc[i_monitor].left, sm.rc[i_monitor].top, sm.rc[i_monitor].right - sm.rc[i_monitor].left, sm.rc[i_monitor].bottom - sm.rc[i_monitor].top, TRUE);

		RECT rc;

		CWindow::GetClientRectAbs(g_hWndMap, rc);

		MoveWindow(g_hWndMap, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, TRUE);

		ShowLeftScr(SW_SHOW);

		ShowRightScr(SW_HIDE);
	}
	else
	if (eScr == ELS_BOOK_MARKS)
	{
		gBookMarks.EventChActive();

		gMesWnd.SetWnd_I2();

		ShowLeftScr(SW_HIDE);

		ShowRightScr(SW_SHOW);
	}
	else
	if (eScr == ELS_VIDEO_WALL)
	{
	}
	
}

void ChLogicalScreen()
{
	if (g_i_user_interface != 1) { return; }

	static ELogicalScreen eScr= ELS_MAP;

	win_e::SMonitors& sm = gMonitors;

	if (sm.i_monitor < 0) { return; }

	ViewLogicalScreen(eScr);

	int i = (int)eScr;
	int i_max = (int)ELS_BOOK_MARKS; // ELS_VIDEO_WALL;

	if (i == i_max) { eScr = (ELogicalScreen)0; }
	else { i++; eScr = (ELogicalScreen)i; }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ReadGlobal()
{
	if (GetKeyState(VK_F1)&0x80)
	{
		if (g_i_user_interface==1) 
		{
		 WindowChShow(g_hWndMap);
		 gDrawWnd.ChShow();
		}
	}else
	if (GetKeyState(VK_F2)&0x80)
	{
		if (g_i_user_interface==1) 
		{
			gBookMarks.ChShow();
		 gMesWnd.ChShow();
		}
	}else
	if (GetKeyState(VK_ESCAPE)&0x80)
	{
		DestroyWindow(g_hWndMap); 
	}
	else
	if (GetKeyState(VK_SCROLL) & 0x80)
	{
		ChLogicalScreen();
	}

	/*
	if (msg.message==WM_KEYDOWN)
	{
		int vk=msg.wParam;

		if (vk==VK_F2) 
		{
			gWndMain.ChShow();
		}
	}
	*/
}

DWORD WINAPI thread_proc(LPVOID lpThreadParameter)
{
	while(1)
	{
		ReadGlobal();

		Sleep(100);
	}
}

void CrThread()
{
	HANDLE h = CreateThread(0, 0, thread_proc, 0, 0, 0 );
}                                                           
//VOID CALLBACK ShowMainWnd_TIMERPROC(HWND, UINT, UINT_PTR, DWORD) {gWndMain.Show(true);}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
int CALLBACK WinMain(
	HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine,
	int       nCmdShow
)
{
	if (win_e::ProcessExists(L"transman.exe"))
	{ MessageBoxA(0, "Process already run/������� ��� �������", "transman.exe", 0); return 1; }
	
	Init(hInstance);

	CrThread();  //SetTimer(gWndMain.GetHWND(), 1, 10000, ShowMainWnd_TIMERPROC);

	MSG msg;
	
	HWND hwnd= 0;

	while (GetMessage(&msg, hwnd, 0, 0)) //
	{	
		
		//if (msg.hwnd==)
		{
			/*static time_t time_prev=0;
			
			time_t time=clock();

			if (time - time_prev > 400)
			{
				gWndMap.GetLocationURL(g_wz_map_addr);

				time_prev = time;
			}*/
		

			//if (f_ret == -1)	{break;}else{}
			//
			
		}

		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

}
