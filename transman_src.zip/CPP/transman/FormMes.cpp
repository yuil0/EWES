#include <memory.h>
#include <time.h>
#include "FormMes.h"  
#include "main.h"  
#include "..\\transman_srv\\time_e.h"  
#include "BookMarks.h"
#include "login_wnd.h"
#include "..\\transman_srv\\str.h"

const int c_form_mes_delta_time = 1;

const char *csz_form_mes_SQL_query_fill = "c:\\transman\\form_mes\\SQL_query_fill.txt";

CFormMes::CFormMes()
{
	m_fInit=false;
	
	memset(this, 0, sizeof(CFormMes));
	
	unlink(csz_form_mes_SQL_query_fill);

	m_fInit=true;
}

CFormMes::~CFormMes()
{
	
}

DWORD WINAPI CFMSSQLThreadProc(LPVOID lpParameter)
{
	CFormMes *p_this = (CFormMes*)lpParameter;

	if (p_this == 0) { return 0; }

	while (1)
	{
		p_this->Exec();

		Sleep(1000);
	}

	return 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool CFormMes::Open()
{
	if (m_fInit == false) { return false; }
	
	CrPenBrush();

	m_l_enabled_fill_list = 1;

	DWORD dThreadId;

	HANDLE h = CreateThread(0, 0, CFMSSQLThreadProc, (LPVOID)this, 0, &dThreadId);

	return h != 0;
}

void CFormMes::Close() { CrPenBrush(); }


void CFormMes_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	char sz[MAX_PATH + 1];
	sprintf(sz,  "CFormMes. ������ MS SQL : %s", sz_text);
	SendMessageA(g_hWndMap, WM_SETTEXT, 0, (LPARAM)sz);
}

void CFormMes_FN_MSSQL_ADD(void *p_param, FldsPtr fp)
{
	CFormMes *p_this = (CFormMes *)p_param;

	if (p_this == 0) { return; }

	p_this->Add(fp);
}

void  CFormMes::Add(FldsPtr fp)
{
	
	_bstr_t bstr_id_ate_3(fp->Item["id_ate_3"]->Value);
	_bstr_t bstr_device_number(fp->Item["device_number"]->Value);
	_bstr_t bstr_stop_name_from(fp->Item["stop_name_from"]->Value);
	_bstr_t bstr_stop_name_to(fp->Item["stop_name_to"]->Value);
	_bstr_t bstr_time_cmd_minute_from (fp->Item["time_cmd_minute_from"]->Value);
	_bstr_t bstr_time_cmd_minute_to (fp->Item["time_cmd_minute_to"]->Value);
	_bstr_t bstr_id_picas_stop_from(fp->Item["id_picas_stop_from"]->Value);
	_bstr_t bstr_id_picas_stop_to(fp->Item["id_picas_stop_to"]->Value);
	_bstr_t bstr_garage_num(fp->Item["garage_num"]->Value);
	_bstr_t bstr_state_num(fp->Item["state_num"]->Value);
	
	/*VARIANT v_id_formalize_message = fp->Item["id_formalize_message"]->Value; //.decVal.Lo32	
	_bstr_t bstr_dt_created(fp->Item["dt_created"]->Value);
	_bstr_t bstr_route_short_name(fp->Item["route_short_name"]->Value);
	_bstr_t bstr_garage_num(fp->Item["garage_num"]->Value);
	_bstr_t bstr_state_num(fp->Item["state_num"]->Value);
	*/

	//<w1
	SFormMesRow o;
	
	
	o.id_ate_3 = (char*)bstr_id_ate_3;
	o.device_number = (char*)bstr_device_number;
	o.stop_name_from = (char*)bstr_stop_name_from;
	o.stop_name_to = (char*)bstr_stop_name_to;
	o.time_cmd_minute_from = (char*)bstr_time_cmd_minute_from;
	o.time_cmd_minute_to = (char*)bstr_time_cmd_minute_to;
	o.id_picas_stop_from = (char*)bstr_id_picas_stop_from;
	o.id_picas_stop_to = (char*)bstr_id_picas_stop_to;
	o.garage_num = (char*)bstr_garage_num;	
	o.state_num = (char*)bstr_state_num;
	
	/*o.id_formalize_message= v_id_formalize_message.decVal.Lo32;
	o.dt_created=(char*)bstr_dt_created;	
	o.route_short_name=(char*)bstr_route_short_name;
	o.garage_num = (char*)bstr_garage_num;
	o.state_num = (char*)bstr_state_num;	
*/

	m_list.push_back(o);
	//>w1
}

void CFormMes::FillList()
{
	if (m_l_enabled_fill_list==0) { return; }

	if (m_list.size()) { return; } //m_list.clear();

	std_string sz_query =
		"SELECT c.id_ate_3\r\n"
		", c.device_number\r\n"
		", (SELECT s.stop_name FROM dbo.picas_stops s WHERE fmo.id_picas_stop_from = s.id_picas_stop) stop_name_from\r\n"
		", (SELECT s.stop_name FROM dbo.picas_stops s WHERE fmo.id_picas_stop_to = s.id_picas_stop) stop_name_to\r\n"
		", fmo.time_cmd_minute_from\r\n"
		", fmo.time_cmd_minute_to\r\n"
		", fmo.id_picas_stop_from\r\n"
		", fmo.id_picas_stop_to\r\n"
		", b.garage_num\r\n"
		", b.state_num\r\n"
		"FROM dbo.form_mes_off fmo, dbo.ate_3 c LEFT JOIN dbo.ate_3_book b ON (b.device_number=c.device_number)\r\n"
		"WHERE fmo.id_ate_3 = c.id_ate_3;";
	
	char *p_query = (char*)sz_query.c_str();

	FILE *fo = fopen(csz_form_mes_SQL_query_fill,"wb");
	if (fo) { fprintf(fo, "%s\r\n", p_query); fclose(fo); }

	
	bool f_exec = MSSQL_Exec(p_query, CFormMes_FN_MSSQL_ADD, CFormMes_FN_MSSQL_MES_ERR, this);  //SELECT TOP 10 id_formalize_message, dt_created, device_number, route_short_name, garage_num, state_num, stop_name_from, time_cmd_minute_from, stop_name_to, time_cmd_minute_to, i_state FROM dbo.formalize_messages WHERE i_state=0

	if (f_exec)
	{
		Fill_ControlPanel_combo();
	}	
}
///////////////////////////////////////////////////////////////////////////////////////////////////
void CFormMes::Exec()
{
	if (gLoginWnd.IsFoundUserInDB() == false) { return; } //YUIL 2017-12-08

	FillList();	

	Paint();
}

bool CFormMes::GetNextRow(int& index, SFormMesRow* p_row)
{
	if (index < 0 || index >= m_list.size()) { return  false; }
	
	p_row = &m_list[index];

	index++;
}

void CFormMes::Fill_ControlPanel_combo()
{
	HWND hwnd;

	CWinCtrl* p_ctrls;

	if (g_i_user_interface == 0)
	{
		CControlPanelWnd& cp = gControlPanelWnd;

		p_ctrls = &cp.GetCtrls();

		hwnd = cp.GetHWND();
	}
	else
	if (g_i_user_interface == 1)
	{
		p_ctrls = &gBookMarks.GetMapCtrls();

		hwnd = gBookMarks.GetHWND();
	}
	else
	{ return; }

	if (hwnd == 0 || p_ctrls == 0) { return; }

	int index = 0;

	SZone o;

	p_ctrls->SendMes("combo_form_mes", CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);

	char sz_row[MAX_PATH + 1];

	for (int i=0; i<m_list.size(); i++)
	{
		SFormMesRow& row = m_list[i];
		
		if (g_i_user_interface == 0) { sprintf(sz_row, "%s", row.device_number.c_str()); }  //sprintf(sz_row, "%d %s", row.id_formalize_message, row.device_number.c_str());  //sprintf(sz_row, "%d %s %s", row.id_formalize_message, row.dt_created.c_str(), row.device_number.c_str());
		else
		if (g_i_user_interface == 1)
		{
			sprintf(sz_row, "%s %s", row.device_number.c_str(), row.stop_name_from.c_str());
		}

		p_ctrls->SendMes("combo_form_mes", CB_ADDSTRING, (WPARAM)0, (LPARAM)sz_row);
	}

	p_ctrls->SendMes("combo_form_mes", CB_SETCURSEL, (WPARAM)0, (LPARAM)0);
	
	p_ctrls->SendMes("combo_form_mes", WM_SETFOCUS, (WPARAM)0, (LPARAM)0); //p_ctrls->SendMes("static_text", WM_SETTEXT, (WPARAM)0, (LPARAM)GetRowLongText(0, sz_row));
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
void CFormMes::Fill_ControlPanel_combo_device()
//
{
	if (g_i_user_interface != 1) { return; }
	
	CWinCtrl* p_ctrls = &gBookMarks.GetMapCtrls(); //HWND hwnd = gBookMarks.GetHWND();

	if (p_ctrls == 0) { return; } //hwnd == 0 || 

	std::vector<std_string> uniq_list; //SFind<std_string> sFind; //sFind.FillUnique(std::vector<Type>& list, std::vector<Type>& uniq_list)

	//1.  get  uniq
	for (int i = 0; i<m_list.size(); i++)
	{
		SFormMesRow& row = m_list[i];

		bool fFound = FindInStrList(uniq_list, (char*)row.device_number.c_str()); //sFind.Find(uniq_list, row.device_number);

		if (fFound == false)
		{
			uniq_list.push_back(row.device_number);
		}		
	}
	
	//2.  fill
	char sz_val[MAX_PATH + 1];

	char* sz_combo = "combo_from_mes_car";

	p_ctrls->SendMes(sz_combo, CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);

	for (int i = 0; i<uniq_list.size(); i++)
	{
		strcpy(sz_val, uniq_list[i].c_str());

		p_ctrls->SendMes(sz_combo, CB_ADDSTRING, (WPARAM)0, (LPARAM)sz_val);
	}

	p_ctrls->SendMes(sz_combo, CB_SETCURSEL, (WPARAM)0, (LPARAM)0);
}



void Fill_ControlPanel_combo_device_db_ADD(void *p_param, FldsPtr fp)
{
	CFormMes *p_this = (CFormMes *)p_param;

	if (p_this) { p_this->Fill_ControlPanel_combo_device_db(fp); }
}

void CFormMes::Fill_ControlPanel_combo_device_db(FldsPtr fp)
{
	CWinCtrl* p_ctrls = &gBookMarks.GetMapCtrls();

	if (p_ctrls == 0) { return; }

	_bstr_t bstr_device_number(fp->Item["device_number"]->Value);

	char* sz_combo = "combo_from_mes_car";

	p_ctrls->SendMes(sz_combo, CB_ADDSTRING, (WPARAM)0, (LPARAM)((char*)bstr_device_number));
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
void CFormMes::Fill_ControlPanel_combo_device_db()
//
{
	char* sz_combo = "combo_from_mes_car";

	CWinCtrl* p_ctrls = &gBookMarks.GetMapCtrls(); 

	if (p_ctrls == 0) { return; } 

	p_ctrls->SendMes(sz_combo, CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);

	bool f_exec = MSSQL_Exec("SELECT device_number FROM dbo.ate_3", Fill_ControlPanel_combo_device_db_ADD, CFormMes_FN_MSSQL_MES_ERR, this); //if (f_exec) {}

	if (f_exec)
	{
		p_ctrls->SendMes(sz_combo, CB_SETCURSEL, (WPARAM)0, (LPARAM)0);
	}
}

/*char* CFormMes::GetRowLongText(int index, char *sz_buf)
{
	if (index < 0 || index >= m_list.size()) { return  0; }

	SFormMesRow& r = m_list[index];

	sprintf(sz_buf, "%d: �������: %s, ���_�: %s, ���_�: %s, ��: %s, ���_��: %d, ���: %s, ���_���: %d", r.id_formalize_message, r.route_short_name.c_str(), r.garage_num.c_str(), r.state_num.c_str(), r.stop_name_from.c_str(), r.time_cmd_minute_from, r.stop_name_to.c_str(), r.time_cmd_minute_to);

	return sz_buf;
}

bool CFormMes::Send(int index)
{
	if (index < 0 || index >= m_list.size()) { return false; }

	SFormMesRow& r = m_list[index];

	//1. ������ ����� ���������
	char sz_val[MAX_PATH + 1];

	std_string sz_buf = "�������� ������������� �������� �� �������� ";
	sz_buf.append(r.route_short_name.c_str());
	sz_buf.append(" ���. � '");
	sz_buf.append(r.garage_num.c_str());
	sz_buf.append("' ���. � '");
	sz_buf.append(r.state_num.c_str());
	sz_buf.append("' �� ��������� ����������� '");
	sz_buf.append(r.stop_name_from.c_str());
	sz_buf.append("' ������ ����� ");
	itoa(r.time_cmd_minute_from, sz_val, 10); sz_buf.append(sz_val);
	sz_buf.append(", �� ��������� �������� '");
	sz_buf.append(r.stop_name_to.c_str());
	sz_buf.append("' ������ ����� ");
	itoa(r.time_cmd_minute_to, sz_val, 10); sz_buf.append(sz_val);
	sz_buf.append(". �� ����������� ��������� ���������� �� ���������� ��������");

	FILE  *fo = fopen("C:\\transman\\form_mes.txt","ab");
	if (fo)
	{
		struct tm tm;

		time_e::GetCurLocalDateTime(tm);

		fprintf(fo,"%04d-%02d-%02d_%02d:%02d:%02d: %s%c%c", tm.tm_year, tm.tm_mon, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec, sz_buf.c_str(),13,10);

		fclose(fo);
	} //sprintf(sz_buf, "�������� ������������� �������� �� �������� %s ���. �: %s ���. �: %s �� ��������� ����������� '%s' ������ ����� %d, �� ��������� �������� '%s' ������ ����� %d. �� ����������� ��������� ���������� �� ���������� ��������", r.route_short_name.c_str(), r.garage_num.c_str(), r.state_num.c_str(), r.stop_name_from.c_str(), r.time_cmd_minute_from, r.stop_name_to.c_str(), r.time_cmd_minute_to);

	//2. �������� � ��  ��� �������	
	sz_buf = "UPDATE dbo.formalize_messages SET i_state=1 WHERE id_formalize_message=";

	itoa(r.id_formalize_message, sz_val, 10); sz_buf.append(sz_val);	

	FN_MSSQL_ADD fn_mssql_add = 0;

	bool f_exec = MSSQL_Exec((char*)sz_buf.c_str(), fn_mssql_add, CFormMes_FN_MSSQL_MES_ERR, this);

	//3.
	DelRow(index); //m_list.clear();FillList();

	return true;
}

void CFormMes::DelRow(int index)
{
	if (index < 0 || index >= m_list.size()) { return; }

	InterlockedExchange(&m_l_enabled_fill_list, 0); //YUIL 2017-09-21 ��������� FillList();

	std::vector<SFormMesRow> copy_list;

	for (int i=0; i<m_list.size(); i++)
	{
		if (i!= index) { copy_list.push_back(m_list[i]); }		
	}

	//m_list.clear();
	m_list = copy_list;


	InterlockedExchange(&m_l_enabled_fill_list, 1); //YUIL 2017-09-21 �������� FillList();

	//YUIL 2017-09-21  : m_list.erase(m_list.begin() + index, m_list.begin() + index + 1);  : ������ : offset out of range

	HWND hwnd;

	CWinCtrl* p_ctrls;

	if (g_i_user_interface == 0)
	{
		CControlPanelWnd& cp = gControlPanelWnd;

		p_ctrls = &cp.GetCtrls();

		hwnd = cp.GetHWND();
	}
	else
	if (g_i_user_interface == 1)
	{
		p_ctrls = &gBookMarks.GetMapCtrls();

		hwnd = gBookMarks.GetHWND();
	}
	else
	{ return; }

	if (hwnd == 0 || p_ctrls == 0) { return; }

	p_ctrls->SendMes("combo_form_mes", CB_DELETESTRING, (WPARAM)index, (LPARAM)0);

	p_ctrls->SendMes("combo_form_mes", CB_SETCURSEL, (WPARAM)0, (LPARAM)0);

	p_ctrls->SendMes("combo_form_mes", WM_SETFOCUS, (WPARAM)0, (LPARAM)0);
	
	char sz_row[MAX_PATH + 1];

	p_ctrls->SendMes("static_text", WM_SETTEXT, (WPARAM)0, (LPARAM)GetRowLongText(0, sz_row));
	
}
*/

void CFormMes::CrPenBrush()
{
	long color = 0x0000FF;
	long step_color = color / ci_max_red_steps/2;

	for (int i = 0; i < ci_max_red_steps; i++)
	{
		m_pen[i] = CreatePen(PS_SOLID, 0, color);

		m_brush[i] = CreateSolidBrush(color);

		color -= step_color;
	}

	m_i_red_step=0;
}

void CFormMes::DelPenBrush()
{
	for (int i = 0; i < ci_max_red_steps; i++)
	{
		DeleteObject(m_pen[i]);

		DeleteObject(m_brush[i]);
	}
}

void CFormMes::PaintOp(HWND hwnd, RECT rc)
{
	HDC hdc = GetDC(hwnd);

	SelectObject(hdc, m_pen[m_i_red_step]);
	SelectObject(hdc, m_brush[m_i_red_step]);

	Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

	ReleaseDC(hwnd, hdc);
}

void CFormMes::Paint()
{
	if (m_list.size() == 0) { return; }	

	SCtrl *p_ctrl;
	
	HWND hwnd;
	
	CWinCtrl* p_ctrls;

	RECT rc;

	if (g_i_user_interface == 0)
	{
		CControlPanelWnd& cp = gControlPanelWnd;

		p_ctrls = &cp.GetCtrls();

	 hwnd = cp.GetHWND();
	}else
	if (g_i_user_interface == 1)
	{
		return;

		/*if (gBookMarks.GetActive() != EBMN_MAP) { return; }		

		p_ctrls = &gBookMarks.GetMapCtrls();		

		hwnd = gBookMarks.GetHWND();
		*/
	}
	else
	{return;}

	if (p_ctrls->Find("static_form_mes", &p_ctrl) == false) { return; }

	if (g_i_user_interface == 0)
	{
		rc.left = 0;
		rc.top = p_ctrl->y;
		rc.right = cl_panel_no_expand_w;
		rc.bottom = p_ctrl->y + p_ctrl->h;
	}
	else
	if (g_i_user_interface == 1)
	{
		rc.left = 0;
		rc.top = p_ctrl->y;
		rc.right = p_ctrl->x; // GetMaxX();
		rc.bottom = p_ctrl->GetMaxY();
	}
	else
	{return;}

	PaintOp(hwnd, rc);

	p_ctrls->Update();
	UpdateWindow(hwnd);

	IncRedStep();
}

void CFormMes::IncRedStep()
{
	time_t t_cur = time(0);

	static time_t t_prev= 0;

	if (t_prev==0 || t_cur - t_prev > c_form_mes_delta_time)
	{
		if (t_prev)
		{
			if (m_i_red_step < ci_max_red_steps - 1)
			{
				m_i_red_step++;
			}
			else { m_i_red_step = 0; }
		}

		t_prev = t_cur;
	}	
}


CFormMes gFormMes;