#ifndef _wnd_hook_h_
#define _wnd_hook_h_

#include <windows.h>

class CWndHook
{
	bool m_fInit;

	HHOOK m_hHook;

	public:

	CWndHook();

	~CWndHook();

	bool Open();

	bool Close();
};

#endif