//D:\users\yuil\JOB\EWES\CPP\transman\formula_latlng_to_point.cpp
	// Leaflet::CRS<Leaflet::SphericalMercator> crs;
	
	LatLng latlng;
	
 double zoom;

	double d = M_PI / 180;

	double dMax = MAX_LATITUDE;
	
	double lat = max( min(dMax, latlng.lat), - dMax);

	double dSin = sin(lat * d);

	Point projectedPoint( R * latlng.lng * d, R * log((1 + dSin) / (1 - dSin)) / 2);		

	double dScale = 256 * pow(2, zoom);

	double t_scale = 0.5 / (M_PI * R);
	
	double _a = t_scale;
	
	double _b = 0.5;
	
	double _c = - t_scale;
	
	double _d = 0.5;		

	if (dScale == 0) { dScale = 1; }   //scale = scale || 1;

	double xNew = dScale * (_a * projectedPoint.x + _b);

	double yNew = dScale * (_c * projectedPoint.y + _d);
