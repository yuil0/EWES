#include <memory.h>
#include <time.h>
#include "new_thread.h"  //#include "..\\transman\\mssql.h"

C_new_thread::C_new_thread()
{
	m_fInit=false;
	
	memset(this, 0, sizeof(C_new_thread));
	
	m_fInit=true;
}

C_new_thread::~C_new_thread()
{
	
}

DWORD WINAPI CFMSSQLThreadProc(LPVOID lpParameter)
{
	C_new_thread *p_this = (C_new_thread*)lpParameter;

	if (p_this == 0) { return 0; }

	while (1)
	{
		if (p_this->Exec()) { }

		Sleep(200);
	}

	return 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool C_new_thread::Open()
{
	if (m_fInit == false) { return false; }

	DWORD dThreadId;

	HANDLE h = CreateThread(0, 0, CFMSSQLThreadProc, (LPVOID)this, 0, &dThreadId);

	return h != 0;
}

/*void SMSSQLAgentRow::Clear()
{                       //time_prev_sec = 0;
	f_enabled=false;
	sz_query.clear();
}*/

/*void CMSSQLAgent_FN_MSSQL_MES_ERR(void *p_param, char *sz_text)
{
	gMesLog.Mes("CMSSQLAgent. ������ MS SQL : %s", sz_text);
}*/

///////////////////////////////////////////////////////////////////////////////////////////////////
bool C_new_thread::Exec()
{
	/*
	for (int i = 0; i < m_list.size(); i++)
	{
		SMSSQLAgentRow& row = m_list[i]; //g_time_mili_sec=time(0); //YUIL 2017-09-21 ��� ����� � ���� ���.int time_sec = g_time_mili_sec / 1000; //YUIL 2017-09-21 ��� ����� � ���.  //if (row.time_prev_sec == 0 || time_sec - row.time_prev_sec > row.pause_sec){row.time_prev_sec = time_sec;}

		if (row.IsEnabled())
		{
			FN_MSSQL_ADD fn_add = 0;    //gMesLog.Mes("C_new_thread. Start SQL query : %s", row.sz_query.c_str());

			bool f_exec = MSSQL_Exec((char*)row.sz_query.c_str(), fn_add, C_new_thread_FN_MSSQL_MES_ERR, this);
		}

		Sleep(row.pause_sec*1000);
	}*/
	
	return true;
}



C_new_thread g_new_thread;