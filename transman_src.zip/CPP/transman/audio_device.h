#ifndef _audio_device_h_
#define _naudio_device_h_

#include "..\\transman_srv\\std_str.h"
#include "wave_header.h"

#pragma comment(lib, "winmm.lib")

class CAudioDevice
{
	bool m_fInit;
	
	std_string device_number;		

	bool m_fInputInit;

	HWAVEIN m_h_in;

	WAVEHDR m_h_buf;

	void ReadBuf();

	void CleanBuf();

	void ReadBufOp();

	WAVEFORMATEX m_wfx;

	void fill_m_wfx();

	void fill_wav_file(char *sz_file);

	void FillWaveHeader(SWaveHeader& hdr);

	void cr_wav_file(SWaveHeader& hdr);

	void SaveToDB(SWaveHeader& hdr);

	void fill_wav_file_sql_binary(std_string& wav_file, char* p_data, int len_data);

	public:
	bool Open();
	void Close();
	void SetDevice(char* sz_device_number_new) { device_number= sz_device_number_new; }
	const char * GetDevice() { return device_number.c_str(); }
	bool IsDevice() { return device_number.size()!=0; }
	void ClearDevice() { device_number.clear(); }
	bool StartWrite();
	void FinWrite();
	void Write();
	void MesProc(UINT u_mes, WPARAM wparam, LPARAM lparam);
	void ErrMes(UINT u_res);
};

extern CAudioDevice gAudioDevice;

#endif