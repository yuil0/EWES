#include <memory.h>
#include "main.h"
#include "rep.h"

#include "BookMarks.h"
#include "login_wnd.h"
#include "MesWnd.h"
#include <commctrl.h>
#include "..\\transman_srv\\time_e.h"
#include "win_e.h"

const int cl_rep_ident_from_left=5;
const int cl_rep_quantity = 10;

CWinCtrl g_ctrls_rep;

void CRep_FN_MSSQL_MES_ERR(void *p_param, char *sz_text)
{
	gMesWnd.Mes("CRep. ������ MS SQL : %s", sz_text);
}

CRep::CRep() {}

CRep::~CRep() {}

bool CRep::Open(HINSTANCE hInstance, HWND hwndParent, int w, int h)
{
	memset(this, 0, sizeof(CRep)); //m_hwndParent = hwndParent;

	m_wnd_size.x= w; m_wnd_size.y= h;
	
	cr_m_gdi_obj(); 

	m_gpb.hbrush= CreateSolidBrush(0xDED9B5); //������� �������� R-181 G-217 B-222=0xDED9B5;
	m_gpb.hpen= CreatePen(PS_SOLID, 0, 0xDED9B5); //������� �������� R-181 G-217 B-222=0xDED9B5;
	
	m_hInstance = hInstance;
	m_hwndParent = hwndParent;

	SBookMarksParams& bm_params = gBookMarks.GetParams();

	//<
	int y = bm_params.i_height + cl_chat_ident_from_top;
	RECT rc = { cl_rep_ident_from_left, bm_params.i_height + cl_chat_ident_from_top, gMonitors.rc[1].right - gMonitors.rc[1].left, y + 22 }; //cl_rep_ident_from_left
	int i_ident_betw_new = 6;
	m_row_but_reps.Open("����� ", rc, i_ident_betw_new, cl_rep_quantity, m_i_rep);
	CallPaint();
	//>                       //CrControls(); 

	m_fInit=true;

	return m_fInit;
}

void CRep::Close()
{
	DeleteObject(m_gpb.hbrush);
	DeleteObject(m_gpb.hpen);

	m_row_but_reps.Close();

	del_m_gdi_obj(); //m_ctrls.Destroy();

	g_ctrls_rep.Destroy(); //for (int i=0; i<m_list_ctrls.size(); i++) { m_list_ctrls[i].ctrls.Destroy(); }
}


void CRep::cr_m_gdi_obj()
{
	m_gdi_obj[ERGDIO_PEN_DEVIDER]=CreatePen(PS_SOLID, 0, 0x0);
	m_gdi_obj[ERGDIO_BRUSH_WHITE]=CreateSolidBrush(0xFFFFFF);
	m_gdi_obj[ERGDIO_PEN_WHITE]=CreatePen(PS_SOLID, 0, 0xFFFFFF);
	
}

void CRep::del_m_gdi_obj()
{
	for (int i=0; i<(int)ERGDIO_QUANTITY; i++)
	{
		DeleteObject(m_gdi_obj[i]);
	}
}

void CRep::Tab()
{
	//m_ctrls.NextFocusActive();
}

/*void CRep::CrControls()
{
	SWinCtrlParam wcp;
	wcp.Clear();
	wcp.rowMax = 5;
	wcp.colMax = 5;
	wcp.hInstance = m_hInstance;
	wcp.hwndParent = m_hwndParent;
	wcp.wCtrl = 70;
	wcp.hCtrl = 22;
	wcp.ident = 5;
	wcp.xOrigin = cl_rep_ident_from_left;
	wcp.yOrigin = m_params.i_height + cl_chat_ident_from_top; //wcp.fHide=true;
	m_ctrls.Init(wcp);

	CrButReps(); //int i_start_id = m_ctrls.GetSize();

	
	m_ctrls.Update(); //m_ctrls.SetFocusActive();
}*/

/*void CRep::AddCtrls(ECtrlsReps eCtrlsReps, int& i_start_id)
{
	if (eCtrlsReps==ECR_0_1_2)
	{
		SRepCtrls o; 
	
		cr_ctrls_rep(o.ctrls, ECR_0_1_2, i_start_id);
		o.add_i_rep(0);
		o.add_i_rep(1);
		o.add_i_rep(2);
		m_list_ctrls.push_back(o);	
	}else
	if (eCtrlsReps==ECR_3)
	{
		SRepCtrls o; 
		cr_ctrls_rep(o.ctrls, ECR_3, i_start_id);
		o.add_i_rep(3);
		m_list_ctrls.push_back(o);	
	}else
	if (eCtrlsReps==ECR_4)
	{
		SRepCtrls o; 
		cr_ctrls_rep(o.ctrls, ECR_4, i_start_id);
		o.add_i_rep(4);
		m_list_ctrls.push_back(o);	
	}
}

void CRep::CrButReps()
{
	SCtrl ctrl;
	std_string ctrl_name;
	std_string ctrl_text;
	char sz_val[10+1];

	for (int i=0; i < cl_rep_quantity; i++)
	{
		itoa(i+1, sz_val, 10); 

		ctrl_name= "but_rep_"; ctrl_name.append(sz_val);
		ctrl_text= "����� "; ctrl_text.append(sz_val);

		//if (i) {m_ctrls.NewRow();}

		ctrl.Clear();
		ctrl.name = ctrl_name.c_str();
		ctrl.classWnd = "button";
		ctrl.textWnd = ctrl_text.c_str();
		ctrl.mul_w = 2.5;
		ctrl.styleAdd = BS_CENTER | BS_AUTORADIOBUTTON | WS_DLGFRAME;
		m_ctrls.Add(ctrl);		
	}
}*/

void CRep::StartFill()
{
}

/*bool SRepCtrls::find_i_rep(int i_rep)
{
	int q = list_i_rep.size();

	bool fFound=false;

	for (int i=0; fFound==false && i<q; i++)
	{
		if (list_i_rep[i]==i_rep) { fFound=true; }
	}

	return fFound;
}*/

void CRep::CallPaint()
{
	if (!m_hwndParent) { return; }

	HDC hdc = GetDC(m_hwndParent);

	Paint(hdc);

	ReleaseDC(m_hwndParent, hdc);
}

void CRep::Show(bool fShow)
{                                        //m_ctrls.ShowAllUpdate(fShow);	
	if (fShow) { CallPaint(); }

	g_ctrls_rep.ShowAllUpdate(fShow);


	/*if (fShow)
	{
		for (int i=0; i<m_list_ctrls.size(); i++) 
		{
			SRepCtrls& o = m_list_ctrls[i];

			bool f_found = o.find_i_rep(m_i_rep);

			o.ctrls.ShowAllUpdate(f_found);
		}
	} 
	else
	{
		for (int i=0; i<m_list_ctrls.size(); i++)  { m_list_ctrls[i].ctrls.ShowAllUpdate(false); }
	}*/
}

/*bool CRep::find_m_ctrls_by_i_rep(int i_rep, SRepCtrls* *pRepCtrls)
{
	bool fFound=false;

	for (int i=0; fFound==false && i<m_list_ctrls.size(); i++)
	{
		SRepCtrls& o= m_list_ctrls[i];

		if (o.find_i_rep(i_rep)) { fFound=true; if (pRepCtrls) {*pRepCtrls=&o;} }
	}

	return fFound;
}*/

void CRep::OnCmd(int id, int notify)
{
	SCtrl* p_ctrl;
	bool fFound = false;

	/*

	if (m_ctrls.Find(id, &p_ctrl))
	{
		char sz_val[10+1];

		fFound=false;

		for (int i=0; fFound==false && i<cl_rep_quantity; i++)
		{
			std_string sz_name= "but_rep_"; itoa(i+1, sz_val, 10); sz_name.append(sz_val);

			if (p_ctrl->name == sz_name) 
			{ 
				gBookMarks.CloseDestroyBrowserWnd();

				but_rep(i); 

				fFound=true; 
			}
		}
		m_ctrls.Update();
	}

	if (fFound) { return; }  //bool fFoundRepCtrls = find_m_ctrls_by_i_rep(m_i_rep, &pRepCtrls); if (fFoundRepCtrls) {CWinCtrl& ctrls = pRepCtrls->ctrls;
	*/

	if (g_ctrls_rep.Find(id, &p_ctrl))
	{
		fFound = true;

		gControlPanelWnd.set_p_ctrls(&g_ctrls_rep);

		gControlPanelWnd.WM__COMMAND(id, notify, m_i_rep); //gControlPanelWnd.SetWndBrowserTop();

		g_ctrls_rep.Update();		
	}  //}

}

void CRep::but_rep()
{
	ECtrlsReps eCtrlsReps;

	if (m_i_rep == 0 || m_i_rep == 1 || m_i_rep == 2) { eCtrlsReps = ECR_0_1_2; } else
 if (m_i_rep == 3) { eCtrlsReps = ECR_3; } else
	if (m_i_rep == 4) { eCtrlsReps = ECR_4; } else
	if (m_i_rep == 5) { eCtrlsReps = ECR_5; } else
	if (m_i_rep == 6) { eCtrlsReps = ECR_6; } else
 if (m_i_rep == 7) { eCtrlsReps = ECR_7; } else
	if (m_i_rep == 8) { eCtrlsReps = ECR_8; } else
	if (m_i_rep == 9) { eCtrlsReps = ECR_9; } else
	{}

	cr_ctrls_rep(eCtrlsReps);

	gControlPanelWnd.set_p_ctrls(&(g_ctrls_rep));

	gControlPanelWnd.combo_rep_op(m_i_rep);

	Show(true);  /*SRepCtrls *pRepCtrls; bool fFoundCtrlsRep = find_m_ctrls_by_i_rep(m_i_rep, &pRepCtrls);if (fFoundCtrlsRep){}*/

}

void CRep::PaintDevider(HDC hdc, int x)
{
	SBookMarksParams& bm_params = gBookMarks.GetParams();

	//<q1 ctrls devider r
	int y = bm_params.i_height + cl_chat_ident_from_top;
	int h = gMonitors.rc[1].bottom - cl_mes_wnd_h- 50;

	SelectObject(hdc, m_gdi_obj[ERGDIO_PEN_DEVIDER]);

	MoveToEx(hdc, x, y, 0); LineTo(hdc, x, y + h);
	//>q1
}

void CRep::Paint(HDC hdc)
{	
	m_row_but_reps.Draw(hdc, &m_gpb);

	//SCtrl *pCtrl; if (m_ctrls.Find("but_rep_10", &pCtrl)) { PaintDevider(hdc, pCtrl->GetMaxX() + 10); }

	/*
	//<q1
	RECT rc;
	rc.left = m_ctrls.GetStatMaxX() + 2*ci_ident;
	rc.top = m_params.i_height + 2*ci_ident;
	rc.right =  m_wnd_size.x - 2*ci_ident; //m_ctrls_r.GetStatMinX() - ci_ident;  //m_wnd_size.x
	rc.bottom = m_wnd_size.y - 2*ci_ident;

	HDC hMem = CreateCompatibleDC(hdc);
	int w_rc= rc.right - rc.left;
	int h_rc= rc.bottom - rc.top;

	HBITMAP memBM = CreateCompatibleBitmap(hdc, w_rc, h_rc);

	SelectObject(hMem, memBM);
	
	SelectObject(hMem, m_gdi_obj[ERGDIO_BRUSH_WHITE]);
	SelectObject(hMem, m_gdi_obj[ERGDIO_PEN_WHITE]);
	Rectangle(hMem, 0, 0, w_rc, h_rc);	

	BitBlt(hdc, rc.left, rc.top, w_rc, h_rc, hMem, 0, 0, SRCCOPY);
	//>q1

	DeleteObject(memBM);
	DeleteObject(hMem);	 */

}

/*int CRep::GetButReptMaxY()
{
 SCtrl *pCtrl; 
	
	if (m_ctrls.Find("but_rep_10", &pCtrl)) { return pCtrl->GetMaxY() + 20; }

	return m_wnd_size.y;
}

int CRep::GetBottom()
{
	return m_f_show_rep==false ? m_wnd_size.y : GetButReptMaxY();	
} */


/*void CRep_fill_dt_rep_date_add(void *p_param, FldsPtr fp)
{
	CRep *p_this = (CRep*)p_param;

	if (p_this) { p_this->fill_dt_rep_date_add(fp); }
}

void CRep::fill_dt_rep_date_add(FldsPtr fp)
{
	_bstr_t bstr_dt(fp->Item["dt"]->Value);

	g_ctrls_rep.SendMes((char*)m_dt_rep_date.c_str(), CB_ADDSTRING, (WPARAM)0, (LPARAM)(char*)bstr_dt);
}*/

void CRep_SUBTRACT_DAY_FUNC(void* p_param, date_time::SDate& date)
{
	CRep::S_fill_dt_rep_date_param* p= (CRep::S_fill_dt_rep_date_param*)p_param;

	if (p== 0) {return;}

	p->p_rep->subtract_day_func(date, p);
}

void CRep::subtract_day_func(date_time::SDate& date, CRep::S_fill_dt_rep_date_param* p_param)
{
	char sz_val[MAX_PATH + 1] = {0};

	sprintf(sz_val, "%04d-%02d-%02dT23:59:59.997", date.year, date.month, date.day);

	p_param->p_ctrls->SendMes((char*)p_param->name.c_str(), CB_ADDSTRING, (WPARAM)0, (LPARAM)sz_val);
}

void CRep::fill_dt_rep_date(char *sz_name, CWinCtrl *p_ctrls_new)
{
	CWinCtrl *p_ctrls = p_ctrls_new ? p_ctrls_new : &g_ctrls_rep;

	p_ctrls->SendMes(sz_name, CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);  //m_dt_rep_date = sz_name;

	struct tm tm;

	time_e::GetCurLocalDateTime(tm);

	date_time::SDate date;

	date.year = tm.tm_year;
	date.month = tm.tm_mon;
	date.day = tm.tm_mday;

	int nDays = 31 * 3;
	
	S_fill_dt_rep_date_param s_param;
	s_param.name = sz_name;
	s_param.p_ctrls = p_ctrls;
	s_param.p_rep = this;

	date_time::SubtractDays(date, nDays, &s_param, CRep_SUBTRACT_DAY_FUNC);

	p_ctrls->SendMes(sz_name, CB_SETCURSEL, (WPARAM)0, (LPARAM)0);
}


//void CRep::cr_ctrls_rep(CWinCtrl& ctrls, ECtrlsReps eCtrlsReps, int& i_start_id)
void CRep::cr_ctrls_rep(ECtrlsReps eCtrlsReps)
{
	int i_start_id = 1; // m_ctrls.GetSize();
	
	CWinCtrl& ctrls = g_ctrls_rep;

	ctrls.Destroy();

	SBookMarksParams& bm_params = gBookMarks.GetParams();

	SWinCtrlParam wcp;
	wcp.Clear();
	wcp.hInstance = m_hInstance;
	wcp.hwndParent = m_hwndParent;
	wcp.wCtrl = 70;
	wcp.hCtrl = 22;
	wcp.ident = 5;
	wcp.xOrigin = cl_rep_ident_from_left;
	wcp.yOrigin = bm_params.i_height + cl_chat_ident_from_top; //wcp.fHide=true;
	wcp.i_start_id= i_start_id;
	ctrls.Init(wcp);

	SCtrl ctrl;

	if (eCtrlsReps==ECR_0_1_2)
	{
		int i_combo_mul_w=5;

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_stop";
		ctrl.classWnd = "static";
		ctrl.textWnd = "���������";
		ctrl.mul_w = 2;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_stop";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWN | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_hour";
		ctrl.classWnd = "static";
		ctrl.textWnd = "���";
		ctrl.mul_w = 2;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_hour"; //fill_combo_rep_hour
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_route";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�������";
		ctrl.mul_w = 2;
		ctrl.mul_h = 1;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_route";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWN | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

	 CChat::Ctrls_set_origin(ctrls, 2,  9); 
		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_mode";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�����";
		ctrl.mul_w = 0.6;
		ctrl.mul_h = 1;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_mode";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 1.98;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_date";
		ctrl.classWnd = "static";
		ctrl.textWnd = "����";
		ctrl.mul_w = 0.8;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "check_rep_date";
		ctrl.classWnd = "button";
		ctrl.mul_w = 0.2;
		ctrl.styleAdd = BS_CHECKBOX;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "dt_rep_date"; 
		ctrl.classWnd = "combobox"; // "SysDateTimePick32"; //DATETIMEPICK_CLASSA
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;// | DTS_SHOWNONE;
		ctrl.mul_w = 1.54;
		ctrl.mul_h = 6; // 1.2;
		ctrls.Add(ctrl);

		CChat::Ctrls_set_origin(ctrls, 4,  9); 
		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "but_rep";
		ctrl.classWnd = "button";
		ctrl.textWnd = "��������"; 
		ctrl.mul_w = 2.3;
		ctrls.Add(ctrl);
		
		fill_dt_rep_date("dt_rep_date");
		gControlPanelWnd.set_p_ctrls(&ctrls);
		gControlPanelWnd.fill_combo_rep_stop();
		gControlPanelWnd.fill_combo_rep_route();		
		
	}else
	if (eCtrlsReps==ECR_3)
	{
		int i_combo_mul_w=5;

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_stop";
		ctrl.classWnd = "static";
		ctrl.textWnd = "���������";
		ctrl.mul_w = 1.6;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_stop";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWN | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_area";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�����";
		ctrl.mul_w = 1.6;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_area";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 10;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_street";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�����";
		ctrl.mul_w = 1.6;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_street";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

	 CChat::Ctrls_set_origin(ctrls, 2,  9); 
		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_mode";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�����";
		ctrl.mul_w = 0.6;
		ctrl.mul_h = 1;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_mode";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 1.98;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		CChat::Ctrls_set_origin(ctrls, 3,  9); 
		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "but_rep";
		ctrl.classWnd = "button";
		ctrl.textWnd = "��������"; 
		ctrl.mul_w = 2.3;
		ctrls.Add(ctrl);
		

		gControlPanelWnd.set_p_ctrls(&ctrls);
		gControlPanelWnd.fill_combo_rep_stop();
	}else
	if (eCtrlsReps==ECR_4)
	{
		int i_combo_mul_w=3;

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_mode";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�����";
		ctrl.mul_w = 1.6;
		ctrl.mul_h = 1;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_mode";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_route";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�������";
		ctrl.mul_w = 1.6;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_route";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWN | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_shape";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�����������";
		ctrl.mul_w = 1.6;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_shape";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		CChat::Ctrls_set_origin(ctrls, 2,  14); 
		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_date";
		ctrl.classWnd = "static";
		ctrl.textWnd = "����";
		ctrl.mul_w = 3;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "check_rep_date";
		ctrl.classWnd = "button";
		ctrl.mul_w = 0.2;
		ctrl.styleAdd = BS_CHECKBOX;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "dt_rep_date"; 
		ctrl.classWnd = "SysDateTimePick32"; 
		ctrl.styleAdd = WS_BORDER;
		ctrl.mul_w = 1.54;
		ctrl.mul_h = 1.2;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_shape_stop_from";
		ctrl.classWnd = "static";
		ctrl.textWnd = "��������� �������";
		ctrl.mul_w = 3;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_shape_stop_from";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 3;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_shape_stop_to";
		ctrl.classWnd = "static";
		ctrl.textWnd = "��������� ��������";
		ctrl.mul_w = 3;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_shape_stop_to";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 3;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		CChat::Ctrls_set_origin(ctrls, 5, 14); 
 	ctrls.NewRow();	
		ctrls.NewRow();	

		ctrl.Clear();
		ctrl.name = "static_rep_shape_stop_from_time";
		ctrl.classWnd = "static";
		ctrl.textWnd = "����� ��������� �������";
		ctrl.mul_w = 3;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_shape_stop_from_time";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 1.6;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_shape_stop_to_time";
		ctrl.classWnd = "static";
		ctrl.textWnd = "����� ��������� ��������";
		ctrl.mul_w = 3;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_shape_stop_to_time";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 1.6;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);


		CChat::Ctrls_set_origin(ctrls, 6, 14); 
		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "but_rep";
		ctrl.classWnd = "button";
		ctrl.textWnd = "��������"; 
		ctrl.mul_w = 2.3;
		ctrls.Add(ctrl);
		
		gControlPanelWnd.set_p_ctrls(&ctrls);
		gControlPanelWnd.fill_combo_rep_route();		
	}else
	if (eCtrlsReps == ECR_5)
	{
		int i_combo_mul_w = 3;

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_street";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�����";
		ctrl.mul_w = 1;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_street";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 2;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_date";
		ctrl.classWnd = "static";
		ctrl.textWnd = "����";
		ctrl.mul_w = 0.8;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "check_rep_date";
		ctrl.classWnd = "button";
		ctrl.mul_w = 0.2;
		ctrl.styleAdd = BS_CHECKBOX;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "dt_rep_date";
		ctrl.classWnd = "combobox"; // "SysDateTimePick32"; //DATETIMEPICK_CLASSA
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;// | DTS_SHOWNONE;
		ctrl.mul_w = 1.54;
		ctrl.mul_h = 6; // 1.2;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "but_rep";
		ctrl.classWnd = "button";
		ctrl.textWnd = "��������";
		ctrl.mul_w = 2.3;
		ctrls.Add(ctrl);

		fill_dt_rep_date("dt_rep_date");
	}
	else
	if (eCtrlsReps == ECR_6)
	{
		int i_combo_mul_w = 3;

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_mode";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�����";
		ctrl.mul_w = 0.8;
		ctrl.mul_h = 1;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_mode";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_date";
		ctrl.classWnd = "static";
		ctrl.textWnd = "����";
		ctrl.mul_w = 0.8;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "check_rep_date";
		ctrl.classWnd = "button";
		ctrl.mul_w = 0.2;
		ctrl.styleAdd = BS_CHECKBOX;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "dt_rep_date";
		ctrl.classWnd = "combobox";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 1.54;
		ctrl.mul_h = 6; // 1.2;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "but_rep";
		ctrl.classWnd = "button";
		ctrl.textWnd = "��������";
		ctrl.mul_w = 2.3;
		ctrls.Add(ctrl);

		fill_dt_rep_date("dt_rep_date");

	}
	else
	if (eCtrlsReps == ECR_7)
	{
		int i_combo_mul_w = 3;

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_mode";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�����";
		ctrl.mul_w = 0.8;
		ctrl.mul_h = 1;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_mode";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_date";
		ctrl.classWnd = "static";
		ctrl.textWnd = "����";
		ctrl.mul_w = 0.8;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "check_rep_date";
		ctrl.classWnd = "button";
		ctrl.mul_w = 0.2;
		ctrl.styleAdd = BS_CHECKBOX;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "dt_rep_date";
		ctrl.classWnd = "combobox";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 1.54;
		ctrl.mul_h = 6; // 1.2;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_date_to";
		ctrl.classWnd = "static";
		ctrl.textWnd = "���� �";
		ctrl.mul_w = 0.8;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "check_rep_date_to";
		ctrl.classWnd = "button";
		ctrl.mul_w = 0.2;
		ctrl.styleAdd = BS_CHECKBOX;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "dt_rep_date_to";
		ctrl.classWnd = "combobox";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 1.54;
		ctrl.mul_h = 6; // 1.2;
		ctrls.Add(ctrl);

		CChat::Ctrls_set_origin(ctrls, 2, 9);
		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_agent";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�����������";
		ctrl.mul_w = 1.3;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_agent";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_route";
		ctrl.classWnd = "static";
		ctrl.textWnd = "�������";
		ctrl.mul_w = 1.3;
		ctrl.mul_h = 1;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_route";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWN | WS_VSCROLL;
		ctrl.mul_w = i_combo_mul_w;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "but_rep";
		ctrl.classWnd = "button";
		ctrl.textWnd = "��������";
		ctrl.mul_w = 2.3;
		ctrls.Add(ctrl);

		fill_dt_rep_date("dt_rep_date");
		fill_dt_rep_date("dt_rep_date_to");
		gControlPanelWnd.set_p_ctrls(&ctrls);
		gControlPanelWnd.fill_combo_rep_route();
	}
	else
	if (eCtrlsReps == ECR_8)
	{
		int i_combo_mul_w = 3;

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_date";
		ctrl.classWnd = "static";
		ctrl.textWnd = "����";
		ctrl.mul_w = 2;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "check_rep_date";
		ctrl.classWnd = "button";
		ctrl.mul_w = 0.2;
		ctrl.styleAdd = BS_CHECKBOX;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "dt_rep_date";
		ctrl.classWnd = "combobox";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 1.6;
		ctrl.mul_h = 6; // 1.2;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_device";
		ctrl.classWnd = "static";
		ctrl.textWnd = "����������";
		ctrl.mul_w = 2;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_rep_device";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 1.6;
		ctrl.mul_h = 6;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "but_rep";
		ctrl.classWnd = "button";
		ctrl.textWnd = "��������";
		ctrl.mul_w = 2.3;
		ctrls.Add(ctrl);

		fill_dt_rep_date("dt_rep_date");
	}
	else
	if (eCtrlsReps == ECR_9)
	{
		int i_combo_mul_w = 3;

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "static_rep_date";
		ctrl.classWnd = "static";
		ctrl.textWnd = "����";
		ctrl.mul_w = 2;
		ctrl.styleAdd = SS_CENTER;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "check_rep_date";
		ctrl.classWnd = "button";
		ctrl.mul_w = 0.2;
		ctrl.styleAdd = BS_CHECKBOX;
		ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "dt_rep_date";
		ctrl.classWnd = "combobox";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.mul_w = 1.6;
		ctrl.mul_h = 6; // 1.2;
		ctrls.Add(ctrl);

		ctrls.NewRow();

		ctrl.Clear();
		ctrl.name = "but_rep";
		ctrl.classWnd = "button";
		ctrl.textWnd = "��������";
		ctrl.mul_w = 2;
		ctrls.Add(ctrl);

		fill_dt_rep_date("dt_rep_date");
	}


	i_start_id+=ctrls.GetSize();

	ctrls.Update();
}

void CRep::Update()
{
	CallPaint(); //m_ctrls.Update();

	g_ctrls_rep.Update();
}

void CRep::SelCombo(char *sz_combo, int  index, CWinCtrl* p_ctrls)
{
	CWinCtrl* p = p_ctrls ? p_ctrls : &g_ctrls_rep;

	p->SendMes(sz_combo, CB_SETCURSEL, (WPARAM)index, (LPARAM)0);
	
	int index_readed = p->SendMes(sz_combo, CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

	if (index_readed != index) 
	{ 
		gMesWnd.Mes("CRep::SelCombo. ������. �� ���������� ������ ����������� ������"); 
	}
}

void CRep::WM__LBUTTONDOWN(POINT& pn)
{
	if (m_row_but_reps.Sel(pn) == false) { return; }

	m_i_rep = m_row_but_reps.index_sel; //gBookMarks.CloseDestroyBrowserWnd();

	but_rep();

	CallPaint();
}