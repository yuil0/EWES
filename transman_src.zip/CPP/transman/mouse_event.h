#ifndef _mouse_event_h_
#define _mouse_event_h_

#include  <windows.h>
#include  <time.h>

class CMouseEvent
{   
	POINT m_point;

	bool m_fRead;

	bool m_event;  //bool Parse(wchar_t *wsz_addr, SMapAddrParam& param);
	
	bool m_event_no_event;
	
	time_t m_time_no_event;

	bool m_lock_no_event;

	bool m_event_interval;

	time_t m_time_event;

	bool m_lock_event;

	void ClearEvent();     //bool DeltaIsOver();

	public:

    CMouseEvent();

	void Clear();

	void Read(time_t time_interval_event, time_t time_interval_no_event);

	bool GetEvent();
	
	bool GetEventNoEvent();

	bool GetEventInterval();
	
};

#endif