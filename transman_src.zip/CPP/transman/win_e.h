#ifndef _win_e_h_
#define _win_e_h_

#include "..\\transman_srv\\std_str.h"
#include <vector>
#include <windows.h>
#include <TlHelp32.h>
#include "MSSQL.h"

namespace win_e
{
	//typedef LRESULT (CALLBACK *FN_WINDOWPROC)(_In_ HWND hwnd, _In_ UINT uMsg, _In_ WPARAM wParam, _In_ LPARAM lParam);

	const int ci_q_monitor=2;
	
	const float  cfl_font_part_h = 0.5;

	bool IsAlreadyRun(char *sz_class_name, char *sz_wnd_name);

	struct SMonitors
	{
		RECT rc[ci_q_monitor];

		int q_monitor;

		int i_monitor; //YUIL 2017-01-09 ������ ��������. ����� ��� ������  ���������� ������� �� ����� ����������, � ��� ������ �������� ����������� ��  ����.

		SMonitors();
		
		void ReadIni();

		void Add(RECT *p_rc) 
		{
			if (p_rc==0) {return;}

			rc[q_monitor] = *p_rc;

			q_monitor++;
		}
	};

		//<q5
	struct S_MSWindow
	{
		std_string sz_class;
		HWND hwnd;
	};

	struct S_MSWindows
	{
		std::vector<S_MSWindow> list;

		S_MSWindows();

		void Add(HWND hwnd) 
		{
			if (hwnd==0) {return;}
		
			S_MSWindow o;

			char sz_class[MAX_PATH+1];

			BOOL f_get = GetClassNameA(hwnd, sz_class, MAX_PATH);

			o.hwnd = hwnd;

			o.sz_class = sz_class;

			list.push_back(o);
		}
	};
	//>q5

	void ShowWndByClass(char *sz_class, bool f_show);

	void ShowSysTray(bool f_show=true);

	void RemoveWndStyle(HWND hwnd, LONG lRemoveStyle);

	void AddWndStyle(HWND hwnd, LONG lAddStyle,  bool fExt=false);

	void ChWndProc(HWND hwnd, WNDPROC procNew, WNDPROC* procPrev);

	bool DrawBitmap(HDC hdc, HBITMAP hbitmap, POINT& pn, POINT* pSize=0, POINT* pSizeCtrl=0, bool fStretch=false);

	bool GetBitmapSize(HBITMAP hbitmap, POINT& size);

	typedef enum
	{
		EPB_PEN_WHITE= 0,		
		EPB_PEN_GRAY_DD,
		EPB_PEN_GRAY_55,
		EPB_PEN_GRAY_CC,
		EPB_PEN_GRAY_E0,
		EPB_PEN_GRAY_EE,
		EPB_PEN_GRAY_55_W2,
		EPB_PEN_GRAY_E0_W2,
		EPB_BRUSH_WHITE,
		EPB_BRUSH_GRAY_CC,
		EPB_BRUSH_GRAY_E0,
		EPB_QUNATITY,
	}EPenBrush;

	extern HGDIOBJ g_penBrush[EPB_QUNATITY];


	struct SRowButtons
	{
		bool fInit;
		RECT rc;
		std_string sz_name_template;
		int i_ident_betw;
		int quantity;
		int index_sel;
		int size_but;
		//
		bool Open(char *sz_name_template_new, RECT& rc_new, int i_ident_betw_new, int quantity_new, int index_sel_new);
		void Close();
		void DrawA(HDC hdc);
		struct SGroundPenBrush
		{
			HBRUSH hbrush;
			HPEN hpen;
		};
		void Draw(HDC hdc, SGroundPenBrush* p_gpb=0);
		void DrawOp(HDC hdc, POINT& pn, int size_but, int h, bool fSel, int index);

		bool Sel(POINT& pn);
	};

	
	void DrawGroupBox(HDC hdc, int x, int y, int w, int h, char *sz_text, int h_caption);

	struct SListBoxItem
	{
		std_string sz_text;
		bool f_select;
		//
		std_string id;
		std_string name;
		std_string param_1;
		void* p_ptr_1;

		SListBoxItem();
		//
		void operator=(const SListBoxItem& p);
	};

	void DrawDevideStrInList(HDC hdc, int i_height_font, HFONT hfont, int ident, std_string& sz, std::vector<int>& list_width, int h_element, int indexItem, int max_x);

	//////////////////////////////////////////////////////////////////////////////
	struct SListBox
	//
	{
		bool fInit;
		RECT rc;

		std::vector<SListBoxItem> list;
		int h_element;
		int index_view;
		//
		int h;
		int q_view;
		long m_f_move;    //POINT m_pn_start; //POINT m_pn;
		int m_bar_y; //bottom bar
		bool m_f_text_only; //bool m_f_bitmap_interface;
		bool m_f_need_checkbox;
		int m_sel_index; //YUIL 2017-02-02
		bool m_f_back_order; //YUIL 2017-02-08 �������� ������� ����������
		bool m_f_no_draw;
		bool m_f_one_sel; //selected only one
		bool m_f_bar_selected; //YUIL 2017-02-13
		bool m_f_no_scroll; 

		std::vector<int> listWidth; //YUIL 2017-02-14 ������ �����
		std_string sz_caption; //YUIL 2017-02-14 ���������, ����������� ������� : '\0'. ����� ������ "\0\0"
		//
		bool Open(RECT& rc_new, int h_element_new, char* sz_sql_query_to_fill=0, bool f_text_only=false, bool f_no_draw=false); // , bool f_bitmap_interface = false);
		void Close();
		void DrawA(HDC hdc, int i_height_font, HFONT hfont, HBITMAP hbitmapOn, HBITMAP hbitmapOff);
		
		void Draw(HDC hdc, int i_height_font, HFONT hfont, HBITMAP hbitmapOn=0, HBITMAP hbitmapOff=0);
		bool Sel(POINT& pn, bool fChState=true, SListBoxItem* *pElement=0, bool fMoveNew =true);
		void SelItemOp(int index);
		void DrawBar(HDC hdc);
		void DrawScroll(HDC hdc); //float get_step_y(int& n);
		bool InScrollBar(POINT& pn); //void ScrollFin();
		void ScrollOp(POINT& pn);
		void SelAll(bool f);
		int GetCountSel(bool& fAll, std::vector<long>& list_index_sel);
		void Add(char* sz_new, bool f_select = false, char* id_new = 0, char* name_new = 0, char *param_1_new=0, void* p_ptr_1_new=0);
		void ExecSQL_query(char* sz_query);
		void add(FldsPtr fp);
		int GetSelIndex() { return m_sel_index; }
		bool GetSelItem(SListBoxItem* *p_item)
		{
			if (m_sel_index == -1) { return false; }

			if (p_item == 0) { return false; }

			*p_item = &list[m_sel_index];

			return true;
		}
		void IncIndexView();
		void DecIndexView();
		bool In(POINT& pn);
		bool InMouseWheel(POINT& pn, int v);
		bool InScrollOp(POINT& pn);
		
		void SetMove(bool f_new)
		{ 
			if (list.size() == 0) { f_new = false; }

			InterlockedExchange(&m_f_move, f_new ? 1 : 0); 
		}
		void  SetOneSel() { m_f_one_sel = true; }
		void ClearList() { list.clear(); }
		void SetTextOnly() { m_f_text_only = true; }
		void SetSelIndex(int index) { m_sel_index = index; }
		bool IsBarSelected() { return m_f_bar_selected; }
		void SetBackOrder() { m_f_back_order = true;}
		void AddWidth(int width_col) { listWidth.push_back(width_col);	}
		void DrawCaption(HDC hdc, int i_height_font, HFONT hfont, int ident);
		void DrawGrid(HDC hdc, int ident);
		void DrawBkGrItem(HDC hdc, EPenBrush ePen, EPenBrush eBrush, int y);
		void DrawBkGrItem_sel(HDC hdc, int y);
		void SetCaption(char* sz) {sz_caption = sz;	}
		bool IsCaption() { return listWidth.size() && sz_caption.size(); }
		void Add(SListBoxItem& sItem) { list.push_back(sItem); }
		void InitBarY()
		{
			m_bar_y = h_element;
			
			if (IsCaption()) { m_bar_y += h_element;}
		}
		void SetNoScroll() { m_f_no_scroll=true; }
	};

	void DrawCheckBox(HDC hdc, int i_height_font, HFONT hfont, int x, int y, int w, int h, char *sz_text, bool f_select, bool f_text_only=false, HBITMAP hbitmapOn=0, HBITMAP hbitmapOff=0);

	

	HFONT Create_Font(char* sz_font_family, int h_font, float part_h = cfl_font_part_h); //void ChFontFamilyCtrl(HWND hwnd, char* sz_font_family);

	struct SBorder
	{
		bool fInit;
		RECT rc;
		int iThick;

		//
		bool Open(RECT& rc_new, int iThick_new);
		void Close();
		void Draw(HDC hdc);
	};
	
	void Set_Cursor(LPCTSTR lpCursorName); //IDC_WAIT //IDC_ARROW //HINSTANCE hInstance, 

	struct SWaitIndicator
	{
		bool fInit;
		RECT rc;
		int q_items;
		int index;

		//
		bool Open(RECT& rc_new, int q_items_new);
		void Close();
		void Draw(HDC hdc, HBRUSH hbrushGround);
		void IndexOp();
	};

	void SetFont(HDC hdc, char *fontName, long nFontSize, bool  fBold, HFONT& hFont);

	/////////////////////////////////////////////////////////////////////////////////////
	struct SBitmapCtrl
	//
	{
		int id;
		POINT pn;
		POINT size;
		std_string text;
		bool fDown;
		HBITMAP hbitmapUp;
		HBITMAP hbitmapDown;
		void Init(char *szFileUp, char *szFileDown=0);
		void Close();
		void Draw(HDC hdc);
		void DrawOp(HDC hdc);
		bool In(POINT& n);
		SBitmapCtrl();
	};

	/////////////////////////////////////////////////////////////////////////////////////
	class CBitmapCtrls
	//
	{
		bool m_fInit;
		std::vector<SBitmapCtrl> m_list;
	 public:
		bool Open();
		void Close();
		bool Add(SBitmapCtrl& sNew);
		void Draw(HDC hdc);
		bool Click(POINT& pn);
	};

	bool GetMouseClientCoord(HWND hwnd, POINT& pn_out);

	void Text_out(HDC hdc, POINT& pn, POINT& size, char *sz_text, int len_text);

	///////////////////////////////////////////////////////////////
	class CToolhelpSnapshot
	//
	{
		bool m_fInit;
		HANDLE m_hSnapshot;
 	public:
		CToolhelpSnapshot(DWORD dwFlags= TH32CS_SNAPPROCESS);
		bool Next(int&  i, PROCESSENTRY32& pe);
	};

	bool ProcessExists(wchar_t* wz_proc_name);

	void DrawFootball(HDC hdc, POINT& pn, int rad);


	struct SDrawTextParam
	{
		HFONT hfont;
		int height_font;
		char *p_text;
		int len_text;
		int ident;
		int x,y,w, h;
		//
		SDrawTextParam();
		//			
	};

	void Draw_Text(HDC hdc, SDrawTextParam& param);

	//////////////////////////////////////////////////////////////////////////////
	struct SEdit
	//
	{
		bool fInit;
		char *m_text;
		int i_text_max;
		int q_text;
		RECT rc; 
		int w, h;
		bool m_f_active;
		bool m_f_read_only;
		HWND m_hwnd;
		int m_id;
		//
																			//
		bool Open(RECT& rc_new, int i_text_max_new=256);
		void Close();

		void DrawOp(HDC hdc, int i_height_font, HFONT hfont);
		void Draw(HDC hdc, int i_height_font, HFONT hfont);
		void SetText(char* sz_new);
		bool KeyDown(int vk); //bool IsValid_VK(int vk);
		bool Add(int vk);
		bool DelLast();
		bool CheckIn(POINT& pn);
		bool IsValid_VK(int& vk, bool fShift);
		char* GetText() { return m_text; }
		void SetReadOnly() { m_f_read_only=true; }
		void Set_hwnd(HWND hwnd) { m_hwnd= hwnd; }
		void SetId(int id_new) { m_id = id_new; };
		void SetActive(bool f) { m_f_active = f; }
	};

	void DrawPenFrame(HDC hdc, RECT& rc, int i_shift=0);

	typedef enum
	{
		EHKLI_ALT_SHIFT=0,
		EHKLI_CTRL_SHIFT,
	}EHotKeysLangInput;

	void GetKeysLangInput(EHotKeysLangInput& eKeys);
	LANGID GetPrimLangId();
	char GetRusCharByKey(char c, bool fUp);

	void CreatePenBrush();
	void DestroyPenBrush();

	
	/*struct SComboBox
	//
	{
		SEdit m_edit;
		SListBox m_list;
		//
		bool Open(RECT& rc_new, int i_text_max_new = 256);
		void Close();
		void ClearList();
		void AddToList(char* sz_new);
		bool CheckIn(POINT& pn, bool& fNeedDrawBkGr);
		void SelectItem(int index);
		bool InScrollOp(POINT& pn);

		void Draw(HDC hdc, SEdit::SDrawTextParam* p_param = 0);
	};*/
	

	struct SCWindowAttr
	{
		int iThick;
		int iCaption;
	};

	bool GetClientRectAbs(HWND hWnd, RECT& rcCleintAbs, SCWindowAttr* pAttr=0);

}//namespace win_e



#endif