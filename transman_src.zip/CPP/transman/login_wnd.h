#ifndef _LoginWnd_h_
#define _LoginWnd_h_

#include "..\\transman\\window.h"
#include "..\\util\\winctrl.h"
#include "MSSQL.h"
#include "..\\transman_srv\\std_str.h"

typedef enum
{
	EUT_UNKNOWN=0,
	EUT_DISP_HI,
	EUT_DISP,
	EUT_COLLAB,
}EUserType;

class CLoginWnd
{
	struct SData
	{
		std_string user;
		std_string psw;
	};
	SData m_data;

	bool m_fInit;
	bool m_fFoundUserInDB;
	CWinCtrl m_ctrls;
 CWindow wnd; //HINSTANCE m_hInstance;
	EUserType m_eUserType;
	std_string m_sz_id_user;
	int m_id_ctrl_active;
	void CrLoginWndControls();
	void WM__CLOSE(HWND hwnd, WPARAM wParam, LPARAM lParam);
 void WM__DESTROY(WPARAM wParam, LPARAM lParam);
 void WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam);
	void WM__COMMAND(HWND hwnd, WPARAM wParam, LPARAM lParam);
	void ReadCtrls();
	void Success();
	bool FindUserInDB();
	void set_from_ini();
	void Tab();
	public:
	CLoginWnd();
	bool Open(); //HINSTANCE hInstance);
	void Close();
	LRESULT MesOp(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	void CrLoginWnd(); //YUIL 2017-11-02 . ���� �����
	void CrThread();
	HWND GetHWND() {return wnd.GetHWND(); }
	void WM__KEYDOWN(HWND hwnd, WPARAM wParam, LPARAM lParam);
	
	const char* GetUser() { return m_data.user.c_str(); }
	const char* GetPassword() { return m_data.psw.c_str(); }
	void Mes(char *szFormat, ...);
	void FindUserInDB_Add(FldsPtr fp);
	EUserType GetUserType() { return m_eUserType; }
	std_string& GetIdUser() { return (std_string&)m_sz_id_user; } //int Get_id_user() { return m_id_user; }

	bool IsFoundUserInDB() { return m_fFoundUserInDB; }
};

extern CLoginWnd gLoginWnd;

#endif