#include <memory.h>
#include "main.h"
#include "Map.h"

#include "BookMarks.h"
#include "login_wnd.h"
#include "MesWnd.h"
#include <commctrl.h>
#include "..\\transman_srv\\time_e.h"
#include "..\\transman_srv\\str.h"
#include "win_e.h"

#include "FormMes.h"  
#include "fill_ctrl.h"

/*void CMap_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesWnd.Mes("CMap. ������ MS SQL : %s", sz_text);
}*/

/*void CMap::fill_form_mes_by_offer()
{                                                                                   	//if (m_ctrls.SendMes("combo_form_mes", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val) == 0) { return; }
	int index = m_ctrls.SendMes("combo_form_mes", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

	if (index < 0) {return;}

	std::vector<SFormMesRow>&list = gFormMes.GetList();

	int q = list.size();

	if (q == 0) { return; }

	SFormMesRow& m = list[index]; //strcpy(sz_val, ); //m_ctrls.SendMes("combo_from_mes_car", WM_SETTEXT, (WPARAM)0, (LPARAM)sz_val);	

	SFillCtrl fc(&m_ctrls);
	fc.SetPosById(SFillCtrl::ETB_COMBOBOX, "combo_from_mes_car", m_list_combo_device_number, (char*)(m.id_ate_3.c_str())); //m_eFormMesName == EFMN_DEVICE ? m.device_number.c_str() : m.garage_num.c_str()

	combo_from_mes_car();

	fc.SetPosByName(SFillCtrl::ETB_COMBOBOX, "combo_check_point_from", m_list_combo_check_point, (char*)m.stop_name_from.c_str());
	fc.SetPosByName(SFillCtrl::ETB_COMBOBOX, "combo_check_point_to", m_list_combo_check_point, (char*)m.stop_name_to.c_str());      //char sz_val[MAX_PATH + 1]; itoa(, sz_val, 10); itoa(m.time_cmd_minute_to, sz_val, 10); 

	m_ctrls.SendMes("edit_form_mes_cmd_from", WM_SETTEXT, (WPARAM)0, (LPARAM)(char*)m.time_cmd_minute_from.c_str());
	m_ctrls.SendMes("edit_form_mes_cmd_to", WM_SETTEXT, (WPARAM)0, (LPARAM)(char*)m.time_cmd_minute_to.c_str());

	ClearDirectSelStops();
}

void CMap::ClearDirectSelStops()
{
	m_p_stop_from = 0;
	m_p_stop_to = 0;
}

bool CMap::CheckCompleteDirectSelStops()
{
	if ((m_p_stop_from == 0 && m_p_stop_to) || (m_p_stop_from && m_p_stop_to == 0))
	{ 
		gMesWnd.Mes("CMap::CheckCompleteDirectSelStops(). ����� ������� ��������� ��������� �� ����� ��� ������� �����������");

		return false; 
	}

	return true;
}*/

bool CMap::IsNoDirectSelStops()
{
	return m_p_stop_from == 0 && m_p_stop_to == 0;
}

/*void CMap::but_clear_form_mes()
{
	m_ctrls.SendMes("combo_from_mes_car", CB_RESETCONTENT, (WPARAM)0, (LPARAM)0); //m_ctrls.SendMes("combo_from_mes_car", WM_SETTEXT, (WPARAM)0, (LPARAM)0);
}

void CMap::combo_from_mes_car()
{
	int index_car = m_ctrls.SendMes("combo_from_mes_car", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
	if (index_car < 0) { return; }

	SNameId& car = m_list_combo_device_number[index_car];

	SFillCtrl fc(&m_ctrls);
	std::vector<std_string> box_names;
	SNameId names;

	box_names.clear();
	box_names.push_back("combo_check_point_from");
	box_names.push_back("combo_check_point_to");
	names.name = "stop_name"; 
	names.id = "id_picas_stop";
	std_string sz_query =
		"SELECT DISTINCT stop_name, id_picas_stop FROM dbo.picas_stops\r\n"
		"WHERE id_picas_stop IN(SELECT DISTINCT id_picas_stop FROM dbo.check_points cp, dbo.picas_routes r, dbo.ate_3 c WHERE cp.id_picas_route = r.id_picas_route AND r.route_id = c.route_id AND c.id_ate_3 = ";	
	sz_query.append(car.id);
	sz_query.append(")\r\n ORDER BY 1\r\n");
	int index_to_set = -1; //YUIL 2017-12-14. �� ����� ����� ��������
	FILE *fo = fopen("C:\\transman\\form_mes\\SQL_query_combo_from_mes_car.txt", "wb");
	if (fo) { fprintf(fo, "%s\r\n", sz_query.c_str()); fclose(fo); }
	fc.fill_from_db(SFillCtrl::ETB_COMBOBOX, box_names, (char*)sz_query.c_str(), names, &m_list_combo_check_point, index_to_set);
	if (fc.GetReadRows() == 0) { gMesWnd.Mes("void CMap::combo_from_mes_car().  ��� ����������� ������� ��� ������"); }


}

/////////////////////////////////////////////////////////////
void CMap::but_form_mes_send()
//
{
	if (CheckCompleteDirectSelStops() == false) { return; }

	char sz_val[MAX_PATH + 1];

	//car
	int index_car = m_ctrls.SendMes("combo_from_mes_car", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
	if (index_car < 0) { return; }
	SNameId& car = m_list_combo_device_number[index_car];

	//stop from
	std_string check_point_from_id;
	if (m_p_stop_from)
	{
		check_point_from_id = m_p_stop_from->id_picas_stop;
	}
	else
	{
		int index_check_point_from = m_ctrls.SendMes("combo_check_point_from", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
		if (index_check_point_from < 0) { return; }
		SNameId& check_point_from = m_list_combo_check_point[index_check_point_from];
		check_point_from_id = check_point_from.id;
	}

	//stop to
	std_string check_point_to_id;
	if (m_p_stop_to)
	{
		check_point_to_id = m_p_stop_to->id_picas_stop;
	}
	else
	{
		int index_check_point_to = m_ctrls.SendMes("combo_check_point_to", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
		if (index_check_point_to < 0) { return; }
		SNameId& check_point_to = m_list_combo_check_point[index_check_point_to];
		check_point_to_id = check_point_to.id;
	}

	std_string sz_query = "EXEC dbo.P_add_form_mes_act @id_user="; sz_query.append(gLoginWnd.GetIdUser());
	sz_query.append(", @id_ate_3="); sz_query.append(car.id); 
	sz_query.append(", @id_picas_stop_from="); sz_query.append(check_point_from_id);
	sz_query.append(", @id_picas_stop_to="); sz_query.append(check_point_to_id);
	sz_query.append(", @time_cmd_minute_from="); if (m_ctrls.SendMes("edit_form_mes_cmd_from", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val)) { sz_query.append(sz_val); } else { sz_query.append("0"); }
	sz_query.append(", @time_cmd_minute_to="); if (m_ctrls.SendMes("edit_form_mes_cmd_to", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val)) { sz_query.append(sz_val); }	else { sz_query.append("0"); }

	bool f_exec = MSSQL_Exec((char*)sz_query.c_str(), 0, CMap_FN_MSSQL_MES_ERR, this);
	
	if (f_exec==false) { gMesWnd.Mes("CMap::but_form_mes_send(). ������ ������ ����. �����. � ��"); }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
DWORD WINAPI CMap_ThreadProc(LPVOID lpParameter)
{
	CMap *p_this = (CMap*)lpParameter;

	if (p_this == 0) { return 0; }

	while (1)
	{
		p_this->ViewFormMes();

		Sleep(1000);
	}

	return 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool CMap::CrThreadViewFormMes()
{
	if (m_fInit == false) { return false; }

	DWORD dThreadId;

	HANDLE h = CreateThread(0, 0, CMap_ThreadProc, (LPVOID)this, 0, &dThreadId);

	return h != 0;
}

void CMap::ViewFormMes()
{
	if (m_ctrls.GetCheckbox("cb_form_mes_re") == false) { return; }

	SFillCtrl fc(&m_ctrls);

	std_string sz_query = "dbo.P_view_form_mes @id_user="; sz_query.append(gLoginWnd.GetIdUser()); //if (m_eFormMesName == EFMN_GARAGE) { sz_query.append(", @i_mode=1"); }

	fc.fill_edit_from_db("edit_form_mes", (char*)sz_query.c_str());
}
*/