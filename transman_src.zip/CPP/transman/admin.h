#ifndef _admin_h_
#define _admin_h_

#pragma once

#include <windows.h>
#include "..\\util\\winctrl.h"
#include "MSSQL.h"
#include "login_wnd.h"
#include "ms_inet.h"
#include "win_e.h"

///////////////////////////////////////////////////////////////////////////
class CAdmin
//
{
public:

private:
	bool m_fInit;
	POINT m_wnd_size;
	CWinCtrl m_ctrls; 
	
	int m_index_start_disp;
	std_string m_sz_id_user; //int m_list_x_ctrls[ci_chat_ctrls_group];
	std_string m_sz_combo;
	HWND m_hwndBrowser;
	

	int m_i_sizeMesPack;
	int m_index_start_common;
	bool m_f_refresh;
	HWND m_hwndParent;
	RECT m_rcParent;

	void CrControls_disp_hi();
	void CrControls_disp_hi_new_disp();
	void CrControls_disp_hi_new_coll();
	void CrControls_disp_hi_bind();
	
	void CrNewDisp();
	void CrNewColl();
	void fill_combo_new_coll_disp();
	void fill_combo_bind_coll();
	bool get_id_user(char *sz_val, std_string* p_id_user=0);
	void Bind();
	bool get_id_user_by_combo(char *sz_combo, std_string& sz_user_id);
	void fill_combo_show_coll();
	
	static int Get_x_step_gr(int q_gr);
	
	void fill_combo_disp_coll();
	void fill_combo_coll_by_id_disp(char* sz_combo_coll, std_string& id_disp);
	void set_edit_disp_mes_by_combo(char *sz_combo);

	typedef enum
	{
		ESMM_ONE=0,
		ESMM_ALL_IN_GROUP,
		ESMM_ALL,
	}ESendMesMode;

	void but_send_new_mes(char *id_chat_mes_type, ESendMesMode eMode = ESMM_ONE);		

	void set_but_refresh(bool fCheck);
	
	void refresh_op();
	void set_check_box(char  *sz_checkbox, bool fCheck);
	bool get_check_box(char  *sz_checkbox);


	public:
	CAdmin();
	~CAdmin();
	bool Open(HINSTANCE hInstance, HWND hwndParent, int w, int h, RECT& rcParent);
	void Close();
	void CrControls(HINSTANCE hInstance, HWND hwndParent); //void CrControlsR(HINSTANCE hInstance, HWND hwndParent);
	void Show(bool fShow);
	void OnCmd(int id, int notify); //void Paint(HDC hdc);
	void Paint(HDC hdc);
	void fill_combo_new_coll_disp_add(FldsPtr fp);
	void fill_combo_bind_coll_add(FldsPtr fp);
	void CrNewColl_add(FldsPtr fp);
	void get_id_user_add(FldsPtr fp);
	void fill_combo_show_coll_add(FldsPtr fp);

	void fill_combo_coll_by_id_disp_add(FldsPtr fp);
	void StartFill();

	void Tab();

	static void Ctrls_set_origin(CWinCtrl& ctrls, int index_gr, int q_gr);

	HWND GetBrowserHWND() { return m_hwndBrowser; }

	void set_refresh(bool f);
	
	CWinCtrl& GetCtrls() { return (CWinCtrl&)m_ctrls; }
	void SetEditMes(Leaflet::LatLng& latlng);
};


#endif