#ifndef _Map_h_
#define _Map_h_

#include <windows.h>
#include "..\\util\\winctrl.h"
#include "MSSQL.h"
#include "login_wnd.h"
#include "ms_inet.h"
#include "..\\transman_srv\\std_str.h"
#include "date_time.h"
#include "fill_ctrl.h"

typedef enum
{
	EMGDIO_PEN_DEVIDER = 0,
	EMGDIO_PEN_WHITE,
	EMGDIO_BRUSH_WHITE,
	EMGDIO_HBITMAP_STATIC_6_2,
	//
	EMGDIO_QUANTITY,
}EMapGDIObject;

class CMap
{
	bool m_fInit;
	POINT m_wnd_size;
	CWinCtrl m_ctrls;
	HGDIOBJ m_gdi_obj[EMGDIO_QUANTITY];
	bool m_f_refresh; 

	HINSTANCE m_hInstance;
	HWND m_hwndParent; //win_e::SListBox lb_routeCar; //win_e::SListBox lb_formMes; //win_e::SListBox lb_carTypes; //win_e::SListBox lb_selCars; //YUIL 2017-02-01 ��������� ������ //win_e::SEdit edit_zone_new_name; //YUIL 2017-02-08

	std::vector<SNameId> m_list_combo_device_number;
	std::vector<SNameId> m_list_combo_check_point;

	HFONT m_hfont_edit;
	std::vector<int> m_id_agent_list;  //win_e::CBitmapCtrls m_bitmapCtrls;
	
	SCtrl* m_pCtrlStop;
	typedef enum { ECP_COMBO_STOP=0, ECP_FROM, ECP_TO} ECheckPoint;
	ECheckPoint m_eCheckPoint; //bool m_f_check_point_from_is_direct; //bool m_f_check_point_to_is_direct;
	SStop* m_p_stop_from;
	SStop* m_p_stop_to; //typedef enum { EFMN_DEVICE= 0, EFMN_GARAGE}EFormMesName; //EFormMesName m_eFormMesName;
	bool m_f_readMes;

	void PaintDevider(HDC hdc, int x);
	void cr_m_gdi_obj();
	void del_m_gdi_obj();		
	void CrGrSt();
	void CrGrNewZone();
	void CrGrMobile(); 
	
	void CrGrSelected();


	void Syn_to_listBox_routeCar();
	void CrGrMes();
	
	/*void but_form_mes_send();
	void but_clear_form_mes();
	void combo_from_mes_car();
	bool CrThreadViewFormMes();
	void ClearDirectSelStops();
	bool CheckCompleteDirectSelStops();*/


	void fill_combo_car_agent(); //void AddBitmapCtrls();
	void SelCombo(char *sz_combo, int  index);
	bool IsNoDirectSelStops();
	void ReadIni();
	void CP_OnCmd(int id, int notify);
	void sel_al_routes();
	void unsel_al_routes(); 	//void sel_routes_by_agent(int id_agent); //void fill_combo_stop();
	void WM__LBUTTONDOWN_combo_car_agent(SCtrl* pCtrl);
	void fill_combo_car_lag_lead();
	void fill_combo_zone();
	void fill_combo_stop();
	//void CrThreadMes();
	void edit_gr_sel_input_op();
public:
	CMap();
	~CMap();
	bool Open(HINSTANCE hInstance, HWND hwndParent, int w, int h);
	void Close();
	void CrControls(); //void CrControlsR(HINSTANCE hInstance, HWND hwndParent);
	void Show(bool fShow);
	void OnCmd(int id, int notify); //void Paint(HDC hdc);
	void Paint(HDC hdc, int i_mode=0); //i_mode 1:groups_invisible_only
	void StartFill();
	void Tab(); //int GetBottom(); bool IsShowRep() { return m_f_show_rep; } //int GetButReptMaxY();
	void Update(); //bool find_m_ctrls_by_i_rep(int i_rep, SRepCtrls* *pRepCtrls=0);
	CWinCtrl& GetCtrls() { return (CWinCtrl&)m_ctrls; }

	void AfterSet();
	void set_edit_find_near_car(char *sz_text);

	void fill_list_show_route_car(int id_agent=0);
	void WM__NOTIFY(WPARAM wParam, LPARAM lParam);
	void WM__LBUTTONDOWN(POINT& pn, HWND hwnd);
	void WM__RBUTTONDOWN(POINT& pn);
	void WM__MOUSEMOVE(POINT pn, WPARAM wParam);
	void WM__LBUTTONUP(POINT& pn, HWND hwnd);
	void WM__KEYDOWN(WPARAM wParam, LPARAM lParam);
	void WM__CHAR(WPARAM wParam, LPARAM lParam);
	void WM__MOUSEWHEEL(WPARAM wParam, LPARAM lParam); //void fill_form_mes_by_offer(); //void ViewFormMes();
	void fill_combo_car_agent_add(FldsPtr fp);
	void OnSelStopOnMap(int index_stop);
	void WM__DRAWITEM(WPARAM wParam, LPARAM lParam);
	void CallPaint();
	void SelCarsToList();
	void ReadMes();
	void ShowMes_add(FldsPtr fp);
	void SetReadMes() {m_f_readMes = true;}
};

void CMap_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState);

#endif