#include <memory.h>
#include <time.h>
#include "car_zone.h"  
#include "..\\transman\\mssql.h"
#include "MesWnd.h"
#include "draw_ate_3.h"

void CCarZone_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState) { gMesWnd.Mes("CCarZone. ������ MS SQL : %s", sz_text); }

CCarZone::CCarZone()
{
/*	m_fInit=false;
	
	memset(this, 0, sizeof(CCarZone));
	
	m_fInit=true;*/
}

CCarZone::~CCarZone()
{
	
}

DWORD WINAPI CCarZone_ThreadProc(LPVOID lpParameter)
{
	CCarZone *p_this = (CCarZone*)lpParameter;

	if (p_this == 0) { return 0; }

	while (1)
	{
		if (p_this->Exec()) { }

		Sleep(200);
	}

	return 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool CCarZone::Open()
{
	//if (m_fInit == false) { return false; }

	DWORD dThreadId;

	HANDLE h = CreateThread(0, 0, CCarZone_ThreadProc, (LPVOID)this, 0, &dThreadId);

	return h != 0;
}

void CCarZone_read(void *p_param, FldsPtr fp)
{		
	_bstr_t bstr_id_car_zone(fp->Item["id_car_zone"]->Value);
	_bstr_t bstr_dt(fp->Item["dt"]->Value);
	_bstr_t bstr_device_number(fp->Item["device_number"]->Value);
	_bstr_t bstr_zone_name(fp->Item["zone_name"]->Value);
	 VARIANT v_f_in= fp->Item["f_in"]->Value;

	gMesWnd.MesB("%s ������ '%s' %s '%s'", (char*)bstr_dt, (char*)bstr_device_number, v_f_in.boolVal ? "������ � ����" : "����� �� ����", (char*)bstr_zone_name);

	std_string sz_query = "UPDATE dbo.car_zones SET f_hide=1 WHERE id_car_zone="; sz_query.append((char*)bstr_id_car_zone);

	bool f_exec = MSSQL_Exec((char*)sz_query.c_str(), 0, CCarZone_FN_MSSQL_MES_ERR, p_param);
	if (f_exec == false)
	{
		gMesWnd.Mes("CCarZone_read(). ������");
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool CCarZone::Exec()
{
	/*std_string sz_query = "DECLARE @t AS TABLE(id_car_zone BIGINT)\r\n";
	sz_query.append("INSERT @t(id_car_zone) SELECT TOP 10 id_car_zone FROM dbo.car_zones cz WHERE cz.f_hide=0 ORDER BY ISNULL(cz.dt_updated, cz.dt_created)\r\n");
	sz_query.append("UPDATE dbo.car_zones SET f_hide=1 WHERE id_car_zone IN (SELECT id_car_zone FROM @t)\r\n");
	sz_query.append("SELECT ISNULL(cz.dt_updated, cz.dt_created)dt, c.device_number, z.name, f_in FROM dbo.car_zones cz, dbo.ate_3 c, dbo.zones z WHERE cz.id_ate_3=c.id_ate_3 AND cz.id_zone=z.id_zone AND cz.id_car_zone IN (SELECT id_car_zone FROM @t);\r\n");
 */
	std_string sz_query;

	/*int q = gVisibleCars.size();

	if (q)
	{
		std_string sz_filter="";
		for (int i = 0; i < q; i++)
		{
			SDeviceATE_3& o = gVisibleCars[i];

			if (i) { sz_filter.append(","); }
			sz_filter.append("'");
			sz_filter.append(o.name);
			sz_filter.append("'");
		}
		sz_query = "SELECT id_car_zone, ISNULL(cz.dt_updated, cz.dt_created)dt, c.device_number, z.name zone_name, f_in FROM dbo.car_zones cz, dbo.ate_3 c, dbo.zones z WHERE cz.f_hide=0 AND cz.id_ate_3=c.id_ate_3 AND cz.id_zone=z.id_zone\r\n";

		sz_query.append(" AND c.device_number IN (\r\n");
		sz_query.append(sz_filter);
		sz_query.append(") \r\n");

		sz_query.append("ORDER BY ISNULL(cz.dt_updated, cz.dt_created) ASC\r\n");
	}
	else*/
	
	sz_query = "SELECT TOP 15 id_car_zone, ISNULL(cz.dt_updated, cz.dt_created)dt, c.device_number, z.name zone_name, f_in FROM dbo.car_zones cz, dbo.ate_3 c, dbo.zones z WHERE cz.f_hide=0 AND cz.id_ate_3=c.id_ate_3 AND cz.id_zone=z.id_zone ORDER BY ISNULL(cz.dt_updated, cz.dt_created) ASC";
	

	bool f_exec = MSSQL_Exec((char*)sz_query.c_str(), CCarZone_read, CCarZone_FN_MSSQL_MES_ERR, (void*)this);
	if (f_exec == false)
	{
		gMesWnd.Mes("CCarZone::Exec(). ������ MS SQL");
	}

	return true;
}



CCarZone gCarZone;