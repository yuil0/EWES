#include <memory.h>
#include <windows.h>
#include <atlbase.h> 
#include <atlstr.h>
#include <Shobjidl.h>

#include "ms_inet.h"
#include "ini_file.h"
#include "MesWnd.h"
#include "window.h"

/*#ifdef DEF_BROWSER_MS_EDGE
const char *csz_start_microsoft_edge = "microsoft-edge:"; //start 
const int ci_len_start_microsoft_edge = strlen(csz_start_microsoft_edge);
#endif*/

CMSInet::CMSInet()
{
	memset(this, 0, sizeof(CMSInet));
	
	m_fInit=true;
}

CMSInet::~CMSInet() {}

char* GetMapAddr(char* sz_addr)
{
		char sz_val[MAX_PATH + 1];

		CIniFile cIniFile;

		std_string sz_zoom;
		std_string sz_map_server;
		if (cIniFile.Get("C:\\transman\\transman.ini", "zoom", sz_val, MAX_PATH + 1) == false) { return 0; }
		sz_zoom=sz_val;
		if (cIniFile.Get("C:\\transman\\transman.ini", "map_server", sz_val, MAX_PATH + 1) == false) { return 0; }
		sz_map_server=sz_val;


		sprintf(sz_addr,  "%s#map=%s/47.22276/39.71884&layer=H", sz_map_server.c_str(), sz_zoom.c_str());

		return sz_addr;
}

bool CMSInet::Open(HINSTANCE hInstance)
{
 char sz_addr[MAX_PATH + 1]={0};

	int i_shift=0;

	if (GetMapAddr(sz_addr + i_shift)==0) {gMesWnd.Mes("������ ������ �����");}

 //#ifdef DEF_BROWSER_MS_EDGE
	//i_shift = ci_len_start_microsoft_edge; //strcpy(sz_addr, csz_start_microsoft_edge);
	//#endif

	
	HRESULT hr;

 //#ifndef DEF_BROWSER_MS_EDGE		

	try
	{
		hr = CoInitialize(0);

		hr = m_browser.CreateInstance(__uuidof(SHDocVw::InternetExplorer));
		
		m_browser->AddressBar = VARIANT_FALSE; // FALSE;		

		m_browser->StatusBar = VARIANT_FALSE;

		m_browser->Visible = VARIANT_TRUE;
		
		hr = m_browser->Navigate(sz_addr);
	}
	catch (_com_error &e) {	return false; }
	/*//#endif

	//#ifdef DEF_BROWSER_MS_EDGE
	HRESULT hr = E_FAIL;

	hr = CoInitialize(NULL);
	
	CComPtr<IApplicationActivationManager> activationManager;

	LPCWSTR edgeAUMID = L"Microsoft.MicrosoftEdge_8wekyb3d8bbwe!MicrosoftEdge"; //LPCWSTR edgeAUMID = L"Microsoft.Windows.Spartan_cw5n1h2txyewy!Microsoft.Spartan.Spartan";

	hr = CoCreateInstance(CLSID_ApplicationActivationManager, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&activationManager));

	if (SUCCEEDED(hr))
	{
	 DWORD newProcessId;

		wchar_t wz_addr[MAX_PATH + 1]={0};

  mbstowcs(wz_addr, sz_addr, MAX_PATH);

	 hr = activationManager->ActivateApplication(edgeAUMID, wz_addr, AO_NONE, &newProcessId);
	}
	else { }

	int i_res = (int)ShellExecuteA(0, sz_addr, 0, 0, 0, SW_SHOW);//WinExec(sz_addr, SW_SHOW);
	
	ERROR_FILE_NOT_FOUND;
	SE_ERR_SHARE;

	f_res = i_res > 32;*	
 SHELLEXECUTEINFOA sei;
	memset(&sei, 0, sizeof(SHELLEXECUTEINFO));

	sei.cbSize= sizeof(SHELLEXECUTEINFO);
	sei.lpVerb= "open";
	sei.lpFile= sz_addr;
	sei.hInstApp = hInstance;
	sei.nShow = SW_SHOW;

	f_res = ShellExecuteExA(&sei)==TRUE; 

	if (f_res)
	{ //sei.hProcess //DWORD lpdwProcessId
	}

 #endif*/

	return hr == S_OK;
}

bool CMSInet::Close(char *sz_part_text)
{
	//#ifndef DEF_BROWSER_MS_EDGE
	if (m_browser == NULL) { return false; }
	
	HRESULT hr = S_FALSE;

	try
	{
		hr = m_browser->Quit();
		m_browser = NULL;
	}
	catch (_com_error &e) { }

	return hr == S_OK;
	/*#endif

 //#ifdef DEF_BROWSER_MS_EDGE	
	HWND hWnd = find_window(sz_part_text, "TabWindowClass");

	CloseWindow(hWnd);
	DestroyWindow(hWnd);

	return true; //hWnd!=0;
	#endif*/
}

bool CMSInet::GetHWND(HWND& hWnd, char *sz_part_text)
{
	//#ifndef DEF_BROWSER_MS_EDGE
	if (m_browser == NULL) { return false; }

	bool fRes = false;

	try
	{
		hWnd = (HWND)m_browser->HWND;
		fRes = true;
	}
	catch (_com_error &e) {}

	return fRes;
	/*#endif

 #ifdef DEF_BROWSER_MS_EDGE		
	/*hWnd = find_window(0, "Frame Tab");

	HWND hwndChild= find_child_window(hWnd, sz_part_text, "TabWindowClass");
	
	S_find_child_window_param s_param;
	s_param.sz_class = "TabWindowClass";
	s_param.sz_part_text = sz_part_text;

	HWND hwnd = find_child_window(s_param);  //
	

	return 0; //hWnd!=0;
	#endif*/
}

HWND CMSInet::GetHWND(char *sz_part_text)
{
	//#ifndef DEF_BROWSER_MS_EDGE
	if (m_browser == NULL) { return 0; }

	try { return (HWND)m_browser->HWND; } catch (_com_error &e) {}

	return 0;
	/*#endif

 #ifdef DEF_BROWSER_MS_EDGE	
	HWND hwnd = find_window(sz_part_text, "TabWindowClass");
	return hwnd;
	#endif*/
}

bool CMSInet::GetLocationURL(wchar_t *wszLocationURL, int i_size_URL, char *sz_part_text)
{
	bool fRes = false;

	//#ifndef DEF_BROWSER_MS_EDGE

	if (m_browser == NULL) { return false; }

	try {lstrcpy(wszLocationURL,  m_browser->LocationURL); fRes = true; } catch (_com_error &e) { }
 /*#endif
	
 #ifdef DEF_BROWSER_MS_EDGE	
	HWND hwnd = find_window(sz_part_text, "TabWindowClass");
	if (hwnd)
	{
		int i_len  = GetWindowTextW(hwnd, wszLocationURL, i_size_URL);

		fRes = i_len!=0;
	}
	#endif*/

	return fRes;	
}

bool MSInet_Open(char *sz_addr, bool f_top, void** p_browser) //, char *sz_caption
{
	if (strlen(sz_addr) == 0) { return  false; }
	
	//#ifndef DEF_BROWSER_MS_EDGE
	HRESULT hr;
	
	BrowserPtr m_browser;

	try
	{
		hr = CoInitialize(0);

		hr = m_browser.CreateInstance(__uuidof(SHDocVw::InternetExplorer));

		if (hr == S_OK)
		{
			m_browser->AddressBar = VARIANT_FALSE; // FALSE;		
			m_browser->StatusBar = VARIANT_FALSE;
			m_browser->Visible = VARIANT_TRUE;

			hr = m_browser->Navigate(sz_addr);			
			
			if (f_top) { SetWindowLong((HWND)m_browser->HWND, GWL_EXSTYLE, WS_EX_TOPMOST);  }

			if (p_browser) { *p_browser = (void*)m_browser; }
		}
	}
	catch (_com_error &e) {	}

	return hr == S_OK;
	/*#endif

	#ifdef DEF_BROWSER_MS_EDGE
	int i_res = WinExec(sz_addr, SW_SHOW);

	return i_res > 31;
 #endif*/
}
