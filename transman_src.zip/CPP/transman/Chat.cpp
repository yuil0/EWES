#include <memory.h>
#include "main.h"
#include "chat.h"

#include "BookMarks.h"
#include "login_wnd.h"
#include "ini_file.h"
#include "MesWnd.h"

const int cl_chat_ident_from_left=5;

const char* csz_chat_mes_type[ECMT_QUANTITY_MES_TYPE] =
{
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6"
};

/*const int ci_mnemo_scheme_pen_path_width=20;
const int ci_mnemo_scheme_pen_path_solid_width=2;
const int cl_mnemo_scheme_ctrl_r_len=195;*/

CChat::CChat() {}

CChat::~CChat() {}

bool CChat::Open(HINSTANCE hInstance, HWND hwndParent, int w, int h, RECT& rcParent)
{
	memset(this, 0, sizeof(CChat)); //m_hwndParent = hwndParent;

	m_i_sizeMesPack = 50;

	m_wnd_size.x= w; m_wnd_size.y= h;

	m_rcParent = rcParent;
	
	cr_m_gdi_obj(); 
	
	m_hwndParent = hwndParent;
	
	CrControls(hInstance, hwndParent); 

	CrProxyWnd();

	m_fInit=true;

	return m_fInit;
}

void CChat::Close()
{
	m_waitIndicator.Close();

	del_m_gdi_obj();

	m_ctrls.Destroy();

	m_proxy_wnd.Destroy();
}


void CChat::cr_m_gdi_obj()
{
	m_gdi_obj[ECGDIO_PEN_DEVIDER]=CreatePen(PS_SOLID, 0, 0x0);
	m_gdi_obj[ECGDIO_BRUSH_WHITE]=CreateSolidBrush(0xFFFFFF);
	m_gdi_obj[ECGDIO_PEN_WHITE]=CreatePen(PS_SOLID, 0, 0xFFFFFF);
	
}

void CChat::del_m_gdi_obj()
{
	for (int i=0; i<(int)ECGDIO_QUANTITY; i++)
	{
		DeleteObject(m_gdi_obj[i]);
	}
}

void CChat::SetUserType(EUserType eNew) 
{ 
	m_eUserType = eNew; 
}

void CChat::CrControls(HINSTANCE hInstance, HWND hwndParent)
{
	SWinCtrlParam wcp;
	wcp.Clear();
	wcp.hInstance = hInstance;
	wcp.hwndParent = hwndParent;
	wcp.wCtrl = 70;
	wcp.hCtrl = 22;
	wcp.ident = 5;
	wcp.xOrigin = cl_chat_ident_from_left;

	SBookMarksParams& bm_params = gBookMarks.GetParams();

	wcp.yOrigin = bm_params.i_height + cl_chat_ident_from_top; //wcp.fHide=true;
	m_ctrls.Init(wcp);

	EUserType eUserType = gLoginWnd.GetUserType();

	if (eUserType == EUT_DISP_HI)
	{
		CrControls_disp_hi(); //m_index_start_disp = m_ctrls.GetSize();
	}
	else
	{
		CrControls_disp();
	}                     //m_index_start_common = m_ctrls.GetSize();

	CrControls_common();
	
	m_ctrls.Update(); //m_ctrls.SetFocusActive();
}

void CChat::Tab()
{
	m_ctrls.NextFocusActive();
}

void CChat::StartFill()
{
		if (m_eUserType==EUT_DISP_HI)
	{
	 fill_combo_new_coll_disp();

	 fill_combo_bind_coll();

		fill_combo_show_coll();
		set_refresh(false);
	}else
	if (m_eUserType==EUT_DISP)
	{
	 fill_combo_disp_coll();

	 fill_combo_disp_templ_mes();

		set_refresh(true);
	}
}

void CChat::CrControls_disp_hi()
{
	CrControls_disp_hi_new_disp();

	CrControls_disp_hi_new_coll();

	CrControls_disp_hi_bind();

	CrControls_disp_hi_show();
}

void CChat::CrControls_disp_hi_new_disp()
{
	SCtrl ctrl;

	ctrl.Clear();
	ctrl.name = "static_new_disp";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����� ���������:";
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 3;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);		
	
	ctrl.Clear();
	ctrl.name = "static_new_disp_name";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "edit_new_disp_name";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT;
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_new_disp");

	ctrl.Clear();
	ctrl.name = "static_new_disp_psw";
	ctrl.classWnd = "static";
	ctrl.textWnd = "������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "edit_new_disp_psw";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT | ES_PASSWORD;
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_new_disp_psw");

	ctrl.Clear();
	ctrl.name = "but_new_disp";
	ctrl.classWnd = "button";
	ctrl.textWnd = "��������";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl); 

}

int CChat::Get_x_step_gr(int q_gr)
{
	win_e::SMonitors& mon= gMonitors;

	return mon.rc[1].right/q_gr; //ci_chat_ctrls_group
}

void CChat::Ctrls_set_origin(CWinCtrl& ctrls, int index_gr, int q_gr)
{
	int x_step = Get_x_step_gr(q_gr);

	int x= index_gr * x_step; //m_list_x_ctrls[index_gr]= x;

	SBookMarksParams& bm_params = gBookMarks.GetParams();

	ctrls.SetOrigin(x, bm_params.i_height + cl_chat_ident_from_top);
}

void CChat::CrControls_disp_hi_new_coll()
{
	SCtrl ctrl;

	Ctrls_set_origin(m_ctrls, 1, ci_chat_ctrls_group); //m_ctrls.NewRow(); //m_ctrls.NewRow();

	ctrl.Clear();
	ctrl.name = "static_new_coll";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����� ���������:";
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 3;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "static_new_coll_name";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "edit_new_coll_name";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT;
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_new_coll");

	ctrl.Clear();
	ctrl.name = "static_new_coll_psw";
	ctrl.classWnd = "static";
	ctrl.textWnd = "������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "edit_new_coll_psw";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT | ES_PASSWORD;
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_new_coll");

	ctrl.Clear();
	ctrl.name = "static_new_coll_disp";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "combo_new_coll_disp";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.4;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_new_coll_disp");

	ctrl.Clear();
	ctrl.name = "but_new_coll";
	ctrl.classWnd = "button";
	ctrl.textWnd = "��������";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

}


void CChat::CrControls_disp_hi_bind()
{
	SCtrl ctrl;

	Ctrls_set_origin(m_ctrls, 2, ci_chat_ctrls_group); //m_ctrls.NewRow(); //m_ctrls.NewRow();

	ctrl.Clear();
	ctrl.name = "static_bind";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�����:";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "static_bind_disp";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "combo_bind_disp";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.4;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_bind");

	ctrl.Clear();
	ctrl.name = "static_bind_coll";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "combo_bind_coll";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.4;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_bind_coll");

	ctrl.Clear();
	ctrl.name = "but_bind";
	ctrl.classWnd = "button";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);
}



void CChat::CrControls_disp_hi_show()
{
	SCtrl ctrl;

	Ctrls_set_origin(m_ctrls, 3, ci_chat_ctrls_group); //m_ctrls.NewRow(); //m_ctrls.NewRow();

	ctrl.Clear();
	ctrl.name = "static_show";
	ctrl.classWnd = "static";
	ctrl.textWnd = "��������:";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "static_show_disp";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 2.4;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "static_show_list_coll";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����������";
	ctrl.mul_w = 2.4;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	m_ctrls.NewRow("static_show");

	ctrl.Clear();
	ctrl.name = "combo_show_disp";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.4;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "list_show_coll";
	ctrl.classWnd = "listbox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | WS_VSCROLL | LBS_NOSEL;
	ctrl.mul_w = 2.4;
	ctrl.mul_h = 3;
	m_ctrls.Add(ctrl);

	/*ctrl.Clear();
	ctrl.name = "but_show_coll_by_coll";
	ctrl.classWnd = "button";
	ctrl.textWnd = "�� ����������";
	ctrl.styleAdd = BS_CHECKBOX;
	ctrl.mul_w = 1.9;
	m_ctrls.Add(ctrl); */

	/*m_ctrls.NewRow("static_show");

	ctrl.Clear();
	ctrl.name = "static_show_coll";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "combo_show_coll";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.4;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);*/

	m_ctrls.NewRow("static_show");
	m_ctrls.NewRow("static_show");
	

	ctrl.Clear();
	ctrl.name = "but_show";
	ctrl.classWnd = "button";
	ctrl.textWnd = "��������";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);
}



void CChat::CrControls_disp()
{
	m_ctrls.SetMaxX(0);
	Ctrls_set_origin(m_ctrls, 0, ci_chat_ctrls_group);

	SCtrl ctrl;

	ctrl.Clear();
	ctrl.name = "static_disp_coll";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "combo_disp_coll";
	ctrl.classWnd = "combobox";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.4;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow();

	ctrl.Clear();
	ctrl.name = "static_disp_templ_mes";
	ctrl.classWnd = "static";
	ctrl.textWnd = "������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "combo_disp_templ_mes";
	ctrl.classWnd = "combobox";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.4;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);

	Ctrls_set_origin(m_ctrls, 1, ci_chat_ctrls_group);

	ctrl.Clear();
	ctrl.name = "edit_disp_mes";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | ES_MULTILINE | WS_VSCROLL;
	ctrl.mul_w = 9;
	ctrl.mul_h = 3;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_send_coord_request";
	ctrl.classWnd = "button";
	ctrl.textWnd = "������ ���������";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_send_go_coord";
	ctrl.classWnd = "button";
	ctrl.textWnd = "��� � �����������";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);
	
	Ctrls_set_origin(m_ctrls, 2, ci_chat_ctrls_group);

	/*ctrl.Clear();
	ctrl.name = "static_new_mes";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����� ���������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	*/

	ctrl.Clear();
	ctrl.name = "but_send_new_mes";
	ctrl.classWnd = "button";
	ctrl.textWnd = "�������";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_send_new_mes_all_group";
	ctrl.classWnd = "button";
	ctrl.textWnd = "������� ������";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_send_new_mes_all";
	ctrl.classWnd = "button";
	ctrl.textWnd = "������� ����";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

}

void CChat::CrControls_common()
{
 //m_index_start_common
	m_ctrls.SetMaxX(0);
	
	int y_max=m_ctrls.GetStatMaxY();

	m_ctrls.SetOrigin(0, y_max);

	m_ctrls.NewRow();
	m_ctrls.NewRow();

	SCtrl ctrl;

	ctrl.Clear();
	ctrl.name = "but_refresh";
	ctrl.classWnd = "button";
	ctrl.textWnd = "���������";
	ctrl.styleAdd = BS_CHECKBOX;
	ctrl.mul_w = 1.4;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_size_mes_pack_inc";
	ctrl.classWnd = "button";
	ctrl.textWnd = "������ ���������";
	ctrl.mul_w = 2.2;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_size_mes_pack_dec";
	ctrl.classWnd = "button";
	ctrl.textWnd = "������ ���������";
	ctrl.mul_w = 2.2;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_SIP_client";
	ctrl.classWnd = "button";
	ctrl.textWnd = "SIP ������";
	ctrl.styleAdd = BS_CHECKBOX;
	ctrl.mul_w = 1.4;
	m_ctrls.Add(ctrl);
}

void CChat::set_but_refresh(bool fCheck)
{
	set_check_box("but_refresh", fCheck);	
}

void CChat::set_check_box(char  *sz_checkbox, bool fCheck)
{
	m_ctrls.SendMes(sz_checkbox, BM_SETCHECK, (WPARAM)(fCheck ? BST_CHECKED : BST_UNCHECKED), (LPARAM)0);
}

bool CChat::get_check_box(char  *sz_checkbox)
{
	return m_ctrls.SendMes(sz_checkbox, BM_GETCHECK, (WPARAM)0, (LPARAM)0)==BST_CHECKED;
}

void CChat::set_refresh(bool f)
{
	m_f_refresh = f;

 set_but_refresh(f);
}

void CChat::refresh_op()
{
	m_f_refresh = m_f_refresh ? false : true;

 set_but_refresh(m_f_refresh);		
}

void CChat::Show(bool fShow)
{
	/*CWinCtrl::SIndexRange sRange;

	std::vector<CWinCtrl::SIndexRange> list_range;

	if (m_eUserType==EUT_DISP_HI)
	{
		sRange.index_from=0;

		sRange.index_to= m_index_start_disp - 1;
	}else
	if (m_eUserType==EUT_DISP)
	{
		sRange.index_from= m_index_start_disp;

		sRange.index_to= m_index_start_common-1; //m_ctrls.GetSize()-1;
	}

	list_range.push_back(sRange);

	//<common
	sRange.index_from= m_index_start_common;

	sRange.index_to= m_ctrls.GetSize()-1;

	list_range.push_back(sRange);
	//>common*/

	m_ctrls.ShowAll(fShow); //, &list_range

	m_ctrls.Update(); //Sleep(50);
}

void CChat::OnCmd(int id, int notify)
{
	SCtrl* p_ctrl;
	
	if (m_ctrls.Find(id, &p_ctrl))
	{
		
		if (p_ctrl->name == "but_new_disp")
		{
			CrNewDisp();
		}else
		if (p_ctrl->name == "but_new_coll")
		{
			CrNewColl();
		}else
		if (p_ctrl->name == "but_bind")
		{
			Bind();
		}else
		if (p_ctrl->name == "combo_show_disp")
		{
			if (notify == CBN_SELCHANGE)
			{			
				fill_combo_show_coll(); 
			}
		}else
		if (p_ctrl->name == "but_show")
		{
			ShowMes();
		}else
		if (p_ctrl->name == "combo_disp_templ_mes")
		{
			if (notify == CBN_SELCHANGE)
			{			
				set_edit_disp_mes_by_combo("combo_disp_templ_mes");
			}
		}else
		if (p_ctrl->name == "but_send_new_mes")
		{
			but_send_new_mes("1");
		}else
		if (p_ctrl->name == "but_send_new_mes_all_group")
		{
			ESendMesMode eMode = ESMM_ALL_IN_GROUP;

			but_send_new_mes("1", eMode);
		}
		else
		if (p_ctrl->name == "but_send_new_mes_all")
		{
			ESendMesMode eMode = ESMM_ALL;

			but_send_new_mes("1", eMode);
		}else
		if (p_ctrl->name == "but_send_coord_request")
		{
			but_send_new_mes("4");
		}else
		if (p_ctrl->name == "but_send_go_coord")
		{
			but_send_new_mes("5");
		}else
		if (p_ctrl->name == "combo_disp_coll")
		{
			if (notify == CBN_SELCHANGE)
			{			
				CloseDestroyBrowserWnd();
			}
		}else
		if (p_ctrl->name == "but_size_mes_pack_inc")
		{
			ChSizeMesPack(true);
		}else
		if (p_ctrl->name == "but_size_mes_pack_dec")
		{
			ChSizeMesPack(false);
		}
		else
		if (p_ctrl->name == "but_refresh")
		{
			refresh_op();
		}
		else
		if (p_ctrl->name == "but_SIP_client")
		{
			but_SIP_client();
		}		
	}
}

void CChat::but_SIP_client(E_but_SIP_client e)
{
	if (e == EBSIPC_CLICK)
	{
		bool fCheck;

		m_ctrls.OpCheckbox("but_SIP_client", &fCheck);		

		Show_SIP_client(fCheck);
	}
}

void CChat::Close_SIP_client_op()
{
	TerminateProcessByClass("MicroSIP"); //

	ShowProxyWnd(EPWM_SHOW);
}

void CChat::Close_SIP_client()
{
	m_ctrls.SetCheckbox("but_SIP_client", false);
	
	Close_SIP_client_op();
}

void CChat::Show_SIP_client(bool fShow)
{
	if (fShow)
	{
		char sz_val[MAX_PATH + 1]; //SIP_client

		CIniFile ini;

		if (ini.Get("c:\\transman\\transman.ini", "SIP_client", sz_val, MAX_PATH))
		{
			WinExec(sz_val, SW_SHOW);
			Sleep(200);

			HWND hwnd = FindWindowA("MicroSIP", 0);
			if (hwnd)
			{
				POINT pos, size;
				GetNeedPosSize(pos, size);
				MoveWindow(hwnd, pos.x, pos.y, size.x, size.y, TRUE);

				win_e::RemoveWndStyle(hwnd, WS_CAPTION);
			}

			ShowProxyWnd(EPWM_HIDE);
		}
		else
		{ gMesWnd.Mes("CChat::but_SIP_client(). �� ���� ���� � SIP ������� � ini"); }		
	}
	else
	{
		Close_SIP_client_op();
	}
}

void CChat::MesErrSIP_Name()
{
	gMesWnd.Mes("CChat::MesErrSIP_Name(). ������ ��� SIP");
}

void CChat::CallPhone(char *sip_name)
{
	if (sip_name == 0) { MesErrSIP_Name(); return; }
	if (strlen(sip_name) == 0) { MesErrSIP_Name(); return; }

	char sz_val[MAX_PATH + 1]; //SIP_client

	CIniFile ini;

	if (ini.Get("c:\\transman\\transman.ini", "SIP_client", sz_val, MAX_PATH))
	{
		add_str(sz_val, MAX_PATH, " ");
		add_str(sz_val, MAX_PATH, sip_name);

		WinExec(sz_val, SW_SHOW);
		Sleep(200);
		/*
		HWND hwnd = FindWindowA("MicroSIP", 0);
		if (hwnd)
		{
		POINT pos, size;
		GetNeedPosSize(pos, size);
		MoveWindow(hwnd, pos.x, pos.y, size.x, size.y, TRUE);

		win_e::RemoveWndStyle(hwnd, WS_CAPTION);
		}*/


	}
	else
	{
		gMesWnd.Mes("CChat::CallPhone(). �� ������ ���� � SIP ������� � ini");
	}
}



void CChat::PaintDevider(HDC hdc, int x, int h_fix)
{
	SBookMarksParams& bm_params = gBookMarks.GetParams();

	//<q1 ctrls devider r
	int y = bm_params.i_height + cl_chat_ident_from_top;
	int h = ci_chat_ctrls_max_y + h_fix; //m_ctrls.GetStatMaxY(); //m_wnd_size.y;

	SelectObject(hdc, m_gdi_obj[ECGDIO_PEN_DEVIDER]);

	MoveToEx(hdc, x, y, 0); LineTo(hdc, x, y + h);
	//>q1
}

void CChat::Paint(HDC hdc)
{
	if (m_eUserType==EUT_DISP_HI)
	{
		/*PaintDevider(hdc, 440, -80);
		PaintDevider(hdc, 860);
		PaintDevider(hdc, 1280);*/
	}else
	if (m_eUserType==EUT_DISP)
	{
	}
}


void CChat::SetEditMes(Leaflet::LatLng& latlng)
{
	char sz_val[MAX_PATH + 1];
	sprintf(sz_val, "%g:%g", latlng.lat, latlng.lng);
	m_ctrls.SendMes("edit_disp_mes", WM_SETTEXT, (WPARAM)0, (LPARAM)sz_val);
}
