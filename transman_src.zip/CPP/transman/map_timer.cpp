#include <memory.h>
#include <windows.h>
#include "map_timer.h"
#include "main.h"
#include "MesWnd.h"
#include "BookMarks.h"

const char *csz_file_class_name = "class_name.txt\0";
const int ciElapsed = 5; //ms
const time_t ctime_mouse_interval_event = 100; //ms
const time_t ctime_mouse_interval_no_event = 10; //ms

CMapTimer::CMapTimer() {}

CMapTimer::~CMapTimer() {}

void CMapTimer::Clear() { memset(this, 0, sizeof(CMapTimer)); }

//DWORD WINAPI CMapTimer_th_proc(LPVOID lpThreadParameter) //
void CALLBACK TIMERPROC_fn(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime) //dwTime : elapsed since the system was started
{
		gMapTimer.TimerFn();

		//Sleep(ciElapsed);
	
}

bool CMapTimer::Open()
{
	Clear();

	unlink(csz_file_class_name);
	
	//CreateThread(0, 0, CMapTimer_th_proc,  this, 0, 0); //
	SetTimer(gWndMain.GetHWND(), 1, ciElapsed, TIMERPROC_fn); //Sleep(2000);EncourageEventSizeMapWnd();

	return true;
}

bool CMapTimer::Close()
{
	KillTimer(gWndMain.GetHWND(), 1);

	return true;
}


BOOL CALLBACK EnumChildWndFunc(HWND hwnd, LPARAM lParam)
{
	CMapTimer* p_this = (CMapTimer*)lParam;

	/*
	if (p_this) { p_this->CheckChildWnd(hwnd); }	
	return 1;*/
	if (IsWindow(hwnd) == FALSE) { return FALSE; }
	
	if (IsWindowVisible(hwnd) == FALSE) { return TRUE; }	

	RECT rc;
	if (GetWindowRect(hwnd, &rc) == FALSE) { return FALSE; }

	POINT pointMouse;

	if (GetCursorPos(&pointMouse) == FALSE) { return FALSE; }

	BOOL  fIn = PtInRect(&rc, pointMouse);

	if (fIn) 
	{ 
		SChieldWnd sChield;
		
		sChield.hWnd = hwnd;
		
		sChield.rc = rc;

		sChield.dClassStyle = GetClassLong(hwnd, GCL_STYLE);                               //UINT uLenWinType = RealGetWindowClass(m_hWnd_Child, m_wszChildWndType, MAX_PATH);

		int iLenClassName = GetClassName(hwnd, sChield.wszChildClassName, MAX_PATH);

		int iLenWndtext = GetWindowText(hwnd, sChield.wszChildWndText, MAX_PATH);

		p_this->AddChield(sChield); //p_this->Set_hWnd_Child(hwnd); 

		p_this->SetMousePoint(pointMouse);
	}

	return TRUE; // !fIn;
}

void CMapTimer::CheckChildWnd(HWND hwnd)
{

}

bool CMapTimer::GetChildWndWithMouse(HWND hParent_hWnd)
{
	m_hWnd_Child = (HWND)0;
	
	m_ListChield.clear();

	(hParent_hWnd, EnumChildWndFunc, (LPARAM)this);

	return m_ListChield.size();
}

/*
HWND CMapTimer::GetTopChildWnd(HWND hParent_hWnd)
{
	m_child_top_hWnd = (HWND)0;

	EnumChildWindows(hParent_hWnd, EnumChildWndFunc, (LPARAM)this);

	return m_child_top_hWnd;
}
*/

void CMapTimer::AddChield(const SChieldWnd& sNew)
{
	m_ListChield.push_back(sNew);
}

bool CMapTimer::ConvertPointToClient(HWND hWnd, const POINT& pnScr, POINT& pnClient)
{
	if (IsWindow(hWnd) == FALSE) { return false; }

	RECT rc;
	RECT crc;

	if (GetWindowRect(hWnd, &rc) == FALSE) { return false; }

	if (GetClientRect(hWnd, &crc) == FALSE) { return false; }

	int iThick = ((rc.right - rc.left) - (crc.right - crc.left)) / 2;
	int iCaption = ((rc.bottom - rc.top) - (crc.bottom - crc.top)) - iThick;

	pnClient = pnScr;

	pnClient.x -= rc.left + iThick;
	pnClient.y -= rc.top + iCaption;

	return true;
}

void CMapTimer::DrawOnPoint(HWND hWnd, const POINT& pn)
{
	HDC hdc = GetDC(hWnd);

	int iRad = 50;

	HGDIOBJ hRes=SelectObject(hdc, (HPEN)GetStockObject(BLACK_PEN));
	
	if (hRes == HGDI_ERROR || hRes == 0) { return; }

	hRes =SelectObject(hdc, (HBRUSH)GetStockObject(BLACK_BRUSH));

	if (hRes == HGDI_ERROR || hRes == 0) { return; }

	int iRes = Rectangle(hdc, pn.x - iRad, pn.y - iRad, pn.x + iRad, pn.y + iRad); //Ellipse

	ReleaseDC(hWnd, hdc);

	UpdateWindow(hWnd);
}

void CMapTimer::AddTextWndFromPoint(wchar_t *wsz_text)
{
	POINT Point;
	if (GetCursorPos(&Point) == FALSE) { return; }

	HWND hWnd = WindowFromPoint(Point);
	if (hWnd == 0) { return; }

	wchar_t wszClassName[MAX_PATH + 1];
	int iRes=GetClassName(hWnd, wszClassName, MAX_PATH);
	if (iRes==0) { return; }

	lstrcat(wsz_text, L" class:'"); lstrcat(wsz_text, wszClassName); lstrcat(wsz_text, L"'");
	
	FILE *fo = 0;
	fopen_s(&fo, csz_file_class_name, "ab");
	char szClassName[MAX_PATH + 1];	
	static char szClassNamePrev[MAX_PATH + 1]="\0";
	if (fo)
	{
		if (GetClassNameA(hWnd, szClassName, MAX_PATH))
		{
			if (strcmp(szClassNamePrev, szClassName))
			{
				fprintf(fo, "%s%c%c", szClassName, 13, 10);
				strcpy(szClassNamePrev, szClassName);
			}			
		}
		
		fclose(fo);
	}		
}

void CMapTimer::AddTextLocationURL(wchar_t *wsz_text)
{
	//wchar_t wszLocationURL[MAX_PATH + 1];

	lstrcat(wsz_text, L" LocationURL: ");

	if (lstrlen(g_wz_map_addr)) 
	{
		lstrcat(wsz_text, g_wz_map_addr);
	}
	else
	{
		lstrcat(wsz_text, L"error");
	}

}

void CMapTimer::AddCaptionText(wchar_t *wsz_text, wchar_t *wsz_title, int iVal)
{
	lstrcat(wsz_text, wsz_title);

	wchar_t wcs_param[MAX_PATH+1];

	_itow(iVal, wcs_param, 10);
		
	lstrcat(wsz_text, wcs_param);
}

void CMapTimer::SetCaptionText()
{
	wchar_t wsz_text[MAX_PATH + 1];

	if (g_i_user_interface==0)
	{
		lstrcpy(wsz_text, L"transman "); //AddCaptionText(wsz_text, L" LEFT_BUTTON: ", m_iCntClickLBut); //wsprintf(wsz_text, L"%04d", m_iCntClickLBut);  //wsprintf(wsz_text, L"pointMouse:{%04d %04d}", pointMouse.x, pointMouse.y);   //

		AddTextLocationURL(wsz_text);
	
		SPointInt cm = gDrawWnd.GetClientMouse();

		AddCaptionText(wsz_text, L" client_mouse: ", cm.x);
		AddCaptionText(wsz_text, L" ", cm.y);

		POINT ptMouse;

		if (GetCursorPos(&ptMouse) == false) { return; }

		//<q1
		HWND hwnd = WindowFromPoint(ptMouse);//wchar_t wz_name[MAX_PATH + 1];int i_len=GetWindowText(hwnd, wz_name, MAX_PATH);lstrcat(wsz_text, L" wnd_name: "); lstrcat(wsz_text, wz_name);

		if (hwnd)
		{
		 wchar_t wz_class[MAX_PATH + 1];
		
		 int i_len=GetClassName(hwnd, wz_class, MAX_PATH); lstrcat(wsz_text, L" wnd_class:\""); lstrcat(wsz_text, wz_class);  lstrcat(wsz_text, L"\"");

		 AddCaptionText(wsz_text, L" hwnd: ", (int)hwnd);

			AddChildWndToFile(hwnd, "C:\\transman\\explore\\wnds.txt");

			WindowsToFile(hwnd, "C:\\transman\\explore\\wnds.txt");
		}
		//>q1

		//AddCaptionText(wsz_text, L" event magnify: ", m_iCntEventMagnify); AddCaptionText(wsz_text, L" event latitude: ", m_iCntEventLatitude); AddCaptionText(wsz_text, L" event longitude: ", m_iCntEventLongitude);//AddCaptionText(wsz_text, L" q_chield: ", m_ListChield.size());	

		gDrawWnd.AddTextTool(wsz_text);  //AddTextWndFromPoint(wsz_text);
	}else
	if (g_i_user_interface==1)  //YUIL 2017-10-18
	{
		lstrcpy(wsz_text, g_wz_name);
	}

	SendMessage(g_hWndMap, WM_SETTEXT, 0, (LPARAM)wsz_text);
}

void CMapTimer::TimerFn()
{
	gWndMap.GetLocationURL(g_wz_map_addr);

	SetCaptionText();

	win_e::SMonitors& sm = gMonitors;

	if (IsWindow(g_hWndMap) == FALSE) { SendMessage(gWndMain.GetHWND(), WM_CLOSE, 0, 0); return; }  //SetWindowText(g_hWndMap, L"*");

	bool f_event = false;

	RECT rc;

	POINT pt;

	if (GetWindowRect(gDrawWnd.GetHWND(), &rc) == FALSE) { return; }//
	
	if (GetCursorPos(&pt) == FALSE) { return; }

	gDrawWnd.CalcClientMouse();

	m_MouseEvent.Read(ctime_mouse_interval_event, ctime_mouse_interval_no_event);

	if (m_MouseEvent.GetEvent())
	{
		if (PtInRect(&rc, pt)) 
		{ 
			gDrawWnd.OnMouseMove();//MessageBoxA(0,"*","*",0); 
		}
	}
	/*bool fMouseEvent = m_MouseEvent.GetEvent();

	if (m_MouseEvent.GetEventNoEvent())
	{
		gDrawWnd.SetDrawObject(true);
	}*/

	m_keyb.Read();

	if (m_keyb.GetEventDown(VK_LBUTTON))
	{		
		if (PtInRect(&rc, pt))
		{
			/*if (fMouseEvent)
			{
				gDrawWnd.SetDrawObject(false);
			}*/
			if (g_ControlPanel_ch==0 && !PtInRect(&g_ControlPanel_rc, pt))
			{
			 gDrawWnd.OnLButton(); // pt);

			 m_iCntClickLBut++;

			 f_event = true;
			}
		}
	}	

	if (g_i_user_interface==0)
	{
		m_posSizeWnd.Read(g_hWndMap);

		if (m_posSizeWnd.GetEvent())
		{
			UpdateWindow(g_hWndMap);

			gDrawWnd.SetPosSizeByMapWnd(); 

			gControlPanelWnd.OnChMap();

			gMesWnd.OnChMap();

			f_event = true;
		}

		if (m_posSizeWnd.GetEventState()) 
		{
			UpdateWindow(g_hWndMap);

			UINT flag = m_posSizeWnd.GetState();

			gDrawWnd.SetPlacement(flag); 

			gControlPanelWnd.OnChMap();

			gMesWnd.OnChMap();
		}
	}else
	if (g_i_user_interface==1)
	{
		gDrawWnd.SetPosSizeByMapWnd(); //MoveWindow(g_hWndMap, sm.rc[0].left, sm.rc[0].top, sm.rc[0].right - sm.rc[0].left, sm.rc[0].bottom - sm.rc[0].top, TRUE);
	}

	//wchar_t wsz_map_addr[MAX_PATH + 1]=L"";

	
	if (lstrlen(g_wz_map_addr)) 
	{ 
		m_MapAddr.Read(g_wz_map_addr);
		
		if (m_MapAddr.GetEvent(EMAP_MAGNIFY))
		{
			m_iCntEventMagnify++;
		}
		if (m_MapAddr.GetEvent(EMAP_LATITUDE))
		{
			m_iCntEventLatitude++;
		}
		if (m_MapAddr.GetEvent(EMAP_LONGITUDE))
		{
			m_iCntEventLongitude++;
		}
		
		bool fEventAddr = m_MapAddr.GetEventAny();

		if (fEventAddr) { f_event = true; }

		if (m_fNotFirst == false || fEventAddr)
		{
			gDrawWnd.CalcCenter(m_MapAddr, !m_fNotFirst);

			gDrawWnd.SetViewOrigin();

			gDrawWnd.CalcCoordObject();

		}
	}


	gDrawWnd.Paint();		

	m_fNotFirst=true;
}