#ifndef _math_e_h_
#define _math_e_h_

#include <math.h>
#include <corecrt_math_defines.h>

template <class Type>
struct SPoint
{
	Type x, y;

	SPoint() { }

	SPoint(Type x_n, Type y_n) { Set(x_n, y_n); }

	void Set(Type x_n, Type y_n) { x = x_n; y = y_n; }

	bool operator==(SPoint& o) 
	{
		return x==o.x && y==o.y;
	}

	bool In(const SPoint& pn_0, const SPoint& pn_1)
	{
		SPoint min, max;
		if (pn_0.x < pn_1.x) { min.x = pn_0.x; max.x = pn_1.x; } else { min.x = pn_1.x; max.x = pn_0.x; }
		if (pn_0.y < pn_1.y) { min.y = pn_0.y; max.y = pn_1.y; } else { min.y = pn_1.y; max.y = pn_0.y; }			
		return x>=min.x && x<=max.x && y>=min.y && y<=max.y;
	}

	bool InMinMax(const SPoint& min, const SPoint& max)
	{
		return x>=min.x && x<=max.x && y>=min.y && y<=max.y;
	}
};

namespace math_e
{

	double dist2D(double x1, double y1, double x2=0, double y2=0);

	bool inRectInt(int x, int y, int x_min, int y_min, int x_max, int y_max);

	void LatitudeLongitudeToXY(double lat, double lng, double& x, double& y); //YUIL x, y  in meter's

	void LatitudeLongitudeToXY_s(char *sz_latitude, char* sz_longitude, double& x, double& y); //YUIL x, y  in meter's

	void LatitudeLongitudeToScreenPoint(double lat, double lng, double zoom, int& xScr, int& yScr, double* p_xPrj=0, double* p_yPrj=0);

	void XYToLatitudeLongitude(double x, double y, double& lat, double& lng);

	void ScreenPointToLatitudeLongitude(int xScr, int yScr, double zoom, double& lat, double& lng);

	void ScreenPointToXY(int xScr, int yScr, double zoom, double& x, double& y);

	bool InPoly(SPoint<double>& pn, SPoint<double>* pPoly, int qPoly);

	double LineFunc(double x, double x_0, double y_0, double x_1, double y_1); //YUIL 2017-10-24 ���������� y

	inline void TurnRelCenter(double center_x, double center_y, double rad, double angle, double& x, double& y)
	{
		x = center_x + rad*cos(angle);
		y = center_y + rad*sin(angle);
	}

	inline void TurnRelCenterSide(double center_x, double center_y, double rad, double angle, double dist_to_side, double& x, double& y)
	{
		x = center_x + rad*cos(angle);
		y = center_y + rad*sin(angle);

		x -= dist_to_side*sin(angle);
		y += dist_to_side*cos(angle);
	}

}

#endif