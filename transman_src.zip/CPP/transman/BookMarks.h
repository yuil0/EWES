#ifndef _BookMarks_h_
#define _BookMarks_h_

#include "..\\transman_srv\\std_str.h"
#include "..\\transman_srv\\str.h"
#include <vector>
#include "window.h" 
#include "MnemoScheme.h"
#include "chat.h"
#include "rep.h"
#include "Map.h"
#include "admin.h"

/*struct SBookMark
{
	std_string name;

};*/

typedef enum
{
	EBMVLM_DRAW=0,
	EBMVLM_POINT_IN,
}EBookMarksViewListMode;

typedef enum
{
	EBMGDIO_LOGO_1_1 = 0, 
	EBMGDIO_BUT_CLOSE,
	EBMGDIO_FONT_CAPTION,
	EBMGDIO_PEN_CAPTION,
	EBMGDIO_BRUSH_CAPTION,
	EBMGDIO_PEN_NON_ACTIVE_BOOKMARK,
	EBMGDIO_BRUSH_NON_ACTIVE_BOOKMARK,
	EBMGDIO_BITMAP_BACKGROUND,
	//
	EBMGDIO_QUANTITY,
}EBookMarksGDIObject;

typedef enum
{
	EBMB_LOGO = 0, 
	EBMB_BUT_CLOSE,
	//
	EBMB_QUANTITY,
}EBookMarksBitmap;

typedef enum
{
	EBMC_BUT_CLOSE=0,
	//
	EBMC_QUANTITY,
}EBookMarksControl;

typedef enum
{
	EBMN_MAP=0,
	EBMN_CHAT, 
	EBMN_MNEMOSCHEME,
	EBMN_REPORT,
	EBMN_ADMIN,
	//
	EBMN_QUANTITY,
}EBookMarkName;

/*typedef enum
{
	EBMGDIO_PEN_BLACK=0,
	EBMGDIO_PEN_WHITE,	
	//
	EBMGDIO_PEN_QUANTITY,	
}EBookMarksGDIObject;*/

struct SBookMarksParams
{
	/*const int m_params.i_top = 120; // = 110 + 2 * 5
	const int m_params.i_height = 160; // = 40 + 120
	const int m_params.i_ident_x = 5; */
	
	int i_top; 
	int i_height;
	int i_ident_x;

	void Init(POINT* a_size_bitmap);
};


////////////////////////////////
class CBookMarks
	//
{
	bool m_fInit;
	EBookMarkName m_active;
	CWindow wnd;
	HGDIOBJ m_gdi_obj[EBMGDIO_QUANTITY]; //HMENU  m_menu;
	POINT m_size_bitmap[EBMB_QUANTITY];
	bool m_f_visible[EBMN_QUANTITY];

	void DrawBookMark(HDC hdc, EBookMarkName eName, int x, int y, int w, int h, int ident_x, bool fActive); //SBookMark& bookMark
	void CrThread(); //void CrGDIObjects(); void DelGDIObjects();

	POINT m_client_size;
	CMnemoScheme m_MnemoScheme; //void MnemoScheme_fill_combo_route();
	CChat m_chat;
	CRep  m_rep; //YUIL 2017-11-13
	CMap m_map; //YUIL 2017-11-22	
	CAdmin m_admin; //YUIL 2017-02-01

	RECT m_rc;

	bool m_f_need_admin;

	HBRUSH m_hbrushGround;
	HPEN m_hpenGround;
	int m_height_font_caption; //win_e::CBitmapCtrls m_bitmapCtrls;
	SBookMarksParams m_params;
	HWND m_hwndChildFocused;
	bool m_fDraw;
	bool m_fBackGroundImage;
	win_e::EHotKeysLangInput m_eHotKeysLangInput;
	bool m_fNeedDrawBkGr;

	void ShowBook(EBookMarkName eBook, bool  fShow);
	void GetRect(RECT& rc, int dh, int i_mode = 0);
	void WM__CLOSE(HWND hwnd, WPARAM wParam, LPARAM lParam);

	void WM__COMMAND(WPARAM wParam, LPARAM lParam);
	void WM__RBUTTONDOWN(HWND hwnd, WPARAM wParam, LPARAM lParam);
	void WM__NOTIFY(HWND hwnd, WPARAM wParam, LPARAM lParam);
	void WM__MOUSEMOVE(HWND hwnd, WPARAM wParam, LPARAM lParam);
	void WM__DRAWITEM(WPARAM wParam, LPARAM lParam);
	void DrawCaption(HDC hdc);
	void cr_m_gdi_obj();
	void del_m_gdi_obj();
	void CrFonts(HDC hdc);
	void DrawOp(HDC hdc);
	void SetSizeBitmap(EBookMarksBitmap eBitmap, int x, int y);
	void SetSizeBitmap_all();  //void AddBitmapCtrls();
	void BM_Close();
	void WM__SETFOCUS(HWND hwnd, WPARAM wParam, LPARAM lParam);
	void ShowAll();
	void LoadIni(); //void DrawLangInput(HDC hdc); //void CheckKeysLangInput();
	int GetCountVisible(int&  q);
public:
	CBookMarks();
	~CBookMarks();
	bool Open();
	void Close();

	typedef enum { EPM_COMMON = 0, EPM_CLEAR_BACK_GROUND, }EPaintMode;

	void Paint(EPaintMode eMode = EPM_COMMON); //i_mode: 1:mnemoscheme ground only
	bool SetActive(EBookMarkName e);
	bool ViewList(EBookMarksViewListMode eMode = EBMVLM_DRAW, HDC hdc = 0, POINT* p_pn = 0);//void OnClick(POINT& pt_scr);

	void ChShow() { wnd.ChShow(); }

	HWND GetHWND() { return wnd.GetHWND(); }
	void CrWnd();   //void fill_list();

	EBookMarkName GetActive() { return m_active; }
	void OnCmd(int id, int notify);

	int GetBookMarkHeight() { return m_params.i_height; } //void MnemoSchemeCrControls(HINSTANCE hInstance, HWND hwndParent);
	void PointInOp();

	void SetUserType(EUserType eNew)
	{
		m_chat.SetUserType(eNew);
		m_chat.StartFill();

		if (m_f_need_admin) //YUIL 2017-02-01
		{
			m_admin.StartFill();
		}
	}

	/*void Chat_CrControls()
	{
		m_chat.CrControls();
		PointInOp();
	}*/

	void CrTimer();
	void TimerOp();
	int OnWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	void WM__KEYDOWN(HWND hwnd, WPARAM wParam, LPARAM lParam);
	void WM__LBUTTONDOWN(HWND hwnd, WPARAM wParam, LPARAM lParam, int i_mode = 0);
	void WM__LBUTTONUP(HWND hwnd, WPARAM wParam, LPARAM lParam);
	void WM__CHAR(WPARAM wParam, LPARAM lParam);
	void WM__SYSKEYDOWN(WPARAM wParam, LPARAM lParam);
	void WM__MOUSEWHEEL(WPARAM wParam, LPARAM lParam);
	
	

	void CrBrowserWnd(char* sz_file_html, char* sz_file_html_only) { m_chat.CrBrowserWnd(sz_file_html, sz_file_html_only); }
	void CloseDestroyBrowserWnd() { m_chat.CloseDestroyBrowserWnd(); }
	CWinCtrl& GetMapCtrls() { return m_map.GetCtrls(); }
	HWND GetChatBrowserHWND() { return m_chat.GetBrowserHWND(); }

	void fill_dt_rep_date(char *sz_name, CWinCtrl *p_ctrls_new = 0) { m_rep.fill_dt_rep_date(sz_name, p_ctrls_new); }

	void SelCombo(char* sz_combo_name, int index) { m_rep.SelCombo(sz_combo_name, index); }
	void SelApply();
	void MapAfterSet() 
	{ 
		m_map.AfterSet(); 
	}
	void set_edit_find_near_car(char *sz_text) { m_map.set_edit_find_near_car(sz_text); }
	CChat& GetChat() { return (CChat&)m_chat; }
	HBRUSH Get_HBRUSH_Ground() { return m_hbrushGround; }  //void GetRectM(RECT& rc);
	void EventChActive();
	SBookMarksParams& GetParams() { return (SBookMarksParams&)m_params; }

	HWND GetFocused() { return m_hwndChildFocused; }

	void ClickOnMap(Leaflet::LatLng& latlng);
	void SetVisible(EBookMarkName eName, bool fNew);
	void LoginSuccess(EUserType eUserTypeNew);
	
	void Map_SelCarsToList()
	{
	 m_map.SelCarsToList();
	}
	void DrawBackground(HDC hdc);
	
	void SetNeedDrawBkGr() {m_fNeedDrawBkGr = true;}

};

extern CBookMarks gBookMarks;
extern LRESULT CALLBACK CBookMarks_WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

#endif