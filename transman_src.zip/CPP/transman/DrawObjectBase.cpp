#include "DrawObjectBase.h"

#include <windows.h>
#include <vector>
#include "math_e.h"

void SDrawObjectBase::Draw(int hdc, int i_draw_radius,  char *sz_title_name, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list, const SPointInt& origin)//const SPointInt& origin, 
{
	int x = point.x + origin.x;
	int y = point.y + origin.y;

	//if (IsHide(x, y, sizeWnd)) { continue; }

	BOOL fRes = Ellipse((HDC)hdc, x - i_draw_radius, y - i_draw_radius, x + i_draw_radius, y + i_draw_radius);

	bool f_in = math_e::inRectInt(clientMouse.x, clientMouse.y, x - i_draw_radius, y - i_draw_radius, x + i_draw_radius, y + i_draw_radius);

	if (f_in)
	{																	//sprintf(sz_text, "",  o.route_long_name);
		sel_point.Set(x + 2 * i_draw_radius, y - i_draw_radius);

		char sz_val[MAX_PATH + 1];

		sprintf(sz_val, "%s : %s", sz_title_name, GetDrawName()); //TextOutA(hdc, xFrom + 2*i_draw_radius, yFrom - i_draw_radius, p_name, strlen(p_name));

		sel_str_list.push_back(sz_val);  //strcat(sel_text, sz_val);
	}

}
