#ifndef _DrawObjectBase_h_
#define _DrawObjectBase_h_
#include "point.h"
#include <vector>
#include "..\\transman_srv\\std_str.h"

const int ci_device_name_len = 32;

struct SDrawObjectBase
{                        //SDrawObjectBase() {}
	SPointInt point;

	char name[ci_device_name_len + 1];  //SDrawObjectBase& operator SDrawObjectBase&() { return (SDrawObjectBase&)*this; }

	void Draw(int hdc, int i_draw_radius, char *sz_title_name, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list, const SPointInt& origin);

	virtual char *GetDrawName() { return name; }
};

//typedef std::vector<SDrawObjectBase> TypeDrawObjectBaseList;

#endif