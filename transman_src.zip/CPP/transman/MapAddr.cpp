#include <memory.h>
#include "MapAddr.h"
#include <stdio.h>  
#include <stdlib.h>  

CMapAddr::CMapAddr() { } //m_fInit=false; memset(this, 0, sizeof(CMapAddr)); m_fInit=true;


void CMapAddr::Clear()
{
	memset(this, 0, sizeof(CMapAddr));
}

void CMapAddr::Read(wchar_t *wsz_addr)
{

	ClearEvent();
	
	SMapAddrParam param;
	Parse(wsz_addr, param);

	if (m_fRead)
	{
		m_event[EMAP_MAGNIFY] = m_param.magnify != param.magnify;

		m_event[EMAP_LATITUDE] = m_param.latitude!= param.latitude;

		m_event[EMAP_LONGITUDE] = m_param.longitude!= param.longitude; //m_event = DeltaIsOver();
	}
	else
	{
		m_fRead = true;
	}
	m_param = param;
}

void CMapAddr::ClearEvent()
{
	for (int i = 0; i < (int)EMAP_QUANTITY; i++)
	{
		m_event[i]=false;
	}
}

bool CMapAddr::Parse(wchar_t *wsz_addr, SMapAddrParam& param)
{
	int len = lstrlen(wsz_addr);    // http://openstreetmap.ru/#map=11/47.2352/39.6802&layer=H
	
	const wchar_t *cwsz_map = L"#map=";

	wchar_t* p_map = wcsstr(wsz_addr, cwsz_map);

	if (p_map == 0) { return false; }
	
	p_map += 5; //  lstrlen(cwsz_map); //if (p_map == 0) { return false; } p_map = wcsstr(p_map, L"/");

	int lPos = 0;	
	
	EMapAddrParam eMapAddrParam = EMAP_MAGNIFY;

	for (int i = 0; p_map[i] && i < len; i++)
	{
		if (p_map[i] == L'/' || p_map[i] == L'&' || i+1== len)
		{
			int lSize = i- lPos;
			
			bool fEnd = false;

			if (p_map[i] != L'/' && p_map[i] != L'&' && i + 1 == len) { lSize++;  fEnd = true; }

			if (lSize)
			{
				wchar_t ch_save;  if (fEnd == false) { ch_save = p_map[i]; p_map[i] = 0; }

				if (eMapAddrParam == EMAP_MAGNIFY)
				{
					swscanf(p_map+ lPos, L"%i", &param.magnify);

					eMapAddrParam = EMAP_LATITUDE;
				}else
				if (eMapAddrParam == EMAP_LATITUDE)
				{					
					param.latitude=_wtof(p_map + lPos);

					eMapAddrParam = EMAP_LONGITUDE;
				}else
				if (eMapAddrParam == EMAP_LONGITUDE)
				{
					param.longitude = _wtof(p_map + lPos);

					break;
				}

				if (fEnd == false) { p_map[i] = ch_save; }
			}

			lPos =i+1;
		}

		if (p_map[i] == L'&') { break; }
	}
}

/*
bool CMapAddr::DeltaIsOver()
{
	for (int i = 0; i < (int)EMAP_QUANTITY; i++)
	{
		if (m_event[i]) { return true; }
	}
	return false;
}

bool CMapAddr::GetDelta(ERectSide eSide, int& iDeltaVal)
{ 
	if (eSide < 0 || eSide>=(int)ERS_QUANTITY) { return false; }
	iDeltaVal  = m_delta[eSide];
	return true;
}*/