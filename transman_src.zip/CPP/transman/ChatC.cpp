#include <memory.h>
#include "main.h"
#include "chat.h"
#include "MesWnd.h"

#include "BookMarks.h"

#include "login_wnd.h"
#include <io.h>

const int ci_chat_size_mes_pack_step=50;
const int ci_chat_size_mes_pack_max =  ci_chat_size_mes_pack_step*50;
const char *csz_chat_file_view_mes = "C:\\transman\\chat\\view_mes.html";
const char *csz_chat_file_view_mes_only="view_mes.html";


void CChat_ShowMes_add(void *p_param, FldsPtr fp)
{
	CChat* p_this=(CChat*)p_param;

	if (p_this) { p_this->ShowMes_add(fp); }
}

/*void CChat::NotifyOnReadedMes(SCharMes& o)
{
	gMesWnd.Mes("����� ��������� �� %s", o.user_from.c_str()); //gMesWnd.Mes("����� ��������� �� %s", o.user_from.c_str());
}*/

void CChat::ShowMes_add(FldsPtr fp)
{
	SCharMes o;

	_bstr_t bstr_dt_create(fp->Item["dt_create"]->Value);
	_bstr_t bstr_user_from(fp->Item["user_from"]->Value);
	_bstr_t bstr_user_to(fp->Item["user_to"]->Value);		
	_bstr_t bstr_mes(fp->Item["mes"]->Value);
	VARIANT v_id_chat_mes_type = fp->Item["id_chat_mes_type"]->Value;
	VARIANT v_id_chat_mes_head = fp->Item["id_chat_mes_head"]->Value;
	
	o.dt_create=(char*)bstr_dt_create;
	
	o.user_from=(char*)bstr_user_from;
	
	o.user_to=(char*)bstr_user_to;

	o.eType= (EChatMesType)v_id_chat_mes_type.intVal;
	
	o.mes= (char*) bstr_mes; //NotifyOnReadedMes(o);
	
	o.id_chat_mes_head = v_id_chat_mes_head.decVal.Lo32;

	static int id_chat_mes_head_max = 0;

	if (id_chat_mes_head_max < o.id_chat_mes_head) 
	{
		id_chat_mes_head_max = o.id_chat_mes_head;
		
		gMesWnd.Mes("����� ��������� �� %s", o.user_from.c_str());
	}

	m_mes_list.push_back(o);
}

bool CChat::ShowMes_op(std_string& id_disp) //, char* sz_id_coll)
{
	char sz_val[MAX_PATH+1];

	/*
	std_string id_coll;

	if (sz_id_coll==0)
	{
		if (m_ctrls.SendMes("combo_show_coll", WM_GETTEXT,  (LPARAM)MAX_PATH, (WPARAM)sz_val)==0) {gMesWnd.Mes("CChat. ������ ��������� ����� ���������� "); return false;}

		if (get_id_user(sz_val, &id_coll)==false) { gMesWnd.Mes("CChat. �� ������ � ��  ��������� '%s'",  sz_val); return false; }
	}
	else
	{ id_coll = sz_id_coll; }*/
	

	std_string sz_query;
	
	/*if (id_disp.size())
	{
		sz_query = "EXEC dbo.P_view_mes @id_user_1="; sz_query.append(id_disp.c_str()); sz_query.append(", @id_user_2=");
	}
	else
	{*/
	sz_query = "EXEC dbo.P_view_mes_one @id_user="; //}
	
	sz_query.append(id_disp.c_str());  

	sz_query.append(", @i_quantity="); itoa(m_i_sizeMesPack, sz_val, 10); sz_query.append(sz_val);

	bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), CChat_ShowMes_add, CChat_FN_MSSQL_MES_ERR, this);		

	if (f_exec)
	{
		//gMesWnd.Mes("��������� � �������� ���");
	}

	return f_exec;
}

void CChat::ShowMes(char* sz_id_disp, bool fActive) //, char* sz_id_coll)
{
	bool  fCheck_SIP_client = m_ctrls.GetCheckbox("but_SIP_client");

	if (fCheck_SIP_client) { return; }

	m_mes_list.clear();	

	std_string id_disp;

	if (sz_id_disp==0)
	{
		char sz_val[MAX_PATH+1];

		if (m_ctrls.SendMes("combo_show_disp", WM_GETTEXT,  (LPARAM)MAX_PATH, (WPARAM)sz_val)==0) {gMesWnd.Mes("CChat. ������ ��������� ����� ���������� "); return;}

		if (get_id_user(sz_val, &id_disp)==false) { gMesWnd.Mes("CChat. �� ������ � ��  ��������� '%s'",  sz_val); return; }	
	}
	else
	{ id_disp = sz_id_disp; }		

	bool f_exec = ShowMes_op(id_disp);

	if (f_exec)
	{
		if (fActive)
		{
			CrViewMesInHTML();

			ShowProxyWnd(EPWM_HIDE);
		}
	}else
	{ gMesWnd.Mes("CChat. ������ ������  ���������"); return; }

}

void CChat::GetMes(SCharMes& o, std_string& sz_mes)
{
	if (o.eType==ECMT_TEXT) {sz_mes=o.mes;} else
	if (o.eType==ECMT_IMG) 
	{
		sz_mes="<IMG WIDTH=300 HEIGHT=200 SRC="; sz_mes.append(o.mes); sz_mes.append("><BR>"); 
	} else
	if (o.eType==ECMT_VIDEO) 
	{
		sz_mes="<embed WIDTH=300 HEIGHT=200 src="; sz_mes.append(o.mes); sz_mes.append("></embed>"); //sz_mes="<video width=320 height=240 controls=controls><source src="; sz_mes.append(o.mes); sz_mes.append("/>Your browser does not support the video tag.</video>"); 
 } else
	if (o.eType==ECMT_REQUEST_COORD) 
	{
		sz_mes = "������ ���������: ";   if (o.mes.size()) { sz_mes.append(o.mes); }
	} else
	if (o.eType==ECMT_GO_COORD) 
	{
		sz_mes="��� � �����������: ";   if (o.mes.size()) { sz_mes.append(o.mes); }
	}

}

bool CChat::CrFileViewMes()
{
	unlink(csz_chat_file_view_mes);

	if (m_mes_list.size()==0) {return false;}

	FILE *fo = fopen(csz_chat_file_view_mes, "wb");

	if (fo == 0) { gMesWnd.Mes("CChat::CrFileViewMes(). ������ �������� ����� ��������� ���������"); return false; }

	fprintf(fo, "<HEAD></HEAD><HTML><BODY><TABLE BORDER=1 CELLSPACING=0 CELLPADDING=5>\r\n");
	fprintf(fo, "<TR><TH>�</TH><TH>����/�����</TH><TH>�� ������������</TH><TH>� ������������</TH><TH>���������</TH></TR>\r\n");

	for  (int i=0; i<m_mes_list.size(); i++)
	{
		SCharMes& o=m_mes_list[i];

		std_string sz_mes;

		GetMes(o, sz_mes);

		fprintf(fo,  "<TR ALIGN=center><TD>%d</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD></TR>\r\n", i + 1, o.dt_create.c_str(), o.user_from.c_str(), o.user_to.c_str(), sz_mes.c_str());
	}
	fprintf(fo, "</TABLE></BODY></HTML>\r\n");

	fclose(fo);
	
	int iRes = _chmod(csz_chat_file_view_mes, S_IREAD | S_IWRITE);

	return true;
}

void CChat::GetNeedPosSize(POINT& pos, POINT& size)
{
	SBookMarksParams& bm_params = gBookMarks.GetParams();

	int y = bm_params.i_height + cl_chat_ident_from_top + ci_chat_ctrls_max_y - 10;

	win_e::SMonitors& mon = gMonitors;

	//RECT rcParent;GetWindowRect(m_hwndParent, &rcParent);

	pos.x = m_rcParent.left; // mon.rc[1].left;
	
	pos.y = y;
	
	size.x = m_rcParent.right - m_rcParent.left; // mon.rc[1].right - mon.rc[1].left;
	
	size.y = mon.rc[1].bottom - 275 - (bm_params.i_top - 8) - 17;
}

void CChat::SetChatBrowserWndPosSize(HWND hwnd)
{
	//int y= m_params.i_height + cl_chat_ident_from_top + ci_chat_ctrls_max_y - 10;	win_e::SMonitors& mon = gMonitors;

	POINT pos;
	POINT size;

	GetNeedPosSize(pos, size);

	win_e::RemoveWndStyle(hwnd, WS_CAPTION); // WS_MAXIMIZEBOX);

	MoveWindow(hwnd, pos.x, pos.y, size.x, size.y, TRUE);//MoveWindow(hwnd, mon.rc[1].left, y, mon.rc[1].right - mon.rc[1].left,  mon.rc[1].bottom - 270/*cl_mes_wnd_h*/, TRUE); 		
}

void CChat::CrBrowserWnd(char* sz_file_html, char* sz_file_html_only)
{

	bool f_top = false;

	bool f_open = MSInet_Open(sz_file_html, f_top); //(char*)csz_chat_file_view_mes

	if (f_open)
	{
		bool fFound = false;

		do
		{
			HWND hwnd = FindWindowA("IEFrame", 0);

			char sz_name[MAX_PATH + 1];

			if (GetWindowTextA(hwnd, sz_name, MAX_PATH))
			{
				if (strstr(sz_name, sz_file_html_only)) { fFound = true; m_hwndBrowser = hwnd; } //csz_chat_file_view_mes_only
			}

		} while (fFound == false);


		SetChatBrowserWndPosSize(m_hwndBrowser);

		//bool fExt = true; win_e::AddWndStyle(m_hwndBrowser, WS_EX_TOPMOST, fExt);
	}
	else
	{
		gMesWnd.Mes("CChat. ������ �������� ������������"); return;
	}

}

void CChat::CrProxyWnd()
{
	POINT pos;
	POINT size;

	GetNeedPosSize(pos, size);

	SWindowCreateParam wcp;

	wcp.hInstance = g_hInstance;
	wcp.wndProc = CBookMarks_WindowProc; //wcp.dwStyleEx=WS_EX_TOPMOST;
	wcp.fVisible = false;
	wcp.x = pos.x; // +14;
	wcp.y = pos.y;
	wcp.w = size.x; // -26;
	wcp.h = size.y;
	wcp.hWndParent = gWndMain.GetHWND();
	wcp.dwStyle = WS_POPUP;
	wcp.dwStyleEx = WS_EX_TOPMOST;
	lstrcpy(wcp.wzClassName, L"CBookMarks");

	m_proxy_wnd.Create(wcp);
	
	POINT size_ind = {200, 20};

	RECT rcInd = { size.x / 2 - size_ind.x / 2, size.y / 2 - size_ind.y / 2, size.x / 2 + size_ind.x / 2, size.y / 2 + size_ind.y / 2 };
	int q_items=10;
	m_waitIndicator.Open(rcInd, q_items);


	/*HWND hwnd = m_proxy_wnd.GetHWND();
	if (hwnd)
	{
	 win_e::RemoveWndStyle(hwnd, WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_SYSMENU | WS_CAPTION);
	}*/
}

void CChat::ShowProxyWnd(EProxyWndMode eMode)
{ 
	m_proxyWndMode = eMode;

	m_proxy_wnd.Show(eMode==EPWM_SHOW || eMode== EPWM_SHOW_WAIT_INDICATOR);

	/*if (f_show)
	{
		RECT rc;

		HWND hwnd = m_proxy_wnd.GetHWND();

		if (GetWindowRect(hwnd, &rc) == FALSE) { return; }

		BOOL fSet = SetWindowPos(hwnd, HWND_BOTTOM, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, SWP_SHOWWINDOW);
	}*/
}

void CChat::CloseDestroyBrowserWnd()
{
	//if (m_hwndBrowser==0) {return;} //char sz_val[MAX_PATH+1]; if (GetClassNameA(m_hwndBrowser, sz_val, MAX_PATH)) {}

	HWND hwndIgnore = g_hWndMap;

	CloseDestroyWindowByClass("IEFrame", hwndIgnore); //gMesWnd.Mes("������� �������� �������� ���� ������ '%s'", sz_val); //CloseWindow(m_hwndBrowser); DestroyWindow(m_hwndBrowser);

	m_hwndBrowser=0; 	
}

void CChat::BrowserRefresh()
{
	if (m_hwndBrowser)
	{                                               //CloseWindow(m_hwndBrowser); DestroyWindow(m_hwndBrowser); 
		int	cmd = APPCOMMAND_BROWSER_REFRESH;
		int uDevice = FAPPCOMMAND_OEM;
		int dwKeys = 0;

		LPARAM lParam = (((cmd & ~FAPPCOMMAND_MASK) + (uDevice & FAPPCOMMAND_MASK)) << 16) + dwKeys;

		BOOL fRes = SendMessage(m_hwndBrowser, WM_APPCOMMAND, (WPARAM)m_hwndBrowser, lParam);

		/*
		#define HIWORD(l)           ((WORD)((((DWORD_PTR)(l)) >> 16) & 0xffff))
		#define GET_FLAGS_LPARAM(lParam)      (LOWORD(lParam))

		#define GET_APPCOMMAND_LPARAM(lParam) ((short)(HIWORD(lParam) & ~FAPPCOMMAND_MASK))
		#define GET_DEVICE_LPARAM(lParam)     ((WORD)(HIWORD(lParam) & FAPPCOMMAND_MASK))
		#define GET_KEYSTATE_LPARAM(lParam)   GET_FLAGS_LPARAM(lParam)
		*/



		/*if (CWindow::ClickKey(m_hwndBrowser, VK_F5)==false)
		{
		CloseDestroyBrowserWnd();
		}*/
	}
}

void CChat::OpenViewMesInHTML(char* sz_file_html, char* sz_file_html_only)
{
	/*if (m_p_browser)  
	{
		m_p_browser->Navigate(csz_chat_file_view_mes);
	}else
	{*/
	//CloseDestroyBrowserWnd();

	BrowserRefresh();

	if (m_hwndBrowser==0)
	{
		CrBrowserWnd(sz_file_html ? sz_file_html : (char*)csz_chat_file_view_mes, sz_file_html_only ? sz_file_html_only : (char*)csz_chat_file_view_mes_only);
	}
}

void CChat::CrViewMesInHTML()
{
	if (CrFileViewMes()==false) {return;}

	OpenViewMesInHTML();
}

void CChat::TimerFast()
{

	if (m_proxyWndMode == EPWM_SHOW_WAIT_INDICATOR)
	{
		time_t& time_prev = m_waitIndicator_time_prev;
		time_t delta_time = 100;
		time_t time = clock();

		if (!time_prev || (time - time_prev)>delta_time)
		{
			CallPaintProxyWnd();

			m_waitIndicator.IndexOp();

			time_prev = time;
		}

	}

}

void CChat::TimerOp(bool fActive)
{
 if (m_f_refresh) //m_eUserType==EUT_DISP)
	{
  char sz_val[MAX_PATH+1];

		if (m_eUserType==EUT_DISP_HI)
		{
			/*if (m_ctrls.SendMes("combo_show_coll", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val)==0) {gMesWnd.Mes("CChat. ������ ������ ����������"); return;}		

			std_string id_user;

			if (get_id_user(sz_val, &id_user)==false)  {gMesWnd.Mes("CChat. ������ ��������� �� ����������"); return;} */

			if (m_ctrls.SendMes("combo_show_disp", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val)==0) {gMesWnd.Mes("CChat. ������ ������ ����������"); return;}		

			std_string id_disp;

			if (get_id_user(sz_val, &id_disp)==false)  {gMesWnd.Mes("CChat. ������ ��������� �� ����������"); return;}

			ShowMes((char*)id_disp.c_str(), fActive); //, (char*)id_user.c_str());
		}else
		if (m_eUserType==EUT_DISP)
		{
			if (m_ctrls.SendMes("combo_disp_coll", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val)==0) {gMesWnd.Mes("CChat. ������ ������ ����������"); return;}		

			std_string id_user;

			if (get_id_user(sz_val, &id_user)==false)  {gMesWnd.Mes("CChat. ������ ��������� �� ����������: %s", sz_val); return;}

			ShowMes((char*)gLoginWnd.GetIdUser().c_str(), fActive); //, (char*)id_user.c_str());
		}
	}

	if (fActive)
	{
		bool fShow = true;

		m_ctrls.ShowAllUpdate(fShow);
	}
}

void CChat::CallPaintProxyWnd()
{
	HWND hwnd = m_proxy_wnd.GetHWND();

	if (!hwnd) { return; }

	HDC hdc = GetDC(hwnd);

	PaintProxyWnd(hdc);

	ReleaseDC(hwnd, hdc);
}

void CChat::PaintProxyWnd(HDC hdc)
{
	m_waitIndicator.Draw(hdc, gBookMarks.Get_HBRUSH_Ground());
}

void CChat::ChSizeMesPack(bool fInc)
{
	if (fInc) 
	{ 
		if (m_i_sizeMesPack < ci_chat_size_mes_pack_max) 
		{
		 m_i_sizeMesPack+=ci_chat_size_mes_pack_step; 
		}
	} 
	else 
	{ 
		if (m_i_sizeMesPack > ci_chat_size_mes_pack_step) 
		{
			m_i_sizeMesPack-=ci_chat_size_mes_pack_step; 
		}		
	}

	ShowMes(); //OpenViewMesInHTML(); // CloseDestroyBrowserWnd();

}