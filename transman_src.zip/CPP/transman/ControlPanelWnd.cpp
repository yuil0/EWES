#include <memory.h>
#include <windows.h>
#include <commctrl.h>
#include <WinUser.h>
#include "main.h"
#include "ControlPanelWnd.h"
#include "FormMes.h"  
#include "..\\transman_srv\\time_e.h"
#include "audio_device.h"
#include "MesWnd.h"

#pragma comment (lib, "Comctl32.lib")

#ifndef GWL_USERDATA
#define GWL_USERDATA        (-21)
#endif

bool g_f_control_panel_expand; 

CWinCtrl* g_cp_p_ctrls=0;

//long g_cp_l_fin_cr_ctrls;


S_fill_combo_rep_shape_stop_time g_fill_combo_rep_shape_stop_from_time_by_dyn;
S_fill_combo_rep_shape_stop_time g_fill_combo_rep_shape_stop_to_time_by_dyn; 
S_fill_combo_rep_stops_by_dyn g_fill_combo_rep_stops_by_dyn;

S_fill_combo_rep_shape_stop_time g_fill_combo_rep_shape_stop_from_time;	
S_fill_combo_rep_shape_stop_time g_fill_combo_rep_shape_stop_to_time;
S_fill_combo_rep_shape_stop g_fill_combo_rep_shape_stop;	

S_fill_combo_agent g_fill_combo_agent;

RECT g_ControlPanel_rc;

long g_ControlPanel_ch;

HWND g_hwndCP;

CControlPanelWnd::CControlPanelWnd() {}

CControlPanelWnd::~CControlPanelWnd() {}

void CControlPanelWnd::WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam)
{		
	//MessageBoxA(0, "WM_LBUTTONDOWN", "*", 0); // SetByExpand(); //wnd.GetHWND()
	
	Ch(); //Expand();
}



DWORD WINAPI ChThreadProc(LPVOID lpParameter);

void CControlPanelWnd::Ch()
{
	InterlockedExchange(&g_ControlPanel_ch, 1);

	DWORD dThreadId;

	HANDLE h = CreateThread(0, 0, ChThreadProc, (LPVOID)this, 0, &dThreadId);

	if (h == 0) { gMesWnd.Mes("������ �������� ������ ��������� ��������� ������ ����������"); return; }
}

DWORD WINAPI ChThreadProc(LPVOID lpParameter)
{
	CControlPanelWnd *p_this = (CControlPanelWnd*)lpParameter;

	if (p_this == 0) { return 1; }

	CWindow& wnd = p_this->GetWindow();

	g_f_control_panel_expand = g_f_control_panel_expand ? false : true; //m_event_size=true;

	//1. ������ ������ ������ ����������  //int w = g_ControlPanel_rc.right - g_ControlPanel_rc.left;
	int xMap= g_ControlPanel_rc.right;

	int w= g_ControlPanel_rc.right - g_ControlPanel_rc.left;

	if (g_f_control_panel_expand)
	{
		g_ControlPanel_rc.right = g_ControlPanel_rc.left + cl_panel_expand_w;
	}
	else
	{
		g_ControlPanel_rc.right = g_ControlPanel_rc.left + cl_panel_no_expand_w;
	}

	int xMapNew = g_ControlPanel_rc.right;

	int w_new = g_ControlPanel_rc.right - g_ControlPanel_rc.left;

	int delta_xMap = xMapNew - xMap;

	int delta_w = w_new - w;

	//2. ������ ������  ����������
	SetWindowPos(wnd.GetHWND(), HWND_TOP, g_ControlPanel_rc.left, g_ControlPanel_rc.top, g_ControlPanel_rc.right - g_ControlPanel_rc.left, g_ControlPanel_rc.bottom - g_ControlPanel_rc.top, SWP_SHOWWINDOW);

	UpdateWindow(wnd.GetHWND());

	//3. �������� �����
	SSizeDelta delta;

	delta.x = delta_xMap;

	delta.w = -delta_w;

	CWindow::ReizeWnd(g_hWndMap, delta);

	//4. �������� ���������
	//CWindow::ReizeWnd(gDrawWnd.GetHWND(), delta);

	Sleep(1);

	InterlockedExchange(&g_ControlPanel_ch, 0);

	return 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK WindowProc_ControlPanel(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CControlPanelWnd *p_this = (CControlPanelWnd*)GetWindowLongA(hwnd, GWL_USERDATA);

	if (p_this == 0) { return DefWindowProc(hwnd, uMsg, wParam, lParam);}

	if (p_this->IsInit()==false) { return DefWindowProc(hwnd, uMsg, wParam, lParam);}

	switch (uMsg)
	{
	/*case WM_CLOSE: WMClose(hwnd, wParam, lParam); break;
	case WM_DESTROY: WMDestroy(wParam, lParam); break;
	case WM_SIZE: WMSize(wParam, lParam); break;*/
	case WM_LBUTTONDOWN: p_this->WM__LBUTTONDOWN(wParam, lParam); break;
	case WM_COMMAND: 
	{int id = LOWORD(wParam);
		int notify= HIWORD(wParam);
		HWND hwndChild = (HWND)lParam; 

		p_this->WM__COMMAND(id,	notify); //wParam, lParam); 
	}
	break;
	case MM_WIM_OPEN: gAudioDevice.MesProc(uMsg, wParam, lParam);
	case MM_WIM_CLOSE: gAudioDevice.MesProc(uMsg, wParam, lParam);
	case MM_WIM_DATA: gAudioDevice.MesProc(uMsg, wParam, lParam);
	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 1;
}

void CControlPanelWnd::set_p_ctrls(CWinCtrl* p_ctrls_new) 
{ 
	g_cp_p_ctrls = p_ctrls_new;
}

bool CControlPanelWnd::Create(HINSTANCE hInstance, wchar_t *wsz_app) //, HWND draw_hwnd_new)
{
	memset(this, 0, sizeof(CControlPanelWnd));

	unlink(csz_report_query);

	g_f_control_panel_expand = false; //draw_hwnd = draw_hwnd_new;

	set_p_ctrls(&m_ctrls);

	//<q1 YUIL ��������� ����
	SWindowCreateParam wcp;

	wcp.hInstance = hInstance;

	wcp.wsz_name = wsz_app;

	wcp.wndProc = WindowProc_ControlPanel;

	wcp.fVisible = true;

	wcp.dwStyleEx = WS_EX_TOPMOST | WS_EX_TOOLWINDOW;

	wcp.dwStyle = WS_POPUP | WS_BORDER; // DLGFRAME;//wcp.hWndParent = draw_hwnd;

	SetFirst(wcp);

	if (wnd.Create(wcp) == false) { return false; }

	g_hwndCP = wnd.GetHWND();

	InterlockedExchange(&g_ControlPanel_ch, 0); //SetEventSize();	//SetByExpand();  //ShowWindow(wnd.GetHWND(), SW_SHOW); //DWORD idThread = GetCurrentThreadId();//CreateWindowA("static", "", WS_CHILD | WS_VISIBLE, 0, 0, cl_panel_expand_w, cl_panel_h, wnd.GetHWND(), (HMENU)0, hInstance, 0); //transman_wnd_class
	
	CrControls(hInstance); //CreateWindowA("button", "*", WS_CHILD|WS_VISIBLE|WS_DLGFRAME, 0, 0, cl_panel_no_expand_w, cl_panel_no_expand_w, wnd.GetHWND(), (HMENU)0, hInstance, 0); //transman_wnd_class	

	Sleep(100);

	//InterlockedExchange(&g_cp_l_fin_cr_ctrls, 1);

	UpdateWindow(wnd.GetHWND());

	//<q1
	INITCOMMONCONTROLSEX icex;
	icex.dwSize = sizeof(icex);
	icex.dwICC = ICC_DATE_CLASSES;
	InitCommonControlsEx(&icex);
	//>q1

	//>q1

	m_fInit = true;

	return true;
}

void CControlPanelWnd::SetFirst(SWindowCreateParam& wcp)
{
	//1. ���������� ���������� ���� �����
	RECT rcMap;

	BOOL  fGet = GetWindowRect(g_hWndMap, &rcMap);

	if (fGet == FALSE) { return; }

	g_ControlPanel_rc = rcMap;

	g_ControlPanel_rc.right = g_ControlPanel_rc.left + cl_panel_no_expand_w;

	wcp.w = g_ControlPanel_rc.right - g_ControlPanel_rc.left;

	wcp.h = g_ControlPanel_rc.bottom - g_ControlPanel_rc.top;

	wcp.x = g_ControlPanel_rc.left;

	wcp.y = g_ControlPanel_rc.top;

	//2. �������� ����  �����
	SSizeDelta delta;

	int w= g_ControlPanel_rc.right - g_ControlPanel_rc.left;

	delta.x = w;
	
	delta.w =  - (w);

	CWindow::ReizeWnd(g_hWndMap, delta);

	//2. �������� ���� ���������
	CWindow::ReizeWnd(gDrawWnd.GetHWND(), delta);
}

void CControlPanelWnd::OnChMap()
{
	if (wnd.GetHWND()==0)  {return;}

	//1. ������ ���� ���������� 
	RECT rcMap;

	BOOL  fGet = GetWindowRect(g_hWndMap, &rcMap);

	if (fGet == FALSE) { return; }

	int wMap = rcMap.right - rcMap.left;

	int hMap = rcMap.bottom - rcMap.top;

	int w = g_ControlPanel_rc.right - g_ControlPanel_rc.left;

	int h = g_ControlPanel_rc.bottom - g_ControlPanel_rc.top;

	g_ControlPanel_rc.left = rcMap.left - w;

	g_ControlPanel_rc.top = rcMap.top;

	g_ControlPanel_rc.right = g_ControlPanel_rc.left + w;

	g_ControlPanel_rc.bottom = g_ControlPanel_rc.top + hMap;

	SSizeDelta delta;

	SetWindowPos(wnd.GetHWND(), HWND_TOP, g_ControlPanel_rc.left, g_ControlPanel_rc.top, g_ControlPanel_rc.right - g_ControlPanel_rc.left, g_ControlPanel_rc.bottom - g_ControlPanel_rc.top, SWP_SHOWWINDOW);
}

/*void CControlPanelWnd::Expand()
{

}*/

void CControlPanelWnd::Destroy()
{
	m_ctrls.Destroy();

	DestroyWindow(wnd.GetHWND());
}

/*void ButExpand(int iNotify,  void *p_param)
{
	CControlPanelWnd* p_this = (CControlPanelWnd*)p_param;

	//p_this->SetByExpand();
}*/

void CControlPanelWnd::Paint(int x, int y, int w, int h)
{                                       //HWND hwnd = wnd.GetHWND();	
	HDC hdc = GetDC(g_hwndCP);

	//RECT crc; GetClientRect(g_hwndCP, &crc);

	Rectangle(hdc, 0, 0, w, h);  // crc.right, crc.bottom);

	ReleaseDC(g_hwndCP, hdc);
}

int CControlPanelWnd::GetH()
{
	RECT crc;

	BOOL  fGetRect = CWindow::GetClientRectAbs(g_hWndMap, crc); //draw_hwnd, GetWindowRect(draw_hwnd,  &rc);

	return crc.bottom - crc.top;
}


void CControlPanelWnd::AddCtrlsMap(float mul, int mode)
{
	if (g_cp_p_ctrls == 0) { return; }

	SCtrl ctrl;

	ctrl.Clear();
	ctrl.name = "static_text";
	ctrl.classWnd = "static";
	ctrl.textWnd = "*";
	ctrl.mul_w = 3.3*mul;
	ctrl.mul_h = 3;
	ctrl.styleAdd = SS_CENTER | WS_BORDER;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow();
	g_cp_p_ctrls->NewRow();
	g_cp_p_ctrls->NewRow();

	ctrl.Clear();
	ctrl.name = "static_route";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�������";
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_route";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2 * mul;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow();
	if (mode == 1) { g_cp_p_ctrls->NewRow(); }

	ctrl.Clear();
	ctrl.name = "static_stop";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_stop";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2 * mul;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow();
	if (mode == 1) { g_cp_p_ctrls->NewRow(); }

	ctrl.Clear();
	ctrl.name = "static_zone_new";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����� ����";
	ctrl.mul_h = 3;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "static_zone_new_name";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���";
	ctrl.mul_w = 0.5*mul;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "edit_zone_new_name";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "����1";
	ctrl.mul_w = 1.451*mul;
	ctrl.styleAdd = WS_BORDER | ES_RIGHT;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_zone_new");

	ctrl.Clear();
	ctrl.name = "but_cr_zone";
	ctrl.classWnd = "button";
	ctrl.textWnd = "������";
	ctrl.mul_w = 2 * mul;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_zone_new");

	ctrl.Clear();
	ctrl.name = "but_zone_new_save";
	ctrl.classWnd = "button";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 2 * mul;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow();
	if (mode == 1) { g_cp_p_ctrls->NewRow(); }

	ctrl.Clear();
	ctrl.name = "static_zone";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����";
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_zone";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2 * mul;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_zone_del";
	ctrl.classWnd = "button";
	ctrl.textWnd = "X";
	ctrl.mul_w = 0.27;
	g_cp_p_ctrls->Add(ctrl);

	Fill_combo_stop();
	Fill_combo_zone();
}

void CControlPanelWnd::CrControls(HINSTANCE hInstance)
{

	SWinCtrlParam wcp;
	wcp.Clear();
	wcp.hInstance = hInstance;
	wcp.hwndParent = wnd.GetHWND();
	wcp.wCtrl = 70;
	wcp.hCtrl = 22;
	wcp.ident = 5;
	wcp.xOrigin = cl_panel_no_expand_w;

	g_cp_p_ctrls->Init(wcp);

	AddCtrlsMap();

	AddCtrlsFormalizeMes();

	AddCtrlsReps();

 AddCtrlsRep8();
	
	AddCtrlsAudio();

	AddCtrlsFindNearCar();

	AddCtrlsCarLagLead();
	
	
}

void CControlPanelWnd::AddCtrlsFormalizeMes(float mul, int mode) //YUIL 2017-09-21
{
	if (g_cp_p_ctrls == 0) { return; }

	SCtrl ctrl;

	g_cp_p_ctrls->NewRow();
	if (mode == 1) { g_cp_p_ctrls->NewRow(); }

	ctrl.Clear();
	ctrl.name = "static_form_mes";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����. �����.";
	ctrl.mul_h = 2;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_form_mes";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2* mul;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_form_mes");

	ctrl.Clear();
	ctrl.name = "but_form_mes_send";
	ctrl.classWnd = "button";
	ctrl.mul_w = mul;
	ctrl.textWnd = "�������"; // > "; //YUIL 2017-09-21 ������� //ctrl.mul_w = 0.27;
	g_cp_p_ctrls->Add(ctrl);

}

void CControlPanelWnd::AddCtrlsReps() //YUIL 2017-09-25
{
	SCtrl ctrl;

	g_cp_p_ctrls->NewRow();

	ctrl.Clear();
	ctrl.name = "static_rep";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�����";
	ctrl.mul_w = 0.7;
	ctrl.mul_h = 17;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_date";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����";
	ctrl.mul_w = 0.8;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "check_rep_date";
	ctrl.classWnd = "button";
	ctrl.mul_w = 0.2;
	ctrl.styleAdd = BS_CHECKBOX;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "dt_rep_date"; //m_hwndDP = CreateWindowExW(WS_EX_TOPMOST,  DATETIMEPICK_CLASSW, L"DateTime", WS_BORDER | WS_CHILD | WS_VISIBLE | DTS_SHOWNONE, cl_panel_no_expand_w/*p_ctrl->x + p_ctrl->w*/, p_ctrl->y, 220, 40, g_hwndCP, NULL, g_hInstance, NULL);
	ctrl.classWnd = "SysDateTimePick32"; //DATETIMEPICK_CLASSA
	ctrl.styleAdd = WS_BORDER;// | DTS_SHOWNONE;
	ctrl.mul_w = 1.54;
	ctrl.mul_h = 1.2;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_date_to";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���� �.";
	ctrl.mul_w = 0.8;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "check_rep_date_to";
	ctrl.classWnd = "button";
	ctrl.mul_w = 0.2;
	ctrl.styleAdd = BS_CHECKBOX;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "dt_rep_date_to";
	ctrl.classWnd = "SysDateTimePick32"; //DATETIMEPICK_CLASSA
	ctrl.styleAdd = WS_BORDER;// | DTS_SHOWNONE;
	ctrl.mul_w = 1.54;
	ctrl.mul_h = 1.2;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_mode";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�����";
	ctrl.mul_w = 0.6;
	ctrl.mul_h = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_mode";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.98;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_stop";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 1;
	ctrl.mul_h = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_stop";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_hour";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���";
	ctrl.mul_w = 1;
	ctrl.mul_h = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_hour";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_route";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�������";
	ctrl.mul_w = 1;
	ctrl.mul_h = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_route";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_shape";
	ctrl.classWnd = "static";
	ctrl.textWnd = "������.";
	ctrl.mul_w = 1;
	ctrl.mul_h = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_shape";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_shape_stop_from";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���. ��.";
	ctrl.mul_w = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_shape_stop_from";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_shape_stop_to";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���. ��.";
	ctrl.mul_w = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_shape_stop_to";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_shape_stop_from_time";
	ctrl.classWnd = "static";
	ctrl.textWnd = "��.���.��.";
	ctrl.mul_w = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_shape_stop_from_time";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_shape_stop_to_time";
	ctrl.classWnd = "static";
	ctrl.textWnd = "��.���.��.";
	ctrl.mul_w = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_shape_stop_to_time";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_area";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�����";
	ctrl.mul_w = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_area";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_street";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�����";
	ctrl.mul_w = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_street";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "static_rep_device";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����.";
	ctrl.mul_w = 1;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_rep_device";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	g_cp_p_ctrls->NewRow("static_rep");

	ctrl.Clear();
	ctrl.name = "but_rep";
	ctrl.classWnd = "button";
	ctrl.textWnd = "��������"; 
	ctrl.mul_w = 2.3;
	g_cp_p_ctrls->Add(ctrl);

	FillCtrlsReps();
}



void CControlPanelWnd::AddCtrlsAudio()
{
	SCtrl ctrl;

	g_cp_p_ctrls->NewRow();

	ctrl.Clear();
	ctrl.name = "static_audio";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�����";
	ctrl.mul_w = 0.65;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_audio_device";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 1.1;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_audio_device";
	ctrl.classWnd = "button";
	ctrl.textWnd = "�����";
	ctrl.mul_w = 1.52;
	g_cp_p_ctrls->Add(ctrl);

	fill_combo_device("combo_audio_device"); //YUIL 2017-10-09 ���������� �� �������
}

void CControlPanelWnd::AddCtrlsFindNearCar()
{
	SCtrl ctrl;

	g_cp_p_ctrls->NewRow();

	ctrl.Clear();
	ctrl.name = "static_find_near_car";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����� �������� ������";
	ctrl.mul_w = 2.7;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_find_near_car";
	ctrl.classWnd = "button";
	ctrl.textWnd = "���";
	ctrl.mul_w = 0.52;
	g_cp_p_ctrls->Add(ctrl);

}

void CControlPanelWnd::AddCtrlsCarLagLead()
{
	SCtrl ctrl;

	g_cp_p_ctrls->NewRow();

 ctrl.Clear();
	ctrl.name = "static_car_lag_lead";
	ctrl.classWnd = "static";
	ctrl.textWnd = "��� ���.";
	ctrl.mul_w = 1.0;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_car_lag_lead";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.0;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

	fill_combo_car_lag_lead();
	/*	ctrl.Clear();
	ctrl.name = "but_car_lag_lead";
	ctrl.classWnd = "button";
	ctrl.textWnd = "���";
	ctrl.mul_w = 0.52;
	g_cp_p_ctrls->Add(ctrl);*/

}

void CControlPanelWnd::AddCtrlsRep8()
{
	SCtrl ctrl;

	g_cp_p_ctrls->NewRow();

	ctrl.Clear();
	ctrl.name = "static_agent";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�����������";
	ctrl.mul_w = 1.3;
	ctrl.styleAdd = SS_CENTER;
	g_cp_p_ctrls->Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_agent";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.1;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);

}


void CControlPanelWnd::Fill_combo_route()
{
	if (g_cp_p_ctrls==0) {return;}
	int index = 0;

	SRoute o;

	g_cp_p_ctrls->SendMes("combo_route", CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);

	g_cp_p_ctrls->SendMes("combo_route", CB_ADDSTRING, (WPARAM)0, (LPARAM)"���");
	g_cp_p_ctrls->SendMes("combo_route", CB_ADDSTRING, (WPARAM)0, (LPARAM)"����.");

	while (gDrawWnd.NextRoute(index, o))
	{
		char *p_name = (char *)o.route_short_name.c_str();

		g_cp_p_ctrls->SendMes("combo_route", CB_ADDSTRING, (WPARAM)0, (LPARAM)p_name);
	}

	g_cp_p_ctrls->SendMes("combo_route", CB_SETCURSEL, (WPARAM)0, (LPARAM)0);
}

void CControlPanelWnd::Fill_combo_stop()
{
	if (g_cp_p_ctrls==0) {return;}

	int index = 0;

	SStop o;
	g_cp_p_ctrls->SendMes("combo_stop", CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);

	g_cp_p_ctrls->SendMes("combo_stop", CB_ADDSTRING, (WPARAM)0, (LPARAM)"���");
	g_cp_p_ctrls->SendMes("combo_stop", CB_ADDSTRING, (WPARAM)0, (LPARAM)"����.");

	while (gDrawWnd.NextStop(index, o))
	{
		char *p_name = (char *)o.stop_name.c_str();

		g_cp_p_ctrls->SendMes("combo_stop", CB_ADDSTRING, (WPARAM)0, (LPARAM)p_name);
	}

	g_cp_p_ctrls->SendMes("combo_stop", CB_SETCURSEL, (WPARAM)0, (LPARAM)0);
}

void CControlPanelWnd::Fill_combo_zone()
{
	if (g_cp_p_ctrls==0) {return;}

	int index = 0;

	SZone o;
	
	g_cp_p_ctrls->SendMes("combo_zone", CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);

	g_cp_p_ctrls->SendMes("combo_zone", CB_ADDSTRING, (WPARAM)0, (LPARAM)"���");
	g_cp_p_ctrls->SendMes("combo_zone", CB_ADDSTRING, (WPARAM)0, (LPARAM)"����.");

	while (gDrawWnd.NextZone(index, o))
	{
		char *p_name = (char *)o.name.c_str();

	 g_cp_p_ctrls->SendMes("combo_zone", CB_ADDSTRING, (WPARAM)0, (LPARAM)p_name);
	}

	g_cp_p_ctrls->SendMes("combo_zone", CB_SETCURSEL, (WPARAM)0, (LPARAM)0);
}

void CControlPanelWnd::FillStaticTextByCombo(char *sz_name_combo_src)
{
	if (g_cp_p_ctrls==0) {return;}

	char sz_buf[MAX_PATH + 1];

	g_cp_p_ctrls->SendMes(sz_name_combo_src, WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_buf);

	g_cp_p_ctrls->SendMes("static_text", WM_SETTEXT, (WPARAM)0, (LPARAM)sz_buf);
}

void CControlPanelWnd::SetStaticText(char *sz_text) { m_ctrls.SendMes("static_text", WM_SETTEXT, (WPARAM)0, (LPARAM)sz_text); }

void CControlPanelWnd::combo_rep_op(int index)
{
	if (g_cp_p_ctrls==0) {return;}

	g_cp_p_ctrls->SendMes("combo_rep_mode", CB_RESETCONTENT, 0, 0);

	if (index == 0) 
	{ 
		fill_combo_rep_mode("����|����|����-����");
		fill_combo_rep_hour(5, 23); 
	} else
	if (index == 1 || index == 2)
	{ 
		fill_combo_rep_mode();
		fill_combo_rep_hour(0, 23); 
	}
	else
	if (index == 3)
	{
		fill_combo_rep_mode("�� ���������|�� ������|�� �����");
		fill_combo_rep_area();
		fill_combo_rep_street();
	}
	else
	if (index == 4)
	{
		fill_combo_rep_mode("����|����");
	}
	else
	if (index == 5)
	{
		fill_combo_rep_street();
	}
	else
	if (index == 6)
	{
		fill_combo_rep_mode("����|��� �����");
	}
	else
	if (index == 7)
	{
		fill_combo_rep_mode("����|����");
		fill_combo_agent();
	}
	else
	if (index == 8)
	{					
		fill_combo_device("combo_rep_device");
	}			
}

void CControlPanelWnd::WM__COMMAND(int id, int notify, int index_rep) 
{                                         //DWORD idThread =GetCurrentThreadId();
	//if (g_cp_l_fin_cr_ctrls == 0) {return;}

	if (g_cp_p_ctrls==0) 	{return;}

	char sz_buf[MAX_PATH + 1];

	SCtrl* p_ctrl;
	
	try
	{
		if (g_cp_p_ctrls->Find(id, &p_ctrl))
		{
			if (p_ctrl->name == "combo_route")
			{
				if (notify == CBN_SELCHANGE)
				{
					int index = g_cp_p_ctrls->SendMes("combo_route", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

					gDrawWnd.SelectRoute(index);				
				}
			}else
			if (p_ctrl->name == "combo_stop")
			{
				if (notify == CBN_SELCHANGE)
				{
					int index = g_cp_p_ctrls->SendMes("combo_stop", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

					gDrawWnd.SelectStop(index);

					FillStaticTextByCombo("combo_stop");
				}
			}
			else
			if (p_ctrl->name == "but_zone_new_save")
			{ 
				if (gDrawWnd.ZoneNewSave())
				{
					Fill_combo_zone();

					Set_but_cr_zone_text_close();

					gDrawWnd.ZoneNewClear("");
				}
			}
			else
			if (p_ctrl->name == "but_zone_del")
			{
				g_cp_p_ctrls->SendMes("combo_zone", CB_SETCURSEL, (WPARAM)0, (LPARAM)0);

				gDrawWnd.SelectZoneDel();

				Fill_combo_zone();
			}
			else
			if (p_ctrl->name == "combo_form_mes")
			{
				if (notify == CBN_SELCHANGE)
				{
					int index = g_cp_p_ctrls->SendMes("combo_form_mes", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
					
					//g_cp_p_ctrls->SendMes("static_text", WM_SETTEXT, (WPARAM)0, (LPARAM)gFormMes.GetRowLongText(index, sz_buf));
				}
			}
			else
			if (p_ctrl->name == "but_form_mes_send")
			{
				int index = g_cp_p_ctrls->SendMes("combo_form_mes", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

				//gFormMes.Send(index);
			}		
			else
			if (p_ctrl->name == "combo_rep")
			{
				if (notify == CBN_SELCHANGE)
				{
					
					int index = g_cp_p_ctrls->SendMes("combo_rep", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
					
					combo_rep_op(index);		

					FillStaticTextByCombo("combo_rep");
				}
			}
			else
			if (p_ctrl->name == "but_rep") 
			{ 
				Rep(index_rep);
			}
			else
			if (p_ctrl->name == "combo_rep_stop")
			{
				if (notify == CBN_SELCHANGE) { FillStaticTextByCombo("combo_rep_stop"); }
			}
			else
			if (p_ctrl->name == "combo_rep_mode")
			{
				if (notify == CBN_SELCHANGE) 
				{ 
					if (index_rep == 3)
					{
						ERep3Mode eRep3Mode = (ERep3Mode)g_cp_p_ctrls->SendMes("combo_rep_mode", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

						g_cp_p_ctrls->SendMes_CB_RESETCONTENT("combo_rep_shape");

						if (eRep3Mode == ER3M_STOP)
						{
							fill_combo_rep_stop();
							g_cp_p_ctrls->SendMes_CB_RESETCONTENT("combo_rep_area");
							g_cp_p_ctrls->SendMes_CB_RESETCONTENT("combo_rep_street");
						}
						else
							if (eRep3Mode == ER3M_AREA)
							{
								fill_combo_rep_area();
								g_cp_p_ctrls->SendMes_CB_RESETCONTENT("combo_rep_stop");
								g_cp_p_ctrls->SendMes_CB_RESETCONTENT("combo_rep_street");
							}
							else
								if (eRep3Mode == ER3M_STREET)
								{
									fill_combo_rep_street();
									g_cp_p_ctrls->SendMes_CB_RESETCONTENT("combo_rep_stop");
									g_cp_p_ctrls->SendMes_CB_RESETCONTENT("combo_rep_area");
								}
					}

					FillStaticTextByCombo("combo_rep_mode"); 
				}
			}
			else
			if (p_ctrl->name == "check_rep_date") 
			{ 
				int i_val=g_cp_p_ctrls->SendMes("check_rep_date", BM_GETCHECK, (WPARAM)0, (LPARAM)0);

				i_val = i_val ? 0 : 1;

				g_cp_p_ctrls->SendMes("check_rep_date", BM_SETCHECK, (WPARAM)i_val, (LPARAM)0);
			}		
			else
			if (p_ctrl->name == "check_rep_date_to")
			{
				int i_val = g_cp_p_ctrls->SendMes("check_rep_date_to", BM_GETCHECK, (WPARAM)0, (LPARAM)0);

				i_val = i_val ? 0 : 1;

				g_cp_p_ctrls->SendMes("check_rep_date_to", BM_SETCHECK, (WPARAM)i_val, (LPARAM)0);
			}
			else
			if (p_ctrl->name == "combo_rep_route")
			{
				if (notify == CBN_SELCHANGE) 
				{ 
					int index_mode = g_cp_p_ctrls->SendMes("combo_rep_mode", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

					if (index_mode == 0) { fill_combo_rep_shape(); } else
					if (index_mode == 1) { fill_combo_rep_stops_by_dyn(); } //YUIL 2017-09-29 ��������� �� ������������ ��������. ����.
				}
			}
			else
			if (p_ctrl->name == "combo_rep_shape")
			{
				if (notify == CBN_SELCHANGE) 
				{ 
					fill_combo_rep_shape_stop(); 
					FillStaticTextByCombo("combo_rep_shape"); 
				}
			}
			else
			if (p_ctrl->name == "combo_rep_shape_stop_from")
			{
				if (notify == CBN_SELCHANGE) 
				{ 
					int index_mode= g_cp_p_ctrls->SendMes("combo_rep_mode", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

					if (index_mode == 0) { fill_combo_rep_shape_stop_time("combo_rep_shape_stop_from", "combo_rep_shape_stop_from_time", g_fill_combo_rep_shape_stop_from_time); } else
					if (index_mode == 1) { fill_combo_rep_shape_stop_time_by_dyn("combo_rep_shape_stop_from", "combo_rep_shape_stop_from_time", g_fill_combo_rep_shape_stop_from_time_by_dyn); }

					FillStaticTextByCombo("combo_rep_shape_stop_from"); 
				}
			}
			else
			if (p_ctrl->name == "combo_rep_shape_stop_to")
			{
				if (notify == CBN_SELCHANGE)
				{
					int index_mode = g_cp_p_ctrls->SendMes("combo_rep_mode", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

					if (index_mode == 0) { fill_combo_rep_shape_stop_time("combo_rep_shape_stop_to", "combo_rep_shape_stop_to_time", g_fill_combo_rep_shape_stop_to_time);} else
					if (index_mode == 1) { fill_combo_rep_shape_stop_time_by_dyn("combo_rep_shape_stop_to", "combo_rep_shape_stop_to_time", g_fill_combo_rep_shape_stop_to_time_by_dyn); }

					FillStaticTextByCombo("combo_rep_shape_stop_to");
				}
			}
			else
			if (p_ctrl->name == "combo_rep_area")
			{
				if (notify == CBN_SELCHANGE) { FillStaticTextByCombo("combo_rep_area"); }
			}
			else
			if (p_ctrl->name == "combo_rep_street")
			{
				if (notify == CBN_SELCHANGE) { FillStaticTextByCombo("combo_rep_street"); }
			}
			else
			if (p_ctrl->name == "combo_rep_device")
			{
				if (notify == CBN_SELCHANGE) { FillStaticTextByCombo("combo_rep_device"); }
			}
			else
			if (p_ctrl->name == "but_audio_device")
			{			
				if (gAudioDevice.IsDevice() == false)
				{
					if (g_cp_p_ctrls->SendMes("combo_audio_device", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_buf) == 0) { gMesWnd.Mes("������ ������ ����� ����������"); }
					else
					{
						g_cp_p_ctrls->SendMes("combo_audio_device", CB_RESETCONTENT, (WPARAM)FALSE, (LPARAM)0); 

						gAudioDevice.SetDevice(sz_buf);

						sprintf(sz_buf, "���� %s", gAudioDevice.GetDevice());

						SetWindowTextA(p_ctrl->hwnd, sz_buf);

						gAudioDevice.StartWrite();
					}
				}
				else
				{
					fill_combo_device("combo_audio_device");

					SetWindowTextA(p_ctrl->hwnd, "�����");

					gAudioDevice.ClearDevice();
				}
				
			}
			else
			if (p_ctrl->name == "but_find_near_car")
			{
				g_cp_p_ctrls->SendMes("but_find_near_car", WM_SETTEXT, (WPARAM)0, (LPARAM)(gDrawWnd.IsFindNearCar()?"���":"����")); 
				
				gDrawWnd.InvertFindNearCar();
			}else
			/*if (p_ctrl->name == "combo_car_lag_lead")
			{
				if (notify == CBN_SELCHANGE) 
				{ 
					FillStaticTextByCombo("combo_car_lag_lead"); 

					int index = g_cp_p_ctrls->SendMes("combo_car_lag_lead", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
					
					if (index>=0){ gDrawWnd.SetCarLagLeadView((ECarLagLeadView)index); }
				}
			}				
			else
			if (p_ctrl->name == "but_car_lag_lead")
			{
				ctrls.SendMes("but_car_lag_lead", WM_SETTEXT, (WPARAM)0, (LPARAM)(gDrawWnd.IsCarLagLead()?"���":"����")); 
				
				gDrawWnd.InvertCarLagLead();
			}
			else*/
			if (p_ctrl->name == "combo_agent")
			{
				if (notify == CBN_SELCHANGE) { FillStaticTextByCombo("combo_agent"); }
			}		
		}
	}catch(...) 
	{
		
	}	
}

int CControlPanelWnd::SendMes(char *name, UINT uMes, WPARAM wParam, LPARAM lParam)
{
	if (g_cp_p_ctrls==0) {return 0;}

	return g_cp_p_ctrls->SendMes(name, uMes, wParam, lParam);
}

bool CControlPanelWnd::Find(char *name, SCtrl* *p_ctrl)
{
	if (g_cp_p_ctrls==0) {return false;}

	return g_cp_p_ctrls->Find(name, p_ctrl);
}

void CControlPanelWnd::Update()
{
	if (g_cp_p_ctrls==0) {return;}

	g_cp_p_ctrls->Update();
}

