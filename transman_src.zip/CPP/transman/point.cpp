#include "point.h"
#include <memory.h>
#include "math_e.h"

SPointInt::SPointInt() { memset(this, 0, sizeof(SPointInt)); }

void SPointInt::SetByLatLng(const Leaflet::LatLng& latlng, double zoom)
{
	math_e::LatitudeLongitudeToScreenPoint(latlng.lat, latlng.lng, zoom, x, y, &xPrj, &yPrj);
}

void SPointInt::GetLatLng(Leaflet::LatLng& latlng, double zoom)
{
	//YUIL ��������� ��� zoom>2
	math_e::ScreenPointToLatitudeLongitude(x, y, zoom, latlng.lat, latlng.lng);
}