#include <memory.h>
#include <windows.h>
#include "audio_device.h"
#include "mes_wnd.h"
#include <mmeapi.h>
#include <mmreg.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "main.h"
#include "mssql.h"
#include "MesWnd.h"
#include "..\\transman_srv\\time_e.h"
#include "..\\transman_srv\\str.h"

const char *csz_path_audio_out = "C:\\transman\\audio_out";

const DWORD c_audio_format= WAVE_FORMAT_1M08;  /* mmeapi.h : 11.025 kHz, Mono,   8-bit  */

const WORD c_audio_SamplesPerSec = 11025; //Herz

const WORD c_audio_bitsPerSample = 8; //������� ����� / ��������. 8 16 32 ...

const int ci_audio_len_buf = 1024; //256;

long g_audio_write_cycle_done=0;

DWORD WINAPI CAudioDevice_ThreadProc(LPVOID lpParameter);

void CAudioDevice_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesWnd.Mes("CAudioDevice. ������ MS SQL : %s", sz_text);
}

bool CAudioDevice::Open()
{
	memset(this, 0, sizeof(CAudioDevice));
	
	m_fInit=true;

	return m_fInit;
}

void CAudioDevice::Close()
{
	FinWrite();

	if (m_h_buf.lpData) { delete m_h_buf.lpData; }
}

bool CAudioDevice::StartWrite()
{
	g_audio_write_cycle_done = 1;

	HANDLE h = CreateThread(0, 0, CAudioDevice_ThreadProc, (LPVOID)this, 0, 0);

	return h != 0;
}

DWORD WINAPI CAudioDevice_ThreadProc(LPVOID lpParameter)
{
	CAudioDevice *p_this = (CAudioDevice *)lpParameter;

	if (p_this == 0) { return 0; }

	while (g_audio_write_cycle_done)
	{
		p_this->Write();

		Sleep(200);
	}

	return 1;
}

DWORD WINAPI CAudioDevice_InProc(DWORD dwInstance)
{
	return 1;
}

void CAudioDevice::ErrMes(UINT u_res)
{
	if (u_res == MMSYSERR_BADDEVICEID) { gMesWnd.Mes(" CAudioDevice. Specified device identifier is out of range."); } else
	if (u_res == MMSYSERR_NODRIVER) { gMesWnd.Mes(" CAudioDevice. No device driver is present."); } else
	if (u_res == MMSYSERR_NOMEM) { gMesWnd.Mes(" CAudioDevice. Unable to allocate or lock memory."); } else
	if (u_res == MMSYSERR_ALLOCATED) { gMesWnd.Mes("CAudioDevice. Specified resource is already allocated."); } else
	if (u_res == WAVERR_BADFORMAT) { gMesWnd.Mes("CAudioDevice. Attempted to open with an unsupported waveform - audio format."); } else
	if (u_res == MMSYSERR_INVALHANDLE) { gMesWnd.Mes("CAudioDevice. Specified device handle is invalid."); } else
	if (u_res == MMSYSERR_INVALPARAM) { gMesWnd.Mes("CAudioDevice. The buffer's base address is not aligned with the sample size."); } else
	if (u_res == WAVERR_UNPREPARED) { gMesWnd.Mes("CAudioDevice. Buffer pointed to by the pwh parameter has not been prepared."); } else
	if (u_res == WAVERR_STILLPLAYING) { gMesWnd.Mes("CAudioDevice. ��������� ����� ��� ��� � �������;"); } else
	if (u_res == WAVERR_UNPREPARED) { gMesWnd.Mes("CAudioDevice. ����� �� ��� �����������;"); }

	{}
}

void CAudioDevice::Write()
{
	if (gControlPanelWnd.GetHWND()==0) {return;}

	if (m_fInputInit == false)
	{
		UINT q_devs = waveInGetNumDevs();

		if (q_devs == 0) { gMesWnd.Mes("CAudioDevice::Write(). Not found input audio device"); return; }

		UINT u_res;

		WAVEINCAPS wic;

		UINT u_dev=0;

		bool fFound = false;

		/*for (u_dev = 0; fFound == false && u_dev < q_devs; u_dev++)
		{*/
		memset(&wic, 0, sizeof(WAVEINCAPS));

		u_res = waveInGetDevCaps(u_dev, &wic, sizeof(WAVEINCAPS));

		if (u_res != MMSYSERR_NOERROR) { ErrMes(u_res); return; }

		fFound = true; //if (wic.dwFormats & c_audio_format) {  }
		//}

		if (fFound == false) { gMesWnd.Mes("CAudioDevice::Write(). ����� ���������� ��� ���������� ������� �� �������"); return; }

		DWORD fdwOpen = CALLBACK_WINDOW | WAVE_FORMAT_DIRECT; // | WAVE_FORMAT_QUERY;

		fill_m_wfx();

		u_res = waveInOpen(&m_h_in, u_dev, &m_wfx, (DWORD)gControlPanelWnd.GetHWND(), 0, fdwOpen);

		if (u_res != MMSYSERR_NOERROR) { ErrMes(u_res); return; }

		memset(&m_h_buf, 0, sizeof(WAVEHDR)); 

		m_h_buf.lpData = new char[ci_audio_len_buf];

		if (m_h_buf.lpData == 0) { FinWrite(); return;	}

		CleanBuf();
		
		m_h_buf.dwBufferLength = ci_audio_len_buf;
		
		u_res = waveInPrepareHeader(m_h_in, &m_h_buf, sizeof(WAVEHDR));

		if (u_res != MMSYSERR_NOERROR) { ErrMes(u_res); FinWrite(); return; }

		u_res = waveInAddBuffer(m_h_in, &m_h_buf, sizeof(WAVEHDR)); 

		if (u_res != MMSYSERR_NOERROR) { ErrMes(u_res); FinWrite(); return; }

		u_res = waveInStart(m_h_in);  // ��� ����� ���� �� ����
		
		if (u_res != MMSYSERR_NOERROR) { ErrMes(u_res); FinWrite(); return; }
		
		m_fInputInit = true;
	}
}

void CAudioDevice::fill_m_wfx()
{
		m_wfx.wFormatTag = WAVE_FORMAT_PCM;                          // format type 

  m_wfx.nChannels = 1;                                         // number of channels (i.e. mono, stereo...)

  m_wfx.nSamplesPerSec = c_audio_SamplesPerSec;                // sample rate . Herz

		m_wfx.wBitsPerSample = c_audio_bitsPerSample;                // number of bits per sample of mono data 

		m_wfx.nBlockAlign = m_wfx.nChannels * m_wfx.wBitsPerSample / 8;  // block size of data , ������� �� 8 ��������� � �����

  m_wfx.nAvgBytesPerSec= m_wfx.nSamplesPerSec * m_wfx.nBlockAlign; // for buffer estimation 

  m_wfx.cbSize = sizeof(WAVEFORMATEX); 
}

void CAudioDevice::CleanBuf()
{
	if (m_h_buf.lpData) { memset(m_h_buf.lpData, 0, ci_audio_len_buf); }
}

void CAudioDevice::MesProc(UINT u_mes, WPARAM wparam, LPARAM lparam)
{
	if (m_fInputInit==false)  {return;}

 if (u_mes==MM_WIM_OPEN)
	{
		HWAVEIN hwi = (HWAVEIN)wparam;

	}else
	if (u_mes==MM_WIM_CLOSE)
	{
		HWAVEIN hwi = (HWAVEIN)wparam;

	}
	if (u_mes==MM_WIM_DATA)
	{
		HWAVEIN hwi = (HWAVEIN)wparam;

		WAVEHDR* p_hdr=(WAVEHDR*)lparam;  

		if (p_hdr->dwBufferLength == p_hdr->dwBytesRecorded)
		{			
			ReadBuf(); //����� ����� ������ � ����
		}
	}
}

void CAudioDevice::FinWrite()
{
	InterlockedExchange(&g_audio_write_cycle_done, 0);

	UINT u_res = waveInStop(m_h_in);
	
	if (u_res != MMSYSERR_NOERROR) { ErrMes(u_res); }

	u_res = waveInClose(m_h_in);

	if (u_res != MMSYSERR_NOERROR) { ErrMes(u_res); }

	ReadBuf();
}

void CAudioDevice::ReadBuf()
{
	ReadBufOp();

	UINT u_res = waveInUnprepareHeader(m_h_in, &m_h_buf, sizeof(WAVEHDR)); 
	
	if (u_res != MMSYSERR_NOERROR) { ErrMes(u_res); }

	CleanBuf();
}

void CAudioDevice::fill_wav_file(char *sz_file)
{
	sprintf(sz_file,"%s\\%s_",csz_path_audio_out, device_number.c_str());
	
	char ch_replace = '_';

	time_e::LocalTimeToText(sz_file, ch_replace);

	strcat(sz_file, ".wav");
}

void CAudioDevice::FillWaveHeader(SWaveHeader& hdr)
{
	DWORD u_file_len = sizeof(SWaveHeader) + m_h_buf.dwBytesRecorded; //44 + ...

	memcpy(hdr.chunkId, "RIFF", 4);

	hdr.chunkSize = u_file_len - 8;

	memcpy(hdr.charformat, "WAVE", 4);

	memcpy(hdr.subchunk1Id, "fmt ", 4);

	hdr.subchunk1Size = 16;

	hdr.audioFormat = 1;

	hdr.numChannels = 1;

	hdr.sampleRate = c_audio_SamplesPerSec;

	hdr.byteRate = m_wfx.nAvgBytesPerSec;

	hdr.blockAlign = m_wfx.nBlockAlign;

	hdr.bitsPerSample = m_wfx.wBitsPerSample;

	memcpy(hdr.subchunk2Id, "data", 4);

	hdr.subchunk2Size = m_h_buf.dwBytesRecorded;

}

void CAudioDevice::cr_wav_file(SWaveHeader& hdr)
{
	char sz_file[MAX_PATH+1];
	
	fill_wav_file(sz_file);

	int fo=open(sz_file, O_WRONLY | O_BINARY | O_CREAT, S_IREAD);

	if (fo<0) { gMesWnd.Mes("CAudioDevice. ������ �������� �����"); return;}

	int i_written = write(fo, (char*)&hdr, sizeof(SWaveHeader));

	if (i_written != sizeof(SWaveHeader)) { gMesWnd.Mes("CAudioDevice. ������ ������ ��������� �����"); close(fo); return;}

	i_written = write(fo, m_h_buf.lpData, m_h_buf.dwBytesRecorded);

 if (i_written != m_h_buf.dwBytesRecorded) { gMesWnd.Mes("CAudioDevice. ������ ������ ������ �����"); close(fo); return;}

	close(fo);

}

void CAudioDevice::fill_wav_file_sql_binary(std_string& wav_file, char* p_data, int len_data)
{
	char sz_buf[MAX_PATH+1];

	for (int i=0; i<len_data; i++)
	{
		char b = p_data[i];

		ByteToHex(sz_buf, b, MAX_PATH);

		wav_file.append(sz_buf);
	}
}

void CAudioDevice::SaveToDB(SWaveHeader& hdr)
{
	std_string wav_file="0x";

	fill_wav_file_sql_binary(wav_file, (char*)&hdr, sizeof(SWaveHeader));

	fill_wav_file_sql_binary(wav_file, m_h_buf.lpData, m_h_buf.dwBytesRecorded);

	std_string sz_query = "DECLARE @id_audio_out_prev BIGINT; SET @id_audio_out_prev=ISNULL((SELECT MAX(id_audio_out) FROM dbo.audio_out), 0);\r\n";

	sz_query.append("SET IDENTITY_INSERT dbo.audio_out ON\r\n");

 sz_query.append("INSERT dbo.audio_out(id_audio_out, dt_created,  device_number,  wav_file)\r\n");

 sz_query.append("SELECT     @id_audio_out_prev + 1,  GETDATE(), N'"); sz_query.append(device_number.c_str()); sz_query.append("', "); sz_query.append(wav_file.c_str()); sz_query.append("\r\n");
 
	sz_query.append("SET IDENTITY_INSERT dbo.audio_out OFF");

	bool f_exec = MSSQL_Exec((char*)sz_query.c_str(), 0, CAudioDevice_FN_MSSQL_MES_ERR, (void*)this);
}

void CAudioDevice::ReadBufOp()
{
	if (m_h_buf.dwBytesRecorded==0) { return; }

	SWaveHeader hdr;	

	FillWaveHeader(hdr);

	cr_wav_file(hdr);

	//SaveToDB(hdr);
}

CAudioDevice gAudioDevice;