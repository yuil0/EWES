#include <memory.h>
#include <windows.h>
#include "draw_ate_3.h"
#include "MesWnd.h"
#include "math_e.h"
#include "draw_data.h"
#include "..\\transman_srv\\str.h"
#include "..\\transman_srv\\time_e.h"
#include "ini_file.h"
#include "BookMarks.h"
#include "ini_file.h"

const int ci_sleep_between_load = 600;
int g_count_ch_route=0; //YUIL 2017-02-02 //������� ����� ���������

std::vector<SDeviceATE_3> gVisibleCars;
std::vector<SShapePoint> gVisibleShapePoints;

CDrawATE_3::CDrawATE_3(){}

CDrawATE_3::~CDrawATE_3(){}

void CDrawATE_3_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesWnd.Mes("CControlPanelWnd_rep. ������ MS SQL : %s", sz_text);
}

void SLoadVisibleShapePoints_add(void *p_param, FldsPtr fp) 
{ 
	SLoadVisibleShapePoints* p_this = (SLoadVisibleShapePoints*)p_param; 
	
	if (p_this) 
	{ 
		p_this->add(fp); 
	} 
}

void SLoadVisibleShapePoints::add(FldsPtr fp)
{
	SShapePoint o;

	VARIANT v_shape_pt_sequence = fp->Item["shape_pt_sequence"]->Value; //date
	VARIANT v_lat = fp->Item["lat"]->Value;  //.decVal.Lo32 , scale
	VARIANT v_lng = fp->Item["lng"]->Value;  //.decVal.Lo32 , scale

	double lat, lng;

	lat = v_lat.decVal.Lo32 / pow(10, v_lat.decVal.scale);
	lng = v_lng.decVal.Lo32 / pow(10, v_lng.decVal.scale);


	math_e::LatitudeLongitudeToScreenPoint(lat, lng, zoom, o.x, o.y);

	//o.x = v_x.decVal.Lo32 / pow(10, v_x.decVal.scale);
	//o.y = v_y.decVal.Lo32 / pow(10, v_y.decVal.scale);

	gVisibleShapePoints.push_back(o);
}

void LoadVisibleShapePoints(char* shape_id_postfix, double zoom) //_a-b, _a-b_option1
{
	gVisibleShapePoints.clear();

	char sz_query[500 + 1]; strcpy(sz_query, "select shape_pt_sequence, shape_pt_lat lat, shape_pt_lon lng from dbo.picas_shapes where shape_id=(select route_id from  dbo.picas_routes where agency_id = (SELECT id FROM dbo.picas_agents where id_agent = 29))");	
		

	strcat(sz_query, "+'");
	strcat(sz_query, shape_id_postfix);
	strcat(sz_query, "' ORDER BY shape_pt_sequence");

	SLoadVisibleShapePoints s(zoom);

	bool fExec = MSSQL_Exec(sz_query, SLoadVisibleShapePoints_add, CDrawATE_3_FN_MSSQL_MES_ERR, &s);

	if (fExec == false)
	{
		gMesWnd.Mes("LoadVisibleShapePoints(). ������ MSSQL");
	}
}

bool CDrawATE_3::Open()
{
	memset(this, 0, sizeof(CDrawATE_3));

	m_fInit = true;

	LoadIni(); //Load();

	m_f_draw = true;

	return m_fInit;
}

void CDrawATE_3::Close()
{

}

/*DWORD WINAPI CDrawATE_3_Load_proc(LPVOID lpParameter)
{
	CDrawATE_3* p_this= (CDrawATE_3*)lpParameter;

	if (p_this==0) {return  0;}

	while(1)
	{
		p_this->LoadTh();

		Sleep(500);
	}

	return 1;
}*/

//void CDrawATE_3::Load() { HANDLE h = CreateThread(0, 0, CDrawATE_3_Load_proc, this, 0, 0); }

/*void CDrawATE_3::LoadTh()
{
		LoadOp(); //FillLagLead();

		InterlockedExchange(&m_l_copy_proc, 1); //gMesWnd.Mes("CDrawATE_3::LoadTh(). start copy");
		
		m_dev_list_draw = m_dev_list;

		InterlockedExchange(&m_l_copy_proc, 0); //gMesWnd.Mes("CDrawATE_3::LoadTh(). end copy");
}*/

void CDrawATE_3::LoadIni()
{
	CIniFile ini;
	
	char sz_val[MAX_PATH + 1];

	if (ini.Get("C:\\transman\\transman.ini", "DrawATE_3_SElectSQLCondAllDate", sz_val, MAX_PATH))
	{
		m_fSElectSQLCondAllDate = atoi(sz_val);
	}

	if (ini.Get("C:\\transman\\transman.ini", "car_draw_radius", sz_val, MAX_PATH))
	{
		m_car_draw_radius = atoi(sz_val);
	}

	
}

void CDrawATE_3_LoadOp_ADD(void *p_param, FldsPtr fp)
{
	CDrawATE_3 * p_this = (CDrawATE_3*)p_param;

	if (p_this) {p_this->LoadOp_ADD(fp);}
}

void CDrawATE_3::LoadOp_ADD(FldsPtr fp)
{
	SDeviceATE_3 o;

	VARIANT v_dt = fp->Item["dt"]->Value; //date

	_bstr_t bstr_device_number(fp->Item["device_number"]->Value);

	VARIANT v_latitude = fp->Item["latitude"]->Value;  //.decVal.Lo32 , scale

	VARIANT v_longitude = fp->Item["longitude"]->Value;  //.decVal.Lo32 , scale

	VARIANT v_azimut = fp->Item["azimut"]->Value; //VT_I4;

	VARIANT v_speed = fp->Item["speed"]->Value; //VT_I4;

	VARIANT v_dt_created = fp->Item["dt_created"]->Value;

	VARIANT v_dt_update = fp->Item["dt_update"]->Value;

	_bstr_t bstr_route_short_name(fp->Item["route_short_name"]->Value); //YUIL 2017-09-13

	VARIANT v_x = fp->Item["x"]->Value;

	VARIANT v_y = fp->Item["y"]->Value;

	VARIANT v_id_picas_route = fp->Item["id_picas_route"]->Value;

	VARIANT v_id_agent = fp->Item["id_agent"]->Value;

	_bstr_t bstr_agent_name(fp->Item["agent_name"]->Value);

	VARIANT v_id_car_type = fp->Item["id_car_type"]->Value;	

	_bstr_t bstr_user_name(fp->Item["user_name"]->Value);
	
	_bstr_t bstr_sip_name(fp->Item["sip_name"]->Value);

	VARIANT v_i_lag_lead = fp->Item["i_lag_lead"]->Value;

	o.Clear();

	o.dt = v_dt.dblVal;

	strcpy(o.name, (char*)bstr_device_number);

	o.latlng.lat = v_latitude.decVal.Lo32 / pow(10, v_latitude.decVal.scale);

	o.latlng.lng = v_longitude.decVal.Lo32 / pow(10, v_longitude.decVal.scale);

	o.azimut = v_azimut.intVal;				//YUIL. ���� �� ����������� �� �����.

	o.speed = v_speed.intVal;				//YUIL . �������� / ���

	o.dt_created = v_dt_created.dblVal;

	o.dt_update = v_dt_update.dblVal;

	strcpy(o.route, (char*)bstr_route_short_name);

	o.x = v_x.dblVal;

	o.y = v_y.dblVal;

	o.id_picas_route = v_id_picas_route.decVal.Lo32;  //YUIL 2017-10-25. ��� ������ ��� ����������

	o.f_formalize_messages = fp->Item["f_formalize_messages"]->Value.intVal == 1;

	o.id_agent = v_id_agent.decVal.Lo32;

	strcpy(o.agent_name, (char*)bstr_agent_name);

	o.id_car_type = v_id_car_type.intVal;

	strcpy(o.user_name, (char*)bstr_user_name);

	strcpy(o.sip_name, (char*)bstr_sip_name);
	
	o.eLagLeadState = (ELagLeadState)v_i_lag_lead.intVal; //YUIL 2017-02-07

	m_dev_list.push_back(o);

	if (o.id_picas_route != 0) { m_count_id_picas_route_not_null++; }

}

////////////////////////////////////////////////////////////////////
void CDrawATE_3::LoadOp()
{
	m_dev_list.clear();

	m_count_id_picas_route_not_null = 0;

	std_string sz_query = "SELECT dt, c.device_number, latitude, longitude, azimut, speed, c.dt_created, dt_update, ISNULL(route_short_name, N'?')route_short_name, x, y "
		", ISNULL((SELECT id_picas_route FROM dbo.picas_routes r WHERE r.route_id = c.route_id), 0)id_picas_route "
		", ISNULL((SELECT TOP 1 1 FROM dbo.formalize_messages m WHERE m.id_ate_3 = c.id_ate_3), 0) f_formalize_messages "
		", ISNULL(c.id_agent, 0)id_agent, ISNULL(a.name, '')agent_name, id_car_type "
		", ISNULL(u.user_name, '')user_name "
		", ISNULL(u.sip_name, '')sip_name "		
		",CASE "
				"WHEN f_lag IS NULL THEN 0 "
				"WHEN f_lag = 1 THEN 1 "
				"ELSE 2 "
			"END i_lag_lead "
		"FROM dbo.ate_3 c LEFT JOIN dbo.picas_agents a ON(a.id_agent = c.id_agent)  "
		"LEFT JOIN dbo.users u ON(u.device_number = c.device_number)";

	if (m_fSElectSQLCondAllDate == false)
	{
		sz_query.append(" WHERE ISNULL(c.dt_update, c.dt_created) >= DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0)");
	}

	bool fExec = MSSQL_Exec((char*)sz_query.c_str(), CDrawATE_3_LoadOp_ADD, CDrawATE_3_FN_MSSQL_MES_ERR, this);
	
	if (fExec==false)
	{
		gMesWnd.Mes("CDrawATE_3::LoadOp(). ������ MSSQL");
	}

	m_fLoad=true;  //YUIL 2017-11-03 ��� ����������� ������ ��������
}

/*void SDeviceATE_3::AddLagLead(FldsPtr fp, bool fLag)
{
	_bstr_t bstr_stop_name(fp->Item["stop_name"]->Value);
	_bstr_t bstr_shape_id(fp->Item["shape_id"]->Value);
	_bstr_t bstr_arrival_time(fp->Item["arrival_time"]->Value);
	_bstr_t bstr_departure_time(fp->Item["departure_time"]->Value);

	SCarLagLead o;

	o.stop_name=(char*)bstr_stop_name;
	o.shape_id=(char*)bstr_shape_id;
	o.arrival_time=(char*)bstr_arrival_time;
	o.departure_time=(char*)bstr_departure_time;

	if (fLag) { m_lag.push_back(o); } else { m_lead.push_back(o); }
}

void CDrawATE_lag_3_FN_MSSQL_ADD(void *p_param, FldsPtr fp)
{
	SDeviceATE_3* p_this = (SDeviceATE_3*)p_param;

	if (p_this) {bool fLag=true; p_this->AddLagLead(fp, fLag);}
}

void CDrawATE_lead_3_FN_MSSQL_ADD(void *p_param, FldsPtr fp)
{
	SDeviceATE_3* p_this = (SDeviceATE_3*)p_param;

	if (p_this) {bool fLag=false; p_this->AddLagLead(fp, fLag);}
}

void CDrawATE_3::FillLagLead()
{
	bool f_exec;

	for (int i=0; i<m_dev_list.size(); i++)
	{
		SDeviceATE_3& o=m_dev_list[i];

		o.m_lag.clear();

		o.m_lead.clear();
		
		std_string sz_query = "SELECT stop_name, shape_id, CONVERT(NVARCHaR(8),arrival_time)arrival_time, CONVERT(NVARCHaR(8),departure_time)departure_time FROM dbo.car_lag_lead  cll, dbo.picas_stops s WHERE cll.stop_id = s.stop_id AND f_lag=1 AND device_number='";
		
		sz_query.append(o.name); sz_query.append("'"); 

		f_exec= MSSQL_Exec((char*)sz_query.c_str(), CDrawATE_lag_3_FN_MSSQL_ADD, CDrawATE_3_FN_MSSQL_MES_ERR, &o);		

		sz_query = "SELECT stop_name, shape_id, CONVERT(NVARCHaR(8),arrival_time)arrival_time, CONVERT(NVARCHaR(8),departure_time)departure_time FROM dbo.car_lag_lead  cll, dbo.picas_stops s WHERE cll.stop_id = s.stop_id AND f_lead=1 AND device_number='";
		
		sz_query.append(o.name); sz_query.append("'"); 

		f_exec= MSSQL_Exec((char*)sz_query.c_str(), CDrawATE_lead_3_FN_MSSQL_ADD, CDrawATE_3_FN_MSSQL_MES_ERR, &o);		
		
	}
}*/

void  SDeviceATE_3::Clear()
{
	memset(this, 0, sizeof(SDeviceATE_3));
}

/*
TypeDeviceATE_3List* CDrawATE_3::GetPList()
{ 
	TypeDeviceATE_3List *p = &m_dev_list;

	return p; // (TypeDeviceATE_3List*)&m_dev_list;
}*/

/*////////////////////////////////////////////////////////////////////
void CDrawATE_3::DrawOp(HDC hdc)
{
	for (int i = 0; i < m_dev_list.size(); i++)
	{
		SDeviceATE_3& o = m_dev_list[i]; 

		int xFrom = o.point.x + origin.x;
		int yFrom = o.point.y + origin.y;
	}
}*/

/*void SDeviceATE_3::Draw(int hdc, int i_draw_radius, char *sz_title_name, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list)//const SPointInt& origin, 
{
	int x = point.x; // +origin.x;
	int y = point.y; // + origin.y;

					 //if (IsHide(x, y, sizeWnd)) { continue; }

	BOOL fRes = Ellipse((HDC)hdc, x - i_draw_radius, y - i_draw_radius, x + i_draw_radius, y + i_draw_radius);

	bool f_in = math_e::inRectInt(clientMouse.x, clientMouse.y, x - i_draw_radius, y - i_draw_radius, x + i_draw_radius, y + i_draw_radius);

	if (f_in)
	{																	//sprintf(sz_text, "",  o.route_long_name);
		sel_point.Set(x + 2 * i_draw_radius, y - i_draw_radius);

		char sz_val[MAX_PATH + 1];

		sprintf(sz_val, "%s : %s", sz_title_name, GetDrawName()); //TextOutA(hdc, xFrom + 2*i_draw_radius, yFrom - i_draw_radius, p_name, strlen(p_name));

		sel_str_list.push_back(sz_val);  //strcat(sel_text, sz_val);
	}

}*/

void SDeviceATE_3::SelectGDI_Objs(int hdc, CDrawATE_3_Draw_param& param)
{
	HGDIOBJ *pgo = param.p_pen_brush;
	
	ECarType eCarType = (ECarType)(id_car_type - 1);

	if (eCarType == ECT_TROL)
	{
		SelectObject((HDC)hdc, (HPEN)pgo[EPB_PEN_TROL]);
		SelectObject((HDC)hdc, (HBRUSH)pgo[EPB_BRUSH_TROL]);
	}
	else
	if (eCarType == ECT_BUS)
	{
		SelectObject((HDC)hdc, (HPEN)pgo[EPB_PEN_BUS]);
		SelectObject((HDC)hdc, (HBRUSH)pgo[EPB_BRUSH_BUS]);
	}
	else
	if (eCarType == ECT_TRAM)
	{
		SelectObject((HDC)hdc, (HPEN)pgo[EPB_PEN_TRAM]);
		SelectObject((HDC)hdc, (HBRUSH)pgo[EPB_BRUSH_TRAM]);
	}
	else
	if (eCarType == ECT_MINIBUS)
	{
		SelectObject((HDC)hdc, (HPEN)pgo[EPB_PEN_MINIBUS]);
		SelectObject((HDC)hdc, (HBRUSH)pgo[EPB_BRUSH_MINIBUS]);
	}
	else
	if (eCarType == ECT_SHUTTLE)
	{
		SelectObject((HDC)hdc, (HPEN)pgo[EPB_PEN_MINIBUS]);
		SelectObject((HDC)hdc, (HBRUSH)pgo[EPB_BRUSH_MINIBUS]);
	}
	else
	if (eCarType == ECT_LIM_MOB)
	{
		SelectObject((HDC)hdc, (HPEN)pgo[EPB_PEN_LIM_MOB]);
		SelectObject((HDC)hdc, (HBRUSH)pgo[EPB_BRUSH_LIM_MOB]);
	}
	else
	{
		SelectObject((HDC)hdc, (HPEN)pgo[EPB_PEN_CAR]); ////p_pen_car//p_brush_car
		SelectObject((HDC)hdc, (HBRUSH)pgo[EPB_BRUSH_CAR]);
	}

}

void SDeviceATE_3::Draw(bool fFillVisible, int hdc, int i_draw_radius,  char *sz_title_name, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list, const SPointInt& origin, CDrawATE_3_Draw_param& param)
{
	int max_index_in_DB = (int)ECT_QUANTITY;

	if (id_car_type >= 1 && id_car_type <= max_index_in_DB) //YUIL 2017-01-30
	{
		bool fDrawCarType = param.p_drawCarTypes[id_car_type - 1];

		if (fDrawCarType == false) {return;}
	}
	
	ECarType eCarType = (ECarType)(id_car_type - 1);	
	
	POINT drawPoint;

	long& x = drawPoint.x;
	long& y = drawPoint.y;

	x = point.x + origin.x;
	y = point.y + origin.y;

	if (SDrawData::IsHide(x, y, sizeWnd)) { return; }
	
	ECarLagLeadView eView = param.m_CarLagLeadView;

	bool f_view=false;

	if (eView==ECLLV_ALL) //���
	{
		f_view=true;
	}else
	if (eView==ECLLV_LAG)  //��������� 
	{
		f_view = eLagLeadState == ELLS_LAG; //if (f_formalize_messages) { f_view = true; } //if (m_lag.size()) {f_view=true;}
	}else
	if (eView==ECLLV_LEAD) //�����������
	{
		f_view = eLagLeadState == ELLS_LEAD; //f_view = false; //if (m_lead.size()) {f_view=true;}
	}else
	if (eView==ECLLV_NORM)
	{
		f_view = eLagLeadState == ELLS_NORMAL; //if (f_formalize_messages==false) { f_view = true; } //if (!m_lag.size() && !m_lead.size()) {f_view=true;}
	}

	if (f_view)
	{ 
		DrawRouteSelCar((HDC)hdc, origin, i_draw_radius, param);

		if ((eCarType >= ECT_TROL && eCarType <= ECT_MINIBUS) || eCarType==ECT_LIM_MOB)
		{
			SelectGDI_Objs(hdc, param);

			BOOL fRes = Ellipse((HDC)hdc, x - i_draw_radius, y - i_draw_radius, x + i_draw_radius, y + i_draw_radius);
		}
		else
		if (eCarType == ECT_SHUTTLE)
		{
			win_e::DrawFootball((HDC)hdc, drawPoint, i_draw_radius);
		}

		if (fFillVisible)
		{
			gVisibleCars.push_back(*this); //InterlockedExchange(&m_lDraw, 1);
		}
	}

	/*
	bool f_car_lag_lead = param.f_car_lag_lead;

	if (f_car_lag_lead && (m_lag.size()==0 && m_lead.size()==0)) {return;}

	BOOL f_res;

	else
	{
		bool f_lag = m_lag.size() > m_lead.size();

		SelectObject((HDC)hdc, param.p_pen_car_light);

		SelectObject((HDC)hdc, (HGDIOBJ)(f_lag ? param.p_brush_car_light : param.p_brush_car));

		f_res= Pie((HDC)hdc, x - i_draw_radius, y - i_draw_radius, x + i_draw_radius, y + i_draw_radius
			               , x, y - i_draw_radius, x, y + i_draw_radius); 

		SelectObject((HDC)hdc, (HGDIOBJ)(f_lag ? param.p_brush_car : param.p_brush_car_light));

		f_res= Pie((HDC)hdc, x - i_draw_radius, y - i_draw_radius, x + i_draw_radius, y + i_draw_radius
			               , x, y + i_draw_radius, x, y - i_draw_radius); 
																		
	}*/

	bool f_in = math_e::inRectInt(clientMouse.x, clientMouse.y, x - i_draw_radius, y - i_draw_radius, x + i_draw_radius, y + i_draw_radius);

	if (f_in)
	{																	//sprintf(sz_text, "",  o.route_long_name);
		sel_point.Set(x + 2 * i_draw_radius, y - i_draw_radius);

			

		if (eView==ECLLV_LAG || eView==ECLLV_LEAD)
		{
			/*for (int i=0; i<m_lag.size(); i++)
			{
				SCarLagLead& o = m_lag[i];

				std_string sz_val=sz_title_name; sz_val.append(" : "); 

				sz_val.append(name); sz_val.append(" ������� ��� : ���. "); sz_val.append(o.stop_name);

				sz_val.append(", ����. "); sz_val.append(o.shape_id); sz_val.append(" "); sz_val.append(o.arrival_time);

				 sz_val.append(" "); sz_val.append(o.departure_time);

				sel_str_list.push_back(sz_val);  
			}

			for (int i=0; i<m_lead.size(); i++)
			{
				SCarLagLead& o = m_lead[i];

				std_string sz_val=sz_title_name; sz_val.append(" : "); 

				sz_val.append(name); sz_val.append(" ��������� ��� : ���. "); sz_val.append(o.stop_name);

				sz_val.append(", ����. "); sz_val.append(o.shape_id); sz_val.append(" "); sz_val.append(o.arrival_time);

				 sz_val.append(" "); sz_val.append(o.departure_time);

				sel_str_list.push_back(sz_val);  
			}*/
		}else
		{ 
			std_string sz_val=sz_title_name; sz_val.append(" : "); sz_val.append(GetDrawName()); sel_str_list.push_back(sz_val);  
		} 
	}

}

void DrawRouteSelCar(HDC hdc, const SPointInt& origin, int i_draw_radius, CDrawATE_3_Draw_param& param)
{//if (fSel == false) { return; }

	int q = gVisibleShapePoints.size();

	if (q == 0) { return; }

	HGDIOBJ* p_pen_brush = param.p_pen_brush;

	SelectObject(hdc, (HPEN)p_pen_brush[EPB_PEN_ROUTE_LINE]);
	SelectObject(hdc, (HBRUSH)p_pen_brush[EPB_BRUSH_ROUTE_POINT]);
	
	POINT prev_pn;

	for (int i = 0; i < q; i++)
	{
		SShapePoint& o = gVisibleShapePoints[i];

		int x = o.x + origin.x;
		int y = o.y + origin.y;

		if (i == 0 || i == q - 1)
		{
			//BOOL fRes = Ellipse((HDC)hdc, x - i_draw_radius, y - i_draw_radius, x + i_draw_radius, y + i_draw_radius);
		}

		if (i)
		{
			LineTo(hdc, x, y);
		}
		else
		{
			MoveToEx(hdc, x, y, 0);
		}
	}
}


bool CDrawATE_3::NextVisible(int& i, SDeviceATE_3& o)
{
	int q = gVisibleCars.size();

	if (i >= q) { return false; }

	o = gVisibleCars[i];

	i++;
	return true;
}

bool CDrawATE_3::NextVisiblePtr(int& i, SDeviceATE_3* *p)
{
	int q = gVisibleCars.size();

	if (i >= q) { return false; }

	*p = &gVisibleCars[i];

	i++;
	return true;
}

////////////////////////////////////////////////////////////////////
void CDrawATE_3::Draw(HDC hdc, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list, const SPointInt& origin, CDrawATE_3_Draw_param& param, double zoom)
{
	if (m_fInit == false || m_f_draw==false) { return; }
 
	static time_t time_prev = 0;
	time_t time = clock();
	
	if (time_prev == 0 || (time - time_prev) > ci_sleep_between_load)
	{
		LoadOp();
		Calc(zoom, origin);
		time_prev = time;
	}
	//if (m_l_copy_proc) { return; } //���� �����������. ����� ������

	SFind<long> sFind;

	bool fFillVisible = false;

	//<w1
	static time_e::CTimeOut �TimeOut(1200);
	if (�TimeOut.IsOver(time))
	{
		fFillVisible = true;
		gVisibleCars.clear();
	}
	//>w1

	for (int i = 0; i < m_dev_list.size(); i++)
	{
		SDeviceATE_3& o = m_dev_list[i]; //InterlockedExchange(&o.m_lDraw, 0);

		if (m_list_enable_routes.size())
		{
			if (o.id_picas_route != 0)
			{
				int  m = 0;
				m++;
			}

			if (sFind.Find(m_list_enable_routes, o.id_picas_route) == false) { continue; }
		}

		if (m_id_agent && o.id_agent != m_id_agent) { continue; }

		/*bool f_route_94 = !stricmp(o.route, "94");
		bool f_route_96 = !stricmp(o.route, "96");

		if (m_id_agent==15 && (f_route_94==false && f_route_96==false))
		{
			int k = 0;
			k++;
		}*/

		o.Draw(fFillVisible, (int)hdc, m_car_draw_radius, o.agent_name, sizeWnd, clientMouse, sel_point, sel_str_list, origin,  param);
	}
	

}

void CDrawATE_3::UnSelAll()
{
	for (int i = 0; i < m_dev_list.size(); i++)
	{
		SDeviceATE_3& o = m_dev_list[i];

		o.fSel = false;
	}
}

void CDrawATE_3::Calc(double zoom, const SPointInt& origin)
{
	if (m_l_copy_proc) { return; } //���� �����������. ����� ������

	if (zoom == 0) { return; }

	for (int i = 0; i < m_dev_list.size(); i++)
	{
		SDeviceATE_3& o = m_dev_list[i];

		o.point.SetByLatLng(o.latlng, zoom);
	}
}

char* SDeviceATE_3::GetDrawName()
{
	sz_full_name = name; //char sz_full_name[MAX_PATH + 1]; strcpy(sz_full_name, (char*)name.c_str());  //

	sz_full_name.append(" �������: "); sz_full_name.append(route);

	char sz_val[MAX_PATH + 1];

	//strcat(sz_full_name, " ������: "); itoa(azimut, sz_val, 10); strcat(sz_full_name, sz_val); //YUIL. ���� �� ����������� �� �����.	
	//strcat(sz_full_name,  " ��������: "); itoa(speed, sz_val, 10); strcat(sz_full_name, sz_val);

	sz_full_name.append(" ������: "); itoa(azimut, sz_val, 10); sz_full_name.append(sz_val); //YUIL. ���� �� ����������� �� �����.	
	sz_full_name.append(" ��������: "); itoa(speed, sz_val, 10); sz_full_name.append(sz_val);

	return (char*)sz_full_name.c_str();
}

bool CDrawATE_3::FindNear(double x, double y, SDeviceATE_3& sDev)
{
	if (m_dev_list.size()<1) {return false;}

	double dDistMin; 

	int indexMin;

	for (int i=0; i<m_dev_list.size(); i++)
	{
		SDeviceATE_3& o = m_dev_list[i];
		
		double dDist= math_e::dist2D(x, y, o.x, o.y);

		if (i==0) {dDistMin=dDist; indexMin=0;}
		else
		{
			if (dDist < dDistMin) {dDistMin = dDist; indexMin=i;}
		}
	}

	sDev=m_dev_list[indexMin];

	return true;
}

bool CDrawATE_3::FillCombo(CWinCtrl* p_ctrls, char *sz_combo)
{
	p_ctrls->SendMes(sz_combo, CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);

	int q = m_dev_list.size();
	
	char sz_val[MAX_PATH + 1];

	for (int i = 0; i < q; i++)
	{
		SDeviceATE_3 o = m_dev_list[i];

		strcpy(sz_val, o.name);

		p_ctrls->SendMes(sz_combo, CB_ADDSTRING, (WPARAM)0, (LPARAM)sz_val);
	}

	p_ctrls->SendMes(sz_combo, CB_SETCURSEL, (WPARAM)0, (LPARAM)0);

	return true;
}

bool CDrawATE_3::Find(char *name, int& index)
{
	std::vector<SDeviceATE_3>* p_dev_list;
	
	if (m_dev_list.size()==0) 
	{ 
		if (m_dev_list.size() == 0) { return false; }

		p_dev_list = &m_dev_list;

		return false;
	}
	else
	{
		p_dev_list= &m_dev_list;
	}	

	int q = p_dev_list->size();

	bool fFound = false;

	char sz_val[MAX_PATH+1];

	for (int i = 0; fFound==false && i < q; i++)
	{
		SDeviceATE_3 o = p_dev_list->operator[](i);

		strcpy(sz_val, o.name);

		if (!stricmp(sz_val, name)) 
		{ fFound = true; index = 0; } //o.name == name
	}

	return fFound;
}

