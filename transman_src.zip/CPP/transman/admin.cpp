#include <memory.h>
#include "main.h"
#include "admin.h"

#include "BookMarks.h"
#include "login_wnd.h"
#include "ini_file.h"
#include "MesWnd.h"

CAdmin::CAdmin() {}

CAdmin::~CAdmin() {}

bool CAdmin::Open(HINSTANCE hInstance, HWND hwndParent, int w, int h, RECT& rcParent)
{
	memset(this, 0, sizeof(CAdmin)); //m_hwndParent = hwndParent;

	m_i_sizeMesPack = 50;

	m_wnd_size.x= w; m_wnd_size.y= h;

	m_rcParent = rcParent;
	
	m_hwndParent = hwndParent;
	
	CrControls(hInstance, hwndParent); 

	m_fInit=true;

	return m_fInit;
}

void CAdmin::Close()
{
	m_ctrls.Destroy();

}

void CAdmin::CrControls(HINSTANCE hInstance, HWND hwndParent)
{
	SWinCtrlParam wcp;
	wcp.Clear();
	wcp.hInstance = hInstance;
	wcp.hwndParent = hwndParent;
	wcp.wCtrl = 70;
	wcp.hCtrl = 22;
	wcp.ident = 5;
	wcp.xOrigin = 5;

	SBookMarksParams& bm_params = gBookMarks.GetParams();

	wcp.yOrigin = bm_params.i_height + cl_chat_ident_from_top; //wcp.fHide=true;
	m_ctrls.Init(wcp);

	EUserType eUserType = gLoginWnd.GetUserType();

	CrControls_disp_hi();

	m_index_start_disp = m_ctrls.GetSize();

	m_index_start_common = m_ctrls.GetSize();

	m_ctrls.Update(); //m_ctrls.SetFocusActive();
}

void CAdmin::Tab()
{
	m_ctrls.NextFocusActive();
}

void CAdmin::StartFill()
{
	fill_combo_new_coll_disp();

	fill_combo_bind_coll();

	fill_combo_show_coll();

	set_refresh(false);
}

void CAdmin::CrControls_disp_hi()
{
	CrControls_disp_hi_new_disp();

	CrControls_disp_hi_new_coll();

	CrControls_disp_hi_bind();	
}

void CAdmin::CrControls_disp_hi_new_disp()
{
	SCtrl ctrl;

	ctrl.Clear();
	ctrl.name = "static_new_disp";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����� ���������:";
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 3;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);		
	
	ctrl.Clear();
	ctrl.name = "static_new_disp_name";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "edit_new_disp_name";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT;
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_new_disp");

	ctrl.Clear();
	ctrl.name = "static_new_disp_psw";
	ctrl.classWnd = "static";
	ctrl.textWnd = "������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "edit_new_disp_psw";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT | ES_PASSWORD;
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_new_disp_psw");

	ctrl.Clear();
	ctrl.name = "but_new_disp";
	ctrl.classWnd = "button";
	ctrl.textWnd = "��������";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl); 

}

int CAdmin::Get_x_step_gr(int q_gr)
{
	win_e::SMonitors& mon= gMonitors;

	return mon.rc[1].right/q_gr; //ci_chat_ctrls_group
}

void CAdmin::Ctrls_set_origin(CWinCtrl& ctrls, int index_gr, int q_gr)
{
	int x_step = Get_x_step_gr(q_gr);

	int x= index_gr * x_step; //m_list_x_ctrls[index_gr]= x;

	SBookMarksParams& bm_params = gBookMarks.GetParams();

	ctrls.SetOrigin(x, bm_params.i_height + cl_chat_ident_from_top);
}

void CAdmin::CrControls_disp_hi_new_coll()
{
	SCtrl ctrl;

	Ctrls_set_origin(m_ctrls, 1, ci_chat_ctrls_group); //m_ctrls.NewRow(); //m_ctrls.NewRow();

	ctrl.Clear();
	ctrl.name = "static_new_coll";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����� ���������:";
	ctrl.mul_w = 1.6;
	ctrl.mul_h = 3;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "static_new_coll_name";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "edit_new_coll_name";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT;
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_new_coll");

	ctrl.Clear();
	ctrl.name = "static_new_coll_psw";
	ctrl.classWnd = "static";
	ctrl.textWnd = "������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "edit_new_coll_psw";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT | ES_PASSWORD;
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_new_coll");

	ctrl.Clear();
	ctrl.name = "static_new_coll_disp";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "combo_new_coll_disp";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.4;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_new_coll_disp");

	ctrl.Clear();
	ctrl.name = "but_new_coll";
	ctrl.classWnd = "button";
	ctrl.textWnd = "��������";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

}


void CAdmin::CrControls_disp_hi_bind()
{
	SCtrl ctrl;

	Ctrls_set_origin(m_ctrls, 2, ci_chat_ctrls_group); //m_ctrls.NewRow(); //m_ctrls.NewRow();

	ctrl.Clear();
	ctrl.name = "static_bind";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�����:";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "static_bind_disp";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "combo_bind_disp";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.4;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_bind");

	ctrl.Clear();
	ctrl.name = "static_bind_coll";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "combo_bind_coll";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.4;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow("static_bind_coll");

	ctrl.Clear();
	ctrl.name = "but_bind";
	ctrl.classWnd = "button";
	ctrl.textWnd = "���������";
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);
}


void CAdmin::set_but_refresh(bool fCheck)
{
	set_check_box("but_refresh", fCheck);	
}

void CAdmin::set_check_box(char  *sz_checkbox, bool fCheck)
{
	m_ctrls.SendMes(sz_checkbox, BM_SETCHECK, (WPARAM)(fCheck ? BST_CHECKED : BST_UNCHECKED), (LPARAM)0);
}

bool CAdmin::get_check_box(char  *sz_checkbox)
{
	return m_ctrls.SendMes(sz_checkbox, BM_GETCHECK, (WPARAM)0, (LPARAM)0)==BST_CHECKED;
}

void CAdmin::set_refresh(bool f)
{
	m_f_refresh = f;

 set_but_refresh(f);
}

void CAdmin::refresh_op()
{
	m_f_refresh = m_f_refresh ? false : true;

 set_but_refresh(m_f_refresh);		
}

void CAdmin::Show(bool fShow)
{
	CWinCtrl::SIndexRange sRange;

	std::vector<CWinCtrl::SIndexRange> list_range;

	sRange.index_from=0;

	sRange.index_to= m_index_start_disp - 1;

	list_range.push_back(sRange);

	//<common
	sRange.index_from= m_index_start_common;

	sRange.index_to= m_ctrls.GetSize()-1;

	list_range.push_back(sRange);
	//>common

	m_ctrls.ShowAll(fShow, &list_range);

	m_ctrls.Update(); //Sleep(50);
}

void CAdmin::OnCmd(int id, int notify)
{
	SCtrl* p_ctrl;
	
	if (m_ctrls.Find(id, &p_ctrl))
	{
		
		if (p_ctrl->name == "but_new_disp")
		{
			CrNewDisp();
		}else
		if (p_ctrl->name == "but_new_coll")
		{
			CrNewColl();
		}else
		if (p_ctrl->name == "but_bind")
		{
			Bind();
		}else
		if (p_ctrl->name == "combo_show_disp")
		{
			if (notify == CBN_SELCHANGE)
			{			
				fill_combo_show_coll(); 
			}
		}else
		if (p_ctrl->name == "combo_disp_templ_mes")
		{
			if (notify == CBN_SELCHANGE)
			{			
				set_edit_disp_mes_by_combo("combo_disp_templ_mes");
			}
		}else
		if (p_ctrl->name == "but_send_new_mes")
		{
			but_send_new_mes("1");
		}else
		if (p_ctrl->name == "but_send_new_mes_all_group")
		{
			ESendMesMode eMode = ESMM_ALL_IN_GROUP;

			but_send_new_mes("1", eMode);
		}
		else
		if (p_ctrl->name == "but_send_new_mes_all")
		{
			ESendMesMode eMode = ESMM_ALL;

			but_send_new_mes("1", eMode);
		}else
		if (p_ctrl->name == "but_send_coord_request")
		{
			but_send_new_mes("4");
		}else
		if (p_ctrl->name == "but_send_go_coord")
		{
			but_send_new_mes("5");
		}else
		if (p_ctrl->name == "combo_disp_coll")
		{
			if (notify == CBN_SELCHANGE)
			{			

			}
		}
		else
		if (p_ctrl->name == "but_refresh")
		{
			refresh_op();
		}
	}
}

void CAdmin::Paint(HDC hdc)
{
}


void CAdmin::SetEditMes(Leaflet::LatLng& latlng)
{
	char sz_val[MAX_PATH + 1];
	sprintf(sz_val, "%g:%g", latlng.lat, latlng.lng);
	m_ctrls.SendMes("edit_disp_mes", WM_SETTEXT, (WPARAM)0, (LPARAM)sz_val);
}
