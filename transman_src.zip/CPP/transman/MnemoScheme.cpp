#include <memory.h>
#include "MnemoScheme.h"

#include "draw_data.h"
#include "main.h"
#include "BookMarks.h"

#include "MesWnd.h"
#include "date_time.h"
#include "..\\transman_srv\\time_e.h"
#include "math_e.h"
#include "ini_file.h"

const int cl_mnemo_scheme_ident_from_left=5;
const int cl_mnemo_scheme_ident_from_top=5;

const int ci_MnemoScheme_ident = 10;
const int ci_MnemoScheme_path_ident = 150;
const int ci_MnemoScheme_legend_w = 600;
const int ci_MnemoScheme_path_rad = 200;
const int ci_MnemoScheme_path_thick = 18;

const char* csz_MnemoScheme_font_file = "C:\\transman\\MnemoScheme_font.txt";
const int ci_MnemoScheme_rad = 8;

CMnemoScheme::CMnemoScheme() {}

CMnemoScheme::~CMnemoScheme() {}

void CMnemoScheme::LoadIni()
{
	CIniFile ini;

	char sz_value[MAX_PATH+1];

	if (ini.Get("c:\\transman\\transman.ini", "mnemoscheme_check_point_view", sz_value, MAX_PATH))
	{
		m_eCheckPointNameView = (ECheckPointNameView)atoi(sz_value);
	}
}

bool CMnemoScheme::Open(HINSTANCE hInstance, HWND hwndParent, int w, int h)
{
	memset(this, 0, sizeof(CMnemoScheme));

	m_hwnd = hwndParent;

	m_wnd_size.x= w; m_wnd_size.y= h;
	
	m_bitmap_stop_size.x = 48;
	m_bitmap_stop_size.y = 48;

	LoadIni();

	m_param.Init();

	cr_m_gdi_obj();

	CrControls(hInstance, hwndParent);

	m_paint.Init(m_wnd_size, m_ctrls.GetStatMaxY());

	m_path.Init(m_paint.w, m_paint.h);

	combo_route_SELCHANGE();

	m_fInit=true;

	return m_fInit;
}

void CMnemoScheme::Close()
{
	if (m_fInit == false) { return; }

	del_m_gdi_obj();

	m_ctrls.Destroy(); //DestroyMenu(m_menu);
}

void SMnemoSchemeParam::Init()
{
	color_path_AB_up = 0x61BA2F;
	color_path_BA_down = 0x5D9FFE;
	color_stop_bord = 0xBD6F0A;
	color_stop_in = 0x6AF9FC;
	color_check_point_bord = 0xEFDEC4;
																															//�� ����� ���� = ��������� ������
																															//�� ����� = ��������� ������
																															//�� ����� ����� = �����
	color_sel_route_in= 0xE8E3E4; //��������� ������� ������ 

	stop_size = 252;
	stop_bord_thick = 20;
	check_point_size = 135; //128;
	check_point_thick = 20;
																								//�� ������� = �� �������
	path_thick=98; // ������� ����
	//
	iFontStop_h = 22;
	iFont_h = iFontStop_h*0.6;
	iFontMini_h = iFont_h * 0.7;
	//
	rad_stop = (stop_size / 2)*ci_MnemoScheme_path_thick / path_thick;

	float coef = (float)ci_MnemoScheme_path_thick / (float)path_thick;

	rad_car = (check_point_size / 2) * coef;

	rad_car_in = ((check_point_size - check_point_thick * 2) / 2) * coef * 0.8;

}

void CMnemoScheme::cr_m_gdi_obj()
{
	m_gdi_obj[EMSGDIO_PEN_WHITE] = CreatePen(PS_SOLID, 0, 0xFFFFFF);		
	m_gdi_obj[EMSGDIO_PEN_BLACK] = CreatePen(PS_SOLID, 0, 0);
	
	m_gdi_obj[EMSGDIO_PEN_SEL_FRAME] = CreatePen(PS_SOLID, 0, 0xDFFFFF);
	m_gdi_obj[EMSGDIO_BRUSH_SEL_FRAME] = CreateSolidBrush(0xDFFFFF);
	
	m_gdi_obj[EMSGDIO_BRUSH_STOP_BORD] = CreateSolidBrush(m_param.color_stop_bord);
	m_gdi_obj[EMSGDIO_BRUSH_STOP_IN] = CreateSolidBrush(m_param.color_stop_in);
	m_gdi_obj[EMSGDIO_BRUSH_PATH_AB_UP] = CreateSolidBrush(m_param.color_path_AB_up);
	m_gdi_obj[EMSGDIO_BRUSH_PATH_BA_DOWN] = CreateSolidBrush(m_param.color_path_BA_down);
	m_gdi_obj[EMSGDIO_BRUSH_SEL_ROUTE_IN] = CreateSolidBrush(m_param.color_sel_route_in);	
	m_gdi_obj[EMSGDIO_BRUSH_CONTROL_POINT_BORD] = CreateSolidBrush(m_param.color_check_point_bord);
	m_gdi_obj[EMSGDIO_BRUSH_WHITE] = CreateSolidBrush(0xFFFFFF);		

	m_gdi_obj[EMSGDIO_BITMAP_BUS] =LoadImageA(0, "C:\\transman\\img\\bus_31%.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	m_gdi_obj[EMSGDIO_STOP_A] = LoadImageA(0, "C:\\transman\\img\\stop_a.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	m_gdi_obj[EMSGDIO_STOP_B] = LoadImageA(0, "C:\\transman\\img\\stop_b.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	m_gdi_obj[EMSGDIO_PEN_GROUND] = CreatePen(PS_SOLID, 0, 0xDED9B5); //������� �������� R-181 G-217 B-222=0xDED9B5;
	m_gdi_obj[EMSGDIO_BRUSH_GROUND] = CreateSolidBrush(0xDED9B5); //������� �������� R-181 G-217 B-222=0xDED9B5;
}

void CMnemoScheme::del_m_gdi_obj()
{
	for (int i=0; i<(int)EMSGDIO_QUANTITY; i++)
	{
		DeleteObject(m_gdi_obj[i]);
	}
}

void CMnemoScheme::CrControls(HINSTANCE hInstance, HWND hwndParent)
{
	SBookMarksParams& bm_params = gBookMarks.GetParams();

	SWinCtrlParam wcp;
	wcp.Clear();
	wcp.hInstance = hInstance;
	wcp.hwndParent = hwndParent;
	wcp.wCtrl = 70;
	wcp.hCtrl = 22;
	wcp.ident = 5;
	wcp.xOrigin = cl_mnemo_scheme_ident_from_left;
	wcp.yOrigin = bm_params.i_height + cl_mnemo_scheme_ident_from_top;

	m_ctrls.Init(wcp);

	SCtrl ctrl;

	ctrl.Clear();
	ctrl.name = "static_route";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�������";
	ctrl.mul_w = 2;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_route";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.5;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow();

	ctrl.Clear();
	ctrl.name = "static_rep_date";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����";
	ctrl.mul_w = 2;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "check_rep_date";
	ctrl.classWnd = "button";
	ctrl.mul_w = 0.2;
	ctrl.styleAdd = BS_CHECKBOX;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "dt_rep_date";
	ctrl.classWnd = "combobox";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.23;
	ctrl.mul_h = 6; // 1.2;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow();

	ctrl.Clear();
	ctrl.name = "static_car";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�������� �����";
	ctrl.mul_w = 2;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_car";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2.5;
	ctrl.mul_h = 6;

	m_ctrls.Add(ctrl);
	gBookMarks.fill_dt_rep_date("dt_rep_date", &m_ctrls);
	fill_combo_route();

	m_ctrls.Update();

	m_ctrls.AddMenuItemText("View rect", &m_i_menu_item_view_rect);
}


void CMnemoScheme::fill_combo_route()
{
	int index = 0;

	SRoute o;
	
	m_ctrls.SendMes("combo_route", CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);

	while (gDrawWnd.NextRoute(index, o))
	{
		//if (o.f_check_points == false) { continue; }

		char *p_name = (char *)o.route_short_name.c_str();

		m_ctrls.SendMes("combo_route", CB_ADDSTRING, (WPARAM)0, (LPARAM)p_name);
	}

	m_ctrls.SendMes("combo_route", CB_SETCURSEL, (WPARAM)0, (LPARAM)0);
}

void CMnemoScheme::Show(bool fShow)
{
	if (m_fInit == false) { return; }

	m_ctrls.ShowAll(fShow);
	m_ctrls.Update();
}

void CMnemoScheme::OnCmd(int id, int notify)
{
	if (m_fInit == false) { return; }
	
	SCtrl* p_ctrl;
	
	if (m_ctrls.Find(id, &p_ctrl))
	{
		if (id == m_i_menu_item_view_rect)
		{
			m_fShowRect = m_fShowRect ? false :true;

			m_ctrls.MarkMenuItem(m_i_menu_item_view_rect, m_fShowRect);

			CallPaint();
		}
		else
		{
			if (p_ctrl->name == "combo_route")
			{
				if (notify == CBN_SELCHANGE)
				{
					combo_route_SELCHANGE();
				}
			}else
			if (p_ctrl->name == "check_rep_date")
			{
				bool fCheck;

				m_ctrls.OpCheckbox("check_rep_date", &fCheck); //bool f_date = m_ctrls.GetCheckbox("check_rep_date");
			}
		}
	}
}

void CMnemoScheme::fill_combo_car()
{
	char *sz_name_combo = "combo_car";

	m_ctrls.SendMes(sz_name_combo, CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);

	int q = m_mnemoCars.list_last.size();

	for (int i = 0; i < q; i++)
	{
		SMnemoCarLast& oLast = m_mnemoCars.list_last[i];
		SMnemoCar& o = m_mnemoCars.list[oLast.index_last];

		m_ctrls.SendMes(sz_name_combo, CB_ADDSTRING, (WPARAM)0, (LPARAM)o.garage_num.c_str());
	}

	m_ctrls.SendMes(sz_name_combo, CB_SETCURSEL, (WPARAM)0, (LPARAM)0);
}

void CMnemoScheme::combo_route_SELCHANGE()
{
	int index = m_ctrls.SendMes("combo_route", CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

	if (gDrawWnd.GetRoute(index, m_route))
	{
		fill_by_sel_combo_route();
		
		fill_by_sel_combo_route_BA();		

		CallPaint();

		fill_combo_car();
	}
	else { gMesWnd.Mes("CMnemoScheme::OnCmd(). ������ ��������� ��������"); }
}

void CMnemoScheme::SPaint::Init(POINT& m_wnd_size, int i_ctrls_StatMaxY)
{
	SBookMarksParams& bm_params = gBookMarks.GetParams();

	rc.left = ci_MnemoScheme_ident;

	rc.top = bm_params.i_height + cl_chat_ident_from_top + i_ctrls_StatMaxY + ci_MnemoScheme_ident; //m_ctrls.GetStatMaxY()

	rc.right = m_wnd_size.x - ci_MnemoScheme_ident;

	rc.bottom = m_wnd_size.y; // -ci_MnemoScheme_ident;

	w = rc.right - rc.left;

	h = rc.bottom - rc.top;

}

void CMnemoScheme::Paint(HDC hdc, int i_mode)
{
	if (m_fInit == false) { return; }

	CrFonts(hdc);

	HDC hMem = CreateCompatibleDC(hdc);
	
	HBITMAP memBM = CreateCompatibleBitmap(hdc, m_paint.w, m_paint.h);

	SelectObject(hMem, memBM);
 
	PaintOp(hMem, m_paint.w, m_paint.h, i_mode);

	BitBlt(hdc, m_paint.rc.left, m_paint.rc.top, m_paint.w, m_paint.h, hMem, 0, 0, SRCCOPY);

	DeleteObject(memBM);

	DeleteObject(hMem);

	m_ctrls.Update();
}

void CMnemoScheme::DrawGround(HDC hdc, int w, int h)
{
	SelectObject(hdc, m_gdi_obj[m_fShowRect ? EMSGDIO_PEN_BLACK : EMSGDIO_PEN_GROUND]); //EMSGDIO_PEN_WHITE
	SelectObject(hdc, m_gdi_obj[EMSGDIO_BRUSH_GROUND]);

	Rectangle(hdc, 0, 0, w, h);
}

void CMnemoScheme::SPath::Init(int w, int h)
{
	const int ci_path_left_ident = 100;

	rc.left = ci_path_left_ident + ci_MnemoScheme_path_ident;
	rc.top = ci_MnemoScheme_path_ident;
	rc.right = w - ci_MnemoScheme_path_ident - ci_MnemoScheme_legend_w + ci_path_left_ident;
	rc.bottom = h - ci_MnemoScheme_path_ident;

	hr = rc.bottom - rc.top;

	//<inside rect
	irc = rc;

	irc.left += ci_MnemoScheme_path_thick;
	irc.top += ci_MnemoScheme_path_thick;
	irc.right -= ci_MnemoScheme_path_thick;
	irc.bottom -= ci_MnemoScheme_path_thick;
	ihr = irc.bottom - irc.top;

	int rad = ci_MnemoScheme_path_rad;

	radi = 0.95 * rad * ihr / hr;

	//<q1 ����������� �����
	�enter_rc.left = (rc.left + irc.left) / 2;
	�enter_rc.right = (rc.right + irc.right) / 2;
	�enter_rc.top = (rc.top + irc.top) / 2;
	�enter_rc.bottom = (rc.bottom + irc.bottom) / 2;
	
	i_�enter_rad = (radi + rad) / 2;
	
	i_�enter_rad_axe_prj = 0.707 * i_�enter_rad;

	//>q1 ����������� �����
}

void CMnemoScheme::SPath::DrawPath(HDC hdc, HGDIOBJ* gdi_obj)
{
	SelectObject(hdc, gdi_obj[EMSGDIO_PEN_BLACK]);

	BOOL fRes = RoundRect(hdc, rc.left, rc.top, rc.right, rc.bottom, ci_MnemoScheme_path_rad, ci_MnemoScheme_path_rad);

	fRes = RoundRect(hdc, irc.left, irc.top, irc.right, irc.bottom, radi, radi); //inside rect
	
	int y = (rc.top + rc.bottom) / 2;
	int s = 1;
	//LEFT
	MoveToEx(hdc, rc.left-s, y, 0);
	LineTo(hdc, irc.left+s, y);
	//RIGHT
	MoveToEx(hdc, irc.right-s, y, 0);
	LineTo(hdc, rc.right+s, y);
}

/*void CMnemoScheme::SetFont(HDC hdc,  char *fontName, long nFontSize, bool  fBold, HFONT& hFont)
{
	LOGFONTA logFont = { 0 };
	logFont.lfHeight = -MulDiv(nFontSize, GetDeviceCaps(hdc, LOGPIXELSY), 72);
	logFont.lfWeight = fBold ? FW_BOLD : FW_NORMAL;
	logFont.lfCharSet = RUSSIAN_CHARSET; // ANSI_CHARSET;
	strcpy(logFont.lfFaceName, fontName);

	hFont = CreateFontIndirectA(&logFont);
}*/

int CALLBACK CMnemoScheme_EnumFontFamExProc(CONST LOGFONTA *plf, CONST TEXTMETRICA *lpntme, DWORD FontType, LPARAM lParam)
{
	//int i = 0; i++;
	FILE *fo = fopen(csz_MnemoScheme_font_file, "ab");
	if (fo)
	{
		fprintf(fo,"lfFaceName:%s\r\n", plf->lfFaceName);
		fprintf(fo, "fHeight:%d\r\n", plf->lfHeight);
		fprintf(fo, "lfWidth:%d\r\n", plf->lfWidth);
		fprintf(fo, "lfEscapement:%d\r\n", plf->lfEscapement);
		fprintf(fo, "lfOrientation:%d\r\n", plf->lfOrientation);
		fprintf(fo, "lfItalic:%d\r\n", plf->lfItalic);
		fprintf(fo, "lfUnderline:%d\r\n", plf->lfUnderline);
		fprintf(fo, "lfStrikeOut:%d\r\n", plf->lfStrikeOut);
		fprintf(fo, "lfCharSet:%d\r\n", plf->lfCharSet);
		fprintf(fo, "lfOutPrecision:%d\r\n", plf->lfOutPrecision);
		fprintf(fo, "lfClipPrecision:%d\r\n", plf->lfClipPrecision);
		fprintf(fo, "lfQuality:%d\r\n", plf->lfQuality);
		fprintf(fo, "lfPitchAndFamily:%d\r\n", plf->lfPitchAndFamily);
		fprintf(fo, "\r\n");
		fclose(fo);
	}
	return 1;
}

void CMnemoScheme::EnumFonts(HDC hdc)
{
	//<q1
	LOGFONTA Logfont;
	memset(&Logfont, 0, sizeof(LOGFONTA));
	Logfont.lfCharSet = DEFAULT_CHARSET; //strcpy(Logfont.lfFaceName, "Arial");

	unlink(csz_MnemoScheme_font_file);
	int i_res = EnumFontFamiliesExA(hdc, &Logfont, CMnemoScheme_EnumFontFamExProc, (LPARAM)this, 0);
	//>q1
}

void CMnemoScheme::CrFonts(HDC hdc)
{
	static bool fCrFonts = false;
	
	if (fCrFonts) { return; }

	//EnumFonts(hdc);
	bool fBold = true;
	win_e::SetFont(hdc, "Arial", m_param.iFontStop_h, fBold, (HFONT&)m_gdi_obj[EMSGDIO_FONT_STOP]);
	win_e::SetFont(hdc, "Arial", m_param.iFont_h, fBold, (HFONT&)m_gdi_obj[EMSGDIO_FONT]);
	win_e::SetFont(hdc, "Arial", m_param.iFontMini_h, fBold, (HFONT&)m_gdi_obj[EMSGDIO_FONT_MINI]);

	fCrFonts = true;
}

void CMnemoScheme::GetDrawPointStop(bool f_A, POINT& pn)
{
	pn.x = f_A ? m_path.�enter_rc.left : m_path.�enter_rc.right;
	pn.y = (m_path.�enter_rc.bottom + m_path.�enter_rc.top) / 2;
}

void CMnemoScheme::DrawStopOp(POINT c, HDC hdc, bool f_A) //, char *sz_text)
{
	bool fDraw=win_e::DrawBitmap(hdc, (HBITMAP)m_gdi_obj[f_A ? EMSGDIO_STOP_A : EMSGDIO_STOP_B], c, &m_bitmap_stop_size);

	/*
	int rad = (m_param.stop_size / 2)*ci_MnemoScheme_path_thick / m_param.path_thick;
	int rad_in = ((m_param.stop_size - m_param.stop_bord_thick * 2) / 2)*ci_MnemoScheme_path_thick / m_param.path_thick;

	SelectObject(hdc, m_gdi_obj[EMSGDIO_PEN_BLACK]);
	SelectObject(hdc, m_gdi_obj[EMSGDIO_BRUSH_STOP_BORD]);
	BOOL fRes = Ellipse(hdc, c.x - rad, c.y - rad, c.x + rad, c.y + rad);

	SelectObject(hdc, m_gdi_obj[EMSGDIO_BRUSH_STOP_IN]);
	fRes = Ellipse(hdc, c.x - rad_in, c.y - rad_in, c.x + rad_in, c.y + rad_in); //TEXTMETRIC tm; fRes=GetTextMetrics(hdc, &tm);
	
	if (sz_text)
	{
		Text_Out(hdc, c, sz_text, (HFONT)m_gdi_obj[EMSGDIO_FONT_STOP], m_param.iFontStop_h);
	}*/
}

void CMnemoScheme::DrawStop(HDC hdc, bool f_A) //, char *sz_text)
{
	POINT c;

	GetDrawPointStop(f_A, c);

	c.x -= m_bitmap_stop_size.x / 2;
	c.y -= m_bitmap_stop_size.y / 2;

	DrawStopOp(c, hdc, f_A); // sz_text);

	/*int rad = (m_param.stop_size / 2)*ci_MnemoScheme_path_thick / m_param.path_thick;
	int rad_in = ((m_param.stop_size - m_param.stop_bord_thick * 2) / 2)*ci_MnemoScheme_path_thick / m_param.path_thick;

	SelectObject(hdc, m_gdi_obj[EMSGDIO_PEN_BLACK]);
	SelectObject(hdc, m_gdi_obj[EMSGDIO_BRUSH_STOP_BORD]);
	BOOL fRes = Ellipse(hdc, c.x - rad, c.y - rad, c.x + rad, c.y + rad);

	SelectObject(hdc, m_gdi_obj[EMSGDIO_BRUSH_STOP_IN]);
	fRes = Ellipse(hdc, c.x - rad_in, c.y - rad_in, c.x + rad_in, c.y + rad_in); //TEXTMETRIC tm; fRes=GetTextMetrics(hdc, &tm);

	Text_Out(hdc, c, sz_text, (HFONT)m_gdi_obj[EMSGDIO_FONT_STOP], m_param.iFontStop_h);*/
}

void CMnemoScheme::CalcShift_Text_Out(char *sz_text, int font_h, POINT& shift, int* piLenText)
{
	POINT char_size = { font_h*0.81, font_h*1.4 };
	int iLenText = strlen(sz_text);
	int iSizeTextPix = char_size.x * iLenText;
	shift.x = iSizeTextPix / 2;
	shift.y = char_size.y / 2;
	if (piLenText) { *piLenText = iLenText; }
}

void CMnemoScheme::Text_Out(HDC hdc, POINT& c, char *sz_text, HFONT hfont, int font_h)
{
	if (sz_text == 0) { return; }
	
	if (strlen(sz_text) == 0) { return; }

	SelectObject(hdc, hfont);

	SetBkMode(hdc, TRANSPARENT);

	POINT shift;

	int iLenText;

	CalcShift_Text_Out(sz_text, font_h, shift, &iLenText);

	BOOL fRes = TextOutA(hdc, c.x - shift.x, c.y - shift.y, sz_text, iLenText);
}

void CMnemoScheme::Text_OutB(HDC hdc, POINT c, char *sz_text, HFONT hfont, int iLenText)
{
	SelectObject(hdc, hfont);

	SetBkMode(hdc, TRANSPARENT);

	BOOL fRes = TextOutA(hdc, c.x, c.y, sz_text, iLenText);
}

void CMnemoScheme::FloodPath(HDC hdc)
{
	SelectObject(hdc, m_gdi_obj[EMSGDIO_BRUSH_PATH_AB_UP]);

	POINT pn = { (m_path.�enter_rc.left + m_path.�enter_rc.right) / 2,  m_path.�enter_rc.top };

	BOOL fRes = ExtFloodFill(hdc, pn.x, pn.y, 0, FLOODFILLBORDER);
}

void CMnemoScheme::FloodPathDown(HDC hdc)
{
	SelectObject(hdc, m_gdi_obj[EMSGDIO_BRUSH_PATH_BA_DOWN]);

	POINT pn = { (m_path.�enter_rc.left + m_path.�enter_rc.right) / 2,  m_path.�enter_rc.bottom };

	BOOL fRes = ExtFloodFill(hdc, pn.x, pn.y, 0, FLOODFILLBORDER);
}

void CMnemoScheme::DrawSelRouteIn(HDC hdc)
{
	char sz_val[MAX_PATH + 1];

	m_ctrls.SendMes("combo_route", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val); //char sz_text[MAX_PATH + 1];sprintf(sz_text, "��������� ������� %s", sz_val);

	int h = m_path.�enter_rc.bottom - m_path.�enter_rc.top;

	int dy = h/2 - m_path.radi;	

	POINT pn = { (m_path.�enter_rc.left + m_path.�enter_rc.right) / 2,  (m_path.�enter_rc.top + m_path.�enter_rc.bottom) / 2 - dy };
	
	POINT shift = { 0,0 };

	std_string sz_text = "��������� ������� "; sz_text.append(sz_val);

	std::vector<std_string> text_list; text_list.push_back(sz_text);

	DrawLabel(hdc, pn, shift, (HBRUSH)m_gdi_obj[EMSGDIO_BRUSH_SEL_ROUTE_IN], 0, (HFONT)m_gdi_obj[EMSGDIO_FONT_STOP], m_param.iFontStop_h, 0, text_list); // "��������� ������� %s", sz_val);
}

void CMnemoScheme::DrawLabel(HDC hdc, POINT pn, POINT shift, HBRUSH hbrushBackGround, HPEN hpenEraser,HFONT hfont, int h_font, SDrawLabelBitmap* p_bitmap, std::vector<std_string>& text_list) //char *szFormat, ...)
{
	int i_ident = 10;

	const int ci_tri = 3;

	const int ci_ident_betw = 4;

	int i_ident_bitmap_y = 4;

	/*va_list va;

	va_start(va, szFormat);  //int len = _vscprintf(szFormat, va);

	char buf[MAX_PATH + 1];//len + strlen(g_szmapp)+ ci_time_len +2 if (buf == 0) { return; }

	memset(buf, 0, MAX_PATH + 1);

	vsprintf(buf, szFormat, va);*/

	SelectObject(hdc, m_gdi_obj[EMSGDIO_PEN_BLACK]);

	SelectObject(hdc, hbrushBackGround);
	
	struct SText
	{
		std_string sz;
		POINT text_size; //���������� �������
		int iLenText;
		//---
		POINT pn;
	};

	std::vector<SText> tp_list;

	for (int i = 0; i < text_list.size(); i++)
	{
		SText s_text_new;

		s_text_new.sz = text_list[i];
		tp_list.push_back(s_text_new);

		int q = tp_list.size();
		
		if (q == 0) { gMesWnd.Mes("CMnemoScheme::DrawLabel. ������ ���������� ���������� ������"); return; }

		SText& s_text = tp_list[q-1];
		POINT& text_size= s_text.text_size;
		int& iLenText = s_text.iLenText;

		CalcShift_Text_Out((char*)text_list[i].c_str(), h_font, text_size, &iLenText);
	}

	POINT bitmap_size = { 0, 0 };
	
	POINT size = { 0, 0 }; //����� ���������� �������                  

	for (int i = 0; i < tp_list.size(); i++)
	{
		POINT& text_size = tp_list[i].text_size;

		if (size.x < text_size.x) { size.x = text_size.x; }

		size.y += text_size.y + ci_ident_betw / 2; //}
	}


	POINT pn_bitmap= pn;

	if (p_bitmap)
	{                                                                     
		bitmap_size = p_bitmap->size;

		if (size.x < bitmap_size.x / 2) { size.x = bitmap_size.x / 2; }

		size.y += bitmap_size.y / 2 + ci_ident_betw/2 - i_ident_bitmap_y; //}
	}

	RECT rc;	

	int wc = (shift.x + shift.y)*0.2;

	int pth = ci_MnemoScheme_path_thick*0.8;

	int sum_text_size_y = tp_list.size() * (h_font + ci_ident_betw);

	if (shift.x == 0 && shift.y == 0)
	{
		rc.left = pn.x - size.x - i_ident;
		rc.top = pn.y - size.y - i_ident;
		rc.right = pn.x + size.x + i_ident;
		rc.bottom = pn.y + size.y + i_ident;
		
		for (int i = 0; i < tp_list.size(); i++)
		{
			SText& o = tp_list[i];

			o.pn.x = pn.x - o.text_size.x;
			o.pn.y = pn.y - size.y + i*(h_font + ci_ident_betw);
		}

		if (p_bitmap)
		{
			pn_bitmap.x += -bitmap_size.x / 2;
			pn_bitmap.y += -size.y + sum_text_size_y;
		}

	}else
	if (shift.x)
	{
		if (shift.x > 0)
		{
			rc.left = pn.x + shift.x;
			rc.top = pn.y - size.y - i_ident;
			rc.right = pn.x + shift.x + 2 * (size.x + i_ident);
			rc.bottom = pn.y + size.y + i_ident;

			for (int i = 0; i < tp_list.size(); i++)
			{
				SText& o = tp_list[i];

				o.pn.x = pn.x + shift.x + (i_ident)+size.x - o.text_size.x;
				o.pn.y = pn.y - size.y + i*(h_font + ci_ident_betw); //o.pn.y = pn.y - size.y;
			}

			if (p_bitmap)
			{
				pn_bitmap.x += shift.x + (i_ident) + size.x - bitmap_size.x/2;
				pn_bitmap.y += - size.y + sum_text_size_y;
			}	

			POINT a[ci_tri] = { { pn.x + pth, pn.y },{ rc.left, pn.y - wc },{ rc.left, pn.y + wc } }; BOOL fRes = Polygon(hdc, a, ci_tri); //MoveToEx(hdc, rc.left, pn.y - wc, 0); LineTo(hdc, pn.x + pth, pn.y); LineTo(hdc, rc.left, pn.y + wc);ExtFloodFill(hdc, pn.x + wc, pn.y, 0, FLOODFILLBORDER);

			HPEN hPrevPen; //������� �����
			if (hpenEraser) { hPrevPen = (HPEN)SelectObject(hdc, hpenEraser); }
			MoveToEx(hdc, rc.left, pn.y - wc+1, 0); LineTo(hdc, rc.left, pn.y + wc-1);
			SelectObject(hdc, hPrevPen);
		}
		else
		{
			rc.left = pn.x + shift.x - 2 * (size.x + i_ident);
			rc.top = pn.y - size.y - i_ident;
			rc.right = pn.x + shift.x;
			rc.bottom = pn.y + size.y + i_ident;

			for (int i = 0; i < tp_list.size(); i++)
			{
				SText& o = tp_list[i];

				o.pn.x = pn.x + shift.x - (i_ident)-size.x - o.text_size.x;
				o.pn.y = pn.y - size.y + i*(h_font + ci_ident_betw); //o.pn.y = pn.y - size.y;
			}

			if (p_bitmap)
			{
				pn_bitmap.x += shift.x - (i_ident) - size.x - bitmap_size.x / 2;
				pn_bitmap.y += -size.y + sum_text_size_y;
			}

			POINT a[ci_tri] = { { pn.x - pth, pn.y }, { rc.right - 1, pn.y - wc },{ rc.right - 1, pn.y + wc } };
			BOOL fRes = Polygon(hdc, a, ci_tri);
		}
	}else
	if (shift.y)
	{
		int dya = 1;
		if (shift.y > 0)
		{
			rc.left = pn.x - size.x - i_ident;
			rc.top = pn.y + shift.y;
			rc.right = pn.x + size.x + i_ident;
			rc.bottom = pn.y + shift.y + 2*(size.y + i_ident);

			for (int i = 0; i < tp_list.size(); i++)
			{
				SText& o = tp_list[i];

				o.pn.x = pn.x - o.text_size.x;
				o.pn.y = pn.y + shift.y + i_ident + i*(h_font + ci_ident_betw); // +text_size.y;//- size.y 
			}


			if (p_bitmap)
			{
				pn_bitmap.x += - bitmap_size.x / 2;
				pn_bitmap.y += shift.y + i_ident + sum_text_size_y;
			}

			POINT a[ci_tri] = { { pn.x, pn.y + pth }, { pn.x - wc, rc.top + dya }, { pn.x + wc, rc.top + dya } };
			BOOL fRes = Polygon(hdc, a, ci_tri);
		}
		else
		{
			rc.left = pn.x - size.x - i_ident;
			rc.top = pn.y + shift.y - 2*(size.y + i_ident);
			rc.right = pn.x + size.x + i_ident;
			rc.bottom = pn.y + shift.y;

			for (int i = 0; i < tp_list.size(); i++)
			{
				SText& o = tp_list[i];

				o.pn.x = pn.x - o.text_size.x;
				o.pn.y = pn.y + shift.y - i_ident - 2 * size.y + i*(h_font + ci_ident_betw);
			}


			if (p_bitmap)
			{
				pn_bitmap.x += -bitmap_size.x / 2;
				pn_bitmap.y += +shift.y - i_ident - 2*size.y + sum_text_size_y;
			}

			POINT a[ci_tri] = { { pn.x, pn.y - pth }, { pn.x - wc, rc.bottom - dya },{ pn.x + wc, rc.bottom - dya } };
			BOOL fRes = Polygon(hdc, a, ci_tri);
		}
	}

	BOOL fRes = RoundRect(hdc, rc.left, rc.top, rc.right, rc.bottom, ci_MnemoScheme_rad, ci_MnemoScheme_rad);

	if (hpenEraser && (shift.x || shift.y))
	{
		HPEN hPrevPen= (HPEN)SelectObject(hdc, hpenEraser);

		if (shift.x)
		{
			if (shift.x > 0)
			{			
				MoveToEx(hdc, rc.left, pn.y - wc + 1, 0); LineTo(hdc, rc.left, pn.y + wc);
			}else
			{
				MoveToEx(hdc, rc.right-1, pn.y - wc, 0); LineTo(hdc, rc.right - 1, pn.y + wc - 1);
			}
		}else
		if (shift.y)
		{
			if (shift.y > 0)
			{
				MoveToEx(hdc, pn.x - wc + 1, rc.top, 0); LineTo(hdc, pn.x + wc - 1, rc.top);
			}
			else
			{
				MoveToEx(hdc, pn.x - wc + 1, rc.bottom-1, 0); LineTo(hdc, pn.x + wc - 2, rc.bottom - 1);
			}
		}

		SelectObject(hdc, hPrevPen);
 }

	for (int i = 0; i < tp_list.size(); i++)
	{
		SText& o = tp_list[i];

		Text_OutB(hdc, o.pn, (char*)o.sz.c_str(), hfont, o.iLenText);
	}

	if (p_bitmap)
	{
		pn_bitmap.y += i_ident_bitmap_y;

		bool fDraw = win_e::DrawBitmap(hdc, p_bitmap->h, pn_bitmap, &(p_bitmap->size));
	}
}

void CMnemoScheme::DrawCheckPoint(HDC hdc, POINT& pn)
{
	float coef = (float)ci_MnemoScheme_path_thick / (float)m_param.path_thick;

	int rad = (m_param.check_point_size / 2) * coef;

	int rad_in = ((m_param.check_point_size - m_param.check_point_thick * 2) / 2) * coef;

	//<�����
	SelectObject(hdc, m_gdi_obj[EMSGDIO_PEN_BLACK]);
	
	SelectObject(hdc, m_gdi_obj[EMSGDIO_BRUSH_CONTROL_POINT_BORD]);

	BOOL fRes = Ellipse(hdc, pn.x - rad, pn.y - rad, pn.x + rad, pn.y + rad);
	//>�����

	//<������
	SelectObject(hdc, m_gdi_obj[EMSGDIO_BRUSH_STOP_BORD]);

	fRes = Ellipse(hdc, pn.x - rad_in, pn.y - rad_in, pn.x + rad_in, pn.y + rad_in); //TEXTMETRIC tm; fRes=GetTextMetrics(hdc, &tm);
	//>������
}

//void SDrawPoint::Set(POINT& pn_new, int i_order_new) { pn = pn_new; i_order = i_order_new; }

void CMnemoScheme::AddToDrawPointList(bool fForward, std::vector<SDrawPoint>& list, int x, int y, int& i_order)
{
	SDrawPoint o;
	o.pn.x = x;
	o.pn.y = y;
	o.i_order = i_order;
	list.push_back(o);
	if (fForward) { i_order++; }
	else { i_order--; }
}

SDrawPointAdder::SDrawPointAdder(bool fForward_new, std::vector<SDrawPoint>* p_list_new, int i_order_max)
{
	memset(this, 0, sizeof(SDrawPointAdder));

	fForward = fForward_new;
	p_list = p_list_new;

	i_order = fForward ? 1 : i_order_max - 1;
}

void SDrawPointAdder::add(int x, int y)
{
	SDrawPoint o;
	o.pn.x = x;
	o.pn.y = y;
	o.i_order = i_order;

	p_list->push_back(o);

	if (fForward) 
	{ i_order++; }
	else 
	{ i_order--; }
}

bool CMnemoScheme::GetDrawPointsCheckPoints(bool fForward, std::vector<SDrawPoint>& list)
{
	list.clear();

	int q = fForward ? m_list_check_point_AB.list.size() : m_list_check_point_BA.list.size();

	if (q < 3)
	{ 
		if (err_id_picas_route != m_route.id_picas_route) { gMesWnd.Mes("CMnemoScheme::DrawCheckPoints(). ������ ��������� ���������� �����. ����� %s: %s", fForward ? "��" : "��", m_route.route_id.c_str()); }

		err_id_picas_route = m_route.id_picas_route;

		return false; 
	}

	int i_order_max = fForward ? m_list_check_point_AB.GetMaxOrder() : m_list_check_point_BA.GetMaxOrder();

	int axe_prj = m_path.i_�enter_rad_axe_prj;

	int y_hi = fForward ? m_path.�enter_rc.top : m_path.�enter_rc.bottom;

	int y_lo = y_hi + (fForward ? axe_prj : -axe_prj);

	int x_mid = (m_path.�enter_rc.right + m_path.�enter_rc.left) / 2;
	
	int x_left = m_path.�enter_rc.left;

	int x_right = m_path.�enter_rc.right;

	int x_left_top = m_path.�enter_rc.left + axe_prj;
	
	int x_right_top = m_path.�enter_rc.right - axe_prj;

	int w_top = x_right - x_left - 2 * axe_prj;		

	SDrawPointAdder dpa(fForward, &list, i_order_max); //int i_order = fForward ? 1 : i_order_max - 1;

	int w_step = q - 5 >0 ? w_top / (q - 5) : w_top/2;
	

	if (q == 3)
	{
		dpa.add(x_mid, y_hi);
	}else
	if (q == 4)
	{
		dpa.add(x_left_top, y_hi);
		
		dpa.add(x_right_top, y_hi);
	}else
	if (q == 5)
	{
		dpa.add(x_left, y_lo);

		dpa.add(x_mid, y_hi);

		dpa.add(x_right, y_lo);
	}else
	if (q == 6)
	{
		dpa.add(x_left, y_lo);

		dpa.add(x_left_top, y_hi);

		dpa.add(x_right_top, y_hi);

		dpa.add(x_right, y_lo);
	} else
	if (q == 7)
	{
		dpa.add(x_left, y_lo);
	 dpa.add(x_left_top, y_hi);
  dpa.add(x_mid, y_hi);
  dpa.add(x_right_top, y_hi);
  dpa.add(x_right, y_lo);
	} else
	if (q == 8)
	{
		dpa.add(x_left, y_lo);
	 dpa.add(x_left_top, y_hi);
  dpa.add(x_left_top + w_step, y_hi);
  dpa.add(x_left_top + 2 * w_step, y_hi);
  dpa.add(x_right_top, y_hi);
  dpa.add(x_right, y_lo);
	} else
	if (q == 9)
	{
		dpa.add(x_left, y_lo);
	 dpa.add(x_left_top, y_hi);
  dpa.add(x_left_top + w_step, y_hi);
  dpa.add(x_left_top + 2 * w_step, y_hi);
  dpa.add(x_left_top + 3 * w_step, y_hi);
  dpa.add(x_right_top, y_hi);
  dpa.add(x_right, y_lo);
	} else
	if (q == 10)
	{
		dpa.add(x_left, y_lo);
	 dpa.add(x_left_top, y_hi);
  dpa.add(x_left_top + w_step, y_hi);
  dpa.add(x_left_top + 2 * w_step, y_hi);
  dpa.add(x_left_top + 3 * w_step, y_hi);
  dpa.add(x_left_top + 4 * w_step, y_hi);
  dpa.add(x_right_top, y_hi);
		dpa.add(x_right, y_lo);
	}

	return true;
}

void CMnemoScheme::DrawCheckPoints(HDC hdc, bool fForward, std::vector<SMnemoCheckPointRow>& list_check_point)
{
	std::vector<SDrawPoint> list;

	if (GetDrawPointsCheckPoints(fForward, list) == false) { return; }

	for (int i = 0; i < list.size(); i++) { DrawCheckPoint(hdc, list[i].pn); }
}

void CMnemoScheme::DrawCar(HDC hdc, POINT& pn, bool fLeft)
{
	bool fSel = false;

	//<�����
	SelectObject(hdc, m_gdi_obj[EMSGDIO_PEN_BLACK]);

	SelectObject(hdc, m_gdi_obj[EMSGDIO_BRUSH_STOP_BORD]);

	int& rad_car = m_param.rad_car;
	int& rad_car_in = m_param.rad_car_in;

	BOOL fRes = Ellipse(hdc, pn.x - rad_car, pn.y - rad_car, pn.x + rad_car, pn.y + rad_car);
	//>�����

	//<������
	SelectObject(hdc, m_gdi_obj[fSel ? EMSGDIO_BRUSH_STOP_BORD : EMSGDIO_BRUSH_WHITE]);
	SelectObject(hdc, m_gdi_obj[fSel ? EMSGDIO_PEN_BLACK : EMSGDIO_PEN_WHITE]);	
	const int ci_tri = 3;

	POINT shift = { rad_car_in * cos(M_PI / 3), rad_car_in * sin(M_PI / 3) };

	if (fLeft==false)
	{
		POINT a[ci_tri] = { { pn.x - shift.x, pn.y - shift.y },{ pn.x - shift.x, pn.y + shift.y },{ pn.x + rad_car_in, pn.y } }; fRes = Polygon(hdc, a, ci_tri); //fRes = Ellipse(hdc, pn.x - rad_car_in, pn.y - rad_car_in, pn.x + rad_car_in, pn.y + rad_car_in); //TEXTMETRIC tm; fRes=GetTextMetrics(hdc, &tm);
	}
	else	
	{
		POINT a[ci_tri] = { { pn.x - rad_car_in, pn.y }, { pn.x + shift.x, pn.y - shift.y },{ pn.x + shift.x, pn.y + shift.y } }; fRes = Polygon(hdc, a, ci_tri); //fRes = Ellipse(hdc, pn.x - rad_car_in, pn.y - rad_car_in, pn.x + rad_car_in, pn.y + rad_car_in); //TEXTMETRIC tm; fRes=GetTextMetrics(hdc, &tm);
	}
	//>������
}

bool SMnemoCar::GetDrawTrianLeft()
{
	return !f_forward;
}

/*
POINT CMnemoScheme::GetPointShift(SMnemoCar& o)
{
	bool f_draw_shift = o.len_interval_minutes >= 0 && o.event_minutes < o.len_interval_minutes;

	if (f_draw_shift)
	{
		POINT pn_shift;

		SMnemoPlace next_place;

		GetNextPlace(o, next_place);
			
		POINT pn_next;

		if (CalcPointOp(next_place, pn_next))
		{
			float coef = (float)o.len_interval_minutes / (float)o.len_interval_minutes;

			int dx = pn_next.x - o.pn.x;
			int dy = pn_next.y - o.pn.y;

			if (abs(dx) > 2 && abs(dy) > 2)
			{				
				float R = dx;

				float phi = M_PI_2*coef;

				float v_cos = R - R*cos(phi);
				float v_sin = R*sin(phi);

				pn_shift = o.pn;

				if (dx > 0 && dy < 0)
				{
					pn_shift.x += v_cos;
					pn_shift.y -= v_sin;
				}else
				if (dx > 0 && dy > 0)
				{
					pn_shift.x += v_sin;
					pn_shift.y += v_cos;
				}else
				if (dx < 0 && dy > 0)
				{
					pn_shift.x -= v_cos;
					pn_shift.y += v_sin;
				}else
				if (dx < 0 && dy < 0)
				{
					pn_shift.x -= v_sin;
					pn_shift.y -= v_cos;
				}

			}
			else
			{
				pn_shift.x = dx * coef;
				pn_shift.y = dy * coef;
			}

			return pn_shift;
		}
	}

	

	return o.pn;
}
*/

bool SMnemoCars::FindLastByGarageNum(char *garage_num, int& index_last)
{
	bool fFound = false;

	int q = list_last.size();

	char sz_val[MAX_PATH+1];

	for (int i = 0; fFound == false && i < q; i++)
	{
		SMnemoCarLast& oLast = list_last[i];
		SMnemoCar& o = list[oLast.index_last];

		strcpy(sz_val, o.garage_num.c_str());

		if (!stricmp(sz_val, garage_num)) { fFound = true; index_last = i; }
	}

	return fFound;
}

void CMnemoScheme::CalcDrawPoint(POINT& pn, POINT& pn_next, int i_place_order, int q_place, POINT& pn_calc)
{
	const int ci_ident=1;

	int dx = pn_next.x - pn.x;
	int dy = pn_next.y - pn.y;
	pn_calc = pn_next;

	if (dx && dy)
	{
		float R = fabs(dx);
		float angle = ((float)(M_PI_2*i_place_order)) / ((float)(q_place + ci_ident));

		if (dx > 0 && dy < 0)
		{			
			pn_calc.x -= R*sin(angle);
			pn_calc.y += R*(1 - cos(angle));
		}else
		if (dx > 0 && dy > 0)
		{			
			pn_calc.x -= R*(1 - cos(angle));
			pn_calc.y -= R*sin(angle);
		}else
		if (dx < 0 && dy > 0)
		{
			pn_calc.x += R*sin(angle);
			pn_calc.y -= R*(1 - cos(angle));
		}else
		if (dx < 0 && dy < 0)
		{
			pn_calc.x += R*(1 - cos(angle));
			pn_calc.y += R*sin(angle);
		}
	}
	else
	{
		if (dx == 0 && dy < 0)
		{
			pn_calc.y += abs(dy)*i_place_order / (q_place + ci_ident);
		}else
		if (dx >0 && dy == 0)
		{
			pn_calc.x -= abs(dx)*i_place_order / (q_place + ci_ident);
		}else
		if (dx==0 && dy > 0)
		{
			pn_calc.y -= abs(dy)*i_place_order / (q_place + ci_ident);
		}else
		if (dx < 0 && dy == 0)
		{
			pn_calc.x += abs(dx)*i_place_order / (q_place + ci_ident);
		}
	}
}

void CMnemoScheme::CalcDrawPoint_AB(POINT& pn, POINT& pn_next, int i_place_order, int q_place, POINT& pn_calc)
{
	const int ci_ident = 1;

	/*SPoint<int> sPoint(pn_next.x, pn_next.y);

	SPoint<int> pn_0();
	SPoint<int> pn_1;
	if (sPoint.In(pn_0, pn_1) == false) { return; }
	*/
	if (pn_next.x < m_path.rc.left || pn_next.x > m_path.rc.right || pn_next.y<m_path.rc.top || pn_next.y>m_path.rc.bottom) 
	{
		pn_calc = pn;
		return;
	}


	int dx = pn_next.x - pn.x;
	int dy = pn_next.y - pn.y;
	pn_calc = pn;

	if (dx && dy)
	{
		float R = math_e::dist2D(dx, dy)*1.1; //fabs(dx);
		float angle = ((float)(M_PI_2*i_place_order)) / ((float)(q_place + ci_ident));

		float r_sin = R*sin(angle);
		float r_cos= R*(1 - cos(angle));

		if (dx > 0 && dy < 0)
		{
			pn_calc.x += r_cos;
			pn_calc.y -= r_sin;
		}
		else
			if (dx > 0 && dy > 0)
			{
				pn_calc.x += r_sin;
				pn_calc.y += r_cos;
			}
			else
				if (dx < 0 && dy > 0)
				{
					pn_calc.x -= r_cos;
					pn_calc.y += r_sin;
				}
				else
					if (dx < 0 && dy < 0)
					{
						pn_calc.x -= r_sin;
						pn_calc.y -= r_cos;
					}
	}
	else
	{
		if (dx == 0 && dy < 0)
		{
			pn_calc.y -= abs(dy)*i_place_order / (q_place + ci_ident);
		}
		else
			if (dx >0 && dy == 0)
			{
				pn_calc.x += abs(dx)*i_place_order / (q_place + ci_ident);
			}
			else
				if (dx == 0 && dy > 0)
				{
					pn_calc.y += abs(dy)*i_place_order / (q_place + ci_ident);
				}
				else
					if (dx < 0 && dy == 0)
					{
						pn_calc.x -= abs(dx)*i_place_order / (q_place + ci_ident);
					}
	}

	CheckCalcedPoint(pn_calc);
}

/*bool SMnemoCar::OrderOnStop()
{
	if (i_order == 0) { return true; }

	return true;
}*/

/*int CMnemoScheme::GetMaxOrder()
{
	SMnemoCheckPointRows m_list_check_point_AB;
	SMnemoCheckPointRows m_list_check_point_BA;
}*/

void CMnemoScheme::DrawCarA(HDC hdc, int index)
{
	SMnemoCarLast& oLast = m_mnemoCars.list_last[index];
	SMnemoCar& o = m_mnemoCars.list[oLast.index_last]; //if (o.i_order ==0 || o.i_order== GetMaxOrder(o.f_forward)) { return; } //YUIL 2017-12-19 //���������_2017_12_08_transman

	POINT pn_calc;

	CalcDrawPoint_AB(o.pn, o.pn_next, oLast.i_place_order, oLast.q_place, pn_calc);

	int y = (m_path.�enter_rc.bottom + m_path.�enter_rc.top) / 2;

	if (math_e::dist2D(pn_calc.x, pn_calc.y, m_path.�enter_rc.left, y) < (m_bitmap_stop_size.x/2 + m_param.rad_car)) { return; }
	if (math_e::dist2D(pn_calc.x, pn_calc.y, m_path.�enter_rc.right, y) < (m_bitmap_stop_size.x / 2 + m_param.rad_car)) { return; }

	DrawCar(hdc, pn_calc, o.GetDrawTrianLeft());
}

void CMnemoScheme::DrawCars(HDC hdc)
{
	PlaceCars();
	
	char sz_val[MAX_PATH + 1];

	bool fSel = false;
	int index_last;

	if (m_ctrls.SendMes("combo_car", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val))
	{
		fSel = m_mnemoCars.FindLastByGarageNum(sz_val, index_last);
	}

	int q = m_mnemoCars.list_last.size();

 for (int i = 0; i < q; i++) 
	{ 
		if (fSel && i == index_last) { continue; }

		DrawCarA(hdc, i);
	}	

	if (fSel) 
	{ 
		DrawCarA(hdc, index_last);
	}
}

void CMnemoScheme::PlaceCars()
{
	static time_t time_prev = 0;
	
	time_t time = clock();

	time_t delta_time = 400; //ms

	if (time_prev==0 || (time - time_prev) > delta_time)
	{
		time_prev = time;

		LoadCheckPointEventsFromDB();		
	}
}

int SMnemoCheckPointRows::GetMaxOrder(SMnemoCheckPointRow* *p_check_point)
{
	int iMaxOrder = -1;

	for (int i = 0; i < list.size(); i++)
	{
		int i_order = list[i].i_order;

		if (iMaxOrder < i_order) { iMaxOrder = i_order; if (p_check_point) { *p_check_point = &list[i]; } }
	}

	return iMaxOrder;
}

bool CMnemoScheme::FindInDrawPoints(std::vector<SDrawPoint>& list, int i_order, SDrawPoint* *pDrawPoint)
{
	bool fFound = false;

	for (int i = 0; fFound==false && i < list.size(); i++)
	{
		SDrawPoint& o = list[i];

		if (o.i_order == i_order) { fFound = true; if (pDrawPoint) { *pDrawPoint = &o; } }
	}

	return fFound;
}

int CMnemoScheme::GetMaxOrder(bool f_forward, SMnemoCheckPointRow* *p_check_point)
{
	return f_forward ? m_list_check_point_AB.GetMaxOrder(p_check_point) : m_list_check_point_BA.GetMaxOrder(p_check_point);
}

void CMnemoScheme::FillMnemoPlaceNext(SMnemoPlace& place, SMnemoPlace& next)
{
	bool& f_forward = place.f_forward;
	int& i_order = place.i_order;

	int i_order_max = GetMaxOrder(f_forward); // f_forward ? m_list_check_point_AB.GetMaxOrder() : m_list_check_point_BA.GetMaxOrder();

	if (i_order_max == -1) { next.f_forward = f_forward; next.i_order = i_order; return; }

	if (i_order == i_order_max)
	{
		int i_order_max_next = !f_forward ? m_list_check_point_AB.GetMaxOrder() : m_list_check_point_BA.GetMaxOrder();

		if (i_order_max_next == -1) { next.f_forward = f_forward; next.i_order = i_order; return; }

		next.f_forward = !f_forward;
		next.i_order = 0;
	}else
	{
		next.f_forward = f_forward;
		next.i_order = i_order+1;
	}
}

void CMnemoScheme::Calc_Point(SMnemoPlace& place, POINT& pn)
{
	bool& f_forward = place.f_forward;
	int& i_order = place.i_order;

	if (i_order == 0)
	{
		bool f_A = f_forward ? true : false;

		GetDrawPointStop(f_A, pn);
	}
	else
	{
		int i_order_max = f_forward ? m_list_check_point_AB.GetMaxOrder() : m_list_check_point_BA.GetMaxOrder();

		if (i_order == i_order_max)
		{
			bool f_A = f_forward ? false : true;

			GetDrawPointStop(f_A, pn);
		}
		else
		{
			std::vector<SDrawPoint> list;

			if (GetDrawPointsCheckPoints(f_forward, list) == false) { return; }

			SDrawPoint *pDrawPoint;

			if (FindInDrawPoints(list, i_order, &pDrawPoint) == false) { return; }

			pn = pDrawPoint->pn;			
		}
	}

	CheckCalcedPoint(pn);
}

void CMnemoScheme::CheckCalcedPoint(POINT& pn)
{
	if (pn.x < m_path.�enter_rc.left) { pn.x = m_path.�enter_rc.left; }
	if (pn.x > m_path.�enter_rc.right) { pn.x = m_path.�enter_rc.right; }
	if (pn.y < m_path.�enter_rc.top) { pn.y = m_path.�enter_rc.top; }
	if (pn.y > m_path.�enter_rc.bottom) { pn.y = m_path.�enter_rc.bottom; }
}

bool CMnemoScheme::CalcPointOp(SMnemoPlace& place, POINT& pn, POINT& pn_next)
{
	bool& f_forward = place.f_forward;
	int& i_order = place.i_order;

	SMnemoPlace next;

	FillMnemoPlaceNext(place, next);

	Calc_Point(place, pn);

	Calc_Point(next, pn_next);	

	return true;
}

bool CMnemoScheme::CalcPoint(SMnemoCar& o)
{
	SMnemoPlace place;

	place.f_forward = o.f_forward;
	place.i_order = o.i_order;

	bool fRes = CalcPointOp(place, o.pn, o.pn_next);

	return fRes;
}

bool CMnemoScheme::GetNextPlace(SMnemoCar& o, SMnemoPlace& next_place)
{
	int i_order_max = o.f_forward ? m_list_check_point_AB.GetMaxOrder() : m_list_check_point_BA.GetMaxOrder();

	int i_order_next;
	int f_forward_next;

	if (o.i_order == i_order_max)
	{
		i_order_next=0;
		f_forward_next = !o.f_forward;
	}
	else
	{
		i_order_next = o.i_order + 1;
		f_forward_next = o.f_forward;
	}

	return true;
}

void CMnemoScheme::FindNearNextCar(int indexLast, SMnemoCarLast& oLast, SMnemoCar& o) //SMnemoCar& s_car
{	
	std::vector<SMnemoCar>& list = m_mnemoCars.list;
	std::vector<SMnemoCarLast>& list_last = m_mnemoCars.list_last;

	o.f_next = false;	

	if (list.size() == 0) { return; }

	//1.
	std::vector<SMnemoCar::SNext> next_list;

	SMnemoCar::SNext s_next;

	SMnemoCar::SNext s_near; //���� �������� �� �������
	s_near.index = -1;
	bool fLet = false;

	for (int i = 0; i < list.size(); i++)
	{
		SMnemoCar& oL = list[i];

		if (oL.id_ate_3 == o.id_ate_3) { continue; }

		//<d1
		int d_minutes = abs(o.time_minutes - oL.time_minutes);

		if (s_near.index == -1) { fLet = true; }
		else
		{
			if (s_near.d_minutes > d_minutes) { fLet = true; }
		}

		if (fLet)
		{
			s_near.index = i;
			s_near.d_minutes = d_minutes;
		}
		//>d1

		if (oL.f_forward != o.f_forward || oL.i_order != o.i_order || o.time_minutes < oL.time_minutes) { continue; }

		s_next.index = i;

		s_next.d_minutes = o.time_minutes - oL.time_minutes;

		next_list.push_back(s_next);
	}
	
	//2.
	if (next_list.size() == 0) 
	{ 
		//2.1. ���� �������� �� �������
		if (s_near.index != -1)
		{
			o.s_next = s_near;
			s_near.eAlg = SMnemoCar::EA_EASY_NEAR;
			o.f_next = true;
		}
		return; 
	}
	

	o.f_next = true;

	//3.
	SMnemoCar::SNext& s_next_near = o.s_next;
	s_next_near.eAlg = SMnemoCar::EA_ONE_ORDER;

	for (int i=0; i < next_list.size(); i++)
	{
		SMnemoCar::SNext& n = next_list[i];

		if (i == 0) { s_next_near = n; }
		else
		{
			if (s_next_near.d_minutes > n.d_minutes) { s_next_near = n; }
		}
	}

}

void CMnemoScheme::ReportAboutCalcPrevToFile()
{
	FILE *fo = fopen("C:\\transman\\mnemo_scheme\\report_list_last.txt", "wb");
	
	if (fo == 0) { return; }

	for (int i = 0; i < m_mnemoCars.list_last.size(); i++)
	{
		SMnemoCarLast& oLast = m_mnemoCars.list_last[i];
		SMnemoCar& o= m_mnemoCars.list[oLast.index_last];

		fprintf(fo, "i_event:%d id_ate_3:%d garage_num:'%s' f_forward:%d i_order:%d stop_name:'%s' time_minutes:%d f_next:%d prev_id_ate_3:%d prev_garage_num:'%s' prev_d_minutes:%d\r\n", o.i_event, o.id_ate_3, o.garage_num.c_str(), o.f_forward, o.i_order, o.stop_name.c_str(), o.time_minutes, o.f_next, o.f_next ? m_mnemoCars.list[o.s_next.index].id_ate_3 : -1, o.f_next ? m_mnemoCars.list[o.s_next.index].garage_num.c_str() : "", o.f_next ? o.s_next.d_minutes : -1);
	}

	fclose(fo);
}


bool SMnemoCars::FindLast(int id_ate_3, SMnemoCarLast* *p_car)
{
	bool  fFound = false;

	for (int i = 0; fFound == false && i < list_last.size(); i++)
	{
		SMnemoCarLast& o = list_last[i];

		if (o.id_ate_3 == id_ate_3) { fFound = true; *p_car = &o; }
	}

	return fFound;
}

void SMnemoCars::AddLast(int index_last_new, int i_event_new, int id_ate_3_new)
{
	SMnemoCarLast *p_car;

	//1.
	bool fFound = FindLast(id_ate_3_new, &p_car);

	//2.
	if (fFound == false)
	{
		SMnemoCarLast o;
		o.index_last = index_last_new;
		o.i_event = i_event_new;
		o.id_ate_3 = id_ate_3_new;
		list_last.push_back(o);

		int q = list_last.size();

		if (q == 0) { return; }

		p_car = &list_last[q - 1];
	}

	//3.
	if (p_car->i_event < i_event_new)
	{
		p_car->i_event = i_event_new;
		p_car->index_last = index_last_new;
	}

}

void SMnemoCars::SortLast()
{
	int q = list_last.size();
	
	for (int i = 0; i < q - 1; i++)
	{
		SMnemoCarLast& o = list_last[i];

		for (int k = i+1; k < q; k++)
		{
			SMnemoCarLast& n = list_last[k];

			if (o.i_event > n.i_event) 
			{
				SMnemoCarLast c = o; o = n; n = c;  //memcpy(&c, &o, sizeof(SMnemoCarLast)); memcpy(&o, &n, sizeof(SMnemoCarLast));memcpy(&n, &c, sizeof(SMnemoCarLast));
			}
		}
	}
}

bool SMnemoCars::FindPlaceCount(bool f_forward, int i_order, int& index)
{
	bool fFound = false;
	
	int q = place_count.size();

	for (int i=0; fFound == false && i<q; i++)
	{
		SMnemoPlaceCount& o = place_count[i];

		if (o.f_forward == f_forward && o.i_order == i_order) { fFound = true; index = i; }
	}

	return fFound;
}

void SMnemoCars::AddPlaceCount(SMnemoCarLast& oLast, SMnemoCar& o)
{
	int q_place_count = place_count.size();

	int index;
	bool fFind = FindPlaceCount(o.f_forward, o.i_order, index);

	if (!fFind)
	{
		SMnemoPlaceCount s_place;
		s_place.f_forward = o.f_forward;
		s_place.i_order = o.i_order;
		s_place.q = 1;
		place_count.push_back(s_place);

		oLast.i_place_order = 0;
	}
	else
	{
		int& q = place_count[index].q;

		oLast.i_place_order = q;

		q++;
	}
}

void SMnemoCars::set_q_place()
{
	for (int i = 0; i < list_last.size(); i++)
	{
		SMnemoCarLast& oLast = list_last[i];
		int index_last = oLast.index_last;
		SMnemoCar& o = list[index_last];

		int indexPlaceCount;
		
		if (FindPlaceCount(o.f_forward, o.i_order, indexPlaceCount))
		{
			oLast.q_place = place_count[indexPlaceCount].q;
		}
	}
}

bool CMnemoScheme::CalcPoints()
{
	std::vector<SMnemoCarLast>& list_last = m_mnemoCars.list_last;
	std::vector<SMnemoCar>& list= m_mnemoCars.list;
	std::vector<SMnemoPlaceCount>& place_count= m_mnemoCars.place_count;

	list_last.clear();

	for (int i = 0; i < list.size(); i++)
	{ 
		SMnemoCar& o = list[i];
		
		m_mnemoCars.AddLast(i, o.i_event, o.id_ate_3);
	}

	place_count.clear();

	for (int i = 0; i < list_last.size(); i++)
	{
		SMnemoCarLast& oLast = list_last[i];
		int index_last = oLast.index_last;
		SMnemoCar& o= m_mnemoCars.list[index_last];
		
		m_mnemoCars.AddPlaceCount(oLast, o);

		FindNearNextCar(i, oLast, o);

		if (CalcPoint(o) == false) { return false; }
	}

	m_mnemoCars.set_q_place();

	m_mnemoCars.SortLast();

	ReportAboutCalcPrevToFile();

	return true;
}

void CMnemoScheme::DrawCheckPointFrame(HDC hdc, POINT& pn, char* sz_text)
{
	POINT pnL = pn;

	POINT shift = {0, 0};

	int i_dist= 30;

	if (m_path.�enter_rc.left   == pn.x) { shift.x =  i_dist; } else
	if (m_path.�enter_rc.right  == pn.x) { shift.x = -i_dist; } else
	if (m_path.�enter_rc.top    == pn.y) { shift.y =  i_dist; } else
	if (m_path.�enter_rc.bottom == pn.y) { shift.y = -i_dist; }
	
	HPEN hpenEraser = (HPEN)m_gdi_obj[EMSGDIO_PEN_WHITE];

	std_string item= sz_text;
	std::vector<std_string> text_list;  text_list.push_back(item);

	DrawLabel(hdc, pnL, shift, (HBRUSH)m_gdi_obj[EMSGDIO_BRUSH_WHITE], hpenEraser, (HFONT)m_gdi_obj[EMSGDIO_FONT], m_param.iFont_h, 0, text_list);
}

void CMnemoScheme::CalcShiftDraw(POINT& pn, POINT& pn_next, POINT& shift)
{
	shift.x = 0;
	shift.y = 0;

	int dx = pn_next.x - pn.x;
	int dy = pn_next.y - pn.y;
	int i_dist = 30;

	if (dx && dy)
	{
		if (dx > 0 && dy < 0) { shift.x = -i_dist; }
		else
  if (dx > 0 && dy > 0) { shift.x = i_dist; }
		else
		if (dx < 0 && dy > 0) { shift.x = i_dist; }
		else
		if (dx < 0 && dy < 0) { shift.x = -i_dist; }
	}
	else
	{
		if (m_path.�enter_rc.left == pn.x) { shift.x = -i_dist; }
		else
		if (m_path.�enter_rc.right == pn.x) { shift.x = i_dist; }
		else
		if (m_path.�enter_rc.top == pn.y) { shift.y = -i_dist; }
		else
		if (m_path.�enter_rc.bottom == pn.y) { shift.y = i_dist; }
	}
}

void CMnemoScheme::DrawCarFrame(HDC hdc, POINT& pn, std::vector<std_string>& text_list, bool fSel, POINT& shift, EMnemoSchemeGDIObject eFont)
{
	POINT pnL = pn;

	HPEN hpenEraser = (HPEN)m_gdi_obj[fSel ? EMSGDIO_PEN_SEL_FRAME : EMSGDIO_PEN_WHITE];

	SDrawLabelBitmap s_bitmap = { (HBITMAP)m_gdi_obj[EMSGDIO_BITMAP_BUS], {41, 20} };

	int iFont_h = eFont == EMSGDIO_FONT ? m_param.iFont_h : m_param.iFontMini_h;

	DrawLabel(hdc, pnL, shift, (HBRUSH)m_gdi_obj[fSel ? EMSGDIO_BRUSH_SEL_FRAME : EMSGDIO_BRUSH_WHITE], hpenEraser, (HFONT)m_gdi_obj[eFont], iFont_h, &s_bitmap, text_list);
}

void CMnemoScheme::DrawCarFrameA(HDC hdc, int i, bool fSel)
{
	SMnemoCarLast& oLast = m_mnemoCars.list_last[i];
	SMnemoCar& o = m_mnemoCars.list[oLast.index_last];

	std::vector<std_string> text_list;

	std_string item = o.garage_num; text_list.push_back(item);

	if (o.f_next)
	{
		SMnemoCar::SNext& s_next = o.s_next;

		SMnemoCar& oNext = m_mnemoCars.list[s_next.index];

		char sz_val[MAX_PATH + 1];

		itoa(s_next.d_minutes, sz_val, 10); item = sz_val; item.append(" ���. => "); item.append(oNext.garage_num.c_str());

		if (s_next.eAlg == SMnemoCar::EA_EASY_NEAR) { item.append(" *"); }

		text_list.push_back(item);
	}

	//FILE *fo = fopen("C:\\transman\\mnemo_scheme\\car_farame_text.txt",  "wb");		if (fo) { fprintf(fo, "%s", sz_text.c_str()); fclose(fo); }

	POINT pn_calc;

	CalcDrawPoint_AB(o.pn, o.pn_next, oLast.i_place_order, oLast.q_place, pn_calc);

	POINT shift;

	CalcShiftDraw(o.pn, o.pn_next, shift);

	DrawCarFrame(hdc, pn_calc, text_list, fSel, shift);
}

void CMnemoScheme::DrawCarFrames(HDC hdc)
{
	char sz_val[MAX_PATH + 1];

	bool fSel = false;
	int index_last;

	if (m_ctrls.SendMes("combo_car", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val))
	{
		fSel = m_mnemoCars.FindLastByGarageNum(sz_val, index_last);
	}

	for (int i = 0; i < m_mnemoCars.list_last.size(); i++)
	{
		if (fSel && i == index_last) { continue; }
		
		DrawCarFrameA(hdc, i, false);
	}

	if (fSel) 
	{ 
		DrawCarFrameA(hdc, index_last, true);
	}

}

char* CMnemoScheme::GetCheckPointName(bool f_forward, SMnemoCheckPointRow& o, std_string& sz_name)
{
	if (m_eCheckPointNameView == ECPV_PLACE) { sz_name = o.name; } else
	if (m_eCheckPointNameView == ECPV_LEGEND) 
	{ 
		
		sz_name = "KT-";
		char sz_val[MAX_PATH + 1];

		if (f_forward)
		{
			sprintf(sz_val, "%d", o.i_order);
		}
		else
		{
			bool f_forward_to_get = true;

			int i_max_order_AB = GetMaxOrder(f_forward_to_get);

			sprintf(sz_val, "%d", i_max_order_AB + o.i_order);
		}
		sz_name.append(sz_val);
		
	}

	return (char*)sz_name.c_str();
}

void CMnemoScheme::DrawCheckPointFramesOp(HDC hdc, SMnemoCheckPointRows& list_check_point, bool f_forward)
{
	

	for (int i = 0; i < list_check_point.list.size(); i++)
	{
		SMnemoCheckPointRow& o = list_check_point.list[i];

		SMnemoPlace place;
		place.f_forward = f_forward;
		place.i_order = o.i_order;
		POINT pn, pn_next;

		if (o.i_order == 0 || o.i_order == GetMaxOrder(f_forward)) { continue; }		

		if (CalcPointOp(place, pn, pn_next) == false) { continue; }

		std_string sz_name;

		char *p_text = GetCheckPointName(f_forward, o, sz_name);

		DrawCheckPointFrame(hdc, pn, p_text); //static char sz_val[MAX_PATH + 1]; sprintf(sz_val, "%d: %s", o.i_order + 1, o.name.c_str()); DrawCheckPointFrame(hdc, pn, sz_val);
	}
}

void CMnemoScheme::DrawCheckPointFrames(HDC hdc)
{
	bool f_forward;

	f_forward = true;  DrawCheckPointFramesOp(hdc, m_list_check_point_AB, f_forward);
	
	f_forward = false; DrawCheckPointFramesOp(hdc, m_list_check_point_BA, f_forward);
}

void CMnemoScheme::DrawLegend(HDC hdc, int w)
{
	const int ci_ident = 300;
	const int ci_ident_y = -120;
	const int ci_ident_betw_x = 60;
	int start_x = m_path.rc.right + ci_ident;
	int start_y = m_path.rc.top + ci_ident_y;
	
	int step_y = m_param.rad_stop * 2 * 0.9;

	char sz_val[MAX_PATH + 1];
	POINT pn, pn_text;
	HFONT hfont = (HFONT)m_gdi_obj[EMSGDIO_FONT];  //m_param.iFont_h //m_param.rad_stop
	int index;
	//<stop
	pn.x = start_x - m_bitmap_stop_size.x/2;
	pn.y = start_y - m_bitmap_stop_size.y / 2;
	pn_text.x = start_x + ci_ident_betw_x;
	pn_text.y = start_y - m_param.iFont_h / 2;
	bool f_A = true;
	DrawStopOp(pn, hdc, f_A); sprintf(sz_val, "�������� ��������� ��������"); Text_OutB(hdc, pn_text, sz_val, hfont, strlen(sz_val));
	//>stop

	//<check_point
	index = 1;
	pn.x = start_x;
	pn.y = start_y + index * step_y;
	pn_text.x = start_x + ci_ident_betw_x;
	pn_text.y = start_y + index * step_y - m_param.iFont_h / 2;
	DrawCheckPoint(hdc, pn); sprintf(sz_val, "������������ �����"); Text_OutB(hdc, pn_text, sz_val, hfont, strlen(sz_val));
	//>check_point

	//<car
	index = 2;
	pn.x = start_x;
	pn.y = start_y + index * step_y;
	pn_text.x = start_x + ci_ident_betw_x;
	pn_text.y = start_y + index * step_y - m_param.iFont_h / 2;
	DrawCar(hdc, pn, true); sprintf(sz_val, "������������ �������"); Text_OutB(hdc, pn_text, sz_val, hfont, strlen(sz_val));
	//>car

	//<stop_frame
	index = 3;
	pn.x = start_x;
	pn.y = start_y + index * step_y;
	pn_text.x = start_x + ci_ident_betw_x;
	pn_text.y = start_y + index * step_y - m_param.iFont_h / 2;
	DrawCheckPointFrame(hdc, pn, "���"); sprintf(sz_val, "��� ����������� �����"); Text_OutB(hdc, pn_text, sz_val, hfont, strlen(sz_val));
	//>stop_frame

	//<car_frame
	index = 5;
	pn.x = start_x;
	pn.y = start_y + index * step_y;
	int i_car_frame_ident = 70;
	pn_text.x = start_x + ci_ident_betw_x + i_car_frame_ident;
	pn_text.y = start_y + index * step_y - m_param.iFont_h / 2;
	std_string item;
	std::vector<std_string> text_list;
	item = "�������� �����"; text_list.push_back(item);
	item = " "; text_list.push_back(item);
	item = "����� �� ����������"; text_list.push_back(item);
	POINT shift = {0, 0}; //CalcShiftDraw(pn, pn, shift);
	DrawCarFrame(hdc, pn, text_list,  false, shift, EMSGDIO_FONT_MINI); sprintf(sz_val, "��������� � ��"); Text_OutB(hdc, pn_text, sz_val, hfont, strlen(sz_val));
	//>car_frame

	DrawCheckPointList(hdc, start_x- i_car_frame_ident, start_y +7*step_y, step_y*0.7, w);
}


/*char* CMnemoScheme::GetCheckPointName_Legend(bool f_forward, SMnemoCheckPointRow& o, std_string& sz_name)
{
		sz_name = "KT-";
		char sz_val[MAX_PATH + 1];


		if (f_forward)
		{
			sprintf(sz_val, "%d", o.i_order);
		}
		else
		{
			bool f_forward_to_get = true;

			int i_max_order_AB = GetMaxOrder(f_forward_to_get);

			sprintf(sz_val, "%d", i_max_order_AB + o.i_order);
		}
		sz_name.append(sz_val);

	}

	return (char*)sz_name.c_str();
}
*/

///void CMnemoScheme::GetMaxOrderName(bool f_forward, std_string& sz_name){}
void CMnemoScheme::DrawCheckPointListOp(bool f_forward, HDC hdc, int start_x, int start_y, int step_y, int& index, int w)
{
	int i_ident_from_right = 10;
	int i_ident_rect_stop = 7;

	std::vector<SMnemoCheckPointRow>* p_list= &(f_forward ? m_list_check_point_AB.list : m_list_check_point_BA.list);	

	int q = p_list->size()-1;

	//stop and check point's	
	for (int i = 0; i < q; i++, index++)
	{
		POINT pn;
		pn.x = start_x;
		pn.y = start_y + index * step_y;

		std_string sz_name;

		if (i == 0)
		{
			SMnemoCheckPointRow* p_check_point;
			int i_max_order = GetMaxOrder(f_forward, &p_check_point); //GetMaxOrderName(f_forward, sz_name);
			if (i_max_order >= 0)
			{
				sz_name = f_forward ? "��" : "��"; sz_name.append(" (�� ");  sz_name.append(p_check_point->name); sz_name.append(")");
			}  //index++;
			
			POINT shift;
			int iLenText;
			CalcShift_Text_Out((char*)sz_name.c_str(), m_param.iFont_h, shift, &iLenText);

			SelectObject(hdc, m_gdi_obj[EMSGDIO_PEN_BLACK]);
			SelectObject(hdc, m_gdi_obj[f_forward ? EMSGDIO_BRUSH_PATH_AB_UP : EMSGDIO_BRUSH_PATH_BA_DOWN]);
			
			BOOL fRes = RoundRect(hdc, pn.x - i_ident_rect_stop, pn.y- i_ident_rect_stop, w-i_ident_from_right+ i_ident_rect_stop, pn.y + shift.y*2+ i_ident_rect_stop, ci_MnemoScheme_rad, ci_MnemoScheme_rad); //m_param.iFont_h
		}
		else
		{
			SMnemoCheckPointRow& o = p_list->operator[](i);

			GetCheckPointName(f_forward, o, sz_name); sz_name.append(" "); sz_name.append(o.name);
		}

		Text_OutB(hdc, pn, (char*)sz_name.c_str(), (HFONT)m_gdi_obj[EMSGDIO_FONT], sz_name.size()); //i==0 ? EMSGDIO_FONT_STOP : 
	}

}

void CMnemoScheme::DrawCheckPointList(HDC hdc, int start_x, int start_y, int step_y, int w)
{
	if (m_eCheckPointNameView == ECPV_PLACE) { return; }

	int index = 0;
	bool f_forward;

	f_forward = true; DrawCheckPointListOp(f_forward, hdc, start_x, start_y, step_y, index, w);
	f_forward = false; DrawCheckPointListOp(f_forward, hdc, start_x, start_y, step_y, index, w);
}

void CMnemoScheme::PaintOp(HDC hdc, int w, int h, int i_mode)
{
	DrawGround(hdc, w, h);
	
	if (i_mode == 0)
	{
		m_path.DrawPath(hdc, m_gdi_obj);
		FloodPath(hdc);
		FloodPathDown(hdc);

		bool f_A;
		f_A = true;  DrawStop(hdc, f_A); // , "�");
		f_A = false; DrawStop(hdc, f_A); //, "�");	


		DrawSelRouteIn(hdc);

		bool fForward;

		fForward = true;  DrawCheckPoints(hdc, fForward, m_list_check_point_AB.list);
		fForward = false; DrawCheckPoints(hdc, fForward, m_list_check_point_BA.list);

		DrawCheckPointFrames(hdc);

		DrawCars(hdc);
		DrawCarFrames(hdc);
		DrawLegend(hdc, w);
	}
}

void CMnemoScheme::CallPaint()
{
	if (!m_hwnd) { return; }

	HDC hdc = GetDC(m_hwnd);

 Paint(hdc);

	ReleaseDC(m_hwnd, hdc);
}