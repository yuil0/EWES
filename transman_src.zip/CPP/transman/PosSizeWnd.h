#ifndef _PosSizeWnd_h_
#define _PosSizeWnd_h_

#include  <windows.h>

typedef enum
{
	ERS_LEFT=0,
	ERS_TOP,
	ERS_RIGHT,
	ERS_BOTTOM,
	ERS_QUANTITY,
}ERectSide;

class CPosSizeWnd
{            //bool m_fInit;
	RECT m_rc;
	bool m_fRead;
	bool m_event;
	int m_delta[ERS_QUANTITY];
	bool DeltaIsOver();

	//WINDOWPLACEMENT m_placement;
	UINT m_f_state;
	bool m_eventState;	

	void CmpPlacement(const WINDOWPLACEMENT& placement);
	public:
	CPosSizeWnd();
	void Clear();
	void ClearEvents();
	void Read(HWND h_wnd, bool fSaveBegin=false);
	bool GetEvent() { return m_event; }
	bool GetDelta(ERectSide eSide, int& iDeltaVal);

	bool GetEventState() { return m_eventState; }
	UINT GetState() { return m_f_state; }
};

#endif