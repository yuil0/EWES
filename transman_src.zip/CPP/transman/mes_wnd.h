#ifndef _mes_wnd_h_
#define _mes_wnd_h_

#include <windows.h>


extern const int ci_len_sz_app;

extern char g_szm_app[];

extern wchar_t g_sz_app[];

extern char g_sz_name[];

extern wchar_t g_wz_name[];


/*void MesBox(wchar_t *wsz_text);

void MesBoxA(char *sz_text);

void Mes(char *szFormat, ...);*/


#endif