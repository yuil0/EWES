//YUIL 2017 yuil@mail.ru

#ifndef _date_time_h_
#define _date_time_h_

namespace date_time
{
	struct SDate
	{
		int year;
		int month;
		int day;
	};
	
	typedef void (*SUBTRACT_DAY_FUNC)(void* p_param, SDate& date);
	
	bool IsHiYear(int year);
	
	int GetMonthMaxDay(SDate& date);
	 
 bool SubtractDays(SDate& date, int nDays, void* p_param, SUBTRACT_DAY_FUNC func=0);
	
	bool SubtractDay(SDate& date);
}

#endif