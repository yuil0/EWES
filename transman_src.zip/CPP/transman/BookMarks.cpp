#include <memory.h>
#include <windows.h>
#include "BookMarks.h"
#include "main.h"
#include <windowsx.h>
#include "math_e.h"
#include "MesWnd.h"
#include "..\\transman_srv\\time_e.h"
#include "ini_file.h"

//const int ci_book_mark_timer_5_sec = 5000; //YUIL 2017-11-09 //const int ci_book_mark_id_timer= 1; //YUIL 2017-11-09


const char* csz_book_mark_caption_name = "������������������ �������������� ������� ���������� ������ ���������� ������������� ����������� (��� �����)";
const char *csz_bookmark_name[EBMN_QUANTITY]=
{
	"�����\0", "���\0", "����������\0", "������\0", "�������������\0"
};

CBookMarks::CBookMarks() {}

CBookMarks::~CBookMarks() {}

bool CBookMarks::Open()
{
	memset(this, 0, sizeof(CBookMarks));
	
	m_fInit=true; //CrGDIObjects();
	
	win_e::GetKeysLangInput(m_eHotKeysLangInput);

	LoadIni();

	SetSizeBitmap_all();

	m_params.Init(m_size_bitmap);

	m_height_font_caption = 12;

	cr_m_gdi_obj();

	m_hbrushGround = CreateSolidBrush(0xDED9B5); //������� �������� R-181 G-217 B-222=0xDED9B5;
	m_hpenGround= CreatePen(PS_SOLID, 0, 0xDED9B5); //������� �������� R-181 G-217 B-222=0xDED9B5;           //AddBitmapCtrls();

	ShowAll();

	CrThread();

	return m_fInit;
}

void CBookMarks::LoadIni()
{
	CIniFile ini;
	
	char sz_val[MAX_PATH+1];

	if (ini.Get("c:\\transman\\transman.ini", "book_mark_need_admin", sz_val, MAX_PATH))
	{
		m_f_need_admin = atoi(sz_val);
	}

	if (ini.Get("c:\\transman\\transman.ini", "BackGroundImage", sz_val, MAX_PATH))
	{
		m_fBackGroundImage = atoi(sz_val);
	}	
}

void CBookMarks::ShowAll()
{
	for (int i = 0; i < (int)EBMN_QUANTITY; i++) 
	{ 
		m_f_visible[i] = (EBookMarkName)i == EBMN_ADMIN && m_f_need_admin == false ? false : true;
	}
}

void CBookMarks::Close()
{                                    //DelGDIObjects(); 
	del_m_gdi_obj();

	DeleteObject(m_hbrushGround);
	DeleteObject(m_hpenGround);
	
	m_MnemoScheme.Close();

	m_chat.Close(); //BOOL f_res = KillTimer(wnd.GetHWND(), ci_book_mark_id_timer);
	
	m_rep.Close();

	m_map.Close(); //m_bitmapCtrls.Close();

	m_admin.Close();

 DestroyWindow(wnd.GetHWND());	//gWndMain.GetHWND()
}

void SBookMarksParams::Init(POINT* a_size_bitmap)
{
	i_top = a_size_bitmap[EBMB_LOGO].y + 2 * 5;

	i_height = 40 + i_top;

	i_ident_x = 5;
}

/*void CBookMarks::AddBitmapCtrls()
{
	if (m_bitmapCtrls.Open() == false) { return; }

	win_e::SMonitors& sm = gMonitors;
	int wScr = sm.rc[1].right - sm.rc[1].left; //int y = m_params.i_top; //int h = m_params.i_height - m_params.i_top;
	int ident_x = m_params.i_ident_x;
	win_e::SBitmapCtrl o;

	o.id = (int)EBMC_BUT_CLOSE;
	o.size.x = 23;
	o.size.y = 23;
	o.pn.x = wScr - o.size.x - ident_x;
	o.pn.y = ident_x;
	o.Init("C:\\transman\\img\\book_marks_but_close.bmp");
	m_bitmapCtrls.Add(o);
}*/

void CBookMarks::cr_m_gdi_obj()
{
	m_gdi_obj[EBMGDIO_LOGO_1_1] = LoadImageA(0, "C:\\transman\\img\\1_1.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE); 
	m_gdi_obj[EBMGDIO_BUT_CLOSE] = LoadImageA(0, "C:\\transman\\img\\book_marks_but_close.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);	 //bus_31%
	m_gdi_obj[EBMGDIO_PEN_CAPTION] = CreatePen(PS_SOLID, 0, 0x685341); //���� ��������� B-106 G-67 R-83 = 0x6A4353
	m_gdi_obj[EBMGDIO_BRUSH_CAPTION] = CreateSolidBrush(0x685341);
	m_gdi_obj[EBMGDIO_PEN_NON_ACTIVE_BOOKMARK] = CreatePen(PS_SOLID, 0, 0x877669); //���������� �������� : R=105 G=118 B=135 : 0x877669
	m_gdi_obj[EBMGDIO_BRUSH_NON_ACTIVE_BOOKMARK] = CreateSolidBrush(0x877669);	

	m_gdi_obj[EBMGDIO_BITMAP_BACKGROUND] = (HBITMAP)LoadImageA(0, "c:\\transman\\img\\0_1�.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

	//EBMGDIO_FONT_CAPTION
}

void CBookMarks::del_m_gdi_obj()
{
	for (int i = 0; i<(int)EBMGDIO_QUANTITY; i++)
	{
		DeleteObject(m_gdi_obj[i]);
	}
}

void CBookMarks::SetSizeBitmap(EBookMarksBitmap eBitmap, int x, int y)
{
	m_size_bitmap[eBitmap].x = x;
	m_size_bitmap[eBitmap].y = y;
}

void CBookMarks::SetSizeBitmap_all()
{
	SetSizeBitmap(EBMB_LOGO, 38, 36); 	//prev:116, 110
	SetSizeBitmap(EBMB_BUT_CLOSE, 23, 23);	
}

void CBookMarks::CrFonts(HDC hdc)
{
	static bool fCrFonts = false;

	if (fCrFonts) { return; }

	bool fBold = true;

	win_e::SetFont(hdc, "Arial", m_height_font_caption, fBold, (HFONT&)m_gdi_obj[EBMGDIO_FONT_CAPTION]);

	fCrFonts = true;
}

/*void CBookMarks::CrGDIObjects()
{
 m_gdiobj[EBMGDIO_PEN_BLACK]=CreatePen(PS_SOLID, 0, 0x000000);
	m_gdiobj[EBMGDIO_PEN_WHITE]=CreatePen(PS_SOLID, 0, 0xFFFFFF);
}

void CBookMarks::DelGDIObjects()
{
	for(int i=0; i<(int)EBMGDIO_PEN_QUANTITY; i++)
	{
  DeleteObject(m_gdiobj[i]);
	}
}*/

void CBookMarks::WM__CLOSE(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	BM_Close();
}

void CBookMarks::BM_Close()
{
	Destroy();

	Sleep(100);

	ExitProcess(1);
}
 
void CBookMarks::WM__SYSKEYDOWN(WPARAM wParam, LPARAM lParam) //���� F10 or Alt
{
}

void CBookMarks::WM__KEYDOWN(HWND hwnd, WPARAM wParam, LPARAM lParam) 
{
		if (wParam == VK_TAB)
		{
		if (m_active==EBMN_MAP)
		{
			m_map.Tab();
		}
		else
		if (m_active == EBMN_CHAT)
		{
			m_chat.Tab();
		}
		else
		if (m_active == EBMN_REPORT)
		{
			m_rep.Tab();
		}
		else
		if (m_active == EBMN_ADMIN)
		{
			m_admin.Tab();
		}
	}
	else
	if (wParam == VK_F5)
	{
		Paint();
	}
	else
	{
		if (m_active == EBMN_MAP)
		{
			m_map.WM__KEYDOWN(wParam, lParam);
		}
	}
}

void CBookMarks::WM__CHAR(WPARAM wParam, LPARAM lParam)
{
	if (m_active == EBMN_MAP)
	{
		m_map.WM__CHAR(wParam, lParam);
	}

}

void CBookMarks::WM__LBUTTONDOWN(HWND hwnd, WPARAM wParam, LPARAM lParam, int i_mode)
{
	POINT pn = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
	
	if (i_mode == 0)
	{
		win_e::SMonitors& sm = gMonitors;

		int wScr = sm.rc[1].right - sm.rc[1].left; //int y = m_params.i_top; //int h = m_params.i_height - m_params.i_top;

		if (pn.y >= 0 && pn.y < m_params.i_height)
		{
			if (pn.x < wScr - m_size_bitmap[EBMB_BUT_CLOSE].x)
			{
				ViewList(EBMVLM_POINT_IN, 0, &pn);
			}
			else
			{
				BM_Close();
			}
		}
	}

	if (m_active == EBMN_REPORT)
	{
		m_rep.WM__LBUTTONDOWN(pn);
	}else
	if (m_active == EBMN_MAP)
	{
		m_map.WM__LBUTTONDOWN(pn, hwnd);
	}

	PointInOp();
	Paint(); //if (i_mode == 0){}
}

void CBookMarks::WM__LBUTTONUP(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	POINT pn = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };

	if (m_active == EBMN_MAP)
	{
		m_map.WM__LBUTTONUP(pn, hwnd);
	}

	Paint();
}

void CBookMarks::WM__RBUTTONDOWN(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	POINT pn = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };

	if (m_active == EBMN_MNEMOSCHEME)
	{
		m_MnemoScheme.WM__RBUTTONDOWN(pn);
	}
	else
	if (m_active == EBMN_MAP)
	{
		m_map.WM__RBUTTONDOWN(pn);
	}
}

void CBookMarks::WM__MOUSEMOVE(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	POINT pn = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };

	if (m_active == EBMN_MAP)
	{
		m_map.WM__MOUSEMOVE(pn, wParam);
	}
}                                                   

void CBookMarks::WM__COMMAND(WPARAM wParam, LPARAM lParam)
{                                         //DWORD idThread =GetCurrentThreadId();
	int notify= HIWORD(wParam);
	int id = LOWORD(wParam);
	HWND hwndChild = (HWND)lParam;

	gBookMarks.OnCmd(id, notify);
}                                    //void WM__TIMER(WPARAM wParam, LPARAM lParam){gBookMarks.TimerOp();}


void CBookMarks::OnCmd(int id, int notify)
{
	if (m_active==EBMN_CHAT)
	{
		m_chat.OnCmd(id, notify);
	}else
	if (m_active==EBMN_REPORT)
	{
		m_rep.OnCmd(id, notify);
	}else
	if (m_active==EBMN_MNEMOSCHEME)
	{
		m_MnemoScheme.OnCmd(id, notify);
	}else
	if (m_active == EBMN_MAP)
	{
		m_map.OnCmd(id, notify);
	}else
	if (m_active == EBMN_ADMIN)
	{
		m_admin.OnCmd(id, notify);
	}
}

void CBookMarks::WM__NOTIFY(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	if (m_active == EBMN_MAP)
	{
		m_map.WM__NOTIFY(wParam, lParam);
	}
}

void CBookMarks::WM__DRAWITEM(WPARAM wParam, LPARAM lParam)
{
	//ctrl.styleAdd = SS_OWNERDRAW;  
	if (m_active == EBMN_MAP)
	{
		m_map.WM__DRAWITEM(wParam, lParam);
	}
}

void CBookMarks::WM__MOUSEWHEEL(WPARAM wParam, LPARAM lParam)
{
	if (m_active == EBMN_MAP)
	{
		m_map.WM__MOUSEWHEEL(wParam, lParam);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK CBookMarks_WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	return gBookMarks.OnWndProc(hwnd, uMsg, wParam, lParam);
}

void CBookMarks::WM__SETFOCUS(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	HWND hwndBM = wnd.GetHWND();
	
	POINT pn_out;

	bool fGet = win_e::GetMouseClientCoord(hwndBM, pn_out);

 m_hwndChildFocused = ChildWindowFromPoint(hwndBM, pn_out); //if (m_active == EBMN_MAP){}
}

int CBookMarks::OnWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
 case WM_CLOSE: WM__CLOSE(hwnd, wParam, lParam); break;
	//case WM_LBUTTONDOWN: WM__LBUTTONDOWN(hwnd, wParam, lParam); break;	
	case WM_RBUTTONDOWN: WM__RBUTTONDOWN(hwnd, wParam, lParam); break;
	//case WM_LBUTTONUP: WM__LBUTTONUP(hwnd, wParam, lParam); break;
	case WM_MOUSEMOVE: WM__MOUSEMOVE(hwnd, wParam, lParam); break; //case WM_PAINT: WM__PAINT(hwnd, wParam, lParam); break;	
	case WM_COMMAND: WM__COMMAND(wParam, lParam); break; //case WM_TIMER: WM__TIMER(wParam, lParam); break;
	case WM_NOTIFY: 	WM__NOTIFY(hwnd, wParam, lParam); break; //case WM_TIMER: WM__TIMER(wParam, lParam); break;
	case WM_SETFOCUS: 	WM__SETFOCUS(hwnd, wParam, lParam); break; //case WM_TIMER: WM__TIMER(wParam, lParam); break;
	case WM_DRAWITEM: 	WM__DRAWITEM(wParam, lParam); break; //case WM_TIMER: WM__TIMER(wParam, lParam); break;	
	case WM_MOUSEWHEEL: 	WM__MOUSEWHEEL(wParam, lParam); break; //case WM_TIMER: WM__TIMER(wParam, lParam); break;			
	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 1;
}

void CBookMarks::GetRect(RECT& rc, int dh, int i_mode)
{
		win_e::SMonitors& sm = gMonitors;

		int index_scr = sm.i_monitor >= 0 ? sm.i_monitor : 1;

		rc= sm.rc[index_scr];

		RECT adjust = {-7, -6, 8, 9}; //{-6, 0, 5, 9}

		if (i_mode==0) 
		{						
			rc.bottom += -dh;
		}else
		if (i_mode==1) 
		{
			rc.bottom = rc.top + dh;
		}
		rc.left += adjust.left;			
		rc.top += adjust.top;
		rc.right += adjust.right;
		rc.bottom += +adjust.bottom;
}

//void CALLBACK CBookMarks_TimerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime) { gBookMarks.TimerOp(); }
DWORD WINAPI CBookMarks_Timer(LPVOID lpParameter)
{
	while (1)
	{
  gBookMarks.TimerOp();

		Sleep(300);
	}
	return 1;
}

void CBookMarks::SelApply()
{
	int index_stop;

	bool fDrawWndSElStop = gDrawWnd.GetIndexSelStop(index_stop);

	if (fDrawWndSElStop == false) { return; }

	if (m_active == EBMN_REPORT)
	{
		m_rep.SelCombo("combo_rep_stop", index_stop + 1); 

		m_rep.Update();

	}else
	if (m_active == EBMN_MAP)
	{
		m_map.OnSelStopOnMap(index_stop);
	}

}

void CBookMarks::ClickOnMap(Leaflet::LatLng& latlng)
{
	if (m_active == EBMN_CHAT)
	{
		m_chat.SetEditMes(latlng);
	}
}

void CBookMarks::TimerOp()
{
	//CheckKeysLangInput();

	time_t time = clock();

	static time_e::CTimeOut cTimeOut_5000(5000);
	static time_e::CTimeOut cTimeOut_1200(1200);

	if (cTimeOut_5000.IsOver(time))
	{	
		if (m_active == EBMN_REPORT)
		{
			m_rep.Update();
		}else
		if (m_active == EBMN_MAP)
		{
		}

		m_chat.TimerOp(m_active == EBMN_CHAT);
	}	

	if (cTimeOut_1200.IsOver(time))
	{
		if (m_active == EBMN_MAP)
		{
			m_map.ReadMes();

			m_map.CallPaint();
		}
		
		/*else
		if (m_active == EBMN_MNEMOSCHEME)
		{
			m_MnemoScheme.CallPaint();
		}*/
	}

	if (m_active == EBMN_CHAT || m_active == EBMN_REPORT)
	{
		m_chat.TimerFast();
	}
}

/*void CBookMarks::CheckKeysLangInput()
{
	bool fShift= GetKeyState(VK_SHIFT) & 0x8000;

	if (fShift)
	{
		if (m_eHotKeysLangInput == win_e::EHKLI_ALT_SHIFT)
		{
			bool fAlt = GetKeyState(VK_MENU) & 0x8000;
			if (fAlt)
			{
				Paint();
			}
		}
		else
		if (m_eHotKeysLangInput == win_e::EHKLI_CTRL_SHIFT)
		{
			bool fCtrl = GetKeyState(VK_CONTROL) & 0x8000;
			if (fCtrl)
			{
				Paint();
			}
		}
	}
}*/

void CBookMarks::CrWnd()
{
	RECT rc;
	GetRect(rc, cl_mes_wnd_h);

	SWindowCreateParam wcp;

	wcp.hInstance = g_hInstance;	
	wcp.wndProc = CBookMarks_WindowProc;

	wcp.wsz_name = g_wz_name;
	//wcp.dwStyleEx=WS_EX_TOPMOST;
	wcp.fVisible = true;
	wcp.w = rc.right - rc.left;
	wcp.h = rc.bottom - rc.top;
	wcp.x= rc.left;
	wcp.y= rc.top; 
	wcp.hWndParent =  gWndMain.GetHWND();
	wcp.hbrush = m_hbrushGround;
	lstrcpy(wcp.wzClassName, L"CBookMarks");
	wnd.Create(wcp);
	
	HWND hwndParent = wnd.GetHWND();

	win_e::RemoveWndStyle(hwndParent, WS_CAPTION); // WS_MAXIMIZEBOX | WS_MINIMIZEBOX); //HWND hwnd= CreateWindowA("button", "Probe", WS_CHILD|WS_VISIBLE, 10, 200, 100, 20, hwndParent, (HMENU)1, g_hInstance, 0); //UpdateWindow(hwnd);
	
	InterlockedExchange((long*)&m_active, (long)EBMN_MAP); //m_active = EBMN_CHAT; //EBMN_MNEMOSCHEME;

	RECT rcCleintAbs;
	
	SCWindowAttr sAttr;

	CWindow::GetClientRectAbs(hwndParent, rcCleintAbs, &sAttr);

	m_client_size.x = wcp.w - 2*sAttr.iThick;
	
	m_client_size.y = wcp.h - sAttr.iCaption - 2*sAttr.iThick;

	m_MnemoScheme.Open(g_hInstance, wnd.GetHWND(), m_client_size.x, m_client_size.y); //MnemoSchemeCrControls(g_hInstance, hwndParent); //

	m_chat.Open(g_hInstance, wnd.GetHWND(), m_client_size.x, m_client_size.y, rc); //MnemoSchemeCrControls(g_hInstance, hwndParent); //
	
	m_rep.Open(g_hInstance, wnd.GetHWND(), m_client_size.x, m_client_size.y); //MnemoSchemeCrControls(g_hInstance, hwndParent); //

	m_map.Open(g_hInstance, wnd.GetHWND(), m_client_size.x, m_client_size.y); //MnemoSchemeCrControls(g_hInstance, hwndParent); //

	m_admin.Open(g_hInstance, wnd.GetHWND(), m_client_size.x, m_client_size.y, rc); //MnemoSchemeCrControls(g_hInstance, hwndParent); //

	PointInOp();

	UpdateWindow(hwndParent);
	
	EventChActive();

}

void CBookMarks::CrTimer()
{                                                             //BOOL f_res = SetTimer(wnd.GetHWND(), ci_book_mark_id_timer, ci_book_mark_timer_5_sec, 0); //CBookMarks_TimerProc //if (f_res==FALSE) { gMesWnd.Mes("CBookMarks. ������ �������� �������"); }
	HANDLE h = CreateThread(0, 0, CBookMarks_Timer, 0, 0, 0 );
}

/*void CBookMarks::fill_list()
{
	SBookMark o;
 
	for (int i=0; i<(int)EBMN_QUANTITY; i++)
	{
		o.name=csz_bookmark_name[i]; list.push_back(o);	
	}
}*/

void CBookMarks::DrawBackground(HDC hdc)
{
	SelectObject(hdc, m_hbrushGround);

	SelectObject(hdc, m_hpenGround);

	Rectangle(hdc, 0, m_params.i_height, m_client_size.x, m_client_size.y); //ground only
}

void CBookMarks::Paint(EPaintMode eMode)
{
	//if (m_fDraw==false) { return; }

	HWND hwnd=wnd.GetHWND();

	if (!hwnd) {return;}

	HDC hdc=GetDC(hwnd);

	CrFonts(hdc);

	ViewList(EBMVLM_DRAW, hdc); //Rectangle(hdc, 10, 10,  100,  100); //m_bitmapCtrls.Draw(hdc);

	if (m_fNeedDrawBkGr)
	{
		m_fNeedDrawBkGr = false;

		DrawBackground(hdc);
	}

	if (eMode == EPM_CLEAR_BACK_GROUND)
	{
		DrawBackground(hdc);
	}
	else
	{
		if (m_active == EBMN_MNEMOSCHEME) { m_MnemoScheme.Paint(hdc); } else
		if (m_active == EBMN_CHAT) { m_chat.Paint(hdc); } else
		if (m_active == EBMN_REPORT) { m_rep.Paint(hdc); } else
		if (m_active == EBMN_MAP) { m_map.Paint(hdc); } else
		if (m_active == EBMN_ADMIN) { m_admin.Paint(hdc); }
		
	}

	//DrawLangInput(hdc);

	ReleaseDC(hwnd,  hdc);
}

/*void CBookMarks::DrawLangInput(HDC hdc)
{
	LANGID prim_lang_id = win_e::GetPrimLangId();
	
	const int ci_lang_max = 3;

	char sz_lang[ci_lang_max + 1];

	if (prim_lang_id == LANG_RUSSIAN)
	{
		set_str(sz_lang, ci_lang_max, "���");
	}else
	if (prim_lang_id == LANG_ENGLISH)
	{
		set_str(sz_lang, ci_lang_max, "ENG");
	}else
	{
		set_str(sz_lang, ci_lang_max, "???");
	}

	SelectObject(hdc, (HBRUSH)GetStockObject(LTGRAY_BRUSH));
	SetBkMode(hdc, OPAQUE);
	TextOutA(hdc, m_client_size.x - 12 * 3, m_client_size.y - 12, sz_lang, ci_lang_max);
}*/

bool CBookMarks::SetActive(EBookMarkName e)
{                           //if (list.size()==0) {return false;}
	m_active = e;

	return true;
}

void CBookMarks::DrawBookMark(HDC hdc, EBookMarkName eName, int x, int y, int w, int h, int ident_x, bool fActive) //SBookMark& bookMark
{
	//HPEN hPenBlack = (HPEN)GetStockObject(BLACK_PEN); //HPEN hPenWhite= (HPEN)GetStockObject(WHITE_PEN);

	if (m_fBackGroundImage==false)
	{
		//<ident bar left, right
		SelectObject(hdc, (HPEN)m_gdi_obj[EBMGDIO_PEN_CAPTION]);
		SelectObject(hdc, (HBRUSH)m_gdi_obj[EBMGDIO_BRUSH_CAPTION]);
		Rectangle(hdc, x, y, x + ident_x, y + h);
		Rectangle(hdc, x + w - ident_x, y, x + w, y + h);
		//>
	}

	//<bookmark bar
	SelectObject(hdc, fActive ? m_hpenGround : (HPEN)m_gdi_obj[EBMGDIO_PEN_NON_ACTIVE_BOOKMARK]);
	SelectObject(hdc, fActive ? m_hbrushGround : (HBRUSH)m_gdi_obj[EBMGDIO_BRUSH_NON_ACTIVE_BOOKMARK]);
	Rectangle(hdc, x + ident_x, y, x + w - ident_x, y + h);
	
	//MoveToEx(hdc, x, y + h, 0); LineTo(hdc, x + ident_x, y + h); //left
	//MoveToEx(hdc, x + w - ident_x, y + h, 0); LineTo(hdc, x + w, y + h); //right
	//>
	
	/*
	MoveToEx(hdc, x, y + h,  0); 
	LineTo(hdc, x + ident_x, y + h); //to right
	LineTo(hdc, x + ident_x, y); //up
	LineTo(hdc, x + w - ident_x, y); //to right
	LineTo(hdc, x + w - ident_x, y + h); //down
	LineTo(hdc, x + w, y + h); //to right*/
	
	//<���������
	//SelectObject(hdc, fActive ? m_hpenGround : hPenBlack);
	//MoveToEx(hdc, x + ident_x, y + h,  0); LineTo(hdc, x + w - ident_x, y + h); 
	//>

	TEXTMETRIC tm;

	BOOL f_get_metr = GetTextMetrics(hdc, &tm);
	
	char *p_text= (char*)csz_bookmark_name[(int)eName]; //(char*)bookMark.name.c_str();

	int len_text = strlen(p_text);

	int x_text= x+(w - len_text * tm.tmAveCharWidth)/2;

	int y_text= m_params.i_top + (h-tm.tmHeight)/2;

	SetBkMode(hdc, TRANSPARENT);

	SetTextColor(hdc, fActive ? 0x000000 : 0xFFFFFF);

	TextOutA(hdc, x_text, y_text, p_text, len_text);
}

int CBookMarks::GetCountVisible(int&  q)
{
	q = 0;
	for (int i = 0; i < (int)EBMN_QUANTITY; i++)
	{
		if (m_f_visible[i]) { q++; }
	}
	return q;
}

void CBookMarks::DrawOp(HDC hdc)
{
	int q = 0; // (int)EBMN_QUANTITY;
	GetCountVisible(q);

	win_e::SMonitors& sm = gMonitors;
	int wScr = sm.rc[1].right - sm.rc[1].left;
	int w = wScr / q;
	int ident_x = m_params.i_ident_x;
	int y = m_params.i_top;
	int h = m_params.i_height - m_params.i_top;

	DrawCaption(hdc);

	int k = 0;

	for (int i = 0; i<(int)EBMN_QUANTITY; i++)
	{
		if (m_f_visible[i]==false) { continue; }

		int x = k * w;

		bool fActive = (EBookMarkName)i == m_active;

		DrawBookMark(hdc, (EBookMarkName)i, x, y, w, h, ident_x, fActive);

		k++;
	}
	
}

bool CBookMarks::ViewList(EBookMarksViewListMode eMode, HDC hdc, POINT* p_pn)
{
	int q = 0; 
	GetCountVisible(q);

	if (q==0) {return false;}
	win_e::SMonitors& sm = gMonitors;
	int wScr = sm.rc[1].right - sm.rc[1].left;
	int w=wScr/q;
	int y = m_params.i_top;
	int h = m_params.i_height - m_params.i_top;
	int ident_x = m_params.i_ident_x;	
	bool fFound = false;


	if (eMode == EBMVLM_DRAW)
	{
		HDC hMem = CreateCompatibleDC(hdc);

		HBITMAP memBM = CreateCompatibleBitmap(hdc, wScr, m_params.i_height);

		SelectObject(hMem, memBM);

		DrawOp(hMem);

		BitBlt(hdc, 0, 0, wScr, m_params.i_height, hMem, 0, 0, SRCCOPY);

		DeleteObject(memBM);

		DeleteObject(hMem);		
	}
	else
	if (eMode == EBMVLM_POINT_IN)
	{
		for (int i = 0; fFound == false && i<q; i++)
		{
			int x = i*w;

			if (p_pn == 0) { return false; }

			if (math_e::inRectInt(p_pn->x, p_pn->y, x, y, x + w, y + h))
			{                                                                      //m_fDraw = false;
				InterlockedExchange((long*)&m_active, (long)i); // m_active = (EBookMarkName)i; //Sleep(50);
				
				EventChActive(); //m_fDraw = true;

				Paint(EPM_CLEAR_BACK_GROUND); //if (m_active == EBMN_MAP || m_active == EBMN_MNEMOSCHEME){}

				fFound = true;
			}
		}
	}

	return fFound;
}

void CBookMarks::DrawCaption(HDC hdc)
{                                                    //static bool fStart = false; if (fStart) { return; } fStart = true;
	win_e::SMonitors& sm = gMonitors;
	int wScr = sm.rc[1].right - sm.rc[1].left;

	//1. ground
	SelectObject(hdc, (HPEN)m_gdi_obj[EBMGDIO_PEN_CAPTION]);
	SelectObject(hdc, (HBRUSH)m_gdi_obj[EBMGDIO_BRUSH_CAPTION]);

	if (m_fBackGroundImage)
	{
		POINT pn = {0, 0};
		
		POINT size = { 1919, 94 };
		POINT sizeCtrl = { wScr, m_params.i_height+32 };// i_height 
		bool fStretch = true;

		

		bool fDrawImg = win_e::DrawBitmap(hdc, (HBITMAP)m_gdi_obj[EBMGDIO_BITMAP_BACKGROUND], pn, &size, &sizeCtrl, fStretch);
	}
	else
	{
		Rectangle(hdc, 0, 0, wScr, m_params.i_top);
	}

	int ident_x = m_params.i_ident_x + 7;
	
	POINT pn = { ident_x , (m_params.i_top - m_size_bitmap[EBMB_LOGO].y)/2 };

	bool fDrawLogo = win_e::DrawBitmap(hdc, (HBITMAP)m_gdi_obj[EBMGDIO_LOGO_1_1], pn, &m_size_bitmap[EBMB_LOGO]);

	//<but close
	POINT pnC = { wScr - m_size_bitmap[EBMB_BUT_CLOSE].x, 0};

	bool fDrawClose = win_e::DrawBitmap(hdc, (HBITMAP)m_gdi_obj[EBMGDIO_BUT_CLOSE], pnC, &m_size_bitmap[EBMB_BUT_CLOSE]);
	//>

	SetBkMode(hdc, TRANSPARENT);
	
	int height_char = 18;

	SetTextColor(hdc, 0);//0xFFFFFF

	BOOL fRes = TextOutA(hdc, ident_x + m_size_bitmap[EBMB_LOGO].x + ident_x, (m_params.i_top - height_char) / 2, csz_book_mark_caption_name, strlen(csz_book_mark_caption_name));

}

void CBookMarks::EventChActive()
{
	RECT rc;

	if (m_active != EBMN_CHAT)
	{                            
		m_chat.Close_SIP_client();
	}

	if (m_active == EBMN_CHAT || m_active == EBMN_REPORT)
	{
		GetRect(rc, m_params.i_height + cl_chat_ident_from_top + ci_chat_ctrls_max_y, 1);
		GetChat().ShowProxyWnd(CChat::EPWM_SHOW);
	}
	else
	{
		GetRect(rc, cl_mes_wnd_h);
		GetChat().ShowProxyWnd(CChat::EPWM_HIDE);
	}

	MoveWindow(wnd.GetHWND(), rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, TRUE);

}

void CBookMarks::ShowBook(EBookMarkName eBook, bool  fShow)
{
	if (eBook==EBMN_MNEMOSCHEME) 
	{ 
		m_MnemoScheme.Show(fShow); 
	}else
	if (eBook==EBMN_CHAT) 
	{ 
		m_chat.Show(fShow); 
	}else
	if (eBook==EBMN_REPORT) 
	{ 
		m_rep.Show(fShow); 
	}else
	if (eBook == EBMN_MAP)
	{
		m_map.Show(fShow);
	}else
	if (eBook == EBMN_ADMIN)
	{
		m_admin.Show(fShow);
	}
}

void CBookMarks::PointInOp()
{
	for (int i=0; i<(int)EBMN_QUANTITY; i++)
	{
		EBookMarkName eBook= (EBookMarkName)i;

		if (m_active!=eBook) { ShowBook(eBook, false); }
	}

	ShowBook(m_active, true);
}

/*
void CBookMarks::OnClick(POINT& pt_scr)  //����� ������
{
	RECT rca;

	SCWindowAttr sWinAttr;

	CWindow::GetClientRectAbs(wnd.GetHWND(), rca, &sWinAttr);

	POINT pn = { pt_scr.x - rca.left, pt_scr.y - rca.top }; 

	win_e::SMonitors& sm = gMonitors;

	if (math_e::inRectInt(pt_scr.x, pt_scr.y, sm.rc[1].right - sWinAttr.iCaption, 0, sm.rc[1].right, sWinAttr.iCaption))  ////YUIL 2017-10-19 ������  ��������� WND_CLOSE
	{
		win_e::ShowSysTray(true);

		CWindow::TerminateProcessByHWND(g_hWndMap);

		Sleep(100);
		
		ExitProcess(1);//DestroyWindow(gWndMain.GetHWND());	//gWndMain.GetHWND()
	}
	else
	{
		gBookMarks.ViewList(EBMVLM_POINT_IN, 0, &pn);
	}
}
*/

DWORD WINAPI CBookMarks_thread_proc(LPVOID lpThreadParameter)
{
	gBookMarks.CrWnd(); //gBookMarks.fill_list();	

	MSG msg;
	
	while (GetMessage(&msg, 0, 0, 0)) //gBookMarks.GetHWND()
	{	
		if (msg.message == WM_KEYDOWN)
		{
			gBookMarks.WM__KEYDOWN(msg.hwnd, msg.wParam, msg.lParam);
		}else
		if (msg.message == WM_SYSKEYDOWN)
		{ 
			gBookMarks.WM__SYSKEYDOWN(msg.wParam, msg.lParam); 
		}else			
		if (msg.message == WM_LBUTTONDOWN)
		{
			int i_mode = 0;

			gBookMarks.WM__LBUTTONDOWN(msg.hwnd, msg.wParam, msg.lParam, i_mode);
		}else
		if (msg.message == WM_LBUTTONUP)
		{
			gBookMarks.WM__LBUTTONUP(msg.hwnd, msg.wParam, msg.lParam);
		}
		if (msg.message == WM_CHAR)
		{
			gBookMarks.WM__CHAR(msg.wParam, msg.lParam);
		}					

		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return 1;
}

void CBookMarks::CrThread()
{
	HANDLE h = CreateThread(0, 0, CBookMarks_thread_proc, 0, 0, 0 );
}     

void CBookMarks::LoginSuccess(EUserType eUserTypeNew)
{
	SetUserType(eUserTypeNew);
	
	SetVisible(EBMN_ADMIN, eUserTypeNew== EUT_DISP_HI); //YUIL 2017-01-31

	PointInOp(); //gBookMarks.Chat_CrControls();
	CrTimer();
	MapAfterSet();
	Paint();
}

void CBookMarks::SetVisible(EBookMarkName eName, bool fNew) 
{ 
	m_f_visible[(int)eName] = eName == EBMN_ADMIN && m_f_need_admin == false ? false : fNew;
}

CBookMarks gBookMarks; //gBookMarks.Paint(HWND hwnd)