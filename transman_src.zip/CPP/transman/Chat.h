#ifndef _chat_h_
#define _chat_h_

#pragma once

#include <windows.h>
#include "..\\util\\winctrl.h"
#include "MSSQL.h"
#include "login_wnd.h"
#include "ms_inet.h"
#include "win_e.h"

const int ci_chat_ctrls_max_y=150;
const int ci_chat_ctrls_group=4;
const int cl_chat_ident_from_top=5;
extern const char *csz_chat_file_view_mes;


typedef enum
{
	ECMT_UNKNOWN = 0,
	ECMT_TEXT,
	ECMT_IMG,
	ECMT_VIDEO,
	ECMT_REQUEST_COORD,
	ECMT_GO_COORD,
	ECMT_AUDIO,
	//
	ECMT_QUANTITY_MES_TYPE,
}EChatMesType;

extern const char* csz_chat_mes_type[ECMT_QUANTITY_MES_TYPE];


typedef enum
{
	ECGDIO_PEN_DEVIDER=0,
	ECGDIO_PEN_WHITE,
	ECGDIO_BRUSH_WHITE,
	//
	ECGDIO_QUANTITY,
}EChatGDIObject;

typedef enum
{
	ECMT_ROAD_CONDITION=0,
	ECMT_FASTER,
	ECMT_LOWER,
	//
	ECMT_QUANTITY,
}EChatMessageTemplate;

struct SCoUserMes
{
	std_string mes;
	bool f_show;
};

struct SCoUser
{
	std_string name;
	std::vector<SCoUserMes> mes_list;	
};

/*typedef enum
{
	ECUC_DISP_HI=0,
	ECUC_DISP,
	//
	ECUC_QUANTITY,
}EChatUserCtrls;*/

struct SCharMes
{
	std_string dt_create;
	std_string user_from;
	std_string user_to;
	EChatMesType eType;
	std_string mes;
	int id_chat_mes_head;
};


typedef enum
{
	ESMM_ONE = 0,
	ESMM_ALL_IN_GROUP,
	ESMM_ALL,
}ESendMesMode;

class CChat
{
public:
	typedef enum
	{
		EPWM_HIDE = 0,
		EPWM_SHOW,
		EPWM_SHOW_WAIT_INDICATOR,
	}EProxyWndMode;

private:
	bool m_fInit;
	POINT m_wnd_size;
	CWinCtrl m_ctrls;
	HGDIOBJ m_gdi_obj[ECGDIO_QUANTITY];
	std::vector<SCoUser> m_co_user_list; //HWND m_hwndParent;
	EUserType m_eUserType; 	//int m_index_start_disp;
	std_string m_sz_id_user; //int m_list_x_ctrls[ci_chat_ctrls_group];
	std_string m_sz_combo;
	std::vector<SCharMes> m_mes_list;   //BrowserPtr m_p_browser;
	HWND m_hwndBrowser;
	
	//HWND m_hwndProxy;
	CWindow m_proxy_wnd;
	EProxyWndMode m_proxyWndMode;

	int m_i_sizeMesPack; //int m_index_start_common;
	bool m_f_refresh;
	HWND m_hwndParent;
	RECT m_rcParent;
	win_e::SWaitIndicator m_waitIndicator;
	time_t m_waitIndicator_time_prev;

	void PaintDevider(HDC hdc, int x, int h_fix=0);
	void cr_m_gdi_obj();
	void del_m_gdi_obj();
	
	void CrControls_disp_hi();
	void CrControls_disp();
	void CrControls_disp_hi_new_disp();
	void CrControls_disp_hi_new_coll();
	void CrControls_disp_hi_bind();
	void CrControls_disp_hi_show();
	void CrNewDisp();
	void CrNewColl();
	void fill_combo_new_coll_disp();
	void fill_combo_bind_coll();
	bool get_id_user(char *sz_val, std_string* p_id_user=0);
	void Bind();
	bool get_id_user_by_combo(char *sz_combo, std_string& sz_user_id);
	void fill_combo_show_coll();
	
	static int Get_x_step_gr(int q_gr);
	
	void CrViewMesInHTML();
	bool CrFileViewMes();
	
	void GetMes(SCharMes& o, std_string& sz_mes);
	void SetChatBrowserWndPosSize(HWND hwnd);
	void fill_combo_disp_coll();
	void fill_combo_coll_by_id_disp(char* sz_combo_coll, std_string& id_disp);
	void fill_combo_disp_templ_mes();
	void set_edit_disp_mes_by_combo(char *sz_combo);

	void ChSizeMesPack(bool fInc=false); 
	void CrControls_common();
	void set_but_refresh(bool fCheck);
	
	void refresh_op();
	void set_check_box(char  *sz_checkbox, bool fCheck);
	bool get_check_box(char  *sz_checkbox);
	bool ShowMes_op(std_string& id_disp); //, char* sz_id_coll);
	void PaintProxyWnd(HDC hdc);

	typedef  enum
	{
		EBSIPC_CLICK=0,
	}E_but_SIP_client;

	void but_SIP_client(E_but_SIP_client e= EBSIPC_CLICK);
	void Show_SIP_client(bool fShow);
	void Close_SIP_client_op(); //void NotifyOnReadedMes(SCharMes& o);
	void MesErrSIP_Name();
	public:
	CChat();
	~CChat();
	bool Open(HINSTANCE hInstance, HWND hwndParent, int w, int h, RECT& rcParent);
	void Close();
	void CrControls(HINSTANCE hInstance, HWND hwndParent); //void CrControlsR(HINSTANCE hInstance, HWND hwndParent);
	void Show(bool fShow);
	void OnCmd(int id, int notify); //void Paint(HDC hdc);
	void Paint(HDC hdc);
	void SetUserType(EUserType eNew) { m_eUserType=eNew; }
	void fill_combo_new_coll_disp_add(FldsPtr fp);
	void fill_combo_bind_coll_add(FldsPtr fp);
	void CrNewColl_add(FldsPtr fp);
	void get_id_user_add(FldsPtr fp);
	void fill_combo_show_coll_add(FldsPtr fp);
	void ShowMes_add(FldsPtr fp);
	void fill_combo_coll_by_id_disp_add(FldsPtr fp);
	void StartFill();
	void ShowMes(char* sz_id_disp=0, bool fActive=true); //, char* sz_id_coll=0);
	void TimerOp(bool fActive);
	void Tab();
	void CrBrowserWnd(char* sz_file_html, char* sz_file_html_only);
	static void Ctrls_set_origin(CWinCtrl& ctrls, int index_gr, int q_gr);
	void CloseDestroyBrowserWnd();
	HWND GetBrowserHWND() { return m_hwndBrowser; }
	void CrProxyWnd();
	void GetNeedPosSize(POINT& pos, POINT& size);

	void ShowProxyWnd(EProxyWndMode eMode);
	void set_refresh(bool f);
	void BrowserRefresh();
	void OpenViewMesInHTML(char* sz_file_html=0, char* sz_file_html_only=0);
	void CallPaintProxyWnd();
	void TimerFast();
	void Close_SIP_client();
	
	CWinCtrl& GetCtrls() { return (CWinCtrl&)m_ctrls; }
	void SetEditMes(Leaflet::LatLng& latlng);

	void but_send_new_mes(char *id_chat_mes_type, ESendMesMode eMode = ESMM_ONE, char* sz_user_to = 0, char* sz_message = 0);
	void CallPhone(char *sip_name);
};


void CChat_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState);

#endif