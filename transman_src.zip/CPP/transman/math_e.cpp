#include <memory.h>
#include <minmax.h>
#include <stdio.h>
#include "math_e.h"

namespace math_e
{
	double dist2D(double x1, double y1, double x2, double y2)
	{
		double dx = x1 - x2;

		double dy = y1 - y2;

		return sqrt(dx * dx + dy * dy);
	}

	bool inRectInt(int x, int y, int x_min, int y_min, int x_max, int y_max)
	{
		return x >= x_min && x < x_max && y >= y_min && y < y_max;
	}

	void LatitudeLongitudeToXY(double lat, double lng, double& x, double& y) //YUIL x, y  in meter's
	{
		const double R = 6378137; //YUIL � ������ ������  �����

		const double MAX_LATITUDE = 85.0511287798;

		double d = M_PI / 180;

		double dMax = MAX_LATITUDE;

		double t_lat = max(min(dMax, lat), -dMax);

		double dSin = sin(t_lat * d);

		x = R * lng * d;

		y = R * log((1 + dSin) / (1 - dSin)) / 2;

	}

	void LatitudeLongitudeToXY_s(char *sz_latitude, char* sz_longitude, double& x, double& y) //YUIL x, y  in meter's
	{
		double lat = atof(sz_latitude);
		
		double lng = atof(sz_longitude);

		LatitudeLongitudeToXY(lat, lng, x, y);

	}

	void LatitudeLongitudeToScreenPoint(double lat, double lng, double zoom, int& xScr, int& yScr, double* p_xPrj, double* p_yPrj)
	{
		const double R = 6378137; //YUIL � ������ ������  �����

		const double MAX_LATITUDE = 85.0511287798;

		double d = M_PI / 180;

		double dMax = MAX_LATITUDE;

		double t_lat = max(min(dMax, lat), -dMax);

		double dSin = sin(t_lat * d);

		double xPrj = R * lng * d;

		double yPrj = R * log((1 + dSin) / (1 - dSin)) / 2;

		double dScale = 256 * pow(2, zoom);

		double t_scale = 0.5 / (M_PI * R);

		double _a = t_scale;

		double _b = 0.5;

		double _c = -t_scale;

		double _d = 0.5;

		if (dScale == 0) { dScale = 1; }   //scale = scale || 1;

		double xNew = dScale * (_a * xPrj + _b);

		double yNew = dScale * (_c * yPrj + _d);

		xScr = xNew;
		
		yScr = yNew;
		/////////////////////////////////////
		if (p_xPrj) { *p_xPrj = xPrj; }
		
		if (p_yPrj) { *p_yPrj = yPrj; }
	}

	void ScreenPointToLatitudeLongitude(int xScr, int yScr, double zoom, double& lat, double& lng)
	{                                        //pointToLatLng: function (point, zoom) 
		const double R = 6378137;

		double dScale = 256 * pow(2, zoom);  //untransformedPoint = this.transformation.untransform(point, scale); //untransform: function (point, scale) {

		if (dScale == 0) { dScale = 1; }     //scale = scale || 1;

		double t_scale = 0.5 / (M_PI * R);

		double _a = t_scale;

		double _b = 0.5;

		double _c = - t_scale;

		double _d = 0.5;

		double xUntr = (xScr / dScale - _b) / _a;

		double yUntr = (yScr / dScale - _d) / _c;   //unproject: function (point) {

		double d = 180 / M_PI;

		lat = (2 * atan( exp(yUntr / R) ) - (M_PI / 2)) * d;

		lng = xUntr * d / R;	                         //return this.projection.unproject(untransformedPoint);

	}


	void XYToLatitudeLongitude(double x, double y, double& lat, double& lng)
	{                            
		const double R = 6378137;

		double d = 180 / M_PI;

		lat = (2 * atan(exp(y / R)) - (M_PI / 2)) * d;

		lng = x * d / R;	     
	}

	bool CrossLines(
		  double xa0, double ya0
		, double xa1, double ya1
		, double xb0, double yb0
		, double xb1, double yb1
		, double& xc, double& yc
	)
	{
		const double cd_small = 0.0001;

		double Dxa = xa1 - xa0;
		double Dya = ya1 - ya0;

		double Dxb = xb1 - xb0;
		double Dyb = yb1 - yb0;

		double d = Dya * Dxb - Dyb * Dxa;

		if (fabs(d) <= cd_small) { return false; }
		
		xc = ((Dxb*yb1 - Dxb*ya1 - Dyb*xb1)*Dxa + Dya*Dxb*xa1) / d;

		if (fabs(Dxa) > cd_small)
		{
			yc = ya1 - Dya*(xa1 - xc) / Dxa;
		}
		else
		{
			if (fabs(Dxb) > cd_small)
			{
				yc = yb1 - Dyb*(xb1 - xc) / Dxb;
			}
			else
			{ return false; }
		}		

		return true;
	}

	void ScreenPointToXY(int xScr, int yScr, double zoom, double& x, double& y)
	{                                        //pointToLatLng: function (point, zoom) 
		const double R = 6378137;

		double dScale = 256 * pow(2, zoom);  //untransformedPoint = this.transformation.untransform(point, scale); //untransform: function (point, scale) {

		if (dScale == 0) { dScale = 1; }     //scale = scale || 1;

		double t_scale = 0.5 / (M_PI * R);

		double _a = t_scale;

		double _b = 0.5;

		double _c = - t_scale;

		double _d = 0.5;

		x= (xScr / dScale - _b) / _a;

		y= (yScr / dScale - _d) / _c;   //unproject: function (point) {
	}


	bool InPoly(SPoint<double>& pn, SPoint<double>* pPoly, int qPoly)
	{
		bool fIn = false;

		double x =pn.x;
		double y =pn.y;

		//1. ��������� �� ������� ���������
		for (int i=0; i<qPoly; i++)
		{
			if (pn==pPoly[i]) {return true;}
		}

		SPoint<double> min, max;

		//2. �������� ����������� ����������� �� ��������. ������� ������.
		int q_cross=0;
		for (int i=0; i<qPoly; i++)
		{
		 int i_next= i==qPoly-1 ? 0 : i+1;
			
			double x_0=pPoly[i].x;
			double y_0=pPoly[i].y;

			double x_1=pPoly[i_next].x;
			double y_1=pPoly[i_next].y;

			SPoint<double> pn_cross;
			pn_cross.x = x_0 == x_1 ? x_0 : LineFunc(y, y_0, x_0, y_1, x_1); //����� �����������
			pn_cross.y= y;

			if (pn_cross.In(pPoly[i], pPoly[i_next])) 
			{
				if (q_cross==0) { min.x =pn_cross.x; max.x =pn_cross.x; }
				else
				{
					if (pn_cross.x < min.x) {min.x = pn_cross.x;}
					if (pn_cross.x > max.x) {max.x = pn_cross.x;}
				}
				q_cross++;
			}
		}

		if (q_cross<2) {return false;}

		//3. �������� ����������� ��������� �� ��������. ������� ������.
		q_cross=0;
		double min_y, max_y;
		for (int i=0; i<qPoly; i++)
		{
		 int i_next= i==qPoly-1 ? 0 : i+1;
			
			double x_0=pPoly[i].x;
			double y_0=pPoly[i].y;

			double x_1=pPoly[i_next].x;
			double y_1=pPoly[i_next].y;

			SPoint<double> pn_cross;
			pn_cross.x = x; //����� �����������
			pn_cross.y = y_0 = y_1 ? y_0 : LineFunc(x, x_0, y_0, x_1, y_1);

			if (pn_cross.In(pPoly[i], pPoly[i_next])) 
			{
				if (q_cross==0) { min.y =pn_cross.y; max.y =pn_cross.y; }
				else
				{
					if (pn_cross.y < min.y) {min.y = pn_cross.y;}
					if (pn_cross.y > max.y) {max.y = pn_cross.y;}
				}

				q_cross++;
			}
		}

		if (q_cross<2) {return false;}

		//4. ��������� ��������� ����� �������������
		return pn.InMinMax(min, max);
	}

	double LineFunc(double x, double x_0, double y_0, double x_1, double y_1) //YUIL 2017-10-24 ���������� y
	{
		if (x_1 == x_0) {return -1;}
	
		return y_0 + (y_1 - y_0) * (x - x_0) / (x_1 - x_0);
	}
}

