#ifndef _ate3_load_h_
#define _ate3_load_h_

const int ci_device_number_len = 16;
#include "std_str.h"
#include <vector>
#include "correct_date_time.h"
#include "std_str.h"

typedef enum  //ATE3 : $����,�����,� �������,������, �������,�����������,��������$
{
	EATE3LF_DATE=0,
	EATE3LF_TIME,
	EATE3LF_DEVICE_NUMBER,
	EATE3LF_LATITUDE,
	EATE3LF_LONGITUDE,
	EATE3LF_AZIMUT,
	EATE3LF_SPEED,
	//
	EATE3LF_QUANTITY,
}EATE3LoadField;

typedef  enum
{
	ESATE3RSE_NONE=0,
	ESATE3RSE_LAT_LNG_OVER,
}ESATE3RowStrErr;

struct SATE3RowStr  //YUIL . $2017-08-24,09:14:48,M166OH,47.273792,39.757253,124,26$
{
	SDate date;

	STime time;

	std_string device_number;

	std_string latitude;

	std_string longitude;

	std_string azimut; //YUIL. ���� �� ����������� �� �����.

	std_string speed; //YUIL . �������� / ���

	int id_agent;

	//calc
	double x, y;

	//fill from other
	std_string route; //from: gATE3, gFileBindCarRoute
	
	ESATE3RowStrErr eErr; //YUIL 2017-09-19 :  0:������, 1:lat_lng_over
	std_string type;

	SATE3RowStr() { Clear(); }

	void Clear();
	void CalcXY();
	void SetRoute(const char *sz_type = "2\0");
};

//void CATE3Load_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState);

class CATE3Load
{
	bool m_fInit; //int m_i_buf_len; //char *m_buf;                                                                    //void ReadOp(EATE3LoadField& eField, char *sz_in, SATE3Row& row);

	bool m_fSaveSQLQuery;

	struct tm m_tm_prev; //std::vector<SATE3RowStr> m_rows;
	
	int m_sleep_after_save;

	void ReadOpStr(EATE3LoadField& eField, char *sz_in, SATE3RowStr& row, int i_max);              //void ReadOpDateTime(EATE3LoadField& eField, char *sz_in, SATE3Row& row, char c_devider); //void ReadOpDateTimeOp(EATE3LoadField& eField, char *sz_in, SATE3Row& row, int& i_step);
	
	bool FindEndRow(char *sz_in, int i_pos, int i_len_in);	//void Save(SATE3RowStr& row); //void Exec(char *sz_query);	//bool FindRow(SATE3RowStr& row, int& index);
	
	void ReadIni();

public:
	CATE3Load(int i_buf_len_new);

	~CATE3Load();

	bool Read(char *sz_in, int i_len_in, int i_max);
	
	bool Test(char *sz_in, int i_len_in);

	void SaveToDB(SATE3RowStr& row, char* sz_id_agent=0); //void Exec(char *sz_query);	

	bool IsInit() { return m_fInit; }	
};


//void cs_CATE3Load_SaveToDB_init(); //void cs_CATE3Load_SaveToDB_del();

#endif