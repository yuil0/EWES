#include <memory.h>
#include "mes_log.h"

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include "..\\transman\\ini_file.h"

CRITICAL_SECTION g_MesLog_cs;

const int ci_time_len = 4 + 1 + 2 + 1 + 2 + 1 + 2 + 1 + 2 + 1 + 2 + 1 + 1;

CMesLog::CMesLog() { memset(this, 0, sizeof(CMesLog)); }

bool CMesLog::Open(char *sz_caption_name, int hwnd, char *sz_log_file)
{
	memset(this, 0, sizeof(CMesLog));	
	
	m_sz_caption_name = sz_caption_name;

	m_sz_log_file = sz_log_file;

	unlink(sz_log_file);

	m_hwnd = hwnd;

	fOpen = true;

	ReadIni();

	InitializeCriticalSection(&g_MesLog_cs);

	return fOpen;
}

void CMesLog::ReadIni()
{
	CIniFile ini; 
	
	char sz_val[MAX_PATH+1];

	if (ini.Get("C:\\transman\\transman.ini", "server_mes", sz_val, MAX_PATH))
	{
		fOpen = atoi(sz_val);
	}
}

void LocalTimeToText(char *sz_text, int i_max)
{
	time_t t = time(0);

	struct tm* tm = localtime(&t);

	int i_len = strlen(sz_text);

	sprintf_s(sz_text + i_len, i_max, "%04d-%02d-%02d_%02d:%02d:%02d: ", tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec); 

}// 4 1 2 1 2 1 2 1 2 1 2 1 1

void CMesLog::Mes(char *szFormat, ...)
{  	
	if (fOpen == false) { return; }

	if (TryEnterCriticalSection(&g_MesLog_cs) == FALSE) { return; } //EnterCriticalSection(&g_MesLog_cs);

	va_list va;
	va_start(va, szFormat); //int len = _vscprintf(szFormat, va);

	static char buf [MAX_PATH + 1];//len + strlen(g_szmapp)+ ci_time_len +2

	memset(buf, 0, MAX_PATH + 1);

	if (m_sz_caption_name.size())
	{ strcpy_s(buf, MAX_PATH, m_sz_caption_name.c_str()); }

	strcat_s(buf, MAX_PATH,  " ");

	LocalTimeToText(buf, MAX_PATH);

	int i_len_buf = strlen(buf);

	if (i_len_buf < MAX_PATH)
	{
		vsprintf(buf + i_len_buf, szFormat, va);  //try{}catch(...) {}
	}	

	SendMessageA((HWND)m_hwnd, WM_SETTEXT, 0, (LPARAM)buf);

	//<l1
	if (fOpen == false) { return; }

	int fa = open(m_sz_log_file.c_str(), O_CREAT | O_WRONLY | O_APPEND | O_BINARY, S_IREAD | S_IWRITE);

	if (fa>=0) 
	{ 
		int iWritten = write(fa, buf, strlen(buf));

		const char * csz_end= "\r\n";

		iWritten = write(fa, csz_end, strlen(csz_end));

		close(fa);
	}
	//>l1

	//Log(buf);

	LeaveCriticalSection(&g_MesLog_cs); 
}

/*////////////////////////////////////////////////////////////////////////////////////
void CMesLog::Log(char* buf)
{
	if (fOpen == false) { return; }

	int fa = open(m_sz_log_file.c_str(), O_CREAT | O_WRONLY | O_APPEND | O_BINARY, S_IREAD | S_IWRITE);

	if (fa < 0) { return; }

	int iWritten = write(fa, buf, strlen(buf));

	char sz_text[MAX_PATH + 1]; 
	
	memset(sz_text, 0, MAX_PATH);

	sprintf_s(sz_text, MAX_PATH, "\r\n");

	iWritten = write(fa, sz_text, strlen(sz_text));

	close(fa);
}*/

void CMesLog::Close()
{
	DeleteCriticalSection(&g_MesLog_cs);
}

CMesLog gMesLog;