#include <memory.h>
#include "FromPicas.h"
#include <corecrt_io.h>

#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <windows.h>
#include <winnls.h>
#include <stdio.h>
#include <time.h>
#include <direct.h>

#include "..\\transman\\ini_file.h"
#include "..\\transman\\math_e.h"
#include "mes_log.h"
#include "correct_date_time.h"

#include "str.h"
#include "file.h"



const int ci_err = -1;

const char *csz_file_query_save = "C:\\transman\\QuerySave.txt";
const int ci_max_q_query = 5000;
const int ci_sleep = 0;
const int ci_picas_load_to_db_progress=200; //YUIL 2017-10-18 

const char *csz_file[EFP_QUANTITY]= 
{ 
	  "routes.txt" 
	, "stops.txt"
	, "shapes.txt"
	, "agency.txt"
	, "calendar.txt"
	, "calendar_dates.txt"
	, "stop_times.txt"
	, "trips.txt"
};

const char *csz_path = "C:\\transman\\from_picas";
const char *csz_find_mask = "C:\\transman\\from_picas\\*.txt";

long gDisableSQL=0; //CRITICAL_SECTION gCS;


void CFromPicas_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesLog.Mes("CFromPicas:: ������ MSSQL : %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
}


CFromPicas::CFromPicas() {}
CFromPicas::~CFromPicas() {}

bool CFromPicas::Init()
{
	m_fInit=false;
	
	memset(this, 0, sizeof(CFromPicas));
	
	m_fInit=true;

	return m_fInit;
}

void CFromPicas::Close()
{
	m_row_list.clear(); //DeleteCriticalSection(&gCS);
}

bool CFromPicas::IsFilesReady(bool *f_file) //IsFilesReady
{
	bool fRes = false;

	int q = (int)EFP_QUANTITY;

	if (m_fLoadIfAllFiles)
	{
		for (int i = 0; i < q; i++)
		{
			if (f_file[i] == false) { return false; }
		}

		fRes = true;
	}
	else
	{
		int iQFound = 0;

		for (int i = 0; i < q; i++)
		{
			if (f_file[i]) { iQFound++; }
		}

		fRes = iQFound != 0;
	}

	return fRes;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool CFromPicas::Load()//(char *sz_name_app, HWND hwnd)
{                                               //std_string sz_query = "";//AddConvertedShortDateToDATETIME(sz_query, "20170426");
	if (m_fInit == false) { return false; }
	
	InterlockedExchange(&gDisableSQL, 1);


	//<ini
	const long cl_max_value = 8;
	char sz_val[cl_max_value + 1];
	CIniFile cIniFile;
	if (cIniFile.Get("C:\\transman\\transman.ini", "srv_from_picas_save_to_db", sz_val, cl_max_value) == false) { return false; }
	
	m_fSaveToDB = atoi(sz_val);

	if (cIniFile.Get("C:\\transman\\transman.ini", "srv_from_picas_load_if_all_files", sz_val, cl_max_value) == false) { return false; }

	m_fLoadIfAllFiles = atoi(sz_val);

	if (cIniFile.Get("C:\\transman\\transman.ini", "srv_from_picas_save_sql_query", sz_val, cl_max_value) == false) { return false; }

	m_fSaveSQLQuery= atoi(sz_val);

	if (cIniFile.Get("C:\\transman\\transman.ini", "test_load_from_picas", sz_val, cl_max_value)) { m_f_test_load_from_picas= atoi(sz_val); }	
	
	//>ini

	_finddata_t fd;

	intptr_t hFile = _findfirst(csz_find_mask, &fd);

	if (hFile == ci_err) { return false; }


	bool f_file[EFP_QUANTITY];

	memset(f_file, 0, EFP_QUANTITY*sizeof(bool));
	
	do
	{
		if (fd.attrib != _A_SUBDIR)
		{
			for (int i = 0; i < (int)EFP_QUANTITY; i++)
			{
				if (!stricmp(fd.name, csz_file[i])) 
				{ f_file[i] = true; } //YUIL �������� ��� ����
			}			
		}
		
	} while (!_findnext(hFile, &fd));
	

	_findclose(hFile); //

	char sz_full[MAX_PATH + 1];

	if (IsFilesReady(f_file) == false) { return false; } //���� ���� ��� ���� � ��
	
	for (int i = 0; i < (int)EFP_QUANTITY; i++)
	{			
		if (f_file[i] == false) { continue; }
		sprintf_s(sz_full, MAX_PATH, "%s\\%s", csz_path, csz_file[i]);

		if (LoadFile(i, sz_full) == false) { return false; }

		CalcSizeFieldsInFile(sz_full);

		if (m_fSaveToDB)
		{
			if (WriteToDB((EFilePicas)i) == false) { return false; }
		}
		
	}
	
	gMesLog.Mes("CFromPicas::�������� �����");
	
	InterlockedExchange(&gDisableSQL, 0);

	return true;
}

/*void CFromPicas::MesWnd(HWND hwnd, char *sz_name_app, char *sz_text)
{
	std_string sz_full= sz_name_app;
	sz_full.append(" ");
	sz_full.append(sz_text);
	SetWindowTextA(hwnd, sz_full.c_str());
}*/

///////////////////////////////////////////////////////////////////////////////////////////////////
bool CFromPicas::LoadFile(int index,  const char *sz_file)
{

	const int ci_len_wrong = 3;

	m_row_list.clear();

	int fi = open(sz_file,  O_RDONLY | O_BINARY);

	if (fi < 0) 
	{ 
		char sz[MAX_PATH + 1];

		sprintf_s(sz, MAX_PATH, "errno : %d",errno);
		
		gMesLog.Mes(sz);

		return false; 
	}

	bool fRes = false;

	int len = filelength(fi);

	if (len)
	{
		char *buf = new char[len + 1];
		if (buf)
		{
			memset(buf, 0, len+1);

			int iReaded = read(fi, buf, len);

			if (iReaded == len)
			{
				//YUIL ������� ������
				int i_shift = 0;

				unsigned char b[ci_len_wrong] = { buf[0], buf[1], buf[2] };

				if (b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF) { i_shift = 3; }

				fRes = LoadFromBuf(index, buf+ i_shift, len+ i_shift);
			}			

			delete buf;
		}
	}

	close(fi);

	return fRes;
}

bool CFromPicas::LoadFromBuf(int index, char *buf, int len)
{
	gMesLog.Mes("CFromPicas::�������� '%s' � ������...", csz_file[index]);

	int iPos = 0;
	
	int i_mes_step = len / 1000;

	for (int i = 0, k=0; i < len; i++, k++)
	{
		if (buf[i] == 10 || buf[i] == 13 || i + 1 == len)
		{
			int iSize = i - iPos;

			int i_shift=0;

			if ((buf[i] != 10 && buf[i] != 13) || i + 1 == len) { iSize++; i_shift = 1;}

			if (iSize)
			{
				char ch_save; ch_save = buf[i+ i_shift]; buf[i + i_shift] = 0;  //if (fEnd == false) {  }

				ReadLineFromBuf(buf + iPos);

				buf[i + i_shift] = ch_save;  //if (fEnd == false) {  }
			}

			iPos = i+1;
			
			if (k>= i_mes_step)
			{
				k = 0;
				gMesLog.Mes("CFromPicas::�������� '%s' � ������ : %.0f %c", csz_file[index], ((float)i*100)/((float)len), '%');
			}
			
		}
	}

	return true;
}


bool CFromPicas::ReadLineFromBuf(char *sz_line)
{
	const int ci_max = 255;
	int iPos = 0;
	
	SRow sRow;
	/*if (m_row_list.size() == 129)
	{
		int t = 0;
		t++;
	}*/

	bool fQuote = false;

	for (int i = 0; sz_line[i]; i++)
	{
		if (sz_line[i] == '"' && sz_line[i + 1] == '"') 
		{ i += 2; }

		if (fQuote == false)
		{
			if (sz_line[i] == '"')
			{ fQuote = true; }
		}
		else
		{
			if (sz_line[i] == '"')
			{ i++;  fQuote = false; }
		}


		if (fQuote == false)
		{
			if (sz_line[i] == ',' || sz_line[i + 1] == 0)
			{
				int iSize = i - iPos;

				bool fEnd = false;

				if (sz_line[i] != ',' && sz_line[i + 1] == 0) { iSize++; fEnd = true; }

				bool fLastEmpty = sz_line[i] == ',' && sz_line[i + 1] == 0;

				if (iSize)
				{
					char ch_save; if (fEnd == false) { ch_save = sz_line[i]; sz_line[i] = 0; }

					char sz_trans[ci_max + 1];

					convert_from_UTF8(sz_line + iPos, sz_trans);

					remove_double_chars(sz_trans, ci_max); 

					//wchar_t wsz_trans[ci_max + 1];

					//memset(wsz_trans,  0, ci_max*sizeof(wchar_t));

					//size_t qRes = mbstowcs(wsz_trans, sz_line + iPos, ci_max);

					//int iWritten =   MultiByteToWideChar(CP_UTF8, MB_PRECOMPOSED, sz_line + iPos, strlen(sz_line + iPos), wsz_trans, ci_max); //CP_UTF8 //CP_ACP //CP_OEMCP

					//int err = 0;

					//if (iWritten==0) { err=GetLastError();}

					//BOOL fTrans = OemToCharA(sz_line + iPos, sz_trans);

					std_string c_str(sz_trans);// sz_line + iPos);

					sRow.m_field_list.push_back(c_str);

					if (fEnd == false) { sz_line[i] = ch_save; }
				}
				else
				{
					std_string c_str("");

					sRow.m_field_list.push_back(c_str);
				}

				if (fLastEmpty)
				{
					std_string c_str("");

					sRow.m_field_list.push_back(c_str);
				}

				iPos = i + 1;
			}
		}
	}

	m_row_list.push_back(sRow);

	return true;
}

void CFromPicas::CalcSizeFieldsInFile(char *sz_file)
{
	//1. ���� �������
	SRow& rowHead = m_row_list[0];

	int q = rowHead.m_field_list.size();
	
	int* a_size = new int[q];

	if (a_size == 0) { return; }

	memset(a_size, 0, q * sizeof(int));

	for (int i = 1; i < m_row_list.size(); i++)
	{
		SRow& row = m_row_list[i];

		int qi = row.m_field_list.size();

		for (int i_field = 0; i_field < q && i_field < qi; i_field++)
		{
			std_string& rstr = row.m_field_list[i_field];

			int i_len = rstr.length();

			if (a_size[i_field] < i_len) { a_size[i_field] = i_len; }		
		}		
	}

	ReportSizeToFile(sz_file, rowHead.m_field_list,  a_size, q);

	delete a_size;

}

void CFromPicas::ReportSizeToFile(char *sz_file, const std::vector<std_string>& name_list,  int *a_size, int q)
{
	const int ci_max = 255;

	char sz_file_rep[ci_max + 1];

	sprintf_s(sz_file_rep, ci_max, "%s.report.txt", sz_file);

	FILE *fo = fopen(sz_file_rep,  "wb");
	if (fo)
	{
		fprintf(fo, "rows : %d%c%c", m_row_list.size() - 1, 13, 10);

		for (int i = 0; i < q; i++)
		{
			std_string name = name_list[i];

			fprintf(fo, ", %s NVARCHAR(%d)%c%c", name.c_str(), 2*a_size[i],13,10); //YUIL 2017-09-06 �������� �� ���, �.�. ������� ����� � Unicode �� ������ ��� �����.
		}

		fclose(fo);
	}
}

SFieldFlags::SFieldFlags() { Clear(); }

void SFieldFlags::Clear() { memset(this, 0, sizeof(SFieldFlags)); }

bool CFromPicas::WriteToDB(EFilePicas eFile)
{
	bool fRes = false;

	std::vector<SFieldFlags> flag_list;

	SFieldFlags ff;

	if (eFile == EFP_ROUTES)
	{
		bool f_dt_created = false;

		ff.Clear(); ff.index_field = 5; ff.f_without_quote = true; flag_list.push_back(ff);

		fRes = WriteToDB_op(eFile, "dbo.picas_routes", "id_picas_route", "route_id , agency_id, route_short_name , route_long_name , route_desc , route_type , route_url , route_color , route_text_color", f_dt_created, &flag_list);
	}
	else
	if (eFile == EFP_STOPS)
	{
		ff.Clear(); ff.index_field = 0; ff.f_without_quote = true; flag_list.push_back(ff);
		ff.Clear(); ff.index_field = 4; ff.f_without_quote = true; ff.eUseAsLatLngForCalcXY = EUALLFCXY_LAT;  flag_list.push_back(ff);
		ff.Clear(); ff.index_field = 5; ff.f_without_quote = true; ff.eUseAsLatLngForCalcXY = EUALLFCXY_LNG;  flag_list.push_back(ff);

		bool f_dt_created = false;

		fRes = WriteToDB_op(eFile, "dbo.picas_stops", "id_picas_stop", "stop_id, stop_code, stop_name, stop_desc, stop_lat, stop_lon, stop_url, location_type, parent_station", f_dt_created, &flag_list);

		FillStops();
	}
	else
	if (eFile == EFP_SHAPES)
	{
		ff.Clear(); ff.index_field = 1; ff.f_without_quote = true; ff.eUseAsLatLngForCalcXY = EUALLFCXY_LAT;  flag_list.push_back(ff);
		ff.Clear(); ff.index_field = 2; ff.f_without_quote = true; ff.eUseAsLatLngForCalcXY = EUALLFCXY_LNG;  flag_list.push_back(ff);
		ff.Clear(); ff.index_field = 3; ff.f_without_quote = true; flag_list.push_back(ff);

		bool f_id_prev = true;

		bool f_dt_created = false;

		fRes = WriteToDB_op(eFile, "dbo.picas_shapes", "id_picas_shape", "shape_id , shape_pt_lat , shape_pt_lon , shape_pt_sequence, shape_dist_traveled", f_dt_created, &flag_list, f_id_prev);

		bool fExec = MSSQL_Exec("EXEC dbo.P_fill_picas_shape_ids", 0, CFromPicas_FN_MSSQL_MES_ERR, this);		
	}
	else
	if (eFile == EFP_AGENTS)
	{
		bool f_dt_created = true;

		fRes = WriteToDB_op(eFile, "dbo.picas_agents", "id_agent", "id, name, url, timezone, lang, phone", f_dt_created, &flag_list);
	}
	else
	if (eFile == EFP_CALENDAR)
	{
		bool f_dt_created = true;

		for (int i = 0; i <= 7; i++)
		{
			ff.Clear(); ff.index_field = i; ff.f_without_quote = true; flag_list.push_back(ff);
		}

		for (int i = 8; i <= 9; i++)
		{
			ff.Clear(); ff.index_field = i; ff.typeConvert = ETC_FROM_SHORT_DATE; flag_list.push_back(ff);
		}

		fRes = WriteToDB_op(eFile, "dbo.picas_calendar", "id_calendar_row", "service_id, monday, tuesday, wednesday, thursday, friday, saturday, sunday, start_date, end_date", f_dt_created, &flag_list);
	}
	else
	if (eFile == EFP_CALENDAR_DATES)
	{
		bool f_dt_created = true;

		ff.Clear(); ff.index_field = 0; ff.f_without_quote = true; flag_list.push_back(ff);
		ff.Clear(); ff.index_field = 1; ff.typeConvert = ETC_FROM_SHORT_DATE; flag_list.push_back(ff);
		ff.Clear(); ff.index_field = 2; ff.f_without_quote = true; flag_list.push_back(ff);

		fRes = WriteToDB_op(eFile, "dbo.picas_calendar_dates", "id_calendar_date", "service_id, date, exception_type", f_dt_created, &flag_list);
	}
	else
	if (eFile == EFP_STOP_TIMES)
	{
		bool f_dt_created = true;

		ff.Clear(); ff.index_field = 0; ff.f_without_quote = true; flag_list.push_back(ff);
		
		ff.Clear(); ff.index_field = 1; ff.typeConvert = ETC_FROM_DATE; flag_list.push_back(ff);
		ff.Clear(); ff.index_field = 2; ff.typeConvert = ETC_FROM_DATE; flag_list.push_back(ff);
		
		ff.Clear(); ff.index_field = 3; ff.f_without_quote = true; flag_list.push_back(ff);
		ff.Clear(); ff.index_field = 4; ff.f_without_quote = true; flag_list.push_back(ff);
		ff.Clear(); ff.index_field = 5; ff.f_without_quote = true; flag_list.push_back(ff);
		ff.Clear(); ff.index_field = 6; ff.f_without_quote = true; flag_list.push_back(ff);

		fRes = WriteToDB_op(eFile, "dbo.picas_stop_times", "id_stop_time", "trip_id, arrival_time, departure_time, stop_id, stop_sequence, pickup_type, drop_off_type", f_dt_created, &flag_list);
	}
	else
	if (eFile == EFP_TRIPS)
	{
		bool f_dt_created = true;

		ff.Clear(); ff.index_field = 1; ff.f_without_quote = true; flag_list.push_back(ff);
		ff.Clear(); ff.index_field = 2; ff.f_without_quote = true; flag_list.push_back(ff);

		fRes = WriteToDB_op(eFile, "dbo.picas_trips", "id_trip", "route_id, service_id, trip_id, trip_headsign, direction_id, block_id, shape_id, wheelchair_accessible", f_dt_created, &flag_list);
	}

	return fRes;
}

void ClearWStr(wchar_t *wsz,  int len)
{
	for (int i = 0; i < len; i++) { wsz[i] = 0; }
}

void AddConvertedShortDateToDATETIME(std_string& sz_query, const char *p_val)
{
	char sz_full[MAX_PATH + 1];

	int m = 0;

	int i = 0;

	int i_len_part;

	i_len_part = 4; memcpy(sz_full + m, p_val + i, i_len_part); m += i_len_part; i += i_len_part;

	i_len_part = 1; memcpy(sz_full + m, "-", i_len_part); m += i_len_part;

	i_len_part = 2;  memcpy(sz_full + m, p_val + i, i_len_part); m += i_len_part; i += i_len_part;

	i_len_part = 1; memcpy(sz_full + m, "-", i_len_part); m += i_len_part;

	i_len_part = 2;  memcpy(sz_full + m, p_val + i, i_len_part); m += i_len_part; i += i_len_part;

	sz_full[m] = 0;

	strcat_s(sz_full, MAX_PATH,  "T00:00:00");

	sz_query.append(sz_full);
}


void AddConvertedDateToDATE(std_string& sz_query, const char *p_val)
{
	char sz_val[MAX_PATH + 1];

	strcpy(sz_val, p_val);

	sz_query.append(CorrectTime(sz_val, MAX_PATH));
}


void CFromPicas::AddRecInQuery(std_string& sz_query, int i, SRow& row, bool f_dt_created, long id_prev, std::vector<SFieldFlags>* p_flag_list, bool f_id_prev, EFilePicas eFile) //EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created)
{
	char sz_val[MAX_PATH + 1];

	sz_query.append(" SELECT ");

	ltoa(i, sz_val, 10); sz_query.append(sz_val); sz_query.append(", ");

	if (f_dt_created) { sz_query.append("GETDATE(), "); } // !

	int q = m_row_list[0].m_field_list.size(); //��� �������
	int qL = row.m_field_list.size();

	if (q!=qL) 
	{ gMesLog.Mes("CFromPicas::AddRecInQuery(). ���������� ����� �� ���������. ���� %s. ������  %d", csz_file[eFile], i); return; }

	bool fFoundLat = false;
	bool fFoundLng = false;
	double  lat, lng;
	
	char szNull[1]={0};

	for (int i_field = 0; i_field < q; i_field++)
	{
		const char *p_val = row.m_field_list[i_field].c_str();  //if (row.m_field_list.size() < q) {return  false; }

		if (i_field) { sz_query.append(", "); }

		SFieldFlags ff;
		ff.f_without_quote = false;
		ff.typeConvert = ETC_NONE;

		FindFieldFlags(i_field, p_flag_list, ff);

		if (!ff.f_without_quote) { sz_query.append("N'"); }

		if (ff.eUseAsLatLngForCalcXY == EUALLFCXY_LAT) 
		{ lat = atof(p_val); fFoundLat= true; }

		if (ff.eUseAsLatLngForCalcXY == EUALLFCXY_LNG) 
		{ lng = atof(p_val); fFoundLng = true; }  //if (ff.eUseAsLatLngForCalcXY == EUALLFCXY_LAT || ff.eUseAsLatLngForCalcXY == EUALLFCXY_LNG) { ff.index_in_row = i_field; fNeedAddFieldXY = true; }

		if (ff.typeConvert == ETC_NONE)
		{
			sz_query.append(p_val);
		}
		else
		if (ff.typeConvert == ETC_FROM_SHORT_DATE)
		{
			AddConvertedShortDateToDATETIME(sz_query, p_val);
		}
		else
		if (ff.typeConvert == ETC_FROM_DATE)
		{
			try
			{
				AddConvertedDateToDATE(sz_query, p_val);
			}
			catch(...)
			{
				gMesLog.Mes("CFromPicas::AddRecInQuery(). Exception AddConvertedDateToDATE().  ���� %s. ������  %d", csz_file[eFile], i);
			}
		}

		if (!ff.f_without_quote) { sz_query.append("'"); }
	}

	if (f_id_prev)
	{
		sprintf_s(sz_val, MAX_PATH, "%d", id_prev);

		sz_query.append(", "); sz_query.append(sz_val);
	}

	if (fFoundLat && fFoundLng)
	{
		double x, y;

		math_e::LatitudeLongitudeToXY(lat, lng, x, y); //YUIL x, y  in meter's

		sprintf_s(sz_val, MAX_PATH, ", %f, %f", x, y);

		row.x = x; //YUIL 2017-09-14

		row.y = y;

		sz_query.append(sz_val);
	}

}

void CFromPicas::AddBeginQueryInQuery(std_string& sz_query, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, bool f_id_prev, std::vector<SFieldFlags>* p_flag_list) //, long id_prev, std::vector<SFieldFlags>* p_flag_list, bool f_id_prev) //EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created)
{
	sz_query = "SET IDENTITY_INSERT "; sz_query.append(sz_table);  sz_query.append(" ON; ");

	sz_query.append("INSERT "); sz_query.append(sz_table); sz_query.append("(");

	sz_query.append(sz_id_field); sz_query.append(", ");

	if (f_dt_created) { sz_query.append("dt_created, "); } // !

	sz_query.append(sz_fields);

	if (f_id_prev)
	{
		sz_query.append(", id_prev");
	}

	if (IsNeedAddFieldXY(p_flag_list))
	{
		sz_query.append(", x, y");
	}

	sz_query.append(")\r\n");
	
}

bool FindInIntVector(const std::vector<int>& id_list, int index)
{
	bool fFound = false;

	for (int i = 0; fFound == false &&  i < id_list.size(); i++)
	{
		int id = id_list[i];

		if (id == index) { fFound = true; }
	}

	return fFound;
}

void CFromPicas::DeleteIdFromDb(int i_start, int i_fin, char *sz_table, char *sz_id_field)
{
	bool fNoRows = true;

	char sz_val[MAX_PATH + 1];

	std_string sz_query = "DELETE FROM "; sz_query.append(sz_table); sz_query.append(" WHERE ");
	sz_query.append(sz_id_field); sz_query.append(">="); itoa(i_start, sz_val, 10); sz_query.append(sz_val);
	sz_query.append(" AND ");
	sz_query.append(sz_id_field); sz_query.append("<="); itoa(i_fin, sz_val, 10); sz_query.append(sz_val);

	char* p_query = (char*)sz_query.c_str();

	bool fExec = MSSQL_Exec(p_query, 0, CFromPicas_FN_MSSQL_MES_ERR, this);
}

void CFromPicas_ExistsMissingIdInDB_ADD(void *p_param, FldsPtr fp) { CFromPicas* p_this = (CFromPicas*)p_param; if (p_this) { p_this->ExistsMissingIdInDB_ADD(fp); } }

void CFromPicas::ExistsMissingIdInDB_ADD(FldsPtr fp)
{
	VARIANT v_id = fp->Item[m_sz_id_field]->Value; //.decVal.Lo32

	int id = (int)v_id.decVal.Lo32;

	m_id_list.push_back(id);
}

bool CFromPicas::ExistsMissingIdInDB(int i_start, int i_fin, EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, bool f_id_prev, std::vector<SFieldFlags>* p_flag_list)
{
	char sz_val[MAX_PATH+1];
	std_string sz_query = "SELECT "; sz_query.append(sz_id_field); sz_query.append(" FROM "); sz_query.append(sz_table); sz_query.append(" WHERE "); 
	sz_query.append(sz_id_field); sz_query.append(">="); itoa(i_start,  sz_val, 10); sz_query.append(sz_val);
	sz_query.append(" AND ");
	sz_query.append(sz_id_field); sz_query.append("<="); itoa(i_fin, sz_val, 10); sz_query.append(sz_val);

	char* p_query = (char*)sz_query.c_str();
	
	m_existsMissingIdInDB = false;
	m_id_list.clear();
	strcpy_s(m_sz_id_field, MAX_PATH, sz_id_field);

	bool fExec = MSSQL_Exec(p_query, CFromPicas_ExistsMissingIdInDB_ADD, CFromPicas_FN_MSSQL_MES_ERR, this); //Sleep(ci_sleep); //struct SPair {int id;int id_prev;};
	
	int q_delta = (i_fin - i_start + 1) - m_id_list.size();

	if (q_delta == 0) { return false; }

	//<q1 ������� ���������
	std::vector<int> id_missing_list;
	
	for (int i = i_start; i<=i_fin; i++)
	{
		if (FindInIntVector(m_id_list, i) == false) { id_missing_list.push_back(i); }
	}

	//>q1

	//<q2 ������� �� ������ �� ������	
	return id_missing_list.size(); // if (id_missing_list.size() < 1) { return; }
	
	//SaveByListId(id_missing_list, eFile, sz_table, sz_id_field, sz_fields, f_dt_created, f_id_prev, p_flag_list, mssql); //for (int i = 0; i < id_missing_list.size(); i++){int id = id_missing_list[i];}
	//>q2
}

bool IsNeedAddFieldXY(std::vector<SFieldFlags>* p_flag_list)
{
	if (p_flag_list == 0) { return false; }

	bool fFoundLat = false;
	bool fFoundLng = false;

	for (int i=0; (fFoundLat == false || fFoundLng == false) && i<p_flag_list->size(); i++)
	{
		SFieldFlags& ff = p_flag_list->operator[](i);

		if (ff.eUseAsLatLngForCalcXY == EUALLFCXY_LAT) 
		{ fFoundLat = true; }
		
		if (ff.eUseAsLatLngForCalcXY == EUALLFCXY_LNG) 
		{ fFoundLng = true; }
	}

	return fFoundLat && fFoundLng;
}

void CFromPicas::SaveByListId(const std::vector<int>& id_missing_list, EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, bool f_id_prev, std::vector<SFieldFlags>* p_flag_list)
{
	if (id_missing_list.size() < 1) { return; }

	std_string sz_query;

	AddBeginQueryInQuery(sz_query, sz_table, sz_id_field, sz_fields, f_dt_created, f_id_prev, p_flag_list);

	int i_start;
	int i_fin;
	int id = 0;

	for (int i = 0; i < id_missing_list.size(); i++) 
	{ 
		int id = id_missing_list[i]; 

		SRow& row = m_row_list[id];

		AddRecInQuery(sz_query, id, row, f_dt_created, id - 1, p_flag_list, f_id_prev, eFile);

		if (i == 0) { i_start = id; }
		else { i_fin = id; }
	}

	int l = 0;

	gMesLog.Mes("���������� ����������� id ��� ������ � MS SQL ������� [%s]. ���������� : %d. �������� %s : >=%d , <=%d. ��������...", sz_table, id_missing_list.size(), sz_id_field, i_start, i_fin);

	bool fCheck = false;

	AddEndQueryInQuery(           eFile,     i_start, i_fin,       sz_table,       sz_id_field,       sz_fields,      f_dt_created,      f_id_prev,                           p_flag_list,                      sz_query,      id - 1,       l, fCheck); 
	
}


void CFromPicas::AddEndQueryInQuery(EFilePicas eFile, int i_start, int& i, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, bool f_id_prev, std::vector<SFieldFlags>* p_flag_list, std_string& sz_query, long id_prev,  int&  l, bool fCheck)
{
	if (sz_query == "") { return; }
	
	sz_query.append("; ");

	sz_query.append("SET IDENTITY_INSERT "); sz_query.append(sz_table);  sz_query.append(" OFF;");

	char *p_query = (char *)sz_query.c_str();

	if (m_fSaveSQLQuery)
	{
		FILE *fo = fopen(csz_file_query_save, "ab");
		if (fo) { fprintf(fo, "%s\r\n", p_query); fclose(fo); }
	}

	if (strlen(sz_table)) //YUIL 2017-10-20 ���� ������ ��� �������
	{
		bool fNoRows = true;

		bool fMissingExists = false; //int i_cycle_count = 0;

		bool fExec = MSSQL_Exec(p_query, 0, CFromPicas_FN_MSSQL_MES_ERR, this);

		fMissingExists= ExistsMissingIdInDB(i_start, i, eFile, sz_table, sz_id_field, sz_fields, f_dt_created, f_id_prev, p_flag_list);

		if (fMissingExists) 
		{ 
			Sleep(100);

			DeleteIdFromDb(i_start, i, sz_table, sz_id_field); 

			Sleep(1000);                 //i_cycle_count++;

			if (m_max_q_query >= 2) 
			{ 
				m_max_q_query /= 2; 

				i = i_start;

				gMesLog.Mes("��������� ������� ������ � MS SQL. ������� ���������� ������� � ����� : %d", m_max_q_query); //gMesLog.Mes("�������� ����  %d ����� �������� ������ � MS SQL. ����� ������ ������.", i_cycle_count);
			}
			else
			{
				gMesLog.Mes("��������� ������� ������ � MS SQL. �������� ���������� ������� � ����� ������: %d. �������� ��=[%d %d]. ������ ����� ?", m_max_q_query, i_start, i);
			}

		} 
	}	

	l = -1;

	sz_query = "";
}

struct SFromPicasCheckExTbl
{
	bool f_exists_table;

	void Add(FldsPtr fp)
	{
		VARIANT v = fp->Item["exists_table"]->Value;

		f_exists_table = v.boolVal==VARIANT_TRUE;
	}
};

void SFromPicasCheckExTbl_FN_MSSQL_ADD(void *p_param, FldsPtr fp)
{
	SFromPicasCheckExTbl * p=(SFromPicasCheckExTbl*)p_param;

	if (p) {p->Add(fp);}
}

bool CFromPicas::WriteToDB_op(EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, std::vector<SFieldFlags>* p_flag_list, bool f_id_prev)
{
	gMesLog.Mes("CFromPicas::�������� '%s' � ���� ������%s...", csz_file[(int)eFile], m_f_test_load_from_picas ? " (����)":""); //SRow& rowHead = m_row_list[0];
	
	m_sz_table=sz_table;

	if (m_f_test_load_from_picas) { m_sz_table.append("_test"); }
		
	std_string sz_text;

	if (m_sz_table.size())
	{
		//<//YUIL 2017-10-20 ������ ��� ���� � ��
		sz_text = "SELECT CONVERT(BIT, CASE WHEN OBJECT_ID('"; sz_text.append(m_sz_table.c_str()); sz_text.append("') IS NOT NULL THEN 1 ELSE 0 END) [exists_table]");

		SFromPicasCheckExTbl s;

		bool f_exec = MSSQL_Exec((char*)sz_text.c_str(), SFromPicasCheckExTbl_FN_MSSQL_ADD, CFromPicas_FN_MSSQL_MES_ERR, &s);

		//<q2 //YUIL 2017-10-20 ����� �� ������ 
		if (s.f_exists_table==false)
		{
			if (m_f_test_load_from_picas==false)
			{
				gMesLog.Mes("������ ��. ��� ������� %s. �������� ��������.", m_sz_table.c_str()); return false;
			}
			else
			{
				gMesLog.Mes("� �� ��� ������� %s. �������� ��������� ��� ��.", m_sz_table.c_str()); 
			}
			
			m_sz_table.clear();
		}
		//>q2
		//>


		//<q1 clear . YUIL 
		sz_text = "TRUNCATE TABLE "; sz_text.append(m_sz_table);	//DELETE FROM

		f_exec = MSSQL_Exec((char*)sz_text.c_str(), 0, CFromPicas_FN_MSSQL_MES_ERR, this);
		//>q1
	}

	int q_row = m_row_list.size();

	int i_step_start = q_row/10;
	
	m_max_q_query = ci_max_q_query; // 785; //YUIL ����  ==0 �� ��� ������. ����� �������  . �����  ��������

	unlink(csz_file_query_save);

	if (WriteToDB_in(m_row_list, eFile, (char*)m_sz_table.c_str(), sz_id_field, sz_fields, f_dt_created, p_flag_list, f_id_prev) == false) { return false; }

	return true;
}

/*void SCrThreadWriteToDBParam::Set(CFromPicas *p_this_new, int index, std::vector<SRow>& row_list, int  i_start, int  q_row_l, EFilePicas eFile, char* sz_table, char* sz_id_field, char*  sz_fields, bool f_dt_created, std::vector<SFieldFlags>& flag_list, bool f_id_prev)
{
	p_this= p_this_new;

	this->index= index;

	for (int i = i_start; row_list.size(); i++) 
	{ 
		this->row_list.push_back(row_list[i]); 

		if (this->row_list.size() >= q_row_l) { break; }
	}

	this->eFile;
	this->sz_table;
	this->sz_id_field;
	this->sz_fields;
	this->f_dt_created;

	for (int i = 0; row_list.size(); i++) { this->flag_list.push_back(flag_list[i]); }
	
	this->f_id_prev= f_id_prev;
}*/
/*void CFromPicas::Copy_row_list(std::vector<SRow>& row_list, int i_start)
{
	for (int i = i_start; ; i++)
	{
		row_list.push_back(m_row_list[i]);

		if (row_list.size() >= m_q_row_l) { break; }
	}
}

void CFromPicas::Copy_flag_list(std::vector<SFieldFlags>& flag_list, std::vector<SFieldFlags>* p_flag_list_src)
{
	for (int i = 0; p_flag_list_src->size(); i++)
	{
		flag_list.push_back(p_flag_list_src->operator[](i));
	}
}


DWORD WINAPI CrThreadWriteToDBThreadProc(LPVOID lpParameter)
{
	EnterCriticalSection(&gCS);

	if (lpParameter == 0) { return 0; }

	SCrThreadWriteToDBParam *p_param= (SCrThreadWriteToDBParam*)lpParameter;  //SCrThreadWriteToDBParam p; memcpy(&p, lpParameter, sizeof(SCrThreadWriteToDBParam));	//std::vector<SRow> row_list;//std::vector<SFieldFlags> flag_list;  //p.p_this->Copy_row_list(row_list, p.i_start); // p.q_row_l); //p.p_this->Copy_flag_list(flag_list, p.p_flag_list);

	CFromPicas *p_this = p_param->p_this;
	
	p_this->WriteToDB_in(p_param->row_list, p_param->eFile, (char*)p_param->sz_table.c_str(), (char*)p_param->sz_id_field.c_str(), (char*)p_param->sz_fields.c_str(), p_param->f_dt_created, &p_param->flag_list, p_param->f_id_prev);

	LeaveCriticalSection(&gCS);

	return 1;
}

void CFromPicas::CrThreadWriteToDB(SCrThreadWriteToDBParam *p_param) //int i_start, int q_row, EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, std::vector<SFieldFlags>* p_flag_list, bool f_id_prev)
{

	DWORD dThreadId;
	HANDLE h = CreateThread(0, 0, CrThreadWriteToDBThreadProc, (LPVOID)p_param, 0, &dThreadId);
}
*/

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool CFromPicas::WriteToDB_in(std::vector<SRow>& row_list, EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, std::vector<SFieldFlags>* p_flag_list, bool f_id_prev)
{	
	std_string sz_query = "";
	
	long id_prev=0;

	int l = 0;

	int q_row = row_list.size();
	
	int i_start;

	for (int i = 1, k=0; i < q_row; i++, k++, l++)
	{
		SRow& row = row_list[i];

		bool  f_end = i + 1 == q_row;
		
		if (f_end == false)
		{
			if (m_max_q_query)
			{
				if (l == m_max_q_query - 1) { f_end = true; }
			}
		}		

		if (l == 0)
		{
			AddBeginQueryInQuery(sz_query, sz_table, sz_id_field, sz_fields, f_dt_created, f_id_prev, p_flag_list);

			i_start = i;
		}

		AddRecInQuery(sz_query, i, row, f_dt_created, i-1, p_flag_list, f_id_prev, eFile);

		if (!f_end) { sz_query.append(" UNION\r\n "); }

		if (f_end)
		{
			AddEndQueryInQuery(eFile, i_start, i, sz_table, sz_id_field, sz_fields, f_dt_created, f_id_prev, p_flag_list, sz_query, id_prev, l);
		}


		if (k == ci_picas_load_to_db_progress)
		{
			k = 0;
			gMesLog.Mes("CFromPicas::�������� '%s' � ���� ������. %d �� %d%s", csz_file[(int)eFile], i, (row_list.size()-1), m_f_test_load_from_picas?" (����)":"");
		}
	}

	return true;
}


void CFromPicas::AddNotSavedIdToFile(EFilePicas eFile, int id)
{
	const int ci_max = 255;

	char sz_file_rep[ci_max + 1];

	sprintf_s(sz_file_rep, ci_max, "%s.id_not_saved.txt", csz_file[(int)eFile]);

	FILE *fo = fopen(sz_file_rep, "ab");

	if (fo) { fprintf(fo, "%d%c%c", id, 13, 10); fclose(fo); }
}

bool CFromPicas::FindFieldFlags(int i_field, std::vector<SFieldFlags>* p_flag_list, SFieldFlags& ff)
{
	if (p_flag_list == 0) { return false; }

	std::vector<SFieldFlags> *p = p_flag_list;

	int i_size = p->size();

	bool fFound = false;

	for (int i = 0; fFound == false && i < i_size; i++) //fFound==false && 
	{
		SFieldFlags& ffL = p->operator[](i);

		if (i_field == ffL.index_field) { fFound = true; ff = ffL; }
	}

	return fFound;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
/*bool CFromPicas::CopyToArch() //YUIL �������� � �����
{
	if (m_fInit == false) { return false; }

	//YUIL ������� ����� �� ������� �������
	time_t t_cur = time(0); //���������� ����� � ���� ����� ������, �������� ����� �������� 1 ������ 1970 �., ��� �������� "-1" � ������ ������.

	if (t_cur == -1) { return false; }

	struct tm* p_tm= localtime(&t_cur);

	//if (m_time_last_arch.tm_year == p_tm->tm_year && m_time_last_arch.tm_mon == p_tm->tm_mon && m_time_last_arch.tm_mday == p_tm->tm_mday) { return true; } //YUIL ��� ���� �������

	char sz_time[ci_max + 1];
	
	sprintf_s(sz_time, ci_max, "%04d_%02d_%02d__%02d_%02d_%02d", p_tm->tm_year+ 1900, p_tm->tm_mon+1, p_tm->tm_mday, p_tm->tm_hour, p_tm->tm_min, p_tm->tm_sec);

	char sz_dir[ci_max + 1];

	sprintf_s(sz_dir, ci_max, "%s\\arch\\%s", csz_path, sz_time);
		
	int i_crDir = _mkdir(sz_dir);

	if (i_crDir == -1) { return false; }

	//YUIL ��������
	char sz_full_prev[ci_max + 1];
	char sz_full_new[ci_max + 1];

	for (int i = 0; i < (int)EFP_QUANTITY; i++)
	{
		sprintf_s(sz_full_prev, ci_max, "%s\\%s", csz_path, csz_file[i]);

		sprintf_s(sz_full_new, ci_max, "%s\\%s", sz_dir, csz_file[i]);

		BOOL bFailIfExists = FALSE;

		BOOL fCopy = CopyFileA(sz_full_prev, sz_full_new, bFailIfExists);

		if (fCopy) { unlink(sz_full_prev); }
	}

	memcpy(&m_time_last_arch , p_tm, sizeof(struct tm));

	return true;
}*/

DWORD WINAPI FromPicasThreadProc(LPVOID lpParameter)
{
	CFromPicas *p_this = (CFromPicas*)lpParameter;

	if (p_this == 0) { return 0; }

	while (1)
	{
		if (p_this->Load()) 
		{ 
			CopyToArch((char*)csz_path, (char**)csz_file, (int)EFP_QUANTITY); //YUIL �������� � �����

			//p_this->CopyToArch(); 
		}

		Sleep(100);
	}

	return 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool CFromPicas::Open()
{
	if (Init() == false) { return false; }   //InitializeCriticalSection(&gCS);

	LoadStopsFromDB();

	DWORD dThreadId;
	HANDLE h = CreateThread(0, 0, FromPicasThreadProc, (LPVOID)this, 0, &dThreadId);
	return h != 0;
}

bool CFromPicas::FillStops()
{
	m_stops.clear();

	SPicasStop sStop;

	for (int i = 1; i < m_row_list.size(); i++)
	{ //stop_id, stop_code, stop_name, stop_desc, stop_lat, stop_lon, stop_url, location_type, parent_station	  

		SRow& rL = m_row_list[i];

		sStop.stop_id=rL.m_field_list[EFPSF_STOP_ID];

		sStop.stop_name= rL.m_field_list[EFPSF_STOP_NAME];

		sStop.x = rL.x;
		
		sStop.y = rL.y;
	}

	return true;
}

void CFromPicas_FN_MSSQL_ADD(void *p_param, FldsPtr fp)
{
	CFromPicas* p_this = (CFromPicas*)p_param;

	if (p_this == 0) { return; }

	_bstr_t bstr_stop_id(fp->Item["stop_id"]->Value);
	
	_bstr_t bstr_stop_name(fp->Item["stop_name"]->Value);

	VARIANT v_x = fp->Item["x"]->Value;
	
	VARIANT v_y = fp->Item["y"]->Value;

	SPicasStop o;

	o.stop_id = (char*)bstr_stop_id;

	o.stop_name = (char*)bstr_stop_name;

	o.x = v_x.dblVal;

	o.y = v_y.dblVal;

	p_this->AddStop(o);
}

void CFromPicas_LoadStopsFromDB_con_str(void *p_param, char* sz_con)
{
	gMesLog.Mes("������ ����������� � �� : %s", sz_con);
}

bool CFromPicas::LoadStopsFromDB()
{
	gMesLog.Mes("CFromPicas::LoadStopsFromDB(). start");

	bool f_query_in_err = false;
	
	FN_MSSQL_END fn_end = 0;

	bool f_load= MSSQL_Exec("SELECT stop_id, stop_name, x, y FROM dbo.picas_stops", CFromPicas_FN_MSSQL_ADD, CFromPicas_FN_MSSQL_MES_ERR, this, "ms_con", 0, f_query_in_err, fn_end, CFromPicas_LoadStopsFromDB_con_str);

	gMesLog.Mes("CFromPicas::LoadStopsFromDB(). fin: %d", f_load);

	return f_load;
}

bool CFromPicas::AddStop(SPicasStop& row)
{
	m_stops.push_back(row);

	return true;
}

CFromPicas gFromPicas;