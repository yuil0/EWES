#ifndef _zones_h_
#define _zones_h_

#include <string>
#include <vector>
#include "..\\transman\\mssql.h"
#include "std_str.h"

struct SZone
{
	std_string id_zone;
	long quantity;
	double x_0, y_0, x_1, y_1, x_2, y_2, x_3, y_3;
};

class CZones
{
	bool m_fInit;
	std::vector<SZone> m_list;
	bool CrThread();
	public:
	CZones();
	~CZones();

	bool Open();
	void Close();
	void ReadFromDB();
	void Add(FldsPtr fp);
	bool FindXY(double x, double y, SZone& s_zone);
};

extern CZones gZones;

#endif