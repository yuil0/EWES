#ifndef _FromPicas_h_
#define _FromPicas_h_

#include <vector>
#include "std_str.h"
#include "..\\transman\\mssql.h"





typedef enum
{
	EFP_ROUTES=0,
	EFP_STOPS,
	EFP_SHAPES,
	EFP_AGENTS,	
	EFP_CALENDAR,
	EFP_CALENDAR_DATES,
	EFP_STOP_TIMES,
	EFP_TRIPS,
	//
	EFP_QUANTITY,
}EFilePicas;

/*struct SReadFile
{
	SReadFile();
}; */

typedef enum
{
	EFPSF_STOP_ID = 0,
	EFPSF_STOP_CODE,
	EFPSF_STOP_NAME,
	EFPSF_STOP_DESC,
	EFPSF_STOP_LAT,
	EFPSF_STOP_LON,
	EFPSF_STOP_URL,
	EFPSF_LOCATION_TYPE,
	EFPSF_PARENT_STATION,
}EFromPicasStopField;

struct SRow
{
	std::vector<std_string> m_field_list;
	double x, y;
};

char UTF8_to(unsigned uVal);

typedef enum
{
	ETC_NONE=0,

	ETC_FROM_SHORT_DATE, //YUIL : from short  date  : sample : 20170426	
	
	ETC_FROM_DATE, //YUIL : from short  date  : sample : 20170426	
}ETypeConvert;

typedef enum
{
	EUALLFCXY_NO=0,
	EUALLFCXY_LAT,
	EUALLFCXY_LNG,
}EUseAsLatLngForCalcXY;

struct SFieldFlags
{
	int index_field;

	bool f_without_quote;
	
	ETypeConvert typeConvert;

	EUseAsLatLngForCalcXY eUseAsLatLngForCalcXY; //YUIL ����������  �������  ��� ������  ��� �������  � ����� ��������� x, y  //int index_in_row; //YUIL ����  �������� ���� �� ���������  �� ����� �������� ����� ������ ���� ������

	SFieldFlags();
	void Clear();
};

void AddConvertedShortDateToDATETIME(std_string& sz_query, const char *p_val);

class CFromPicas;

/*struct SCrThreadWriteToDBParam
{
	CFromPicas *p_this;

	int index;

	std::vector<SRow> row_list;

	EFilePicas eFile;
	std_string sz_table;
	std_string sz_id_field;
	std_string sz_fields;
	bool f_dt_created;
	std::vector<SFieldFlags> flag_list;
	bool f_id_prev;

	void Set(CFromPicas *p_this_new, int index, std::vector<SRow>& row_list, int  i_start, int  q_row_l, EFilePicas eFile, char* sz_table, char* sz_id_field, char*  sz_fields, bool f_dt_created, std::vector<SFieldFlags>& flag_list, bool f_id_prev);
};*/

/*struct SAddFieldXYByLanLng
{
	bool fNeed;
	std_string sz_field_name_lat;
	std_string sz_field_name_lng;
	void Clear() { fNeed = false; sz_field_name_lat.clear();  sz_field_name_lng.clear(); }
	void Set(char *sz_field_name_lat_new, char *sz_field_name_lng_new) { fNeed = true; sz_field_name_lat= sz_field_name_lat_new;  sz_field_name_lng= sz_field_name_lng_new; }
};*/

struct SPicasStop //dbo.picas_stops
{
	std_string stop_id;
	std_string stop_name;
	double x;
	double y;
};

////////////////////////////////////////////
class CFromPicas
{
	bool m_fInit;
	bool m_fSaveToDB;
	bool m_fLoadIfAllFiles;
	bool m_fSaveSQLQuery;
	std::vector<SRow> m_row_list; //HWND m_hwnd;
	int m_max_q_query;            //SAddFieldXYByLanLng  m_AddFieldXYByLanLng;

	struct tm m_time_last_arch;   //std::vector<SCrThreadWriteToDBParam> m_param_list;
	
	std::vector<SPicasStop> m_stops;

	bool m_f_test_load_from_picas;
	std_string m_sz_table; //YUIL 2017-10-20 ������� ��.
	bool m_existsMissingIdInDB;
	std::vector<int> m_id_list;
	char m_sz_id_field[MAX_PATH + 1];

	bool LoadFile(int index, const char *sz_file);
	bool IsFilesReady(bool *f_file);
	bool LoadFromBuf(int index, char *buf, int len);
	bool ReadLineFromBuf(char *sz_line);
	void CalcSizeFieldsInFile(char *sz_file);
	void ReportSizeToFile(char *sz_file, const std::vector<std_string>& name_list, int *a_size, int q);
	bool WriteToDB(EFilePicas eFile);	
	
	bool WriteToDB_op(EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created=false, std::vector<SFieldFlags>* p_flag_list=0, bool f_id_prev=false);
	

	//void CrThreadWriteToDB(SCrThreadWriteToDBParam *p_param);  // int i_start, int q_row, EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, std::vector<SFieldFlags>* p_flag_list, bool f_id_prev);

	bool FindFieldFlags(int i_field, std::vector<SFieldFlags>* p_flag_list, SFieldFlags& ff);//void MesWnd(HWND hwnd, char *sz_name_app, char *sz_text);
	void AddNotSavedIdToFile(EFilePicas eFile, int id);
	void AddRecInQuery(std_string& sz_query, int i, SRow& row, bool f_dt_created, long id_prev, std::vector<SFieldFlags>* p_flag_list, bool f_id_prev, EFilePicas eFile);
	void AddBeginQueryInQuery(std_string& sz_query, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, bool f_id_prev, std::vector<SFieldFlags>* p_flag_list);
	
	void AddEndQueryInQuery(EFilePicas eFile, int i_start, int& i, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, bool f_id_prev, std::vector<SFieldFlags>* p_flag_list, std_string& sz_query, long id_prev, int&  l, bool fCheck=true);

	bool ExistsMissingIdInDB(int i_start, int i_fin, EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, bool f_id_prev, std::vector<SFieldFlags>* p_flag_list);
	void SaveByListId(const std::vector<int>& id_missing_list, EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created, bool f_id_prev, std::vector<SFieldFlags>* p_flag_list);
	void DeleteIdFromDb(int i_start, int i_fin, char *sz_table, char *sz_id_field);
	

	bool Init();
	bool FillStops();
	bool LoadStopsFromDB();

	public:
	CFromPicas();
	~CFromPicas();
	bool Load();// char *sz_name_app, HWND hwnd); //bool CopyToArch();	
	bool Open();
	void Close();
	bool WriteToDB_in(std::vector<SRow>& row_list, EFilePicas eFile, char *sz_table, char *sz_id_field, char *sz_fields, bool f_dt_created = false, std::vector<SFieldFlags>* p_flag_list = 0, bool f_id_prev = false);//void Copy_row_list(std::vector<SRow>& row_list, int i_start);//void Copy_flag_list(std::vector<SFieldFlags>& flag_list, std::vector<SFieldFlags>* p_flag_list_src);//SCrThreadWriteToDBParam& GetParam(int index) { return (SCrThreadWriteToDBParam&)m_param_list[index]; }
	bool AddStop(SPicasStop& row);
	void ExistsMissingIdInDB_ADD(FldsPtr fp);
};

bool FindInIntVector(const std::vector<int>& id_list, int index);
void ClearWStr(wchar_t *wsz, int len);
bool IsNeedAddFieldXY(std::vector<SFieldFlags>* p_flag_list);

extern CFromPicas gFromPicas;
extern long gDisableSQL;

#endif
