#ifndef _timer_h_
#define _timer_h_
#include <vector>

//////////////////////////////////////////////////////////////
class CTimer
{
	bool m_fInit;
	
	
	public:
	CTimer();
	~CTimer();

	void Clear();
	bool Open();
	bool Close();
	void TimerFn();
};

#endif