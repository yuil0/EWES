#include "mes_log.h"
#include "main.h"
#include "..\\transman\\mssql.h"

#include "FromPicas.h"
#include "file_bind_car_route.h" //#include "ExcelOp.h"
#include "ATE3.h"
#include "mssql_agent.h"    //#include "..\\transman\\win_e.h"
#include "file_stops.h"
#include "..\\transman\\math_e.h"
#include "zones.h"
#include "files_check_points.h"
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include "chat.h"
#include "std_str.h"
#include "SockSrvWialon.h"
#include "read_raw_car.h"
#include "..\\transman\\win_e.h"

void main_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesLog.Mes("main():: ������ MSSQL : %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
}


////////////////////////////////////////////////////////////////////////////////////
void AppendToFile(char *sz_file, int len, char* buf, char *sz_addr)
{
	int fa = open(sz_file, O_CREAT | O_WRONLY | O_APPEND | O_BINARY, S_IREAD | S_IWRITE); //"C:\\transman\\chat\\in.txt"

	if (fa < 0) { return; }

	char sz_text[MAX_PATH + 1];

	const char *csz_space= " \0";
	
	const char *csz_new_row= ":\r\n\0";

	int len_sz_space= strlen(csz_space);
	
	int len_sz_new_row= strlen(csz_new_row);

	time_t t = time(0);

	struct tm* tm = localtime(&t);

	sprintf_s(sz_text, MAX_PATH, "%04d-%02d-%02d_%02d:%02d:%02d_length = %d ", tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec, len);

	int iWritten = write(fa, sz_text, strlen(sz_text));

	if  (sz_addr)
	{
	  int len_addr= strlen(sz_addr);

 	if  (len_addr)
	 {
		 iWritten = write(fa, sz_addr, len_addr);
		
		 iWritten = write(fa, csz_space, len_sz_space);
	 }
	}

	iWritten = write(fa, csz_new_row, len_sz_new_row);

	iWritten = write(fa, buf, len);

	sprintf_s(sz_text, MAX_PATH, "%c%c", 13, 10);

	iWritten = write(fa, sz_text, strlen(sz_text));

	close(fa);
}

struct SFix
{
	std_string sz_one;

	void Add(FldsPtr fp);

	void Init() { memset(this, 0, sizeof(SFix)); }

	void SQL_exec()
	{
		if (sz_one.size() == 0) {return; }

		bool f_exec = MSSQL_Exec((char*)sz_one.c_str(), 0, main_FN_MSSQL_MES_ERR, 0);

		sz_one.clear();
	}
};

SFix gFix;

const int ci_len_sz_app = 64;

const int ci_max = 256;

char g_szmapp[ci_len_sz_app] = "transman_srv\0";

wchar_t g_sz_app[ci_len_sz_app] = L"transman_srv\0";

HINSTANCE g_hInstance;

HWND g_hWndMap;

CWindow gWndMain; //CTimer gTimer;

CSockServer gSockServer;



void Destroy(HWND hwnd)
{
	gReadRawCar.Close();

	gFromPicas.Close();

	gSockServer.Close();
	
	gFileBindCarRoute.Close(); 
	
	gATE3.Close();

	gMSSQLAgent.Close();

	gFileStops.Close();
	
	gZones.Close();

	gFileCheckPoints.Close();

	gChat.Close();

	::CoUninitialize();

	DestroyWindow(hwnd);

	std_string_destroy();

	gSockSrvWialon.Close();

	gMesLog.Close();
	//cs_CATE3Load_SaveToDB_del();
}

void WMClose(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	Destroy(hwnd);
}

void WMDestroy(WPARAM wParam, LPARAM lParam)
{
	ExitProcess(1);
}

void WMSize(WPARAM wParam, LPARAM lParam)
{
	int new_width = lParam & 0xFFFF; //The low - order word of lParam specifies the new width of the client area.	
	int new_height = (lParam >> 2) & 0xFFFF; //The high - order word of lParam specifies the new height of the client area.
}

void WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam) {}

///////////////////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	bool fMapWnd = uMsg & (1 << 16);
	switch (uMsg)
	{
	case WM_CLOSE: WMClose(hwnd, wParam, lParam); break;
	case WM_DESTROY: WMDestroy(wParam, lParam); break;
	case WM_SIZE: WMSize(wParam, lParam); break;
	case WM_LBUTTONDOWN: WM__LBUTTONDOWN(wParam, lParam); break;
	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 1;
}

void Fix_FN_MSSQL_ADD(void *p_param, FldsPtr fp)
{
	gFix.Add(fp);
}



void SFix::Add(FldsPtr fp)
{
	_bstr_t bstr_id_ate_3(fp->Item["id_ate_3"]->Value);
	VARIANT v_latitude = fp->Item["latitude"]->Value;
	VARIANT v_longitude = fp->Item["longitude"]->Value;
	
	double x;
	double y;
	math_e::LatitudeLongitudeToXY(v_latitude.decVal.Lo32/ pow(10, v_latitude.decVal.scale), v_longitude.decVal.Lo32 / pow(10, v_longitude.decVal.scale), x, y); // XYToLatitudeLongitude(x, y, lat, lng);

	char sz_val[MAX_PATH + 1];

	std_string sz_query;  sz_query.append("UPDATE dbo.ate_3 SET x="); sprintf_s(sz_val, MAX_PATH, "%f", x); sz_query.append(sz_val);
	
	sz_query.append(", y="); sprintf_s(sz_val, MAX_PATH, "%f", y); sz_query.append(sz_val); sz_query.append(" WHERE id_ate_3=");
	
	sz_query.append((char*)bstr_id_ate_3);
	
	sz_query.append(";");

	//<q1
	int q_in_max = 50;
	static int q_in = 0;

	if (q_in >= q_in_max)
	{
		q_in = 0;

		SQL_exec();
	}
	else
	{
		q_in++;

		sz_one.append(sz_query.c_str());
	}
	
	//>q1

	Sleep(100);
}

void Fix_FN_MSSQL_END(void *p_param)
{
	gFix.SQL_exec();
}

DWORD WINAPI MainFix_ThreadProc(LPVOID lpParameter)
{
	bool f_query_in_err = false;

	bool f_exec = MSSQL_Exec("SELECT id_ate_3, latitude, longitude FROM dbo.ate_3 WHERE x IS NULL OR y IS NULL", Fix_FN_MSSQL_ADD, main_FN_MSSQL_MES_ERR, &gFix, "ms_con", 0, f_query_in_err, Fix_FN_MSSQL_END);

	return f_exec;
}

void Fix()
{
	gFix.Init();

	HANDLE h = CreateThread(0, 0, MainFix_ThreadProc, (LPVOID)0, 0, 0);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void Init(HINSTANCE hInstance)
{
	if (FAILED(::CoInitialize(NULL)))
	{
		MessageBox(0, L"FAILED CoInitialize", g_sz_app, 0); return;
	}                                         //MinimizeAllWnd();

	g_hInstance = hInstance;

	std_string_init();
	//cs_CATE3Load_SaveToDB_init();

	//<q1 YUIL ��������� ����
	SWindowCreateParam wcp;

	wcp.hInstance = hInstance;
	wcp.wsz_name = g_sz_app;
	wcp.wndProc = WindowProc;
	wcp.fVisible = true;
	wcp.w = 1024;
	wcp.h = 768;
	wcp.fCalc_xy = true;

	gWndMain.Create(wcp);
	//>q1

	if (gWndMain.GetHWND()) 
	{
		gMesLog.Open(g_szmapp, (int)gWndMain.GetHWND());

		gFromPicas.Open();

		gFileBindCarRoute.Open();

		gSockServer.Open();
		
		gATE3.Open();
		
		gMSSQLAgent.Open();

		gFileStops.Open();

		gZones.Open();

		gFileCheckPoints.Open();

		gChat.Open();

		gSockSrvWialon.Open();

		gReadRawCar.Open();
		//Fix();
	}

	/* YUIL probe SQL
	CMSSQL cMSSQL;

	bool f_open = cMSSQL.Open();

	if (f_open) { cMSSQL.ExecToFile("SELECT *  FROM dbo.module"); }

	cMSSQL.Close();
	*/
}

int CALLBACK WinMain(
	HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine,
	int       nCmdShow
)
{
	
	if (win_e::ProcessExists(L"transman_srv.exe"))
	{
		MessageBoxA(0, "Process already run/������� ��� �������", g_szmapp, 0); return 1;
	}

	Init(hInstance);

	MSG msg;
	BOOL f_ret;
	while ((f_ret = GetMessage(&msg, 0, 0, 0)))
	{
		if (f_ret == -1)
		{
			//GetLastError.
			break;
		}
		else
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

}
