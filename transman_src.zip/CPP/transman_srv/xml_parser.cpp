#include <memory.h>
#include <string.h>
#include "xml_parser.h"
#include <fcntl.h>
#include <io.h>
#include <sys/stat.h>

/*
CXMLParser::CXMLParser()
{
	m_fInit=false;
	
	memset(this, 0, sizeof(CXMLParser));
	
	m_fInit=true;
}

CXMLParser::~CXMLParser()
{
	
}*/


bool XML_Parse(char *sz_file, void  *p_param, FN_READ fn_read_tag, FN_READ fn_read_betw_tag)
{
	bool fRes = false;

	int fi = open(sz_file, O_RDONLY | O_BINARY);

	if (fi < 0) { return false; }

	int len = filelength(fi);

	if (len == 0) {  }
	else
	{
		char *buf = new char[len+1];

		if (*buf == 0) { }
		else
		{
			int iReaded = read(fi, buf, len);  buf[len] = 0;

			if (iReaded != len) {  }
			else
			{
				fRes = XML_ParseFromBuf(buf, len, p_param, fn_read_tag, fn_read_betw_tag);
			}

			delete buf;
		}

	}

	close(fi);

	return fRes;
}

bool XML_DelUnusedChars(char *sz_in, char *sz_out, int i_out_max)
{
	sz_out[0] = 0;

	int len_in = strlen(sz_in);

	if (len_in > i_out_max - 1) { return false; } //YUIL -1 : NULL terminator

	int q = 0;

	char c_prev;
	
	bool fQuote = false;

	for (int i = 0; i < len_in; i++)
	{
		char c = sz_in[i];
		
		if (c == 13 || c == 10) { continue; } //YUIL

		bool fCopy = true;

		if (fQuote==false)
		{
			if (c == '"')
			{
				fQuote = true;
			}else
			if (c == ' ')
			{
				if (i)
				{
					if (c == c_prev)
					{
						fCopy = false;
					}
				}
			}

		}
		else
		{
			if (c == '"')
			{
				fQuote = false;
			}
		}
		
		if (fCopy)
		{
			sz_out[q] = sz_in[i];

			q++;

			sz_out[q] = 0;
		}

		c_prev = c;
	}

	return true;
}

//<row r="1" spans="1:5" s="1" customFormat="1" x14ac:dyDescent="0.25"><c r="A1" s="1" t="s"><v>161</v></c><c r="B1" s="1" t="s"><v>162</v></c><c r="C1" s="1" t="s"><v>163</v></c><c r="D1" s="1" t="s"><v>164</v></c><c r="E1" s="1" t="s"><v>165</v></c></row>
//<si><t>��� - 3 "�����������"< / t>< / si>
bool XML_ParseFromBuf(char *buf, int len, void  *p_param, FN_READ fn_read_tag, FN_READ fn_read_betw_tag)
{
	int i_pos = 0;
	
	bool f_tag = false;

	for (int i=0; i<len; i++)
	{
		char c = buf[i];

		if (f_tag==false)
		{
			if (c == '<')
			{
				f_tag = true;

				int i_size = i - i_pos;

				if (i_size)
				{
					char ch = buf[i]; buf[i] = 0;

					(fn_read_betw_tag)(p_param, buf + i_pos, i_size);

					buf[i] = ch;
				}

				i_pos = i + 1;
			}

		}
		else
		{
			if (c == '>')
			{
				f_tag = false;

				int i_size = i - i_pos;

				if (i_size)
				{
					char ch = buf[i]; buf[i] = 0;

					char *p_in = buf + i_pos;

					(fn_read_tag)(p_param, p_in, i_size);

					buf[i] = ch;
				}

				i_pos = i + 1;

			}
		}
	}

	return true;
}

void XML_ParseTagOp(int i, int& i_pos, char *sz_in, int& index, void  *p_param, FN_READ_TAG fn_read_tag)
{
	if (i_pos > i) { return; }

	int i_size = i - i_pos;

	int i_shift = 0;

	if (sz_in[i] != ' ' && sz_in[i + 1] == 0) { i_size++; i_shift = 1; }

	if (i_size)
	{
		char ch = sz_in[i + i_shift]; sz_in[i + i_shift] = 0;

		(fn_read_tag)(p_param, index, sz_in + i_pos, i_size);

		sz_in[i + i_shift] = ch;

		index++;
	}

	i_pos = i + 1;
}


//<row r="1" spans="1:5" s="1" customFormat="1" x14ac:dyDescent="0.25"><c r="A1" s="1" t="s"><v>161</v></c><c r="B1" s="1" t="s"><v>162</v></c><c r="C1" s="1" t="s"><v>163</v></c><c r="D1" s="1" t="s"><v>164</v></c><c r="E1" s="1" t="s"><v>165</v></c></row>
bool XML_ParseTag(char *sz_in, void  *p_param, FN_READ_TAG fn_read_tag)
{
	int index = 0;

	char c_prev;
	
	bool fQuote = false;

	int i_pos = 0;

	for (int i = 0; sz_in[i]; i++)
	{
		char c = sz_in[i];

		if (fQuote == false)
		{
			if (c == '"')
			{
				fQuote = true;
			}else
			if (c == ' ' || sz_in[i + 1] == 0)
			{
				XML_ParseTagOp(i, i_pos, sz_in, index, p_param, fn_read_tag);
				
				/* int i_size = i - i_pos;

				int i_shift = 0;

				if (c != ' ' && sz_in[i + 1] == 0) { i_size++; i_shift = 1;}

				if (i_size)
				{
					char ch = sz_in[i + i_shift]; sz_in[i + i_shift]=0;

					(fn_read_tag)(p_param, index, sz_in + i_pos, i_size);

					sz_in[i + i_shift] = ch;

					index++;
				}

				i_pos = i + 1; */
			}
		}
		else
		{
			if (c == '"')
			{
				fQuote = false;
				
				if (sz_in[i + 1] == 0)
				{
					XML_ParseTagOp(i, i_pos, sz_in, index, p_param, fn_read_tag);
				}
			}
		}

		c_prev = c;
	}
	return true;
}

//<row r="1" spans="1:5" s="1" customFormat="1" x14ac:dyDescent="0.25"><c r="A1" s="1" t="s"><v>161</v></c><c r="B1" s="1" t="s"><v>162</v></c><c r="C1" s="1" t="s"><v>163</v></c><c r="D1" s="1" t="s"><v>164</v></c><c r="E1" s="1" t="s"><v>165</v></c></row>
bool XML_GetParamVal(char *sz_in, char* sz_param, char* sz_val, int i_max) //YUIL �������� ��  ���� "��������=��������" "��������", "��������". � "��������" ������� ����������.
{
	char *p_eq = strchr(sz_in, '=');

	if (p_eq == 0)
	{
		strcpy_s(sz_param, i_max,  sz_in);
		
		sz_val[0] = 0;
	}
	else
	{		
		if (p_eq[1] == '"') { strcpy_s(sz_val, i_max, p_eq + 2); }
		else
		{ /*YUIL �������� ������ XML, �� �����  ����������.*/ }

		int len_val = strlen(sz_val);

		if (sz_val[len_val - 1] == '"') { sz_val[len_val - 1] = 0; }
		else
		{ /*YUIL �������� ������ XML, �� �����  ����������.*/ }

		char ch = *p_eq; *p_eq = 0;

		strcpy_s(sz_param, i_max, sz_in);

		*p_eq = ch;
	}

	return true;
}