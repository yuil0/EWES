#ifndef _std_strh_
#define _std_strh_

#include <string.h>
#include <vector>

/*#include "..\\transman_srv\\std_str.h"

typedef std::basic_string<char> std_string; 

#define string std_string
*/

struct std_string
{
	std::vector<char> list;

	const char* c_str()
	{
		return (const char*)list.data();
	}

	char* data()
	{
		int len = list.size();

		if (len == 0) { return 0; }

		return list.data();

		/*

		if (len == 0) { return 0; }

		char *buf = new char[len + 1];

		for (int i = 0; i < len; i++)
		{
			buf[i] = list[i];
		}	

		buf[i] = 0;

		return buf;*/
	}

	bool operator==(const char *sz_in)
 {
		if (sz_in == 0) { return false; }

		int len_in = strlen(sz_in);

		int len = list.size();

		if (len) { len--; } //�������� ����-����������

		if (len != len_in) { return false; }

		for (int i=0; i<len; i++)
		{
			if (list[i] != sz_in[i]) { return false; }
		}

		return true;
 }

	bool operator==(char *sz_in)
	{
		return operator==((const char *)sz_in);
	}

	bool operator==(std_string& sz_in)
	{
		return operator==((const char *)sz_in.c_str());
	}

	void operator=(const char *sz_in)
	{
		list.clear();

		if (sz_in == 0) { return; }

		for (int i=0; sz_in[i]; i++)
		{
			list.push_back((char)sz_in[i]);
		}

		if (list.size())
		{
			list.push_back(0); //�������� ����-����������
		}
	}

	void operator=(std_string& sz_in)
	{
		operator=((const char *)sz_in.c_str());
	}

	void operator=(char *sz_in)
	{
		operator=((const char *)sz_in);
	}

	std_string(char *sz_in)
	{
		operator=(sz_in);
	}

	std_string()
	{
		clear();
	}

	std_string(const char *sz_in)
	{
		operator=(sz_in);
	}

	int size()
	{
		int len = list.size();

		if (len) { len--; }

		return len;
	}
	
	void append(const char *sz_in, int len_in=0); // bool f_binary = false);
	/*{
		int len_in = strlen(sz_in);

		if (len_in == 0) { return; }

		int i = 0;

		int len = list.size();

		if (len)
		{
			char&  last = list[len - 1];
			if (last == 0)  //����  ���� ���� � ����� �� ��� ����������
			{
				last = sz_in[0];
				i++;
			}
		}

		for (; i<len_in; i++)
		{
			list.push_back((char)sz_in[i]);
		}

		list.push_back(0); //�������� ����-����������
	}*/

	void append(char *sz_in)
	{
		append((const char *)sz_in);
	}

	void append(std_string& sz_in)
	{
		append((const char *)sz_in.c_str());
	}

	int length()
	{
		return size();
	}

	char operator[](int index)
	{
		int len = list.size();

		if (index<0 || index >= len) { return 0; }

		return list[index];
	}

	void push_back(char c_new)
	{
		list.push_back(c_new);
	}

	void clear()
	{
		list.clear();
	}


};

void std_string_init();
void std_string_destroy();
#endif