#include "file_stops.h"
#include "file.h"
#include "..\\transman\\mssql.h"
#include "mes_log.h"
#include "str.h"
#include <corecrt_io.h>

const char * csz_file_stops_path = "C:\\transman\\file_stops";
const char * csz_file_stops_SQL_query= "C:\\transman\\file_stops_SQL_query.txt";
const char * csz_file_stops_SQL_query_err = "C:\\transman\\file_stops_SQL_query_err.txt";
const int ci_FileStops_slepp = 1000;

bool CFileStops::Open()
{
	m_fInit = false;

	LoadFromDB();

	if (CrThread() == false) { return false; } //if (FindDriver() == false) { return false; }

	m_fInit = true;

	return m_fInit;
}


void CFileStops::Close() { }

DWORD WINAPI CFileStops_ThreadProc(LPVOID lpParameter)
{
	CFileStops *p_this = (CFileStops *)lpParameter;

	if (p_this == 0) { return 0; }

	while (1)
	{
		p_this->Read();

		Sleep(ci_FileStops_slepp);
	}

	return 1;
}


bool CFileStops::CrThread()
{
	HANDLE h=CreateThread(0, 0, CFileStops_ThreadProc, (LPVOID)this, 0, 0);

	return  h != 0;
}


void CFileStops::Read()
{
	//����� ����� ������ *.xlsx. ���� ���� �� ����� SXLSX
	//<q1
	_finddata_t fd;

	intptr_t hFile = _findfirst("C:\\transman\\file_stops\\*.xlsx", &fd);

	if (hFile == -1) { return; }

	do
	{
		if (fd.attrib != _A_SUBDIR)
		{			
			int i_col_start = 2;

			m_xlsx.Read((char*)csz_file_stops_path, fd.name, i_col_start);
		}

	} while (!_findnext(hFile, &fd));


	_findclose(hFile);
	//>q1

	SaveToDB();	

	gMesLog.Mes("���� %s ��������. ������� : %d", fd.name, m_xlsx.m_rows.size());

	char* a_file_only[1] = { fd.name };

	int q = 1;

	CopyToArch((char*)csz_file_stops_path, (char**) a_file_only, q); //YUIL �������� � �����

}

void CFileStops_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	/*FILE *fo = fopen(csz_file_stops_SQL_query_err, "ab");
	
	if (fo)
	{
		fprintf(fo, "%s\r\n", sz_text);

		fclose(fo);
	}
	
	sz_text[32] = 0;

	gMesLog.Mes(sz_text);*/

	gMesLog.Mes("CFileStops:: ������ MSSQL : %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
}

void CFileStops::SaveToDB_op(std_string& sz_query)
{
	if (sz_query.size() == 0) { return; }

	std_string sz_full = "";

	sz_full.append("DECLARE @id_file_stop_prev BIGINT; SET @id_file_stop_prev=ISNULL((SELECT MAX(id_file_stop) FROM dbo.file_stops),0);\r\n");

	sz_full.append("SET IDENTITY_INSERT dbo.file_stops ON;\r\n");

	sz_full.append("INSERT dbo.file_stops(id_file_stop, dt_created, number, name, lat, lng, id_file_stop_area, id_file_stop_street, stop_id)\r\n");

	sz_full.append("SELECT @id_file_stop_prev + id, GETDATE(), number, name, lat, lng, (SELECT x.id_file_stop_area FROM dbo.file_stop_areas x WHERE x.area=t.area), (SELECT x.id_file_stop_street FROM dbo.file_stop_streets x WHERE x.street=t.street), dbo.FN_near_stop_id(lat, lng) FROM\r\n");

	sz_full.append("(\r\n");

	sz_full.append(sz_query.c_str());

	sz_full.append(")t\r\n");

	sz_full.append("SET IDENTITY_INSERT dbo.file_stops OFF;\r\n");

	FILE *fo = fopen(csz_file_stops_SQL_query, "ab");

	if (fo)
	{
		fprintf(fo, "%s", sz_full.c_str());

		fclose(fo);
	}

	bool f_query_in_err = true;

	bool f_exec = MSSQL_Exec((char*)sz_full.c_str(), NULL, CFileStops_FN_MSSQL_MES_ERR, this, "ms_con", 0, f_query_in_err);
}

void CFileStops::SaveToDB_op_area(std_string& sz_query_area)
{
	if (sz_query_area.size() == 0) { return; }

	std_string sz_full = "";

	sz_full.append("INSERT dbo.file_stop_areas(area)\r\n");

	sz_full.append("SELECT area FROM\r\n");

	sz_full.append("(\r\n");

	sz_full.append(sz_query_area.c_str());

	sz_full.append(")t\r\n");

	sz_full.append("WHERE area NOT IN(SELECT area FROM dbo.file_stop_areas);\r\n");

	FILE *fo = fopen(csz_file_stops_SQL_query, "ab");

	if (fo) { fprintf(fo, "%s", sz_full.c_str()); fclose(fo); }

	bool f_query_in_err = true;

	bool f_exec = MSSQL_Exec((char*)sz_full.c_str(), NULL, CFileStops_FN_MSSQL_MES_ERR, this, "ms_con", 0, f_query_in_err);
}

void CFileStops::SaveToDB_op_street(std_string& sz_query_street)
{
	if (sz_query_street.size() == 0) { return; }

	std_string sz_full = "";

	sz_full.append("INSERT dbo.file_stop_streets(street)\r\n");

	sz_full.append("SELECT street FROM\r\n");

	sz_full.append("(\r\n");

	sz_full.append(sz_query_street.c_str());

	sz_full.append(")t\r\n");

	sz_full.append("WHERE street NOT IN(SELECT street FROM dbo.file_stop_streets);\r\n");

	FILE *fo = fopen(csz_file_stops_SQL_query, "ab");

	if (fo) { fprintf(fo, "%s", sz_full.c_str()); fclose(fo); }

	bool f_query_in_err = true;

	bool f_exec = MSSQL_Exec((char*)sz_full.c_str(), NULL, CFileStops_FN_MSSQL_MES_ERR, this, "ms_con", 0, f_query_in_err);
}

bool CFileStops::AddQueryRowIn(std_string& sz_query, SXLSXRow& row, std_string& sz_query_area, std_string& sz_query_street)
{
	const int ci_max_lan_lng = 9;

	if (row.list.size() == 0) { return false; }

	//<q1 make query
	bool fData = false;  //char sz_val[MAX_PATH+1];

	for (int i = 0; i < (int)EFSF_QUANTITY; i++)
	{
		
		char *p_data = 0;

		if (i < row.list.size()) { p_data = (char*)row.list[i].c_str(); }

		if (i == 0)
		{
			if (strlen(p_data)<1 || IsNum(p_data)==false) { break; }
		}

		if (i) { sz_query.append(", "); }

		EFileStopsField eField = (EFileStopsField)i;

		bool fQoute = eField == EFSF_NUMBER || eField == EFSF_NAME || eField == EFSF_AREA || eField == EFSF_STREET;

		if (fQoute) { sz_query.append("N'"); }

		if (p_data) 
		{ 
			if (eField == EFSF_LAT || eField == EFSF_LNG)
			{				
				if (strlen(p_data) > ci_max_lan_lng) { p_data[ci_max_lan_lng] = 0; } //double dVal;sscanf(p_data,"%g",&dVal);
			}
			
			sz_query.append(p_data);
		}

		if (fQoute) { sz_query.append("'"); }

		sz_query.append(" ");

		if (eField == EFSF_NUMBER) { sz_query.append("number"); } else
		if (eField == EFSF_NAME) { sz_query.append("name"); } else
		if (eField == EFSF_LAT) { sz_query.append("lat"); } else
		if (eField == EFSF_LNG) { sz_query.append("lng"); } else
		if (eField == EFSF_AREA) 
		{ 
			sz_query.append("area"); 
			
			if (p_data) { sz_query_area.append("N'"); sz_query_area.append(p_data); sz_query_area.append("' area"); }
		} else
		if (eField == EFSF_STREET) 
		{ 
			sz_query.append("street"); 

			if (p_data) { sz_query_street.append("N'"); sz_query_street.append(p_data); sz_query_street.append("' street"); }
		}

		fData = true;

	}	

	//>q1

	return fData;
}

void CFileStops::SaveToDB()
{
	bool f_exec= MSSQL_Exec("TRUNCATE TABLE dbo.file_stops", NULL, CFileStops_FN_MSSQL_MES_ERR, this);
	
	f_exec = MSSQL_Exec("TRUNCATE TABLE dbo.file_stop_areas", NULL, CFileStops_FN_MSSQL_MES_ERR, this);
	
	f_exec = MSSQL_Exec("TRUNCATE TABLE dbo.file_stop_streets", NULL, CFileStops_FN_MSSQL_MES_ERR, this);

	unlink(csz_file_stops_SQL_query);
	
	unlink(csz_file_stops_SQL_query_err);	

	std_string sz_query="";

	int q_max_in_query = 10;

	int q_in_query = 0;

	char sz_val[MAX_PATH + 1];

	std_string sz_query_area = "";

	std_string sz_query_street = "";

	int q_area= 0;
	
	int q_street= 0;

	for (int i = 0; i < m_xlsx.m_rows.size(); i++)
	{
		SXLSXRow& row= m_xlsx.m_rows[i];

		if (q_in_query >= q_max_in_query)
		{
			SaveToDB_op_area(sz_query_area);

			SaveToDB_op_street(sz_query_street);

			SaveToDB_op(sz_query);

			sz_query.clear();

			sz_query_area.clear();
			
			sz_query_street.clear();

			q_in_query = 0;

			q_area = 0;

			q_street = 0;
		}
	
		std_string sz_row= "";
		std_string sz_area = "";
		std_string sz_street = "";

		if (AddQueryRowIn(sz_row, row, sz_area, sz_street))
		{
			if (sz_area.size())
			{
				if (q_area) { sz_query_area.append(" UNION\r\n"); } sz_query_area.append("SELECT ");  sz_query_area.append(sz_area.c_str());

				q_area++;
			}

			if (sz_street.size())
			{
				if (q_street) { sz_query_street.append(" UNION\r\n"); } sz_query_street.append("SELECT ");  sz_query_street.append(sz_street.c_str());

				q_street++;
			}

			if (q_in_query) 
			{ 
				sz_query.append(" UNION\r\n");
			}

			sz_query.append("SELECT "); itoa(q_in_query + 1, sz_val, 10); sz_query.append(sz_val); sz_query.append(" id, "); sz_query.append(sz_row.c_str());						
			
			q_in_query++;
		}

	}

	SaveToDB_op(sz_query);

	SaveToDB_op_area(sz_query_area);

	SaveToDB_op_street(sz_query_street);
}

/*void CATE3_FN_MSSQL_ADD(void *p_param, FldsPtr fp)
{
	CFileStops * p_this = (CFileStops *)p_param;

	if (p_this == 0) { return; }

	SATE3Row row;

	_bstr_t bstr_device_number(fp->Item["device_number"]->Value);

	_bstr_t bstr_garage_num(fp->Item["garage_num"]->Value);

	_bstr_t bstr_mark(fp->Item["mark"]->Value);

	_bstr_t bstr_state_num(fp->Item["state_num"]->Value);

	row.sz_device = (char*)bstr_device_number;

	row.sz_garage_num = (char*)bstr_garage_num;

	row.sz_mark = (char*)bstr_mark;

	row.sz_state_num = (char*)bstr_state_num;

	p_this->Add(row);
}*/

void CFileStops::LoadFromDB()
{
	/*std_string sz_cmd = "SELECT device_number, garage_num, mark, state_num FROM dbo.ate_3_book";
	
	m_rows.clear();

	bool fSave = MSSQL_Exec((char*)sz_cmd.c_str(), CATE3_FN_MSSQL_ADD, SATE3Row_FN_MSSQL_MES_ERR, this, "ms_con");

	if (fSave) 
	{ gMesLog.Mes("������� �� �� ���������: %d", m_rows.size()); } 
	else 
	{ gMesLog.Mes("������ �� �� �� ���������"); }
	*/
}

CFileStops gFileStops;