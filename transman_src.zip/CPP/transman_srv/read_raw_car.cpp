#include "read_raw_car.h"
#include "main.h"
#include <windows.h>
#include "mes_log.h"
#include <inttypes.h>
#include <io.h>	//<sys / types.h>, <sys / stat.h>, <errno.h>
#include "..\\transman\\math_e.h"
#include "..\\transman\\ini_file.h"
#include "time_e.h"
#include "zones.h"
#include "str.h"
#include "file_bind_car_route.h"
#include "ATE3.h"
#include "time.h"

const char *csz_raw_car_sql_query_save = "C:\\transman\\raw_car\\sql_query_save.txt\0";
const char *csz_raw_car_not_found_device= "C:\\transman\\raw_car\\not_found_device.txt\0";
const char *csz_raw_car_not_found_route = "C:\\transman\\raw_car\\not_found_route.txt\0";


void CReadRawCar_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesLog.Mes("CReadRawCar:: ������ MSSQL : %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
}

CReadRawCar::CReadRawCar() {}

/*void CReadRawCar::ReadIni()
{
	CIniFile ini;
	char sz_value[MAX_PATH +1];

	if (ini.Get("C:\\transman\\transman.ini", "need_wialon", sz_value, MAX_PATH))
	{
		m_f_need = atoi(sz_value);
	}
}*/

bool CReadRawCar::Open()
{
	memset(this, 0, sizeof(CReadRawCar)); //ReadIni();

	unlink(csz_raw_car_not_found_device);
	unlink(csz_raw_car_not_found_route);
	unlink(csz_raw_car_sql_query_save); //if (m_f_need == false) { return false; }
	
	ReadIni();

	CrThread();

	return  true;
}

void CReadRawCar::Close() { }

DWORD WINAPI CReadRawCar_Thread_proc(LPVOID param)
{
	while (1)
	{
		gReadRawCar.CycleOp();

		Sleep(600);
	}
}



void CReadRawCar::ReadIni()
{
	CIniFile ini;
	char sz_value[MAX_PATH + 1];

	if (ini.Get("C:\\transman\\transman.ini", "raw_car_sleep_after_save", sz_value, MAX_PATH))
	{
		m_sleep_after_save = atoi(sz_value);
	}

	if (ini.Get("C:\\transman\\transman.ini", "shuttle_id_agent", sz_value, MAX_PATH))
	{
		m_shuttle_id_agent = atoi(sz_value);
	}

	
}

void CReadRawCar::CrThread()
{
	HANDLE h = CreateThread(0, 0, CReadRawCar_Thread_proc, (LPVOID)this, 0, 0);

	if (h == 0) { gMesLog.Mes("CReadRawCar::CrThread(). Error of creating thread"); }
}

void CReadRawCar_ADD(void *p_param, FldsPtr fp) { CReadRawCar* p_this = (CReadRawCar*)p_param; if (p_this) { p_this->Add(fp); } }

void CReadRawCar::CycleOp()
{                                  //gMesLog.Mes("CReadRawCar::CycleOp(). ==============================================================================");
	m_cnt=0;

	bool fExec = MSSQL_Exec("EXEC dbo.P_get_raw_car", CReadRawCar_ADD, CReadRawCar_FN_MSSQL_MES_ERR, this);
	
	if (fExec)
	{
		bool fTrunc = MSSQL_Exec("TRUNCATE TABLE dbo.raw_car", 0, CReadRawCar_FN_MSSQL_MES_ERR, this);

		//if (m_cnt) { gMesLog.Mes("CReadRawCar::CycleOp(). ������� %d. �������: %s", m_cnt, fTrunc ? "true" : "false"); }
	}
}

void CReadRawCar::Add(FldsPtr fp)
{
	char sz_val[MAX_PATH+1];

	SATE3RowStr row;

	_bstr_t bstr_device_number(fp->Item["device_number"]->Value);
	_bstr_t bstr_latitude(fp->Item["latitude"]->Value);
	_bstr_t bstr_longitude(fp->Item["longitude"]->Value);
	_bstr_t bstr_azimut(fp->Item["azimut"]->Value);
	_bstr_t bstr_speed(fp->Item["speed"]->Value);
	_bstr_t bstr_id_agent(fp->Item["id_agent"]->Value);
		
	row.device_number = (char*)bstr_device_number;
	row.latitude = (char*)bstr_latitude;
	row.longitude = (char*)bstr_longitude;
	row.azimut = (char*)bstr_azimut;
	row.speed = (char*)bstr_speed;

	row.id_agent = atoi((char*)bstr_id_agent);

	math_e::LatitudeLongitudeToXY_s((char*)row.latitude.c_str(), (char*)row.longitude.c_str(), row.x, row.y);

	char sz_type[MAX_PATH] = { 0 };
	ETypeResult eTypeRes;
	std_string garage_num;
	SetRoute(sz_type, row, garage_num,  eTypeRes);
	
	if (row.id_agent == 0)
	{
		if (row.route.size() == 0)
		{
			FILE *fo;

			if (eTypeRes == ETR_NOT_FOUND_DEVICE)
			{
				fopen_s(&fo, csz_raw_car_not_found_device, "ab");
				if (fo)
				{
					struct tm tm;
					if (time_e::GetCurLocalDateTime(tm))
					{
						fprintf(fo, "%04d-%02d-%02dT%02d:%02d:%02d ", tm.tm_year, tm.tm_mon, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
					}
					fprintf(fo, "device_name:'%s'\r\n", row.device_number.c_str());

					fclose(fo);

					_chmod(csz_raw_car_not_found_device, _S_IREAD | _S_IWRITE);
				}
			}
			else
				if (eTypeRes == ETR_NOT_FOUND_ROUTE)
				{
					fopen_s(&fo, csz_raw_car_not_found_route, "ab");

					if (fo)
					{
						struct tm tm;
						if (time_e::GetCurLocalDateTime(tm))
						{
							fprintf(fo, "%04d-%02d-%02dT%02d:%02d:%02d ", tm.tm_year, tm.tm_mon, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
						}
						fprintf(fo, "garage_num:'%s'\r\n", garage_num.c_str());

						fclose(fo);

						_chmod(csz_raw_car_not_found_route, _S_IREAD | _S_IWRITE);
					}
				}


			if (eTypeRes == ETR_NOT_FOUND_DEVICE)
			{
				int k = 0;
				k++;
			}

			if (eTypeRes == ETR_NOT_FOUND_ROUTE)
			{
				int k = 0;
				k++;
			}
			return;
		}
	}

	SaveToDB(row);

	m_cnt++;
}

void CReadRawCar::SetRoute(char *sz_type, SATE3RowStr& row, std_string& garage_num, ETypeResult& eTypeRes)
{	
	if (row.id_agent == m_shuttle_id_agent)
	{
		row.type = "5";
		eTypeRes = ETR_FOUND;
		return;
	}

	SATE3Row* pATE3Row;

	if (gATE3.GetLoadParam().FindByDevice(row.device_number.c_str(), &pATE3Row) == false) { eTypeRes = ETR_NOT_FOUND_DEVICE; return; } //YUIL 2017-01-30 �������� �������� �����

	SFileBindCarRouteRow* pFileBindCarRouteRow; //if (gFileBindCarRoute.FindByGarageNum(pATE3Row->sz_garage_num.c_str(), &pFileBindCarRouteRow) == false) { return; }

	garage_num = pATE3Row->sz_garage_num;

	if (gFileBindCarRoute.FindByGarageNumAndType(pATE3Row->sz_garage_num.c_str(), sz_type, &pFileBindCarRouteRow) == false) { eTypeRes = ETR_NOT_FOUND_ROUTE; return; }

	row.route = pFileBindCarRouteRow->route;

	eTypeRes = ETR_FOUND;

	row.type = sz_type; //YUIL 2017-01-30
}

//////////////////////////////////////////////////////////////////////////
void CReadRawCar::SaveToDB(SATE3RowStr& row)
//
{                                                                                          //EnterCriticalSection(&cs_CATE3L�oad_SaveToDB);
	if (row.device_number == "") { return; } //YUIL � ������ ������ ���������� �� �����

	char sz_val[MAX_PATH + 1];

	SZone s_zone;

	const int ci_query_len = 1024;

	char sz_query[ci_query_len + 1]; 
	
	strcpy_s(sz_query, ci_query_len, "EXEC dbo.P_add_ate_3 @id_src=1, @device_number = N'");
	
	strcat_s(sz_query, ci_query_len, row.device_number.c_str());

	strcat_s(sz_query, ci_query_len, "', @latitude = ");

	strcat_s(sz_query, ci_query_len, row.latitude.c_str()); 
	
	strcat_s(sz_query, ci_query_len, ", @longitude = "); 
	
	strcat_s(sz_query, ci_query_len, row.longitude.c_str()); 
	
	strcat_s(sz_query, ci_query_len, ", @azimut = ");  
	
	strcat_s(sz_query, ci_query_len, row.azimut.c_str());

	strcat_s(sz_query, ci_query_len, ", @speed = "); 
	
	strcat_s(sz_query, ci_query_len, row.speed.c_str());

	sprintf_s(sz_val, MAX_PATH, ", @x = %f, @y = %f", row.x, row.y); 
	
	strcat_s(sz_query, ci_query_len, sz_val);

	if  (row.route.size())
	{ 
		strcat_s(sz_query, ci_query_len, ", @route_short_name = N'"); 
		
		strcat_s(sz_query, ci_query_len, row.route.c_str()); 
		
		strcat_s(sz_query, ci_query_len, "'");
		
		strcat_s(sz_query, ci_query_len, ", @route_en = N'"); 
		
		strcat_s(sz_query, ci_query_len, GetTranslit((char*)row.route.c_str(), sz_val, MAX_PATH)); 
		
		strcat_s(sz_query, ci_query_len, "'"); //YUIL 2017-09-15 ������������������ ���� ��  �������� �������� ����� ��������. ������ : 18� => 18l, 18� => 18p, 42�=> 42a	
	}			

	strcat_s(sz_query, ci_query_len, ", @id_zone = ");

	if (gZones.FindXY(row.x, row.y, s_zone))
	{
		strcat_s(sz_query, ci_query_len, s_zone.id_zone.c_str());
	}
	else
	{
		strcat_s(sz_query, ci_query_len, "0");
	}

	if (row.id_agent)
	{
		strcat_s(sz_query, ci_query_len, ", @id_agent="); itoa(row.id_agent, sz_val, 10); 
		
		strcat_s(sz_query, ci_query_len, sz_val);
	}
	
	if (row.type.size())
	{
		strcat_s(sz_query, ci_query_len, ", @id_car_type="); 
		
		strcat_s(sz_query, ci_query_len, row.type.c_str());
	}

	strcat_s(sz_query, ci_query_len, ";;");

	if (strstr(sz_query, ";;") == 0)
	{
		gMesLog.Mes("CReadRawCar::SaveToDB. ������. � ������ SQL ������� ��� ����������");
		return;
	}

	//<a1
	static time_t time_prev = 0;
	time_t time = clock();
	if (time_prev==0 || (time - time_prev) > 3600000)
	{
		time_prev = time;
		unlink(csz_raw_car_sql_query_save);
	}
	
	FILE *fo = 0; fopen_s(&fo, csz_raw_car_sql_query_save, "ab"); if (fo) { fprintf_s(fo, "%s\r\n", sz_query); fclose(fo); }	
	//>a1

	bool fExec = MSSQL_Exec((char*)sz_query, NULL, CReadRawCar_FN_MSSQL_MES_ERR, this);
	if (fExec == false) { gMesLog.Mes("CReadRawCar::SaveToDB. ������ ����������/��������� ������ � ��. "); }

	Sleep(m_sleep_after_save);
}

CReadRawCar gReadRawCar;