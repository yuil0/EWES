#ifndef _str_h_
#define _str_h_

#pragma once

#include "std_str.h"

#include <string>

class CMesLog
{
	bool fOpen;
	
	std_string m_sz_caption_name;

	std_string m_sz_log_file;

	int m_hwnd;
	
	void ReadIni(); //bool m_f_check_time;

public:
	CMesLog();

	bool Open(char *sz_caption_name, int hwnd, char *sz_log_file="C:\\transman\\log_server.txt\0");
	
	void Close();

	void Mes(char *szFormat, ...); //void Log(char* buf);
};

void LocalTimeToText(char *sz_text, int i_max);

extern CMesLog gMesLog; //void MesBox(wchar_t *wsz_text);

#endif