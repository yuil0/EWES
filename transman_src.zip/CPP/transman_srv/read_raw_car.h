#ifndef _read_raw_car_h_
#define _read_raw_car_h_

#include "ate3_load.h"
#include "..\\transman\\MSSQL.h"

#ifndef ulong
typedef unsigned long ulong;
#endif

#ifndef uchar
typedef unsigned char uchar;
#endif

class CReadRawCar
{	                                   
	typedef enum
	{
		ETR_FOUND=0,
		ETR_NOT_FOUND_DEVICE,
		ETR_NOT_FOUND_ROUTE,
	}ETypeResult;   //bool m_f_need;

	int m_cnt; //void ReadIni();

	int m_sleep_after_save;
	int m_shuttle_id_agent;

	void SaveToDB(SATE3RowStr& row); // , char* sz_id_agent = 0);
	void SetRoute(char *sz_type, SATE3RowStr& row, std_string& garage_num, ETypeResult& eTypeRes); //void WriteRowToFile(SRow& sRow);
	void CrThread();
	void ReadIni();
	public:
	CReadRawCar();
	bool Open(); 
	void Close();
	void Add(FldsPtr fp);
	void CycleOp();
};

extern CReadRawCar gReadRawCar;

#endif