#ifndef _chat_h_
#define _chat_h_

#include <windows.h>
#include <string>
#include <vector>
#include "std_str.h"
#include "..\\transman\\mssql.h"
#include "std_str.h"

struct SChatMesHead
{
	std_string id_chat_mes_head;
	std_string dt_create; //std_string dt_create_src;
	std_string id_user_from;
	std_string id_user_to;
	std_string id_chat_mes_type;
};

class CChat
{
	bool m_fInit;
	SChatMesHead m_head;
	bool m_f_data_to_trans_exists;
	void HttpPost(const char* id_user_from, const char* id_user_to, const char* sz_mes);
	void ChStatusChatMes();
	std_string m_sz_query_index;
	char m_sz_addr_send[MAX_PATH+1];

	void ReadIni();
	public:
	CChat();
	~CChat();
	bool Open();
	void Close() {}
	void sql_err(char *sz_text);
	void Load();
	void add(FldsPtr fp);
	void add_step_2(FldsPtr fp);
};

extern CChat gChat;

#endif