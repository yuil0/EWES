#include "SockSrvWialon.h"
#include "main.h"
#include <windows.h>
#include "mes_log.h"
#include <inttypes.h>
#include <io.h>	//<sys / types.h>, <sys / stat.h>, <errno.h>
#include "..\\transman\\math_e.h"
#include "..\\transman\\ini_file.h"
#include "..\\transman\\MSSQL.h"
#include "time_e.h"
#include "zones.h"
#include "str.h"
#include "file_bind_car_route.h"
#include "ATE3.h"

const char *csz_wialon_sql_query_save = "C:\\transman\\wialon_sql_query_save.txt\0";
const char *csz_wialon_not_found_device= "C:\\transman\\SockSrv\\wialon_not_found_device.txt\0";
const char *csz_wialon_not_found_route = "C:\\transman\\SockSrv\\wialon_not_found_route.txt\0";

CSockSrvWialon::SRow::SRow()
{
	memset(this, 0, sizeof(CSockSrvWialon::SRow));
}

/*const int cq_wialon_block_name=10;

const char* gsz_wialon_block_name[cq_wialon_block_name]= 
{
	"posinfo",
	"pwr_ext",
	"avl_inputs",
	"avl_outputs",
	"adc1",
	"adc2",
	"gsm",
	"ign",
	"can1",
	"can2"
};*/

void CSockSrvWialon_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesLog.Mes("CSockSrvWialon:: ������ MSSQL : %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
}

CSockSrvWialon::CSockSrvWialon() {}

void CSockSrvWialon_FN_SOCK_SRV_ON_READ(void *p_param, int i_client_sock, char *buf, int len)
{
	CSockSrvWialon* p_this = (CSockSrvWialon*)p_param;

	if (p_this) { p_this->SrvOnRead(i_client_sock, buf, len); }
}

void CSockSrvWialon::SrvOnRead(int i_client_sock, char *buf, int len)
{
	Read(buf, len, i_client_sock);
}

void CSockSrvWialon::ReadIni()
{
	CIniFile ini;
	char sz_value[MAX_PATH +1];

	if (ini.Get("C:\\transman\\transman.ini", "need_wialon", sz_value, MAX_PATH))
	{
		m_f_need = atoi(sz_value);
	}
	if (ini.Get("C:\\transman\\transman.ini", "wialon_sleep_after_save", sz_value, MAX_PATH))
	{
		m_sleep_after_save = atoi(sz_value);
	}
	
}

bool CSockSrvWialon::Open()
{
	memset(this, 0, sizeof(CSockSrvWialon));

	ReadIni();

	unlink(csz_wialon_not_found_device);
	unlink(csz_wialon_not_found_route);
	unlink(csz_wialon_sql_query_save);

	if (m_f_need == false) { return false; }

	return m_srv.OpenOp("50501", this, CSockSrvWialon_FN_SOCK_SRV_ON_READ);
}

void CSockSrvWialon::Close()
{
	m_srv.Close();
}

void CSockSrvWialon::Answer(int i_client_sock)
{
	const int ci_len=1;
	char sz_buf[ci_len] = { 0x11 };
	int i_res = send(i_client_sock, sz_buf, ci_len, 0); // Echo the buffer back to the sender																																																					
}


bool CSockSrvWialon::IsValidChar(char c)
{
	return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '�' && c <= '�') || (c >= '�' && c <= '�');
}

bool CSockSrvWialon::IsValidDeviceName(char * sz_device_name)
{
	char *p = sz_device_name;
	
	if (p[0] < '0' || p[0] > '9')
	{
		return false;
	}

	int len = strlen(p);

	if (len < 4) { return false; }
	/*if (!stricmp(sz_device_name, "posinfo")) { return false; }
	if (!stricmp(sz_device_name, "pwr_ext")) { return false; }
	if (!stricmp(sz_device_name, "avl_inputs")) { return false; }
	if (!stricmp(sz_device_name, "avl_outputs")) { return false; }
	if (!stricmp(sz_device_name, "adc1")) { return false; }
	if (!stricmp(sz_device_name, "adc2")) { return false; }
	if (!stricmp(sz_device_name, "gsm")) { return false; }
	if (!stricmp(sz_device_name, "ign")) { return false; }
	if (!stricmp(sz_device_name, "can1")) { return false; }
	if (!stricmp(sz_device_name, "can2")) { return false; }
	if (!stricmp(sz_device_name, "hdop")) { return false; }
	if (!stricmp(sz_device_name, "mileage")) { return false; }
	if (!stricmp(sz_device_name, "mileage_day")) { return false; }
	if (!stricmp(sz_device_name, "navigation_system")) { return false; }
	if (!stricmp(sz_device_name, "GPS+Glonass")) { return false; }
	if (!stricmp(sz_device_name, "navigation_device")) { return false; }
	if (!stricmp(sz_device_name, "Internal")) { return false; }
	if (!stricmp(sz_device_name, "accuracy")) { return false; }
	if (!stricmp(sz_device_name, "NAN")) { return false; }
	if (!stricmp(sz_device_name, "csq1")) { return false; }
	if (!stricmp(sz_device_name, "nsq1")) { return false; }
	if (!stricmp(sz_device_name, "bat1")) { return false; }
	if (!stricmp(sz_device_name, "pwr1")) { return false; }
	if (!stricmp(sz_device_name, "pwr1")) { return false; }
	if (!strcmp(sz_device_name, "GPS")) { return false; }	//if (!strcmp(sz_device_name, "soft_version")) { return false; }
	if (p[0] == 'Z' && p[1] == 'D') 
	{ 
		bool fNumChar = IsNumChar(p[2]);
		bool fLetterRuChar = IsLetterRuChar(p[2]);

		if (fNumChar == false || fLetterRuChar) { return false; }
	}*/

	return true;
}

bool CSockSrvWialon::FindDeviceName(char *buf, int len, int i, std_string& device_name, int& i_pos)
{
	//���� � ������, ������� ����� � �����, ������� � ���� � ���������� �����
	if (i < 1) { return false; }

	int i_pos_0;
	bool fFound_0 = false;
	bool fValidChars = false;

	for (int k = i - 1; k >= 0; k--)
	{
		char c = buf[k];

		if (fFound_0 == false)
		{
			if (c == 0) { i_pos_0 = k; fFound_0 = true; fValidChars=true;			}
		}
		else
		{
			if (c == 0) 
			{ 
				if (fValidChars)
				{
					int i_size = i_pos_0 - k - 1;
					
					if (i_size)
					{
						char *p = buf + k + 1;

						bool fPassNext= false;

						if (IsNum(p))
						{
							//�����  ��� ����� ������ �� ���� �����
							static char *sz_soft_version = "soft_version\0";
							static int len_soft_version = strlen(sz_soft_version);
							if (k >= len_soft_version)
							{
								if (!stricmp(buf - len_soft_version, sz_soft_version)) 
								{
									fPassNext = true;
									i -= len_soft_version;
								}
							}
						}

						if (fPassNext == false)
						{
							if (IsValidDeviceName(p))
							{
								device_name = (buf + k + 1);
								i_pos = k + 1;
								break;
							}
						}
					}
				}		
				i_pos_0 = k; fValidChars = true;
			}
			else
			{
				if (fValidChars)
				{
					if (IsValidChar(c) == false) { fValidChars = false; }
				}
			}
		}		
	}

	return fValidChars;
}

bool CSockSrvWialon::IsBlock_posinfo(char *buf, int len, int& i, int i_client_sock) //, int& i_pos_value_block)
{
	const char *csz_posinfo = "posinfo\0";
	const int ci_posinfo_len = strlen("posinfo") + 1; // +nullchar
	const int ci_posinfo_data_len = 29;

	if (len - i < ci_posinfo_len) { return false; }

	bool fDone = true;

	//char ch = buf[i + ci_posinfo_len]; buf[i + ci_posinfo_len]=0;

	if (buf[i+0]=='p' && buf[i + 1] == 'o' && buf[i + 2] == 's' && buf[i + 3] == 'i' && buf[i + 4] == 'n' && buf[i + 5] == 'f' && buf[i + 6] == 'o' && buf[i + 7] == 0) 
	{
		int i_pos_posinfo = i;

		i += ci_posinfo_len; //i_pos_value_block = i + ci_posinfo_len;

		if (i + ci_posinfo_data_len <= len)
		{
			std_string device_name;
			int i_pos_device_name;

			bool fFoundDeviceName = FindDeviceName(buf, len, i- ci_posinfo_len, device_name, i_pos_device_name);

			if (fFoundDeviceName)
			{
				SRow sRow;
				strcpy_y(sRow.device_name, ci_device_name_max, (char*)device_name.c_str());
				sRow.Read(buf + i);
				sRow.i_pos_device_name = i_pos_device_name;
				sRow.i_pos_posinfo = i_pos_posinfo;

				//WriteRowToFile(sRow);

				AddRow(sRow);

				Answer(i_client_sock);
			}
			
		}
		else
		{ fDone = false; }
		
	}

	//buf[i + ci_posinfo_len] = ch;

	return fDone;
}

//////////////////////////////////////////////////////////////////////////////////
void CSockSrvWialon::Read(char *buf, int len, int i_client_sock) //t_char_list& list_in)
//
{
	for (int i = 0; i<len; i++)
	{
		if (IsBlock_posinfo(buf, len, i, i_client_sock) == false) { break; }
	}
}

void CSockSrvWialon::AddRow(SRow& sRowNew)
{
	/*int index;
	if (FindRow(sRowNew, index))
	{
		m_rows[index] = sRowNew;
	}
	else
	{
		m_rows.push_back(sRowNew);
	}
	*/

	SaveToDB_pre(sRowNew);

	Sleep(600);
}

void CSockSrvWialon::SRow::Read(char* p_buf)
{
	//BufToFile(p_buf);

	unsigned int m= 0;

	unsigned short v;

	memcpy(&lon, p_buf + m, 8); m += 8;
	memcpy(&lat, p_buf + m, 8); m += 8;
	memcpy(&height, p_buf + m, 8); m += 8;
	memcpy(&v, p_buf + m, 2); m += 2; speed = ((v & 0xFF) << 8) + ((v & 0xFF00) >> 8);
	memcpy(&v, p_buf + m, 2); m += 2; azimut = ((v & 0xFF) << 8) + ((v & 0xFF00) >> 8);
	memcpy(&q_sats, p_buf + m, 1); m += 1;
}

void CSockSrvWialon::WriteRowToFile(SRow& sRow)
{
	FILE *fo = 0;

	fopen_s(&fo, "C:\\transman\\SockSrv\\device_number.txt", "wb");

	if (fo)
	{
		fprintf(fo, "name:'%s' pos_dev_name:%d pos_posinfo:%d\r\n", sRow.device_name, sRow.i_pos_device_name, sRow.i_pos_posinfo);
		fclose(fo);
	}
}

/*void CSockSrvWialon::SRow::BufToFile(char* p_buf)
{
	FILE *fo = 0;

	fopen_s(&fo, "C:\\transman\\SockSrv\\row_buf.txt", "wb");

	if (fo)
	{
		fprintf(fo, "name:'%s' pos_dev_name:%d pos_posinfo:%d\r\n", sRow.device_name, sRow.i_pos_device_name, sRow.i_pos_posinfo);
		fclose(fo);
	}
}*/

void CSockSrvWialon::SaveToDB_pre(SRow& sRow)
{

	if (sRow.device_name[0] == 0) { return; } //YUIL � ������ ������ ���������� �� �����

	char sz_val[MAX_PATH + 1];

	SATE3RowStr row;

	row.device_number = sRow.device_name;
	sprintf_s(sz_val, MAX_PATH, "%g", sRow.lat); row.latitude = sz_val;
	sprintf_s(sz_val, MAX_PATH, "%g", sRow.lon); row.longitude = sz_val;
	sprintf_s(sz_val, MAX_PATH, "%d", sRow.speed); row.speed = sz_val;
	sprintf_s(sz_val, MAX_PATH, "%d", sRow.azimut); row.azimut = sz_val;

	math_e::LatitudeLongitudeToXY(sRow.lat, sRow.lon, row.x, row.y);

	char sz_type[MAX_PATH + 1] = {0};
	ETypeResult eTypeRes;
	std_string garage_num;
	SetRoute(sz_type, row.device_number, row.route, garage_num,  eTypeRes);
	
	row.type = sz_type; //YUIL 2017-01-30

	if (row.route.size() == 0)
	{
		FILE *fo;
		
		if (eTypeRes == ETR_NOT_FOUND_DEVICE)
		{
			fopen_s(&fo, csz_wialon_not_found_device, "ab");
			if (fo)
			{
				struct tm tm;
				if (time_e::GetCurLocalDateTime(tm))
				{
					fprintf(fo, "%04d-%02d-%02dT%02d:%02d:%02d ", tm.tm_year, tm.tm_mon, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
				}
				fprintf(fo, "device_name:'%s' pos_device_name:0x%X pos_posinfo:0x%X\r\n", sRow.device_name, sRow.i_pos_device_name, sRow.i_pos_posinfo);

				fclose(fo);

				_chmod(csz_wialon_not_found_device, _S_IREAD | _S_IWRITE);
			}
		}
		else
		if (eTypeRes == ETR_NOT_FOUND_ROUTE)
		{
			fopen_s(&fo, csz_wialon_not_found_route, "ab");

			if (fo)
			{
				struct tm tm;
				if (time_e::GetCurLocalDateTime(tm))
				{
					fprintf(fo, "%04d-%02d-%02dT%02d:%02d:%02d ", tm.tm_year, tm.tm_mon, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
				}
				fprintf(fo, "garage_num:'%s'\r\n", garage_num.c_str());

				fclose(fo);

				_chmod(csz_wialon_not_found_route, _S_IREAD | _S_IWRITE);
			}
		}
			

		if (eTypeRes == ETR_NOT_FOUND_DEVICE)
		{
			int k = 0;
			k++;
		}

		if (eTypeRes == ETR_NOT_FOUND_ROUTE)
		{
			int k = 0;
			k++;
		}
		return;
	}

	SaveToDB(row);
}

void CSockSrvWialon::SetRoute(char *sz_type, std_string& device_number, std_string& route, std_string& garage_num, ETypeResult& eTypeRes)
{	
	SATE3Row* pATE3Row;

	if (gATE3.GetLoadParam().FindByDevice(device_number.c_str(), &pATE3Row) == false) { eTypeRes = ETR_NOT_FOUND_DEVICE; return; }

	SFileBindCarRouteRow* pFileBindCarRouteRow; //if (gFileBindCarRoute.FindByGarageNum(pATE3Row->sz_garage_num.c_str(), &pFileBindCarRouteRow) == false) { return; }

	garage_num = pATE3Row->sz_garage_num;

	if (gFileBindCarRoute.FindByGarageNumAndType(pATE3Row->sz_garage_num.c_str(), sz_type, &pFileBindCarRouteRow) == false) { eTypeRes = ETR_NOT_FOUND_ROUTE; return; }

	route = pFileBindCarRouteRow->route;

	eTypeRes = ETR_FOUND;
}

void CSockSrvWialon::SaveToDB(SATE3RowStr& row, char* sz_id_agent)
{                                                                                          //EnterCriticalSection(&cs_CATE3L�oad_SaveToDB);
	if (row.device_number == "") { return; } //YUIL � ������ ������ ���������� �� �����


	char sz_val[MAX_PATH + 1];

	SZone s_zone;

	char sz_query[ci_socksrv_buf_len + 1]; 
	
	strcpy_s(sz_query, ci_socksrv_buf_len, "EXEC dbo.P_add_ate_3 @id_src=3, @device_number = N'"); 
	
	strcat_s(sz_query, ci_socksrv_buf_len, row.device_number.c_str());

	strcat_s(sz_query, ci_socksrv_buf_len, "', @latitude = ");

	strcat_s(sz_query, ci_socksrv_buf_len, row.latitude.c_str()); strcat_s(sz_query, ci_socksrv_buf_len, ", @longitude = "); 
	
	strcat_s(sz_query, ci_socksrv_buf_len, row.longitude.c_str()); strcat_s(sz_query, ci_socksrv_buf_len, ", @azimut = ");  
	
	strcat_s(sz_query, ci_socksrv_buf_len, row.azimut.c_str());

	strcat_s(sz_query, ci_socksrv_buf_len, ", @speed = "); 
	
	strcat_s(sz_query, ci_socksrv_buf_len, row.speed.c_str());

	sprintf_s(sz_val, MAX_PATH, ", @x = %f, @y = %f", row.x, row.y); 
	
	strcat_s(sz_query, ci_socksrv_buf_len, sz_val);

	if  (row.route.size())
	{ 
		strcat_s(sz_query, ci_socksrv_buf_len, ", @route_short_name = N'"); 
		
		strcat_s(sz_query, ci_socksrv_buf_len, row.route.c_str()); 
		
		strcat_s(sz_query, ci_socksrv_buf_len, "'");
		
		strcat_s(sz_query, ci_socksrv_buf_len, ", @route_en = N'"); strcat_s(sz_query, ci_socksrv_buf_len, GetTranslit((char*)row.route.c_str(), sz_val, MAX_PATH)); 
		
		strcat_s(sz_query, ci_socksrv_buf_len, "'"); //YUIL 2017-09-15 ������������������ ���� ��  �������� �������� ����� ��������. ������ : 18� => 18l, 18� => 18p, 42�=> 42a	
	}			

	strcat_s(sz_query, ci_socksrv_buf_len, ", @id_zone = ");

	if (gZones.FindXY(row.x, row.y, s_zone))
	{
		strcat_s(sz_query, ci_socksrv_buf_len, s_zone.id_zone.c_str());
	}
	else
	{
		strcat_s(sz_query, ci_socksrv_buf_len, "0");
	}

	if (sz_id_agent)
	{
		if (strlen(sz_id_agent))
		{
			strcat_s(sz_query, ci_socksrv_buf_len, ", @id_agent="); strcat_s(sz_query, ci_socksrv_buf_len, sz_id_agent);
		}
	}

	if (row.type.size()) //YUIL 2017-01-30
	{
		strcat_s(sz_query, ci_socksrv_buf_len, ", @id_car_type="); strcat_s(sz_query, ci_socksrv_buf_len, row.type.c_str());
	}

	strcat_s(sz_query, ci_socksrv_buf_len, ";;");

	if (strstr(sz_query, ";;") == 0)
	{
		gMesLog.Mes("CSockSrvWialon::SaveToDB. ������. � ������ SQL ������� ��� ����������");
		return;
	}

	//<a1
	static time_t time_prev = 0;
	time_t time = clock();
	if (time_prev==0 || (time - time_prev) > 3600000)
	{
		time_prev = time;
		unlink(csz_wialon_sql_query_save);
	}

	
	//>a1

	bool fExec = MSSQL_Exec((char*)sz_query, NULL, CSockSrvWialon_FN_MSSQL_MES_ERR, this);

	if (fExec==false)
	{
		FILE *fo = 0; fopen_s(&fo, csz_wialon_sql_query_save, "ab"); if (fo) { fprintf_s(fo, "%s\r\n", sz_query); fclose(fo); }
	}
	
	Sleep(m_sleep_after_save);
}

CSockSrvWialon gSockSrvWialon;