#include "files_check_points.h"
#include "file.h"

#include "mes_log.h"
#include "str.h"
#include <corecrt_io.h>
#include <string.h>

const int ci_FileCheckPoints_sleep = 1000;

const char* cs_FileCheckPoints_file[EFCP_QUANTITY]=
{
	"����������� ��������� �� ���� ���������.xlsx"
	,"����������� ��������� �� ��������.xlsx"
	,"����������� ��������� �� ������������.xlsx"
};

const char* cs_FileCheckPoints_mask[EFCP_QUANTITY]=
{
"C:\\transman\\FileCheckPoints\\���\\*.xlsx"
,"C:\\transman\\FileCheckPoints\\����\\*.xlsx"
,"C:\\transman\\FileCheckPoints\\����\\*.xlsx"
};

const char* cs_FileCheckPoints_path[EFCP_QUANTITY]=
{
"C:\\transman\\FileCheckPoints\\���"
,"C:\\transman\\FileCheckPoints\\����"
,"C:\\transman\\FileCheckPoints\\����"
};

const char * csz_FileCheckPoints_SQL_query= "C:\\transman\\FileCheckPoints_SQL_query.txt";
const char * csz_FileCheckPoints_SQL_query_err = "C:\\transman\\FileCheckPoints_SQL_query_err.txt";

const char * csz_FileCheckPoints_caption= "�������� ����������� �����";

void CFileCheckPoints_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	CFileCheckPoints* p_this=(CFileCheckPoints*)p_param;

	if (eState == EMSSQLS_START) { gMesLog.Mes("CFileCheckPoints(). MS SQL : ��� �����"); }
	else
	{
		if (p_this) { p_this->sql_err(sz_text); }
	}
}

void CFileCheckPoints::WriteSQLQueryErr(char *sz_text)
{
	FILE *fo = fopen(csz_FileCheckPoints_SQL_query_err, "ab");
	
	if (fo)
	{
		fprintf(fo, "%s: %s\r\n", sz_text, m_sz_query.c_str());

		fclose(fo);
	}
}

void CFileCheckPoints::sql_err(char *sz_text)
{
	WriteSQLQueryErr(sz_text);
	
	sz_text[32] = 0;

	std_string sz_full = csz_FileCheckPoints_caption; sz_full.append("."); sz_full.append(sz_text);

	gMesLog.Mes((char*)sz_full.c_str());
}

bool CFileCheckPoints::Open()
{
	m_fInit = false; //LoadFromDB();

	if (CrThread() == false) { return false; } //if (FindDriver() == false) { return false; }

	m_fInit = true;

	return m_fInit;
}


void CFileCheckPoints::Close() { }

DWORD WINAPI CFileCheckPoints_ThreadProc(LPVOID lpParameter)
{
	CFileCheckPoints *p_this = (CFileCheckPoints *)lpParameter;

	if (p_this == 0) { return 0; }

	while (1)
	{
		p_this->Read(EFCP_BUS); Sleep(300);
	 p_this->Read(EFCP_TRAM); Sleep(300);
		p_this->Read(EFCP_TROL); 

		Sleep(ci_FileCheckPoints_sleep);
	}

	return 1;
}


bool CFileCheckPoints::CrThread()
{
	HANDLE h=CreateThread(0, 0, CFileCheckPoints_ThreadProc, (LPVOID)this, 0, 0);

	return  h != 0;
}

/*char* CFileCheckPoints::get_sz_bat_file(std_string& sz_bat_file)
{
	if (m_eFile==EFCP_BUS) {sz_bat_file="unzip_0.bat";}  else
	if (m_eFile==EFCP_TRAM) {sz_bat_file="unzip_1.bat";}  else
	if (m_eFile==EFCP_TROL) {sz_bat_file="unzip_2.bat";} 

	return (char*)sz_bat_file.c_str();
}*/

void CFileCheckPoints::Read(EFileCheckPoints eFile)
{
	m_eFile=eFile;

	char *p_path= (char*)cs_FileCheckPoints_path[(int)eFile];

	//����� ����� ������ *.xlsx. ���� ���� �� ����� SXLSX
	//<q1
	_finddata_t fd;

	intptr_t hFile = _findfirst(cs_FileCheckPoints_mask[(int)eFile], &fd);

	if (hFile == -1) { return; }

	unlink(csz_FileCheckPoints_SQL_query);
	
	unlink(csz_FileCheckPoints_SQL_query_err);	

	//do
	{
		if (fd.attrib != _A_SUBDIR)
		{			
			int i_col_start = 0;

			//if (CheckFileName(fd.name)){
			int i_var=1; //YUIL 2017-10-27

			std_string sz_bat_file="";

			bool fRead = m_xlsx.Read(p_path, fd.name, i_col_start, i_var);

			if (fRead)
			{
				ReadedToFile();

				SaveToDB();	

			 char* a_file[1]= {fd.name};

   	CopyToArch(p_path, (char**) a_file, 1); //YUIL �������� � �����

				gMesLog.Mes("���� %s ��������. ������� : %d", fd.name, m_xlsx.m_rows.size());
			}else
			{
				gMesLog.Mes("CFileCheckPoints::Read(). ������ �������� ����� %s", fd.name);
			} //}
			
		}
	} //while (!_findnext(hFile, &fd));


	_findclose(hFile);
	//>q1

}

/*bool CFileCheckPoints::CheckFileName(char *sz_name)
{
	bool fFound=false;
	
	if (!stricmp(sz_name, cs_FileCheckPoints_file[EFCP_BUS])) {m_eFile=EFCP_BUS; fFound=true;} else
	if (!stricmp(sz_name, cs_FileCheckPoints_file[EFCP_TRAM])) {m_eFile=EFCP_TRAM; fFound=true;} else
	if (!stricmp(sz_name, cs_FileCheckPoints_file[EFCP_TROL])) {m_eFile=EFCP_TROL; fFound=true;} 

	return fFound;
}*/

void CFileCheckPoints::add_car_type(char* sz_type, int i_type_max)
{
	if (m_eFile==EFCP_BUS) {strcpy_s(sz_type, i_type_max, "2");} else
	if (m_eFile==EFCP_TRAM) {strcpy_s(sz_type, i_type_max,  "3");} else
	if (m_eFile==EFCP_TROL) {strcpy_s(sz_type, i_type_max,  "1");} else
	{gMesLog.Mes("������. CFileCheckPoints::add_car_type(). ����������� ��� ������.");}
}

bool CFileCheckPoints::CheckRoute(char *sz_in, std_string& route_short_name)
{
	if (sz_in == 0) { return false; }

	const char *p_find_num = strchr(sz_in, '�');

	if (p_find_num == 0) { return false; }

	char sz_val[MAX_PATH + 1]; strcpy_s(sz_val, MAX_PATH, p_find_num + 1);

	remove_first_last(sz_val, MAX_PATH, ' ');

	route_short_name = sz_val; //GetTranslit((char*)(p_find_num+1), sz_val, MAX_PATH);

	if (!stricmp(sz_val, "2"))
	{
		int i = 0;
		i++;
	}
	return true;

}

void CFileCheckPoints_P_add_check_point_add(void *p_param, FldsPtr fp)
{
	CFileCheckPoints* p_this = (CFileCheckPoints*)p_param;

	if (p_this) {p_this->P_add_check_point_add(fp);}
}

void CFileCheckPoints::P_add_check_point_add(FldsPtr fp)
{
	s_P_add_check_point_add.i_result=fp->Item["i_result"]->Value.intVal;

	_bstr_t bstr_car_type_name(fp->Item["car_type_name"]->Value);

	s_P_add_check_point_add.car_type_name=(char*)bstr_car_type_name;
}

void CFileCheckPoints::S_P_add_check_point_add::Mes(const char *route_short_name, const char *stop_code)
{
		if (i_result==1) 
		{gMesLog.Mes("%s. ��� ������:%s �������:%s. �� ������� ��������� %s", csz_FileCheckPoints_caption, car_type_name.c_str(), route_short_name, stop_code);} else
		if (i_result==2) 
		{gMesLog.Mes("%s. ��� ������:%s �������:%s. �� ������ �������", csz_FileCheckPoints_caption, car_type_name.c_str(), route_short_name);}
}


void CFileCheckPoints::S_P_add_check_point_add::Clear() {memset(this, 0, sizeof(CFileCheckPoints::S_P_add_check_point_add));}

void CFileCheckPoints::SaveToDB_in(std_string& route_short_name,  std_string& stop_code, std_string& name, bool f_forward, int i_order, char *sz_id_car_type)
{
	char sz_val[MAX_PATH + 1];	

	const int ci_sz_max_type = 2;

	char sz_type_car[ci_sz_max_type + 1];
	
	if (sz_id_car_type==0) { add_car_type(sz_type_car, ci_sz_max_type); } else {strcpy_s(sz_type_car, ci_sz_max_type, sz_id_car_type); }

 if (s_P_add_check_point_add.RouteIsReason(route_short_name,  sz_type_car)==false) {return;}

 m_sz_query="EXEC dbo.P_add_check_point @id_car_type="; 
	
	m_sz_query.append(sz_type_car);

	m_sz_query.append(", @route_short_name=N'"); m_sz_query.append(route_short_name.c_str()); 

	m_sz_query.append("', @route_short_name_translit=N'"); m_sz_query.append(GetTranslit((char*)route_short_name.c_str(), sz_val, MAX_PATH)); 			

	m_sz_query.append("', @stop_code=N'"); m_sz_query.append(stop_code.c_str()); m_sz_query.append("', @name=N'"); m_sz_query.append(name.c_str()); m_sz_query.append("', @f_forward="); 
		
	m_sz_query.append(f_forward ? "1" : "0"); 
	
	m_sz_query.append(", @i_order="); 
	
	sprintf_s(sz_val, MAX_PATH, "%d",i_order); //itoa(i_order, sz_val, 10); 
	
	m_sz_query.append(sz_val);

	FILE *fo=fopen(csz_FileCheckPoints_SQL_query, "wb");

	if (fo) { fprintf(fo,"%s\r\n",m_sz_query.c_str()); fclose(fo);}

	bool f_exec= MSSQL_Exec((char*)m_sz_query.c_str(), CFileCheckPoints_P_add_check_point_add, CFileCheckPoints_FN_MSSQL_MES_ERR, this);

	if (f_exec)
	{
		bool f_not_found= s_P_add_check_point_add.IsNotFound();
		
		if (f_not_found)
		{
			s_P_add_check_point_add.AddNotFound(route_short_name.c_str(), sz_type_car);

		 s_P_add_check_point_add.Mes(route_short_name.c_str(), stop_code.c_str());

		 WriteSQLQueryErr("�� ������: ");
		}		
		
		/*if (s_P_add_check_point_add.i_result==1) {gMesLog.Mes("%s. ���:%s �������:%s. �� ������� ��������� %s", csz_FileCheckPoints_caption, m_eFile==EFCP_BUS?"���":(m_eFile==EFCP_TRAM?"����":"����"), route_short_name.c_str(), stop_code.c_str());} else
		if (s_P_add_check_point_add.i_result==2) {gMesLog.Mes("%s. ���:%s �������:%s. �� ������ �������", csz_FileCheckPoints_caption, m_eFile==EFCP_BUS?"���":(m_eFile==EFCP_TRAM?"����":"����"), route_short_name.c_str());}*/
	}
}

bool CFileCheckPoints::S_P_add_check_point_add::FindNotFound(const char *route_short_name_in, const char *sz_type_car_in)
{
	for (int i=0; i<not_list.size(); i++)
	{
		S_P_add_check_point_add_item& o=not_list[i];

		if (o.route_short_name==route_short_name_in && o.id_car_type==sz_type_car_in) {return true;}
	}

	return false;
}

void CFileCheckPoints::S_P_add_check_point_add::AddNotFound(const char *route_short_name_in, const char *sz_type_car_in)
{
	if (FindNotFound(route_short_name_in, sz_type_car_in)) {return;}

	S_P_add_check_point_add_item o;
	
	o.route_short_name=route_short_name_in;

	o.id_car_type=sz_type_car_in;

	not_list.push_back(o);
}

bool CFileCheckPoints::S_P_add_check_point_add::RouteIsReason(std_string& route_short_name_in,  char *sz_type_car)
{	
	bool f_found= FindNotFound(route_short_name_in.c_str(), sz_type_car);

 return !f_found;
}

void CFileCheckPoints::SaveToDB_op(std_string& route_short_name,  std_string& stop_code, std_string& name, bool f_forward, int& i_order)
{
	bool fNum = IsNum((char*)stop_code.c_str());				

	if (fNum==false) {return;}

	SaveToDB_in(route_short_name,  stop_code, name, f_forward, i_order);

	if (m_eFile==EFCP_BUS)
	{
	 SaveToDB_in(route_short_name,  stop_code, name, f_forward, i_order, "4");
	}

	i_order++;
}

void CFileCheckPoints::set_id_car_type_del_query(std_string& sz_query)
{
	if (m_eFile==EFCP_BUS) {sz_query.append("2,4");} else
	if (m_eFile==EFCP_TRAM) {sz_query.append("3");} else
	if (m_eFile==EFCP_TROL) {sz_query.append("1");} 
}

bool CheckCompleteRow(SXLSXRow& row)
{
	int q=row.list.size();

	if (q==0) {return false;}

	int i_index=1;

	if (i_index>=q) {i_index=q-1;}

	return row.list[i_index].size()!=0;
}

void CFileCheckPoints::ReadedToFile()
{
	FILE *fo = fopen("C:\\transman\\FileCheckPoints\\readed.txt", "wb");

	if (fo == 0) { gMesLog.Mes("CFileCheckPoints::ReadedToFile(). ������ �������� �����"); return; }

	int q = m_xlsx.m_rows.size();

	for (int i = 0; i < m_xlsx.m_rows.size(); i++)
	{
		SXLSXRow& row = m_xlsx.m_rows[i];

		std::vector<std_string>& list = row.list;

		int qL = list.size();

		for (int k = 0; k < qL; k++)
		{
			fprintf(fo, "%s\t", list[k].c_str());
		}		
		fprintf(fo, "\r\n");
	}

	fclose(fo);
}

void CFileCheckPoints::SaveToDB()
{
	m_sz_query="DELETE FROM dbo.check_points WHERE id_picas_stop IS NOT NULL AND id_car_type IN ("; set_id_car_type_del_query(m_sz_query); m_sz_query.append(")");

	bool f_exec= MSSQL_Exec((char*)m_sz_query.c_str(), NULL, CFileCheckPoints_FN_MSSQL_MES_ERR, this); //YUIL 2017-10-26 .������ �������

	s_P_add_check_point_add.Clear();

	std_string route_short_name="";
	int i_order;
	bool f_forward;

	typedef enum {ES_ROUTE=0, ES_DIR_FOR, ES_DIR_BACK} EStep; //�� ��� ������

	EStep eStep=ES_ROUTE; //char sz_val[MAX_PATH + 1];

	int q = m_xlsx.m_rows.size();
	
	int q_sz_dir;

	for (int i = 0; i < m_xlsx.m_rows.size(); i++)
	{
		SXLSXRow& row= m_xlsx.m_rows[i];

		std::vector<std_string>& list = row.list;

		int qL = list.size();

		if (qL==0) {continue;}

		int sum_q = 0;
		
		for (int i = 0; i < qL; i++)
		{
			sum_q += list[i].size();
		}

		if (sum_q == 0) { continue; }
		
		if (eStep==ES_ROUTE)
		{
			char *p = (char*)list[0].c_str(); 

			if (CheckRoute(p, route_short_name))
			{
			 eStep=ES_DIR_FOR;
				f_forward=true;
				i_order=0;
				q_sz_dir = 0;
			}
		}else
		if (eStep==ES_DIR_FOR)
		{
			int len_0 = list[0].size();

			if (len_0)
			{
				if (strchr(list[0].c_str(), '�')) { continue; }
			}

			int len_1 = list[1].size();
			bool f_data = len_0 == 0 && len_1;
			int i_shift = 0;

			if (f_data == false)
			{
				int len_2 = list[2].size();
				f_data = len_1 == 0 && len_2;
				if (f_data) { i_shift++; }
			}

			if (f_data)
			{
				SaveToDB_op(route_short_name, list[1+ i_shift], list[2+ i_shift], f_forward, i_order);
			}
			else
			{
				if (q_sz_dir == 1)
				{
					q_sz_dir = 0;
					eStep = ES_DIR_BACK;
					f_forward = false;
					i_order = 0;
				}
				else
				{ q_sz_dir++; }				
			}                        //bool f_data = CheckCompleteRow(row); if (f_data) {} else {}
		}else
		if (eStep == ES_DIR_BACK)
		{
			int len_0 = list[0].size();
			int len_1 = list[1].size();
			bool f_data = len_0 == 0 && len_1;
			int i_shift = 0;

			if (f_data == false)
			{
				int len_2 = list[2].size();
				f_data = len_1 == 0 && len_2;
				if (f_data) { i_shift++; }
			}

			if (f_data)
			{
				SaveToDB_op(route_short_name, list[1+ i_shift], list[2+ i_shift], f_forward, i_order);
			}
			else
			{
				eStep = ES_ROUTE;
				i--;
			}
		}

	}
	
}



CFileCheckPoints gFileCheckPoints;