#include <memory.h>
#include <io.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "chat.h"
#include "..\\transman\\ini_file.h"
#include "mes_log.h"
#include "main.h"
#include <Wininet.h>
#include "sock_client.h"

const int ci_Chat_sleep = 700;

void CChat_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	CChat* p_this=(CChat*)p_param;
	
	if (eState == EMSSQLS_START) { gMesLog.Mes("MS SQL : ��� �����"); } 
	else
	{
		if (p_this) { p_this->sql_err(sz_text); }
	}
}

void CChat::sql_err(char *sz_text)
{
	char sz_val[MAX_PATH + 1];	
	std_string sz_full = "CChat. "; 
	sz_full.append(m_sz_query_index);
	sz_full.append(sz_text);


	gMesLog.Mes((char*)sz_full.c_str());
}

CChat::CChat()
{
	memset(this, 0, sizeof(CChat));
	
	m_fInit=true;
}

CChat::~CChat() {}

DWORD WINAPI CChat_main(LPVOID lpParameter)
{
	CChat *p_this = (CChat*)lpParameter;

	if (p_this == 0) { return 0; }

	while (1)
	{
		p_this->Load();

		Sleep(ci_Chat_sleep);
	}

	return 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool CChat::Open()
{
	if (m_fInit == false) { return false; }

	ReadIni();

	DWORD dThreadId;
	HANDLE h = CreateThread(0, 0, CChat_main, (LPVOID)this, 0, &dThreadId);
	return h != 0;
}

void CChat::ReadIni()
{
	CIniFile ini; //m_sz_addr_send = "http://192.168.100.36/chat/send/index.php";//char sz_val[MAX_PATH + 1];

	if (ini.Get("C:\\transman\\transman.ini", "chat_srv_send", m_sz_addr_send, MAX_PATH)==false)
	{
		gMesLog.Mes("CChat::ReadIni(). �� ������ �������� chat_srv_send (����� http ��� ������ send) � transman.ini");
	}	
}

void CChat_add(void *p_param, FldsPtr fp)
{
	CChat* p_this = (CChat*)p_param;

	if (p_this) {p_this->add(fp);}
}

void CChat::add(FldsPtr fp)
{
	_bstr_t bstr_id_chat_mes_head(fp->Item["id_chat_mes_head"]->Value);
	_bstr_t bstr_dt_create(fp->Item["dt_create"]->Value);	
	_bstr_t bstr_id_user_from(fp->Item["id_user_from"]->Value);
	_bstr_t bstr_id_user_to(fp->Item["id_user_to"]->Value);
	_bstr_t bstr_id_chat_mes_type(fp->Item["id_chat_mes_type"]->Value); //_bstr_t bstr_dt_create_src(fp->Item["dt_create_src"]->Value);
	

	m_head.id_chat_mes_head = (char*)bstr_id_chat_mes_head;
	m_head.dt_create= (char*)bstr_dt_create;	
	m_head.id_user_from = (char*)bstr_id_user_from;
	m_head.id_user_to = (char*)bstr_id_user_to;
	m_head.id_chat_mes_type = (char*)bstr_id_chat_mes_type;	//m_head.dt_create_src = (char*)bstr_dt_create_src;

	m_f_data_to_trans_exists=true;
}

void CChat_add_step_2(void *p_param, FldsPtr fp)
{
	CChat* p_this = (CChat*)p_param;

	if (p_this) {p_this->add_step_2(fp);}
}

void CChat::add_step_2(FldsPtr fp)
{
	_bstr_t bstr_mes(fp->Item["mes"]->Value);

	std_string sz_mes=(char*)bstr_mes;
	
	HttpPost(m_head.id_user_from.c_str(), m_head.id_user_to.c_str(), sz_mes.c_str());
}

void CChat::HttpPost(const char* id_user_from, const char* id_user_to, const char* sz_mes)
{
	const int ci_max_data = 1024;

	char sz_data[ci_max_data + 1] = { 0 };
	
	strcat_s(sz_data, ci_max_data, "from=");
	
	strcat_s(sz_data, ci_max_data, id_user_from); 
	
	strcat_s(sz_data, ci_max_data, "&to="); 
	
	strcat_s(sz_data, ci_max_data, id_user_to); 
	
	strcat_s(sz_data, ci_max_data, "&message="); 
	
	strcat_s(sz_data, ci_max_data, sz_mes ? sz_mes : "<none>");

	strcat_s(sz_data, ci_max_data, "&date="); 
	
	strcat_s(sz_data, ci_max_data, m_head.dt_create.c_str());
	
	strcat_s(sz_data, ci_max_data, "&id="); 
	
	strcat_s(sz_data, ci_max_data, m_head.id_chat_mes_head.c_str());	
	
	strcat_s(sz_data, ci_max_data, "&type="); 
	
	strcat_s(sz_data, ci_max_data, m_head.id_chat_mes_type.c_str());	

	strcat_s(sz_data, ci_max_data, "\0");

	char rec_buf[MAX_PATH+1]={0};

	bool f_send = http_send_enc_data(m_sz_addr_send, "POST", sz_data, rec_buf, MAX_PATH); //YUIL 2018-01-17 "http://192.168.100.36/chat/send/index.php". ���� : http://192.168.0.102/chat/send/index.php

	if (f_send)
	{
		S_HTTP_answer a;

		bool f_parse= parse_http_answer(rec_buf, MAX_PATH, a);

		if (f_parse)
		{
			if (a.result_code.size())
			{
				int i_result_code = atoi(a.result_code.c_str());

				if (i_result_code == 200)
				{
					//������ ������  ��������� �� 2
					ChStatusChatMes();
				}

				FILE *fo = fopen("C:\\transman\\chat\\http_answer.txt", "wb");
				if (fo)
				{
					fprintf(fo, "r\n%s", rec_buf);
					fclose(fo);
				}
			}
			else
			{
				static time_t time_prev = 0;
				time_t time_delta = 100000;

				mes_by_time(time_prev, time_delta, "CChat::HttpPost(). Error : empty result_code\n");
			}
		}
	}
}

void CChat::ChStatusChatMes()
{
	std_string sz_query="UPDATE dbo.chat_mes_head SET id_chat_mes_state=2, dt_send_to_srv=GETDATE() WHERE id_chat_mes_head="; 
	
	sz_query.append(m_head.id_chat_mes_head);

	m_sz_query_index = "1 ";

	bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), 0, CChat_FN_MSSQL_MES_ERR, this);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void CChat::Load()
{
	m_f_data_to_trans_exists = false;

	std_string sz_query="EXEC dbo.P_get_new_chat_mes_head_from_disp_to_coll";
	
	m_sz_query_index = "2 ";

	bool f_step_1= MSSQL_Exec((char*)sz_query.c_str(), CChat_add, CChat_FN_MSSQL_MES_ERR, this);

	if (m_f_data_to_trans_exists == false) {return;}

	if (f_step_1)
	{
		if (m_head.id_chat_mes_type == "1"  || m_head.id_chat_mes_type == "5")
		{
			sz_query = "SELECT mes FROM dbo.chat_mes WHERE id_chat_mes_head="; sz_query.append(m_head.id_chat_mes_head); sz_query.append(" ORDER BY id_chat_mes");

			m_sz_query_index = "3 ";

			bool f_step_2 = MSSQL_Exec((char*)sz_query.c_str(), CChat_add_step_2, CChat_FN_MSSQL_MES_ERR, this);
		}
		else
		{
			HttpPost(m_head.id_user_from.c_str(), m_head.id_user_to.c_str(), "<none>");
		}
	}

}

CChat gChat;