#pragma once

#include <windows.h> 
#include <string>
#include <vector>
#include "std_str.h"

typedef enum
{
	ELXLSX_SHARED_STRINGS = 0,
	ELXLSX_SHEET1,
	//
	ELXLSX_QUANTITY,
}ELXLSXFile;

typedef enum
{
	ELXLSXC_NONE = 0,
	ELXLSXC_DIRECT,
	ELXLSXC_SHARED_STRING,
}ELXLSXCol;

struct SXLSXRow
{
	std::vector<std_string> list;
};


struct SXLSX
{
	ELXLSXFile m_eFile;
	bool m_f_shared_string;
	ELXLSXCol m_eCol;
	bool m_f_col;
	
	bool m_f_row;
	bool m_f_val;
	
	SXLSXRow m_row;

	int m_q_in_rows;
	int m_q_in_cols;
	int m_i_col_start;

	int m_i_var; //YUIL 2017-10-27 ������ ��������� . ������� ���������.

	std::vector<std_string>  m_shared_strings;
	std::vector<SXLSXRow>  m_rows;

	char m_sz_path_UNZIP[MAX_PATH + 1];

	void ReadTag(int index, char *sz_text, int len_text);
	
	bool Read(char *sz_path, char *sz_file_only, int i_col_start=0, int i_var=0, char *sz_bat_file="unzip_xlsx.bat");

	void ReadOutTag(char *sz_text, int len_text);
	void SetRowField(char *sz_text);
	void Add(const SXLSXRow& row);

	void ClearFolder();
};



