#include <memory.h>
#include "sock_client.h"
#include "mes_log.h"

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>

#include <iostream>
#include <sstream>
#include <string>
#include <time.h>
 
using std::cout;
using std::endl;

// Need to link with Ws2_32.lib, Mswsock.lib, and Advapi32.lib
#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "Mswsock.lib")
#pragma comment (lib, "AdvApi32.lib")


#define DEFAULT_BUFLEN 512
//#define DEFAULT_PORT "27015"

//CSockClient::CSockClient(){memset(this, 0, sizeof(CSockClient));m_fInit=true;}CSockClient::~CSockClient(){}

bool sock_send(const char *sz_server, const char *sz_port, char *sz_mes, char* rec_buf, int i_size_rec_buf)
{
    WSADATA wsaData;
    SOCKET ConnectSocket = INVALID_SOCKET;
    struct addrinfo *result = NULL,
                    *ptr = NULL,
                    hints;
    int iResult;

// Initialize Winsock
iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);

if (iResult != 0) { gMesLog.Mes("sock_send(). WSAStartup failed with error: %d\n", iResult); return false; }

ZeroMemory(&hints, sizeof(hints));
hints.ai_family = AF_INET; //AF_UNSPEC;
hints.ai_socktype = SOCK_STREAM;
hints.ai_protocol = IPPROTO_TCP;

// Resolve the server address and port
iResult = getaddrinfo(sz_server, sz_port, &hints, &result);
if (iResult != 0) { gMesLog.Mes("sock_send(). getaddrinfo failed with error: %d\n", iResult); WSACleanup(); return false; }


ConnectSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
if (ConnectSocket == INVALID_SOCKET) { gMesLog.Mes("sock_send(). socket failed with error: %ld\n", WSAGetLastError()); WSACleanup(); return false; }

iResult = connect(ConnectSocket, result->ai_addr, (int)result->ai_addrlen);
if (iResult == SOCKET_ERROR)
{
	static time_t time_prev = 0;
	time_t time = clock();
	time_t delta_time = 300000;
	if (time_prev == 0 || (time - time_prev) > delta_time)
	{
		gMesLog.Mes("sock_send(). connect() fail: %d\n", WSAGetLastError());
		time_prev = time;
	}
	closesocket(ConnectSocket); WSACleanup();	return false;
}

/*
// Attempt to connect to an address until one succeeds
for(ptr=result; ptr != NULL ;ptr=ptr->ai_next)
{
				// Create a SOCKET for connecting to server
				ConnectSocket = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);

				if (ConnectSocket == INVALID_SOCKET) { gMesLog.Mes("sock_send(). socket failed with error: %ld\n", WSAGetLastError()); WSACleanup(); return false; }

				// Connect to server.
				iResult = connect( ConnectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);

				if (iResult == SOCKET_ERROR) { gMesLog.Mes("sock_send(). connect failed with error: %d\n", WSAGetLastError()); closesocket(ConnectSocket);ConnectSocket = INVALID_SOCKET;  continue; }

				break;
}*/

freeaddrinfo(result);

if (ConnectSocket == INVALID_SOCKET) { gMesLog.Mes("sock_send(). Unable to connect to server!\n"); WSACleanup(); return false; }

// Send an initial buffer
iResult = send(ConnectSocket, sz_mes, (int)strlen(sz_mes), 0);

if (iResult == SOCKET_ERROR) { gMesLog.Mes("sock_send(). send failed with error: %d\n", WSAGetLastError()); closesocket(ConnectSocket); WSACleanup(); return false; }

printf("Bytes Sent: %ld\n", iResult);

// shutdown the connection since no more data will be sent
iResult = shutdown(ConnectSocket, SD_SEND);

if (iResult == SOCKET_ERROR) { gMesLog.Mes("sock_send(). shutdown failed with error: %d\n", WSAGetLastError()); closesocket(ConnectSocket); WSACleanup(); return false; }

// Receive until the peer closes the connection
int i_max_cycle = 3;
int i_cycle = 0;
do
{

	iResult = recv(ConnectSocket, rec_buf, i_size_rec_buf, 0);
	if (iResult > 0) { gMesLog.Mes("sock_send(). Bytes received: %d\n", iResult); }
	else
		if (iResult == 0)
		{
			static time_t time_prev = 0;
			time_t time_delta = 100000;

			mes_by_time(time_prev, time_delta, "sock_send(). Connection closed\n");

			/*time_t time = clock();

			if (time_prev == 0 || (time - time_prev) > time_delta)
			{
				gMesLog.Mes("sock_send(). Connection closed\n");

				time_prev = time;
			}*/
		}
		else
		{
			gMesLog.Mes("sock_send(). recv failed with error: %d\n", WSAGetLastError());
		}
	i_cycle++;
} while (iResult > 0 && i_cycle<= i_max_cycle);

// cleanup
closesocket(ConnectSocket);
WSACleanup();


return true;
}

void mes_by_time(time_t& time_prev, time_t time_delta, char *sz_text)
{
	time_t time = clock();

	if (time_prev == 0 || (time - time_prev) > time_delta)
	{
		gMesLog.Mes(sz_text);

		time_prev = time;
	}
}

/*
	std_string sz_data="from="; sz_data.append(to - ���� (string) ���� user_name �� ������� users
message"";

	std_string sz_enc_data = http_encode("from=
to - ���� (string) ���� user_name �� ������� users
message");
*/

void urlencode(char *s, char *e, int i_e_max) //YUIL 2017-11-02 from http://www.zedwood.com/article/cpp-urlencode-function
{
    static const char lookup[]= "0123456789abcdef";
				
				int length = strlen(s);
				
				int k = 0;

    for(int i=0, ix=length; i<ix; i++)
    {
        const char& c = s[i];
        if ( (48 <= c && c <= 57) ||//0-9
             (65 <= c && c <= 90) ||//abc...xyz
             (97 <= c && c <= 122) || //ABC...XYZ
             (c=='-' || c=='_' || c=='.' || c=='~' || c=='=' || c=='&') //YUIL . add '=', '&'
        )
        {
									
         e[k]=c; k++;
        }
        else
        {									
									e[k] = '%'; k++;
									e[k] = lookup[(c & 0xF0) >> 4]; k++;
									e[k] = lookup[ (c&0x0F) ]; k++;
        }

								if (k >= i_e_max) { break; }
    }
}

//������ �������� ������ HTTP: 
//param_1=val_1&param_2=val_2
bool http_send_enc_data(const char *sz_addr, const char *sz_method, char* sz_mes, char* rec_buf, int i_size_rec_buf) //sz_mes : ���������� ��� �� �������������� ������ � ������������ � �������� HTTP
{
	const int ci_max_data = 1024;

	char sz_enc_mes[ci_max_data + 1] = { 0 };

	urlencode(sz_mes, sz_enc_mes, ci_max_data);

	return http_send(sz_addr, sz_method, sz_enc_mes, rec_buf, i_size_rec_buf);
}

bool http_send(const char *sz_addr, const char *sz_method, char *sz_mes, char* rec_buf, int i_size_rec_buf) //sz_mes : ���������� ��� �������������� ������ � ������������ � �������� HTTP
{
	const int ci_max_full = 1024;
	//sample: 
 //http://192.168.0.102/chat/send/index.php

	const char *csz_http= "http://";
 const int ci_len_http= strlen(csz_http);

	if (strcmp(sz_method, "POST")) {return false;}

	const char *p_http = strstr(sz_addr, csz_http);

	if  (p_http==0) {return false;}

	const char *p_server = strstr(p_http + ci_len_http,   "/");

	char sz_server[MAX_PATH+1];

	if (p_server==0) 
	{ 
		strcpy_s(sz_server, MAX_PATH, p_http + ci_len_http);
	}
	else
	{
		int i_len_server = strlen(p_http + ci_len_http) - strlen(p_server);

		memcpy(sz_server, p_http + ci_len_http, i_len_server); sz_server[i_len_server]=0;
	}

	int len_mes = strlen(sz_mes);

	char sz_val[MAX_PATH+1];

	//<q1 ������ �����
	char sz_full[ci_max_full + 1] = {0};
	strcat_s(sz_full, ci_max_full, sz_method); 
	strcat_s(sz_full, ci_max_full, " "); 
	strcat_s(sz_full, ci_max_full, sz_addr); 
	strcat_s(sz_full, ci_max_full, " HTTP/1.0\r\n");
	strcat_s(sz_full, ci_max_full, "Host: "); 
	strcat_s(sz_full, ci_max_full, sz_server); 
	strcat_s(sz_full, ci_max_full, "\r\n");
	strcat_s(sz_full, ci_max_full, "Referer: "); 
	strcat_s(sz_full, ci_max_full, sz_server); 
	strcat_s(sz_full, ci_max_full, "\r\n");
	strcat_s(sz_full, ci_max_full, "Content-Type: application/x-www-form-urlencoded\r\n");
	strcat_s(sz_full, ci_max_full, "Content-Length: "); itoa(len_mes, sz_val, 10); 
	strcat_s(sz_full, ci_max_full, sz_val); 
	strcat_s(sz_full, ci_max_full, "\r\n");
	strcat_s(sz_full, ci_max_full, "\r\n");
	strcat_s(sz_full, ci_max_full, sz_mes);
	strcat_s(sz_full, ci_max_full, "\0");
	/*sz_full.append(sz_method); sz_full.append(" "); sz_full.append(sz_addr); sz_full.append(" HTTP/1.0\r\n");
 sz_full.append("Host: "); sz_full.append(sz_server); sz_full.append("\r\n");
 sz_full.append("Referer: "); sz_full.append(sz_server); sz_full.append("\r\n");
 sz_full.append("Content-Type: application/x-www-form-urlencoded\r\n");
 sz_full.append("Content-Length: "); itoa(len_mes,  sz_val, 10); sz_full.append(sz_val); sz_full.append("\r\n");
 sz_full.append("\r\n");
 sz_full.append(sz_mes);*/
	//>q1

	FILE *fo=fopen("C:\\transman\\chat\\http_send.txt", "wb");
	if (fo)
	{
		fprintf(fo,"%s\r\n", sz_full);
		fclose(fo);
	}


	return sock_send((const char*) sz_server, (const char*)"80\0", sz_full, rec_buf, i_size_rec_buf);
}

bool parse_http_answer_word(char *sz, S_HTTP_answer& a,  int& q_word)
{
	if  (q_word==0)
	{
		a.protocol=sz;
	}else
	if  (q_word==1)
	{
		a.result_code=sz;
	}else
	if  (q_word==2)
	{
		a.result_word=sz;
	}

	q_word++;

	return true;
}

bool parse_http_answer_row(char *sz, S_HTTP_answer& a, int& q_word)
{
	int i_pos=0;
	
	

	for (int i=0; sz[i]; i++)
	{
		char c=sz[i];
		
		if (c==' ' || sz[i+1]==0)
		{
			int i_size= i-i_pos;

			int i_shift=0;

			if (!(c==' ') && sz[i+1]==0) {i_size++; i_shift=1;}

			if (i_size)
			{
				char ch=sz[i+i_shift]; sz[i+i_shift]=0;

				parse_http_answer_word((sz+i_pos), a,  q_word);				

				sz[i+i_shift]=ch;
			}

			i_pos=i+1;
		}
	}
 
	return true;
}

/*
HTTP/1.1 200 OK
Date: Thu, 02 Nov 2017 15:16:29 GMT
Server: Apache
Content-Length: 0
Connection: close
Content-Type: text/html; charset=UTF-8
*/
bool parse_http_answer(char *sz, int i_len, S_HTTP_answer& a)
{
	if (sz==0 || i_len==0) {return false;}
 
	int i_pos=0;
	int q_word=0;

	for (int i=0; i<i_len && sz[i]; i++)
	{
		char c=sz[i];
		
		if (c==13 || c==10 || i+1==i_len || sz[i+1]==0)
		{
			int i_size= i-i_pos;

			int i_shift=0;

			if (!(c==13 || c==10) && (i+1==i_len || sz[i+1]==0)) {i_size++; i_shift=1;}

			if (i_size)
			{
				char ch=sz[i+i_shift]; sz[i+i_shift]=0;

				parse_http_answer_row((sz+i_pos), a, q_word);				

				sz[i+i_shift]=ch;
			}

			i_pos=i+1;
		}
	}

	return true;
}