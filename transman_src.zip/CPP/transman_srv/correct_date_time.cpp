#include <memory.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "correct_date_time.h"

SDate::SDate() { Clear(); }

void SDate::Clear() { memset(this, 0, sizeof(SDate)); }

STime::STime() { Clear(); }

void STime::Clear() { memset(this, 0, sizeof(STime)); }

/*char* CorrectDate(char*sz_in, SDate* p_date)
{
	const int ci_max_out = 9;

	static char sz_out[ci_max_out + 1];

	sz_out[0] = 0;

	int m= 0;

	try
	{
		//YUIL  2017-09-07 valid  format  : YYYY-MM-DD
		//                                  0123456789 
		typedef enum { EP_Y = 0, EP_M, EP_D }EPart;

		char sz_val[4 + 1];

		int i_cnt_divider = 0;

		const char cc_devider = '-';

		const char *csz_devider = "-";

		for (int i = 0; sz_in[i]; i++)
		{
			if (sz_in[i] == cc_devider) { i_cnt_divider++; }
		}

		//<q0
		if (i_cnt_divider < 2)
		{
			return "0000-00-00";
		}
		//>q0

		EPart ePart = EP_Y;

		int i_pos = 0;

		for (int i = 0; sz_in[i]; i++)
		{
			if (sz_in[i] == cc_devider || sz_in[i + 1] == 0)
			{
				int i_size = i - i_pos;

				int i_shift = 0;

				if (sz_in[i] != cc_devider && sz_in[i + 1] == 0) { i_size++; i_shift = 1; }

				int val = -1;

				if (i_size)
				{
					char ch = sz_in[i + i_shift]; sz_in[i + i_shift] = 0;

					val = atoi(sz_in + i_pos);

					sz_in[i + i_shift] = ch;
				}

				if (val < 0) { break; }

				itoa(val, sz_val, 10);

				int i_val_len = strlen(sz_val);

				if (ePart == EP_Y)
				{
					if (i_val_len < 4)
					{
						for (int k = 0; k < 4 - i_val_len; k++) 
						{ 
							sz_out[m] = '0'; //strcat_s(sz_out, ci_max_out, "0"); 
							m++; 
						}						
					}

					strcat_s(sz_out, ci_max_out, sz_val);  m+= i_val_len;

					if (p_date) { p_date->year = val; }

					ePart = EP_M;
				}
				else
					if (ePart == EP_M)
					{
						if (val > 11) { val = 11; }

						strcat_s(sz_out, ci_max_out, csz_devider); m++;

						if (val < 10)
						{
							sz_out[m] = '0'; // strcat_s(sz_out, ci_max_out, "0");
							m++;
						}

						strcat_s(sz_out, ci_max_out, sz_val); m += i_val_len;

						if (p_date) { p_date->month = val; }

						ePart = EP_D;
					}
					else
						if (ePart == EP_D)
						{
							if (val > 31) { val = 31; }

							strcat_s(sz_out, ci_max_out, csz_devider); m++;

							if (val < 10)
							{
								sz_out[m] = '0'; // strcat_s(sz_out, ci_max_out, "0");
								m++;
							}

							strcat_s(sz_out, ci_max_out, sz_val); m += i_val_len;

							if (p_date) { p_date->day = val; }

							break;
						}

				i_pos = i + 1;
			}
		}

	}
	catch (...)
	{
		strcpy_s(sz_out, ci_max_out, sz_in);
	}

	return sz_out;
}*/

void ChOverIntVal(int& val, int max, ECorrectTimeOverAlg eAlg)
{
	if (val > max) 
	{ 
		if (eAlg == ECTOA_NULL) { val = 0; } else
		if (eAlg == ECTOA_MINUS) { val -= max; } 
	}
}

char* CorrectTime(char*sz_in, int i_max, STime* p_time, ECorrectTimeOverAlg eCorrectTimeOverAlg)
{
	//YUIL  2017-09-07 valid  format  : HH:MM:SS
	//                                  01234567 
	if (strlen(sz_in)==0) {return 0;}

	typedef enum { EP_H=0, EP_M, EP_S}EPart;

	const int ci_out_max = 30;

	static char sz_out[ci_out_max + 1];

	char sz_val[ci_out_max + 1];

	int i_cnt_divider = 0;

	for (int i = 0; sz_in[i]; i++)
	{
		if (sz_in[i] == ':') { i_cnt_divider++; }
	}

	//<q0
	if (i_cnt_divider < 2)
	{
		if (sz_in[2] == ':' && sz_in[5] != ':')
		{
			//������� 

			memcpy(sz_out, sz_in + 0, 5); sz_out[5] = 0;

			strcat_s(sz_out, ci_out_max,  ":");

			strcat_s(sz_out, ci_out_max, sz_in + 5);

			strcpy_s(sz_in, i_max, sz_out);
		}
		else 
		{ return "00:00:00"; }
	}
	//>q0

	EPart ePart = EP_H;
	int i_pos = 0;


	sz_out[0] = 0;

	for (int i = 0; sz_in[i]; i++)
	{
		if (sz_in[i] == ':' || sz_in[i + 1] == 0)
		{
			int i_size = i - i_pos;
			
			int i_shift = 0;

			if (sz_in[i] != ':' && sz_in[i + 1] == 0) { i_size++; i_shift = 1;}

			int val = -1;

			if (i_size)
			{
				memcpy(sz_val, sz_in+i_pos, i_size); sz_val[i_size]=0; //char ch = sz_in[i+ i_shift]; sz_in[i + i_shift]=0;
				
				val = atoi(sz_val); //sz_in+i_pos); //sz_in[i + i_shift] = ch;				
			}

			if (val < 0) { break; }
			
			itoa(val, sz_val, 10);

			if (ePart == EP_H)
			{
				ChOverIntVal(val, 23, eCorrectTimeOverAlg);
				/*
				if (val > 23) 
				{ 
					if (eCorrectTimeOverAlg == ECTOA_NULL) { val=0; } else
					if (eCorrectTimeOverAlg == ECTOA_MINUS) { val-=23; } 
				}*/

				if (val < 10) { strcat_s(sz_out, ci_out_max, "0"); }
				
				itoa(val, sz_val, 10);  

				strcat_s(sz_out, ci_out_max, sz_val);
				
				if (p_time) { p_time->hour = val; }

				ePart = EP_M;
			}else
			if (ePart == EP_M)
			{
				ChOverIntVal(val, 59, eCorrectTimeOverAlg);
				
				/*if (val > 59) 
				{ 
					if (eCorrectTimeOverAlg == ECTOA_NULL) { val=0; } else
					if (eCorrectTimeOverAlg == ECTOA_MINUS) { val-=59; } 
				}*/

				strcat_s(sz_out, ci_out_max, ":");

				if (val < 10) { strcat_s(sz_out, ci_out_max, "0"); }

				itoa(val, sz_val, 10);  

				strcat_s(sz_out, ci_out_max, sz_val);
				
				if (p_time) { p_time->minute = val; }

				ePart = EP_S;
			}
			else
			if (ePart == EP_S)
			{				
				ChOverIntVal(val, 59, eCorrectTimeOverAlg); //if (val > 59) { val -= 59; }

				strcat_s(sz_out, ci_out_max, ":");

				if (val < 10) { strcat_s(sz_out, ci_out_max, "0"); }

				itoa(val, sz_val, 10);  

				strcat_s(sz_out, ci_out_max, sz_val);
				
				if (p_time) { p_time->second = val; }

				break;
			}

			i_pos = i+1;
		}
	}                              

	return sz_out;
}
