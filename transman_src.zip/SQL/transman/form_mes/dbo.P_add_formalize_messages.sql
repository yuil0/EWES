ALTER PROC dbo.P_add_formalize_messages (@route_id NVARCHAR(32)) 
AS -- D:\users\yuil\JOB\EWES\SQL\transman\form_mes\dbo.P_add_formalize_messages
----------------------------------------------------
SET NOCOUNT ON;

DECLARE @dt DATETIME; SET @dt = GETDATE() --'2017-12-06T10:00:00'--;

DECLARE @valid_dev_sec INT, @stop_radius FLOAT, @valid_dev_sto_car_minutes INT; 

SELECT @valid_dev_sec = valid_dev_sec, @stop_radius = stop_radius, @valid_dev_sto_car_minutes = valid_dev_sto_car_minutes FROM dbo.const

DECLARE @time TIME; SET @time = dbo.FN_get_time(@dt);
--DECLARE @time_hi TIME; SET @time = DATEADD(second, 10, @time);
--DECLARE @time_lo TIME; SET @time_lo = DATEADD(second, - @valid_dev_sec, @time);

DECLARE @s AS TABLE(i BIGINT IDENTITY(1, 1), id_picas_stop BIGINT, id_ate_3 BIGINT, id_picas_route BIGINT)

INSERT @s(id_picas_stop, id_ate_3, id_picas_route)
SELECT    id_picas_stop, id_ate_3, id_picas_route FROM 
(SELECT id_picas_stop, s.id_ate_3, ROW_NUMBER() OVER (PARTITION BY id_ate_3 ORDER BY dist) i_order_dist, id_picas_route FROM 
 (SELECT id_picas_stop, s.id_ate_3, dbo.FN_get_dist(stop_x, stop_y, c.x, c.y) dist, id_picas_route FROM 
  (SELECT id_picas_stop, arrival_time_o, departure_time_o, dbo.FN_get_near_car(s.route_id, stop_x, stop_y) id_ate_3, stop_x, stop_y, id_picas_route FROM
   (SELECT s.id_picas_stop
    ,DATEADD(minute, - @valid_dev_sto_car_minutes, st.arrival_time) arrival_time_o
    ,DATEADD(minute,   @valid_dev_sto_car_minutes, st.departure_time) departure_time_o
    ,(SELECT COUNT(1) FROM dbo.ate_3 c WHERE dbo.FN_cross(c.x, c.y, s.x, s.y, @stop_radius)=1)q_cross
    ,r.route_id
	,s.x stop_x
	,s.y stop_y
	,r.id_picas_route
    FROM  dbo.picas_stop_times st, dbo.picas_stops s, dbo.picas_trips t, dbo.picas_routes r, dbo.check_points cp
    WHERE st.trip_id=t.trip_id AND t.route_id=r.route_id AND r.route_id = @route_id --id_picas_route=@id_picas_route
    AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
    AND st.stop_id=s.stop_id
    AND s.id_picas_stop = cp.id_picas_stop AND cp.id_picas_route = r.id_picas_route
   )s
   WHERE @time >= s.arrival_time_o AND @time <= s.departure_time_o AND q_cross=0
  )s, dbo.ate_3 c WHERE s.id_ate_3 = c.id_ate_3
 )s
)s
WHERE i_order_dist=1
ORDER BY s.id_ate_3

DELETE FROM dbo.formalize_messages WHERE id_ate_3 IN (SELECT id_ate_3 FROM @s)

--<q1
DECLARE @id_form_mes_off BIGINT; SET @id_form_mes_off = ISNULL((SELECT MAX(id_form_mes_off) FROM dbo.form_mes_off), 0)

SET IDENTITY_INSERT dbo.form_mes_off ON

INSERT dbo.form_mes_off(     id_form_mes_off, id_ate_3, dt_created, id_picas_route, id_picas_stop_from, time_cmd_minute_from, id_picas_stop_to, time_cmd_minute_to)
SELECT                  @id_form_mes_off + i, id_ate_3,        @dt, id_picas_route,      id_picas_stop,                    0,    id_picas_stop,                  0 FROM @s s 

SET IDENTITY_INSERT dbo.form_mes_off OFF
-->q1