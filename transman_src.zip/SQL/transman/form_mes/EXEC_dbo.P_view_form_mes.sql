--D:\users\yuil\JOB\EWES\SQL\transman\form_mes\EXEC_dbo.P_view_form_mes
EXEC dbo.P_view_form_mes @id_user=1, @i_mode=1