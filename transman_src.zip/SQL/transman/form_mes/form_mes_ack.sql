--D:\users\yuil\JOB\EWES\SQL\transman\form_mes\formalize_message_a

--//YUIL 2017-09-20  ��������������� ���������
--<q1
DROP TABLE dbo.form_mes_ack
CREATE TABLE dbo.form_mes_ack
( id_form_mes_ack BIGINT IDENTITY(1,1)
, device_number NVARCHAR(16)
, dt_created DATETIME
)
-->q1

CREATE CLUSTERED INDEX I_id_form_mes_ack ON dbo.form_mes_ack(id_form_mes_ack)
CREATE NONCLUSTERED INDEX I_device_number ON dbo.form_mes_ack(device_number)
CREATE NONCLUSTERED INDEX I_dt_created ON dbo.form_mes_ack(dt_created)

--TRUNCATE TABLE dbo.form_mes_ack
SELECT * FROM dbo.form_mes_ack

