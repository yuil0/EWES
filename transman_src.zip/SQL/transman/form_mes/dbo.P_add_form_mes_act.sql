ALTER PROC dbo.P_add_form_mes_act 
( @id_user BIGINT
, @id_ate_3 BIGINT
, @id_picas_stop_from BIGINT
, @time_cmd_minute_from INT
, @id_picas_stop_to BIGINT
, @time_cmd_minute_to INT
, @text_mes NVARCHAR(128)=''
) 
AS -- D:\users\yuil\JOB\EWES\SQL\transman\form_mes\dbo.P_add_form_mes_act
----------------------------------------------------
DECLARE @dt DATETIME; SET @dt = GETDATE() --'2017-12-06T10:00:00'--;

--<q0
IF EXISTS
(SELECT 1 FROM dbo.form_mes_act 
 WHERE 
  id_user=@id_user 
  AND id_ate_3=@id_ate_3 
  AND DATEDIFF(second, dt_created, @dt)<5 
  AND id_picas_stop_from=@id_picas_stop_from 
  AND time_cmd_minute_from=@time_cmd_minute_from 
  AND id_picas_stop_to=@id_picas_stop_to 
  AND time_cmd_minute_to=@time_cmd_minute_to
)
BEGIN print 'Repeat fast. No save.'; RETURN; END
-->q0

--<q1
DECLARE @id_form_mes_act BIGINT; SET @id_form_mes_act = ISNULL((SELECT MAX(id_form_mes_act) FROM dbo.form_mes_act), 0) + 1;

SET IDENTITY_INSERT dbo.form_mes_act ON

INSERT dbo.form_mes_act(id_form_mes_act,  id_user,  id_ate_3,  dt_created,  id_picas_stop_from,  time_cmd_minute_from,  id_picas_stop_to,  time_cmd_minute_to, i_state,  text_mes)
SELECT                 @id_form_mes_act, @id_user, @id_ate_3,         @dt, @id_picas_stop_from, @time_cmd_minute_from, @id_picas_stop_to, @time_cmd_minute_to,       0, @text_mes

SET IDENTITY_INSERT dbo.form_mes_act OFF
-->q1