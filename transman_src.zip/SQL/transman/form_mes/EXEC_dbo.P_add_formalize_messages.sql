--D:\users\yuil\JOB\EWES\SQL\transman\form_mes\EXEC_dbo.P_add_formalize_messages

--EXEC dbo.P_add_formalize_messages @route_id='rostov_bus_94'
/*
EXEC dbo.P_add_form_mes_ack @device_number=N'M216OH'

SELECT * FROM dbo.form_mes_act
SELECT * FROM dbo.form_mes_ack

*/

EXEC dbo.P_add_formalize_messages @route_id =N'rostov_bus_94'
SELECT * FROM dbo.form_mes_off


SELECT t.dt_created, u.user_name, c.device_number
,(SELECT stop_name FROM dbo.picas_stops s WHErE s.id_picas_stop=t.id_picas_stop_from) stop_name_frame
,(SELECT stop_name FROM dbo.picas_stops s WHErE s.id_picas_stop=t.id_picas_stop_to) stop_name_to
, time_cmd_minute_from
,  time_cmd_minute_to
,ISNULL((SELECT TOP 1 1 FROM dbo.form_mes_ack k, dbo.ate_3 c WHERE k.dt_created>=t.dt_created AND k.device_number=c.device_number AND c.id_ate_3 = t.id_ate_3), 0) f_ack
FROM dbo.form_mes_act t, dbo.ate_3 c, dbo.users u
WHERE t.id_ate_3=c.id_ate_3 AND t.id_user=u.id_user

/*
SELECT x.dt_created, x.f_ack, ISNULL(t.device_number, k.device_number)
FROM
(SELECT dt_created, 0 f_ack FROM dbo.form_mes_act UNION
 SELECT dt_created, 1 f_ack FROM dbo.form_mes_ack 
)x
LEFT JOIN (SELECT t.dt_created, u.user_name, c.device_number, id_picas_stop_from,  time_cmd_minute_from, id_picas_stop_to,  time_cmd_minute_to, f_received FROM dbo.form_mes_act t, dbo.ate_3 c, dbo.users u WHERE t.id_ate_3=c.id_ate_3 AND t.id_user=u.id_user) t ON (t.dt_created = x.dt_created)
LEFT JOIN (SELECT dt_created, device_number FROM dbo.form_mes_ack) k  ON (k.dt_created = x.dt_created)
ORDER BY x.dt_created

*/