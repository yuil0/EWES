ALTER PROC dbo.P_day_back(@i_days_back INT) AS
-------------------------------------
-- D:\users\yuil\JOB\EWES\SQL\transman\dbo.P_day_back

DECLARE @dt DATETIME; 
SET @dt=DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0);
SET @dt=DATEADD(hour, 23, @dt);
SET @dt=DATEADD(minute, 59, @dt);
SET @dt=DATEADD(second, 59, @dt);
SET @dt=DATEADD(ms, 997, @dt);

DECLARE @dt_m DATETIME; 

SET @dt_m = DATEADD(dd, -@i_days_back, @dt);

SELECT '1'dt

--SELECT CONVERT(NVARCHAR(23), @dt_m, 127)dt
