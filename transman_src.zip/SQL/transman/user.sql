/****** Object:  Login [admin]    Script Date: 31.07.2017 11:15:31 ******/
CREATE LOGIN transman_user WITH PASSWORD=N'Q1234q1234', DEFAULT_DATABASE=[transman], DEFAULT_LANGUAGE=[�������], CHECK_EXPIRATION=OFF, CHECK_POLICY=ON --Q1234q1234
CREATE USER transman_user   FOR LOGIN transman_user

ALTER LOGIN transman_user ENABLE


DROP USER transman_user
DROP LOGIN transman_user


graNt SELECT, INSERT, UPDATE, DELETE, execute, view  definition, alter TO transman_user
GRANT SELECT, view definition ON SCHEMA::dbo TO transman_user