--D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\test_FN_get_q_shape_id
DECLARE @f_direct BIT; SET @f_direct=0; --YUIL 2017-09-18 ����������� : 1 : �����, 0 : �������

SELECT c.dt_created, device_number,speed --ct.name_short_en, c.route_short_name, c.route_en
, 'rostov_'+ct.name_short_en+'_'+c.route_en route_id --(SELECT route_id FROM dbo.picas_routes  r WHERE r.route_short_name=c.route_short_name AND CHARINDEX(ct.name_short_en, r.route_id)!=0)route_id
, ROW_NUMBER() OVER(PARTITION BY cs.id_car_chrono ORDER BY id_car_chrono_stop)i_cross_stop, cs.id_stop
, dbo.FN_get_q_shape_id( 'rostov_'+ct.name_short_en+'_'+c.route_en, @f_direct) q_shape_id
FROM dbo.car_chrono c, dbo.car_chrono_stop cs, dbo.car_type ct
WHERE ISNULL(route_en,'')!='' AND cs.id_car_chrono=c.id_car_chrono AND c.id_car_type=ct.id_car_type --AND speed=0
ORDER BY device_number,  dt_created