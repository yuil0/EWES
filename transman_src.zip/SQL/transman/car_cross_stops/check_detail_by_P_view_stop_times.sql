--D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\check_detail_by_P_view_stop_times
DECLARE @route_id NVARCHAR(32); SET @route_id='rostov_bus_94'
DECLARE @device_number NVARCHAR(16); SET @device_number='P608HT' --M237OH' --M270OH'

SELECT c.id_car_chrono, c.dt_created, ps.stop_id 
,CASE  WheN ps.stop_id =1833 THEN 'stop_id_prev' ELSE '' END [sz_stop_id_prev]
,CASE  WheN ps.stop_id =832 THEN 'stop_id' ELSE '' END [sz_stop_id]
FROM dbo.car_chrono c, dbo.car_chrono_stop cs, dbo.car_type ct, dbo.picas_stops ps
 WHERE ISNULL(route_en,'')!='' AND cs.id_car_chrono=c.id_car_chrono AND c.id_car_type=ct.id_car_type AND cs.id_stop=ps.id_picas_stop
AND c.device_number = @device_number  AND c.dt_created<='2017-09-19T16:00:00'
AND 'rostov_'+ct.name_short_en+'_'+c.route_en = @route_id
order  by 1