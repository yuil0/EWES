ALTER  PROC dbo.P_add_car_chrono
( @dt DATETIME
, @device_number NVARCHAR(16)
, @azimut INT
, @speed INT
, @x FLOAT
, @y FLOAT
, @id_car_type BIGINT
, @route_en NVARCHAR(8)
, @lat DEC(10,6)
, @lng DEC(10,6)
, @id_zone BIGINT
) 
AS 
--D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\dbo.P_add_car_chrono
---------------------------------------------------------
	BEGIN --YUIL ����� ��������
		SET NOCOUNT ON;

		DECLARE @stop_radius FLOAT, @valid_dev_sec INT; SELECT @stop_radius=stop_radius, @valid_dev_sec = valid_dev_sec FROM dbo.const

		IF (@stop_radius IS NULL) BEGIN RETURN; END;

		--<q0 //YUIL 2017-09-15 ������  ��  ������� �� �������
		DECLARE @max_dt_created DATETIME; SET @max_dt_created = (SELECT MAX(dt_created) FROM dbo.car_chrono WHERE device_number=@device_number)
		
		DECLARE @d_sec INT; SET @d_sec= DATEDIFF(second, @max_dt_created,  @dt)

		IF (@d_sec < @valid_dev_sec) BEGIN  print 'dbo.P_add_car_chrono. to fast. exit without save. @d_sec='+CONVERT(NvaRChaR(10),  @d_sec)+' @dt='+CONVERT(NVARCHAR(24), @dt)+' @max_dt_created='+CONVERT(NVARCHAR(24), @max_dt_created); RETURN; END;
		-->q0

		DECLARE @id_car_chrono BIGINT; SET @id_car_chrono = (SELECT MAX(id_car_chrono) FROM dbo.car_chrono WHERE device_number=@device_number)

		--<q1 //YUIL 2017-09-15 ������  ��  �������
		/*		
		IF (@id_car_chrono IS NOT NULL)
		BEGIN
			DECLARE @azimut_prev INT, @speed_prev INT, @x_prev FLOAT, @y_prev FLOAT, @route_short_name_prev NVARCHAR(8), @stop_radius_prev FLOAT, @id_car_type_prev BIGINT

			SELECT 
			   @azimut_prev = azimut
			,  @speed_prev  = speed
			,  @x_prev = x
			,  @y_prev = y
			,  @route_short_name_prev = route_en
			,  @stop_radius_prev      = stop_radius 
			,  @id_car_type_prev      = id_car_type
			FROM dbo.car_chrono WHERE id_car_chrono=@id_car_chrono

			IF (    @azimut_prev = @azimut 
			    AND @speed_prev  = @speed 
				AND  @x_prev = @x 
				AND  @y_prev = @y 
				AND  @route_short_name_prev = @route_en
				AND  @stop_radius_prev = @stop_radius
				AND  @id_car_type_prev = @id_car_type) BEGIN  print 'dbo.P_add_car_chrono. repeated. exit without save.'; RETURN; END;
		END*/
		-->q1

		DECLARE @cross_stops AS TABLE(id_cross_stop BIGINT IDENTITY(1,1), id_stop BIGINT, x FLOAT, y FLOAT)

		INSERT @cross_stops (id_stop,   x,   y)
		SELECT       s.id_picas_stop, s.x, s.y FROM dbo.picas_stops s WHERE dbo.FN_cross(@x, @y, s.x, s.y, @stop_radius)=1

		DECLARE @i_cnt_cross INT; SET @i_cnt_cross=ISNULL((SELECT COUNT(1) FROM @cross_stops), 0);/*IF EXISTS()BEGINEND*/  --IF (@i_cnt_cross>0)BEGIN

		--1. car
		SET @id_car_chrono = ISNULL((SELECT MAX(id_car_chrono) FROM dbo.car_chrono), 0) + 1;

		SET IDENTITY_INSERT dbo.car_chrono ON;

		INSERT dbo.car_chrono(id_car_chrono,  dt_created,  device_number,  azimut,  speed,  x,  y,  stop_radius,  id_car_type,  route_en,  lat,  lng,  id_zone) 
		SELECT               @id_car_chrono,         @dt, @device_number, @azimut, @speed, @x, @y, @stop_radius, @id_car_type, @route_en, @lat, @lng, @id_zone 

		SET IDENTITY_INSERT dbo.car_chrono OFF;

		--2. stop
		DECLARE @id_car_chrono_stop_prev BIGINT; SET @id_car_chrono_stop_prev = ISNULL((SELECT MAX(id_car_chrono_stop) FROM dbo.car_chrono_stop), 0);

		SET IDENTITY_INSERT dbo.car_chrono_stop ON;

		INSERT dbo.car_chrono_stop(                      id_car_chrono_stop,  id_car_chrono, id_stop, stop_x, stop_y) 
		SELECT                     @id_car_chrono_stop_prev + id_cross_stop, @id_car_chrono, id_stop,      x,      y FROM @cross_stops cs

		SET IDENTITY_INSERT dbo.car_chrono_stop OFF; ---END
	END
------------------
/*
CREATE TABLE dbo.err_add_car_chrono
( id_err_add_car_chrono BIGINT IDENTITY(1,1), dt_created DATETIME, device_number NVARCHAR(16), year int
, month int
, day int
, hour int
, minute int
, second int)

CREATE CLUSTERED INDEX I_id_err_add_car_chrono ON dbo.err_add_car_chrono (id_err_add_car_chrono)
-------------------------check by stops
SELECT top 1 *FROM dbo.picas_stops s -- id_picas_stop=1 stop_id='4610' stop_name='29-� �����' x=4427203.978721 y=5979482.316019
SELECT top 1 *FROM dbo.ate_3 -- id_ate_3=1 device_number='M267OH' x=4417811.841963 y=5986155.781453

EXEC dbo.P_add_car_chrono @device_number=N'M267OH', @azimut=0, @speed=20, @x=4417811.841963, @y=5986155.781453, @route_short_name=N'94'  --YUIL 2017-09-15 : 0
EXEC dbo.P_add_car_chrono @device_number=N'M267OH', @azimut=0, @speed=20, @x=4427203.978721, @y=5979482.316019, @route_short_name=N'94'  --YUIL 2017-09-15 : 1

SELECT * FROM dbo.car_chrono   --YUIL 2017-09-15 : ����
SELECT * FROM dbo.car_chrono_stop WHERE id_car_chrono=1--YUIL 2017-09-15 : ����

SELECT *FROM dbo.picas_stops WHERE id_picas_stop IN (SELECT id_stop FROM dbo.car_chrono_stop) --YUIL 2017-09-15 : ����

TRUNCATE TABLE dbo.car_chrono
TRUNCATE TABLE dbo.car_chrono_stop

*/

