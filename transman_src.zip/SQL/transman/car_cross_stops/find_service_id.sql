--D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\find_service_id
SELECT * FROM dbo.picas_calendar --������ ����� service_id

SELECT * FROM dbo.picas_calendar_dates

--<q2
SELECT service_id FROM dbo.picas_calendar c WHERE c.service_id NOT IN (SELECT service_id FROM dbo.picas_calendar_dates) --71

SELECT service_id FROM dbo.picas_calendar_dates c WHERE c.service_id NOT IN (SELECT service_id FROM dbo.picas_calendar) --0
-->q2

SELECT c.*,  cd.date, cd.exception_type FROM dbo.picas_calendar c LEFT JOIN dbo.picas_calendar_dates cd ON(cd.service_id=c.service_id)

SELECT dbo.FN_get_picas_service_id(GETDATE()) 

--<q1
	DECLARE @dt DATETIME; SET @dt=GETDATE()	
	
	DECLARE @dayWeek INT; SET @dayWeek=DATEPART(dw, @dt)

	SELECT c.service_id,  * FROM dbo.picas_calendar c WHERE (@dt>=c.[start_date]  AND @dt <=c.[end_date]) 
	AND 
	CASE @dayWeek 
	 WHEN 1 THEN monday
	 WHEN 2 THEN tuesday
	 WHEN 3 THEN wednesday
	 WHEN 4 THEN thursday
	 WHEN 5 THEN friday 
	 WHEN 6 THEN saturday
	 WHEN 7 THEN sunday
	END=1			
	AND dbo.FN_enabled_picas_calendar_dates(@dt, c.service_id)=1
	--SELECT @dayWeek[@dayWeek]
-->q1