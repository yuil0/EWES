CREATE FUNCTION dbo.FN_get_date(@dt DATETIME)
RETURNS DATETIME
AS -- //YUIL 2017-09-18 : D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\dbo.FN_get_date
BEGIN
	DECLARE  @dt_only  DATETIME; SET  @dt_only=  DATEADD(dd,  DATEDIFF(dd, 0, @dt), 0)  

	RETURN @dt_only;
END