CREATE PROC dbo.P_add_car_cross_stops
(@device_number NVARCHAR(16) --//YUIL 2017-09-14 ������������� �� ���-3
,@stop_id BIGINT --//YUIL 2017-09-14 ������������� �� �����
,@car_x FLOAT
,@car_y FLOAT
,@stop_x FLOAT
,@stop_y FLOAT
,@stop_radius FLOAT
) 
AS 
--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\dbo.P_add_car_cross_stops
---------------------------------------------------------

	DECLARE @id_car_cross_stop BIGINT; SET @id_car_cross_stop = ISNULL((SELECT MAX(id_car_cross_stop) FROM dbo.car_cross_stops), 0) + 1;

	SET IDENTITY_INSERT dbo.car_cross_stops ON;

	INSERT dbo.car_cross_stops(id_car_cross_stop, dt_created,  device_number,  stop_id,  car_x,  car_y,  stop_x,  stop_y,  stop_radius) 
	SELECT                    @id_car_cross_stop,  GETDATE(), @device_number, @stop_id, @car_x, @car_y, @stop_x, @stop_y, @stop_radius

	SET IDENTITY_INSERT dbo.car_cross_stops OFF;
------------------
/*
DECLARE @r FLOAT; SET @r=11.4*4
EXEC dbo.P_add_car_cross_stops @device_number=N'?', @stop_id=0, @car_x=0, @car_y=0, @stop_x=0, @stop_y=0, @stop_radius=@r

SELECT * FROM  dbo.car_cross_stops
SELECT *,  stop_radius/4 FROM  dbo.const
TRUNCATE TABLE dbo.car_cross_stops
*/