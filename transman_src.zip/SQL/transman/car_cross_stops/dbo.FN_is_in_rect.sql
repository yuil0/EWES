CREATE FUNCTION dbo.FN_is_in_rect
( @x FLOAT, @y FLOAT
, @x1 FLOAT, @y1 FLOAT
, @x2 FLOAT, @y2 FLOAT
)
RETURNS BIT
AS -- //YUIL 2017-09-20 : D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\dbo.FN_is_in_rect
BEGIN
	DECLARE  @f_in BIT; 

	DECLARE @x_min FLOAT; SET @x_min=CASE WHEN @x1 < @x2 THEN  @x1 ELSE @x2 END;
	DECLARE @y_min FLOAT; SET @y_min=CASE WHEN @y1 < @y2 THEN  @y1 ELSE @y2 END;
	DECLARE @x_max FLOAT  SET @x_max=CASE WHEN @x1 > @x2 THEN  @x1 ELSE @x2 END;
	DECLARE @y_max FLOAT; SET @y_max=CASE WHEN @y1 > @y2 THEN  @y1 ELSE @y2 END;
	
	SET  @f_in= CASE WHEN @x>=@x_min AND @y>=@y_min AND @x<=@x_max AND @y<=@y_max THEN 1 ELSE 0  END;

	RETURN @f_in;
END