--D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\find_out_order
-- //YUIL 2017-09-18 ������ : ���������� �� �������.

DECLARE @valid_dev_sec int; SET @valid_dev_sec=60--YUIL 2017-09-18 . ���������� ����������  � ��������
DECLARE @dt DATETIME; SET @dt='2017-09-18T07:00:00' --GETDATE() --YUIL 2017-09-18 .  ����� ��������� ������ �� ���������.
DECLARE @dt_only DATETIME; SET @dt_only = dbo.FN_get_date(@dt) 
DECLARE @time TIME; SET  @time = dbo.FN_get_time(@dt) --DECLARE @f_direct BIT; SET @f_direct=0; --YUIL 2017-09-18 ����������� : 1 : �����, 0 : �������

--<q4  //YUIL 2017-09-18 ������  ���������� �������� ��� ������
DECLARE @route AS TABLE(route_id NVARCHAR(32))
INSERT @route (route_id) SELECT 'rostov_bus_94'
INSERT @route (route_id) SELECT 'rostov_bus_96' --INSERT @route (route_id) SELECT 'rostov_bus_96' --INSERT @route (route_id) SELECT route_id FROM  dbo.picas_routes WHERE route_id IN ('rostov_bus_94', 'rostov_bus_96')--route_short_name in ('94','96')
-->q4

--<q2
DECLARE @data AS TABLE(stop_id BIGINT, stop_sequence INT, shape_id NVARCHAR(32), arrival_time TIME, departure_time TIME, sz_end NVARCHAR(32), f_enabled_picas_calendar BIT)

INSERT       @data(stop_id,   shape_id,    stop_sequence,    arrival_time,    departure_time,                                                                          sz_end,                         f_enabled_picas_calendar)
SELECT DISTINCT st.stop_id, t.shape_id, st.stop_sequence, st.arrival_time, st.departure_time, SUBSTRING(t.shape_id, LEN(t.route_id)+2, LEN(t.shape_id) - (LEN(t.route_id)+1)), dbo.FN_enabled_picas_calendar(@dt, t.service_id)
	 FROM dbo.picas_stop_times st, dbo.picas_trips  t --, dbo.car_chrono c, dbo.car_chrono_stop cs, dbo.car_type ct
	 WHERE @time >= DATEADD(second, - @valid_dev_sec, st.arrival_time ) AND @time <= DATEADD(second, @valid_dev_sec, st.departure_time) 
	 AND st.trip_id = t.trip_id --AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1 --YUIL ���������   ���������� �� ����� ���� picas_calendar_dates, picas_calendar -- --AND ISNULL(route_en,'')!='' AND cs.id_car_chrono=c.id_car_chrono AND c.id_car_type=ct.id_car_type --AND t.shape_id = dbo.FN_get_shape_id( 'rostov_'+ct.name_short_en+'_'+c.route_en, @f_direct)   --AND t.shape_id ='rostov_bus_1_a-b'
	 AND route_id IN (SELECT route_id FROM @route)

DELETE FROM @data  WHERE f_enabled_picas_calendar=0
-->q2

DECLARE @min_arrival_time TIME, @max_departure_time TIME;

SELECT @min_arrival_time=MIN(arrival_time), @max_departure_time=MAX(departure_time) FROM @data

SELECT @min_arrival_time[@min_arrival_time],   @max_departure_time[@max_departure_time]

--<q0 --
DECLARE @car_crono AS TABLE(dt_created DATETIME, time TIME, device_number NVARCHAR(16), speed INT,  route_id NVARCHAR(32), stop_id BIGINT)

INSERT @car_crono (dt_created,                          time, device_number, speed,                                           route_id,    stop_id)
SELECT           c.dt_created, dbo.FN_get_time(c.dt_created), device_number, speed, 'rostov_'+ct.name_short_en+'_'+c.route_en route_id, ps.stop_id
FROM dbo.car_chrono c, dbo.car_chrono_stop cs, dbo.car_type ct, dbo.picas_stops ps
WHERE ISNULL(route_en,'')!='' AND cs.id_car_chrono=c.id_car_chrono AND c.id_car_type=ct.id_car_type AND cs.id_stop=ps.id_picas_stop
AND dbo.FN_get_date(c.dt_created) = @dt_only 
AND dbo.FN_get_time(c.dt_created)>=@min_arrival_time AND dbo.FN_get_time(c.dt_created)<=@max_departure_time
ORDER BY device_number,  dt_created
-->q0

--<q1

--SELECT * FROM @car_crono WHERE stop_id=934 AND route_id='rostov_bus_96'

SELECT t.stop_id, t.shape_id, stop_sequence, t.arrival_time, t.departure_time, sz_end, CASE WHEN q_car_on!=0 THEN 1 ELSE 0 END car_on, q_car_on FROM 
(
	SELECT t.stop_id, t.shape_id, stop_sequence, t.arrival_time, t.departure_time, sz_end 
	,ISNULL((SELECT count(1) FROM @car_crono cc WHERE cc.route_id+'_'+sz_end=t.shape_id AND cc.stop_id=t.stop_id
			 AND  cc.time >= DATEADD(second, - @valid_dev_sec, t.arrival_time ) AND cc.time <= DATEADD(second, @valid_dev_sec, t.departure_time) 
			), 0)[q_car_on]
	FROM @data t
	/*(SELECT DISTINCT st.stop_id, t.shape_id, st.arrival_time, st.departure_time --st.trip_id, t.service_id
	 , SUBSTRING(t.shape_id, LEN(t.route_id)+2, LEN(t.shape_id) - (LEN(t.route_id)+1)) sz_end
	 FROM dbo.picas_stop_times st, dbo.picas_trips  t --, dbo.car_chrono c, dbo.car_chrono_stop cs, dbo.car_type ct
	 WHERE @time >= DATEADD(second, - @valid_dev_sec, st.arrival_time ) AND @time <= DATEADD(second, @valid_dev_sec, st.departure_time) 
	 AND st.trip_id = t.trip_id
	 AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1 --YUIL ���������   ���������� �� ����� ���� picas_calendar_dates, picas_calendar -- --AND ISNULL(route_en,'')!='' AND cs.id_car_chrono=c.id_car_chrono AND c.id_car_type=ct.id_car_type --AND t.shape_id = dbo.FN_get_shape_id( 'rostov_'+ct.name_short_en+'_'+c.route_en, @f_direct)   --AND t.shape_id ='rostov_bus_1_a-b'
	)t*/
)t
--WHERE car_on=1
order  by 1, 2, 3, 4

-->q1
-- shape_id
--rostov_bus_94_a-b stop_id=1813

