ALTER FUNCTION dbo.FN_cross
( @car_x FLOAT
, @car_y FLOAT
, @stop_x FLOAT
, @stop_y FLOAT
, @stop_radius FLOAT)
RETURNS BIT
AS --D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\dbo.FN_cross
BEGIN
	DECLARE @i_cross BIT;

	DECLARE @fl_dist FLOAT; SET @fl_dist=SQRT(SQUARE(@car_x - @stop_x) + SQUARE(@car_y - @stop_y))

	SET @i_cross = CASE WHEN @fl_dist < @stop_radius THEN 1 ELSE 0 END;

	RETURN @i_cross;
END;
/*
SELECT dbo.FN_cross(0, 0, 0, 1, 1)[IsCross]
*/