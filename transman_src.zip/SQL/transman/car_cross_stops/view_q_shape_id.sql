--D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\view_q_shape_id
-- ��� �������   �  ������  shape_id. ����� � ����������� ����� �� shape_id.

DECLARE @dt DATETIME; SET @dt=GETDATE()
DECLARE @route_id NVARCHAR(32); SET @route_id='rostov_bus_94'
DECLARE @f_direct BIT; SET @f_direct=1; --YUIL 2017-09-18 ����������� : 1 : �����, 0 : �������

	DECLARE @route_id_mask NVARCHAR(33); SET @route_id_mask = @route_id + '_';
	
	SELECT shape_id FROM
	(SELECT distinct shape_id, SUBSTRING(shape_id, LEN(@route_id_mask)+1, LEN(shape_id) - LEN(@route_id_mask))sz_end FROM dbo.picas_trips t
	 WHERE CHARINDEX(@route_id_mask, shape_id)!=0
	 AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
	)x
	 WHERE (@f_direct=1 AND CHARINDEX('a', sz_end) < CHARINDEX('-', sz_end))
	 OR    (@f_direct=0 AND CHARINDEX('a', sz_end) > CHARINDEX('-', sz_end))
	

	/*SELECT shape_id FROM
	 (SELECT distinct shape_id, SUBSTRING(shape_id, LEN(@route_id_mask)+1, LEN(shape_id) - LEN(@route_id_mask))sz_end FROM dbo.picas_shapes WHERE CHARINDEX(@route_id_mask, shape_id)!=0)x
	 WHERE (@f_direct=1 AND CHARINDEX('a', sz_end) < CHARINDEX('-', sz_end))
	 OR    (@f_direct=0 AND CHARINDEX('a', sz_end) > CHARINDEX('-', sz_end))*/
	
----
SELECt route_id from dbo.picas_routes where route_id like 'rostov_bus_94%'