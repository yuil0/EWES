--D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\view_detail_by_P_view_stop_times
DECLARE @dt DATETIME; SET @dt='2017-09-19T16:00:00'
DECLARE @route_id NVARCHAR(32); SET @route_id='rostov_bus_94'
DECLARE @stop_id_prev  INT; SET @stop_id_prev=  841--840
DECLARE @stop_id INT; SET @stop_id =880 --841
DECLARE @valid_dev_sec int; SET @valid_dev_sec=30--YUIL 2017-09-18 . ���������� ����������  � ��������

DECLARE @stop_prev_x FLOAT; 
DECLARE @stop_prev_y FLOAT
DECLARE @stop_x FLOAT
DECLARE @stop_y FLOAT

SELECT @stop_prev_x=x , @stop_prev_y=y FROM  dbo.picas_stops WHERE stop_id=@stop_id_prev
SELECT @stop_x=x , @stop_y=y FROM  dbo.picas_stops WHERE stop_id=@stop_id

SELECT @stop_prev_x[@stop_prev_x], @stop_prev_y[@stop_prev_y]
SELECT @stop_x[@stop_x], @stop_y[@stop_y]

DECLARE @dt_only DATETIME; SET @dt_only = dbo.FN_get_date(@dt) 
DECLARE @time TIME; SET  @time = dbo.FN_get_time(@dt) --DECLARE @f_direct BIT; SET @f_direct=0; --YUIL 2017-09-18 ����������� : 1 : �����, 0 : �������

/*
--<q5 ���������� �� ����
DECLARE @car AS TABLE(device_number NVARCHAR(16))

INSERT @car(device_number) SELECT DISTINCT device_number FROM (SELECT device_number FROM dbo.car_chrono c WHERE ISNULL(route_en,'')!='' AND dbo.FN_get_date(c.dt_created) = @dt_only )t
-->q5

--<q6 --��������� ����� �� ���� (����������, ���������)
DECLARE @car_stop_last AS TABLE(dt_created DATETIME, time TIME, time_sec INT, device_number NVARCHAR(16), stop_id BIGINT, route_id NVARCHAR(32)) --YUIL 2017-09-19 : time_sec:����� � ��������

INSERT @car_stop_last (dt_created, time,                  time_sec, device_number, route_id, stop_id)
SELECT                 dt_created, time, DATEDIFF(second, 0, time), device_number, route_id, stop_id FROM
(SELECT          c.dt_created, dbo.FN_get_time(c.dt_created) time, device_number, 'rostov_'+ct.name_short_en+'_'+c.route_en route_id, ps.stop_id
 , ROW_NUMBER() OVER (PARTITION BY device_number, ps.stop_id ORDER BY c.dt_created DESC) i_order
 FROM dbo.car_chrono c, dbo.car_chrono_stop cs, dbo.car_type ct, dbo.picas_stops ps
 WHERE ISNULL(route_en,'')!='' AND cs.id_car_chrono=c.id_car_chrono AND c.id_car_type=ct.id_car_type AND cs.id_stop=ps.id_picas_stop
 AND dbo.FN_get_date(c.dt_created) = @dt_only
 AND c.dt_created<=@dt
)t
WHERE i_order=1
-->q6
*/
--<q7 ���������� �� ���� � ���������� ������� x, y
DECLARE @car_last AS TABLE(device_number NVARCHAR(16), x FLOAT, y FLOAT,  route_id NVARCHAR(32)); 

INSERT @car_last(device_number, x, y, route_id) 
SELECT           device_number, x, y, route_id FROM 
(SELECT device_number, x, y, ROW_NUMBER() OVER (PARTITION BY device_number ORDER BY c.dt_created DESC)i_order, 'rostov_'+ct.name_short_en+'_'+c.route_en route_id
  FROM dbo.car_chrono c, dbo.car_type ct WHERE ISNULL(route_en,'')!='' AND dbo.FN_get_date(c.dt_created) = @dt_only AND c.dt_created<=@dt  AND c.id_car_type=ct.id_car_type
)t 
WHERE i_order=1
-->q7

SELECT cl.device_number, cl.x, cl.y, dbo.FN_get_dist(cl.x, cl.y, @stop_x, @stop_y)dist FROM @car_last cl  WHERE cl.route_id = @route_id
				   
SELECT c.device_number, ROW_NUMBER() OVER (ORDER BY dist ASC)i_order FROM
		          (SELECT cl.device_number, dbo.FN_get_dist(cl.x, cl.y, @stop_x, @stop_y)dist 
		           FROM @car_last cl 
		           WHERE cl.route_id = @route_id AND dbo.FN_is_in_rect( cl.x, cl.y, @stop_prev_x, @stop_prev_y, @stop_x, @stop_y)=1
				  )c

/*
SELECT * FROM @car_stop_last WHERE device_number='M237OH' AND stop_id  IN(@stop_id,  @stop_id_prev)
SELECT * FROM @car_stop_last WHERE device_number='P608HT' AND stop_id  IN(@stop_id,  @stop_id_prev)

SELECT device_number, time_sec_prev, time_sec, time_sec_prev-time_sec d_time   FROM  
(SELECT device_number
,ISNULL((SELECT time_sec FROM @car_stop_last csl WHERE csl.device_number=c.device_number AND csl.route_id=@route_id AND csl.stop_id = @stop_id_prev),0)time_sec_prev
,ISNULL((SELECT time_sec FROM @car_stop_last csl WHERE csl.device_number=c.device_number AND csl.route_id=@route_id AND csl.stop_id = @stop_id),0)  time_sec				 
 FROM @car c WHERE 				
				 ISNULL((SELECT time_sec FROM @car_stop_last csl WHERE csl.device_number=c.device_number AND csl.route_id=@route_id AND csl.stop_id = @stop_id_prev),0)
				 >
				 ISNULL((SELECT time_sec FROM @car_stop_last csl WHERE csl.device_number=c.device_number AND csl.route_id=@route_id AND csl.stop_id = @stop_id),0)				 
)t
order by time_sec_prev desc*/