ALTER FUNCTION dbo.FN_enabled_picas_calendar_dates(@dt DATETIME, @service_id BIGINT) --YUIL ���� �� ���������� �� ������. ���� �������  ��� �� ���������.
RETURNS BIT
AS --YUIL 2017-09-15 D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\dbo.FN_enabled_picas_calendar_dates
BEGIN
	DECLARE @f_enabled BIGINT;

	DECLARE @exception_type INT; 
	
	SET @exception_type=ISNULL((SELECT exception_type FROM dbo.picas_calendar_dates cd WHERE service_id=@service_id AND date<=@dt AND cd.id_calendar_date=(SELECT MAX(id_calendar_date) FROM dbo.picas_calendar_dates cd WHERE service_id=@service_id AND date<=@dt)),1)

	SET @f_enabled= 
	CASE @exception_type 
	 WHEN 1 THEN 1 --true
	 WHEN 2 THEN 0 --false
	END

	RETURN @f_enabled;
END

/*
FROM dbo.picas_calendar_dates cd WHERE service_id=@service_id AND date<=@dt

SELECT * FROM dbo.picas_calendar_dates WHERE service_id=197665 AND date<'2017-12-23T00:00:00.000' --0

SELECT dbo.FN_enabled_picas_calendar_dates('2017-12-23T00:00:00.000', 197665)
----
SELECT * FROM dbo.picas_calendar_dates cd WHERE exception_type=1 AND service_id=198057 order by date

SELECT dbo.FN_enabled_picas_calendar_dates('2017-12-31T00:00:00.000', 198057)
----
SELECT service_id, COUNT(DISTINCT exception_type) FROM dbo.picas_calendar_dates cd 
GROUP BY service_id
HAVING COUNT(DISTINCT exception_type)>1 --0
*/