--D:\users\yuil\JOB\EWES\SQL\transman\test\test_NVARCHAR_max
DECLARE @sz NVARCHAR(max); SET @sz=''

DECLARE @sz_part NVARCHAR(max); SET @sz_part='0123456789'
DECLARE @i InT; SET @i=1

WHILE @i<=30000
BEGIN
	SET @sz=@sz+@sz_part;

	print 'LEN(@sz)='+CONVERT(NVARCHAR(10), LEN(@sz))

	SET @i=@i+1
END

-- 300 000