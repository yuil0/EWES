--D:\users\yuil\JOB\EWES\SQL\transman\file_stops\cr_file_stops.sql

--1. 
--<q1
DROP TABLE dbo.file_stops
CREATE TABLE dbo.file_stops
( id_file_stop BIGINT IDENTITY(1,1)
, dt_created DATETIME
, number NVARCHAR(6)
, name NVARCHAR(64)
, lat FLOAT
, lng FLOAT
, id_file_stop_area BIGINT --area NVARCHAR(32)
, id_file_stop_street BIGINT --street NVARCHAR(32)
, stop_id BIGINT
)

CREATE CLUSTERED INDEX I_id_file_stop ON dbo.file_stops(id_file_stop)
CREATE INDEX I_number ON dbo.file_stops(number)
CREATE INDEX I_stop_id ON dbo.file_stops(stop_id)

SELECT * FROM dbo.file_stops WHERE number=090218
SELECT * FROM dbo.picas_stops WHEre stop_id=2064


SELECT * FROM dbo.file_stops WHErE id_file_stop_area IS NULL OR	id_file_stop_street IS NULL --stop_id IS NULL

sp_spaceused 'dbo.file_stops'
-->q1

--<q2 area
DROP TABLE dbo.file_stop_areas
CREATE TABLE dbo.file_stop_areas( id_file_stop_area BIGINT IDENTITY(1,1), area NVARCHAR(32))
CREATE CLUSTERED INDEX I_id_file_stop_area ON dbo.file_stop_areas(id_file_stop_area)

INSERT dbo.file_stop_areas(area) 
SELECT area FROM
(SELECT @area_0 area UNION 
 SELECT @area_1 area UNION
 SELECT @area_2 area
)t 
WHERE area NOT IN(SELECT area FROM dbo.file_stop_areas)

SELECT area FROM dbo.file_stop_areas ORDER BY id_file_stop_area

(SELECT x.id_file_stop_area FROM dbo.file_stop_areas x WHERE x.area=t.area)
-->q2


--<q2 street
DROP TABLE dbo.file_stop_streets
CREATE TABLE dbo.file_stop_streets( id_file_stop_street BIGINT IDENTITY(1,1), street NVARCHAR(32))
CREATE CLUSTERED INDEX I_id_file_stop_street ON dbo.file_stop_streets(id_file_stop_street)

INSERT dbo.file_stop_streets(street) SELECT @street WHERE @street NOT IN(SELECT street FROM dbo.file_stop_streets)

SELECT * FROM dbo.file_stop_streets WHERE street like N'%���������%'
SELECT * FROM dbo.file_stop_streets WHERE id_file_stop_street=133 --54

(SELECT x.id_file_stop_street FROM dbo.file_stop_streets x WHERE x.street=t.street)
-->q2


-- SELECT dbo.FN_near_stop_id(@stop_lat FLOAT, @stop_lon FLOAT)