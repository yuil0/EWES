--D:\users\yuil\JOB\EWES\SQL\transman\file_stops\find_near_stop_id

DECLARE @stop_lat FLOAT; SET @stop_lat=47.34935	
DECLARE @stop_lon FLOAT;  SET @stop_lon=39.78965
DECLARE @delta FLOAT;  SET @delta=0.1

SELECT stop_id, stop_name, i_order FROM
(SELECT stop_id, stop_name, ROW_NUMBER() OVER (ORDER BY dist ASC)i_order FROM
 (SELECT stop_id, stop_name, dbo.FN_get_dist(stop_lat, stop_lon, @stop_lat, @stop_lon)dist FROM dbo.picas_stops WHERE ABS(stop_lat - @stop_lat)<@delta AND ABS(stop_lon - @stop_lon)<@delta) s
)s
WHERE i_order=1

 