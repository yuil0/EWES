ALTER PROC dbo.P_list_day_back(@i_days_back INT=31) AS
-------------------------------------
-- D:\users\yuil\JOB\EWES\SQL\transman\dbo.P_list_day_back

DECLARE @dt DATETIME; 
SET @dt=DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0);
SET @dt=DATEADD(hour, 23, @dt);
SET @dt=DATEADD(minute, 59, @dt);
SET @dt=DATEADD(second, 59, @dt);
SET @dt=DATEADD(ms, 997, @dt);

DECLARE @i INT; SET @i=0;

DECLARE @t AS TABLE(dt DATETIME);



WHILE (@i<@i_days_back)
BEGIN
	DECLARE @dt_m DATETIME; SET @dt_m = DATEADD(dd, -@i, @dt);

	INSERT @t(dt) SELECT @dt_m;

	SET @i=@i+1;
END

SELECT CONVERT(NVARCHAR(23), dt, 127)dt FROM @t --SELECT LEN('2017-11-21 00:00:00.000')
