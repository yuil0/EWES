--D:\users\yuil\JOB\EWES\SQL\transman\tables.sql
--<q2
SELECT s.name+'.'+o.name, create_date, modify_date, ps.row_count
,'SELECT * FROM '+s.name+'.'+o.name[query]
,'<TR ALIGN=RIGHT><TD>'+CONVERT(NVARCHAR(10), ROW_NUMBER() OVER(ORDER BY ps.row_count))+'</TD><TD>'+s.name+'.'+o.name+'</TD><TD> </TD><TD>'+CONVERT(NVARCHAR(10),ps.row_count)+'</TD></TR>'[table]

,'<BR><B>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+CONVERT(NVARCHAR(10), ROW_NUMBER() OVER(ORDER BY ps.row_count)+2)+N'. ������� '+s.name+'.'+o.name+'.</B><TABLE BORDER=1 CELLPADDING=5 CELLSPACING=0>'+CHAR(13)+CHAR(10)+N'<TR><TH>�</TH><TH>��� ����</TH><TH>���</TH><TH>�����</TH></TR>'+CHAR(13)+CHAR(10)+'</TABLE>'[Open_part]
,'SELECT ''<TR ALIGN=RIGHT><TD>''+CONVERT(NVARCHAR(10), ROW_NUMBER() OVER(ORDER BY column_id))+''</TD><TD>''+c.name+''</TD>''+
''<TD>''+t.name+CASE WHEN t.name IN(''text'',''varchar'',''char'',''nvarchar'',''nchar'') THEN ''(''+CONVERT(NVARCHAR(10),c.max_length/2)+'')'' ELSE  '''' END+''</TD><TD> </TD></TR>''
FROM sys.columns c , sys.types t
WHERE c.OBJECT_ID=OBJECT_ID('''+s.name+'.'+o.name+''') AND c.system_type_id=t.system_type_id  AND t.system_type_id=t.user_type_id'
from sys.schemas s, sys.objects o
LEFT JOIN sys.dm_db_partition_stats ps ON (ps.object_id=o.object_id  AND ps.index_id < 2)
where o.schema_id=s.schema_id AND type='U' and (o.name like '%picas%' OR o.name='ate_3') AND o.name NOT IN('picas_shape_lines')
-->q2

--SELECT * FROM sys.columns where OBJECT_ID=OBJECT_ID('dbo.picas_routes')


/*
SELECT  * FROM sys.types t WHERE t.system_type_id=t.user_type_id

SELECT '<TR ALIGN=RIGHT><TD>'+CONVERT(NVARCHAR(10), ROW_NUMBER() OVER(ORDER BY column_id))+'</TD><TD>'+c.name+'</TD>'+
'<TD>'+t.name+CASE WHEN t.name IN('text','varchar','char','nvarchar','nchar') THEN '('+CONVERT(NVARCHAR(10),c.max_length)+')' ELSE  '' END+'</TD><TD> </TD></TR>'
FROM sys.columns c , sys.types t
WHERE c.OBJECT_ID=OBJECT_ID('dbo.picas_agents') AND c.system_type_id=t.system_type_id  AND t.system_type_id=t.user_type_id
*/
/*
select s.name+'.'+o.name, create_date, modify_date 
from sys.objects o , sys.schemas s where o.schema_id=s.schema_id AND type='U' and o.name like '%picas%'
AND o.name NOT IN('picas_shape_ids', 'dbo.picas_shape_lines')


--<q1
DECLARE @sz NVARCHAR(max); SET @sz=''

select @sz = @sz + (CASE WHEN @sz='' THEN '' ELSE CHAR(13)+CHAR(10) END)+'EXEC sp_spaceused '''+s.name+'.'+o.name+''';'
from sys.objects o , sys.schemas s where o.schema_id=s.schema_id AND type='U' and o.name like '%picas%'
AND o.name NOT IN('picas_shape_ids', 'dbo.picas_shape_lines')

EXEC sp_executesql @sz

-->q1
*/

--select *from sys.dm_db_partition_stats ps where object_id=object_id('dbo.picas_routes');

---select count(1) from dbo.picas_shapes