exec sp_spaceused 'dbo.picas_shape_lines' --rows=62846           

DBCC CHECKTABLE ("dbo.picas_shape_lines")
DBCC CLEANTABLE (transman, 'dbo.picas_shape_lines')