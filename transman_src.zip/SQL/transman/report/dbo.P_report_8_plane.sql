ALTER PROC dbo.P_report_8_plane
( @i_mode TINYINT=0 /*YUIL 2017-10-05 0:���� ��� ��������
					�������� 1: ������� �������  ����������					
                    */
, @dt_from DATETIME=NULL
, @dt_to DATETIME=NULL
, @route_id NVARCHAR(32)=NULL
, @agent_id NVARCHAR(16)=NULL --//YUIL 2017-10-24  ����� �����������
) 
AS
------------------------------------------------------------------------------------------------------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_report_8_plane

SET NOCOUNT ON;  --DECLARE @sz NVARCHAR(MAX);

IF (@i_mode=1) BEGIN print N'Clearing'; TRUNCATE TABLE dbo._rep_8_plane_out; RETURN; END

IF (@dt_from IS  NULL OR @dt_to IS NULL OR @route_id IS NULL) BEGIN print 'Param''s is empty'; RETURN; END

IF (@dt_from > @dt_to) BEGIN print 'Param''s is wrong'; RETURN; END

--<q5  cr
IF (OBJECT_ID('dbo._rep_8_plane_out')IS NULL) 
BEGIN
  --DROP TABLE dbo._rep_8_plane_out
 CREATE TABLE dbo._rep_8_plane_out(id_rep_out BIGINT IDENTITY(1,1), agency_name NVARCHAR(64), dt DATETIME, route_name_rus NVARCHAR(32), delta_time_min INT, q_race INT, type_day NVARCHAR(8)); 
 CREATE CLUSTERED INDEX I_id_out ON dbo._rep_8_plane_out(id_rep_out)
END
-->q5

DECLARE @t AS TABLE(id BIGINT IdENTItY(1,1), dt DATETIME, min_time TIME, max_time TIME, q_race INT,  f_work_day BIT)

WHILE @dt_from <= @dt_to
BEGIN

	DECLARE @weekday INT; SET @weekday=DATEPART(weekday, @dt_from);

	DECLARE @f_work_day BIT; SET @f_work_day= CASE WHEN @weekday>=0 AND @weekday<=5 THEN 1 ELSE  0  END;

	INSERT @t (dt, min_time, max_time, q_race, f_work_day)--DECLARE @t AS TABLE(route_id NVARCHAR(32), shape_id NVARCHAR(32), time TIME, f_enabled_picas_calendar BIT)--INSERT @t(route_id, shape_id,                time, f_enabled_picas_calendar) --,  f_enabled_picas_calendar	
	SELECT     @dt_from,  MIN(departure_time), MAX(departure_time), COUNT(DISTINCT st.trip_id), @f_work_day --trip_id ��� ������ �� ����������� == ����
	FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id = t.trip_id AND dbo.FN_enabled_picas_calendar(@dt_from, t.service_id)=1 AND route_id = @route_id

	SET @dt_from=DATEADD(day, 1, @dt_from);
END

INSERT dbo._rep_8_plane_out(agency_name,   dt,                                                route_name_rus,                       delta_time_min,   q_race,   type_day)
SELECT                           a.name, t.dt, dbo.FN_route_type_string(r.route_type)+' '+r.route_short_name, DATEDIFF(minute, min_time, max_time), t.q_race, CASE WHEN t.f_work_day=1 THEN N'���.' ELSE N'���.' END
FROM @t t, dbo.picas_routes r, dbo.picas_agents a
WHERE @route_id=r.route_id AND r.agency_id=a.id
AND a.id=ISNULL(@agent_id, a.id) --//YUIL 2017-10-24
ORDER BY t.id 


SELECT * FROM dbo._rep_8_plane_out