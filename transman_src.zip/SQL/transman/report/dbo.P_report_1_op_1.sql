ALTER PROC dbo.P_report_1_op_1
(                                      --@user_name NVARCHAR(32)='user'
  @dt  DATETIME=NULL
, @stop_id BIGINT=NULL --//YUIL 2017-09-22 @stop_id IS NULL : ��� ���� ���������
, @hour INT=NULL --//YUIL 2017-09-22 . ����� ��� ��������� ����-����, ����� ������� ��������� ����������� 
, @route_id NVARCHAR(32)=NULL --, @f_out BIT=NULL
, @f_time_limit BIT=1 --//YUIL 2017-09-27 ����������� �� �������
, @device_number NVARCHAR(16)=NULL --//YUIL 2017-10-09
) 
AS --���� dbo.P_report_1 :D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_report_1_op_1
------------------

	DECLARE @dt_only DATETIME; SET @dt_only = dbo.FN_get_date(@dt) 

	DECLARE @time TIME; SET  @time = dbo.FN_get_time(@dt) --DECLARE @f_direct BIT; SET @f_direct=0; --YUIL 2017-09-18 ����������� : 1 : �����, 0 : �������

	DECLARE @f_datetime_from_data BIT; SELECT @f_datetime_from_data=f_datetime_from_data FROM dbo.const; --//YUIL 2017-10-31 ����� ���� �� ����� ������


	--<q6 --����� �  ����� ������ � ��������� �������� �������� �  ��������� � �������� �������� ���������� �� ���������   --IF (OBJECT_ID('dbo.#car_stop') IS NOT NULL) BEGIN DROP TABLE dbo.#car_stop; END;
	CREATE TABLE #car_stop (id_car_stop BIGINT IDENTITY(1,1), stop_id  BIGINT, dt_created DATETIME, time TIME, hour INT, device_number NVARCHAR(16), route_id NVARCHAR(32), i_type TINYINT, speed INT, id_car_chrono BIGINT, id_car_type BIGINT) --YUIL 2017-09-22: i_type: 0:start 1:fin
	CREATE CLUSTERED INDEX I_id_car_stop ON #car_stop (id_car_stop)
	CREATE INDEX I_device_number_stop_id_route_id ON #car_stop (device_number, stop_id, route_id)	INCLUDE(i_type)

	INSERT #car_stop (stop_id, dt_created, time,                 hour, device_number, route_id,                                         i_type, speed, id_car_chrono, id_car_type)
	SELECT            stop_id, dt_created, time, DATEPART(hour, time), device_number, route_id, (CASE WHEN f_prev_no_stop=1 THEN 0 ELSE 1 END), speed, id_car_chrono, id_car_type 
	FROM
	(SELECT          ps.stop_id, c.dt_created, dbo.FN_get_time(c.dt_created) time, device_number, 'rostov_'+ct.name_short_en+'_'+c.route_en route_id
	 , ISNULL((SELECT 1 FROM dbo.car_chrono o WHERE o.id_car_chrono=c.id_car_chrono-1  AND NOT EXISTS(SELECT 1 FROM dbo.car_chrono_stop p WHERE p.id_car_chrono=o.id_car_chrono)), 0) f_prev_no_stop
	 , ISNULL((SELECT 1 FROM dbo.car_chrono o WHERE o.id_car_chrono=c.id_car_chrono+1  AND NOT EXISTS(SELECT 1 FROM dbo.car_chrono_stop p WHERE p.id_car_chrono=o.id_car_chrono)), 0) f_next_no_stop
	 , speed,  c.id_car_chrono, c.id_car_type
	 FROM dbo.car_chrono c, dbo.car_chrono_stop cs, dbo.car_type ct, dbo.picas_stops ps
	 WHERE ISNULL(route_en,'')!='' AND cs.id_car_chrono=c.id_car_chrono AND c.id_car_type=ct.id_car_type AND cs.id_stop=ps.id_picas_stop AND ps.stop_id=ISNULL(@stop_id, ps.stop_id) 
	 AND dbo.FN_get_date(c.dt_created) = @dt_only
	 --AND device_number='K715BX' ANd stop_id=1861 --! ����� ������� ������
	)t WHERE (f_prev_no_stop=1 OR  f_next_no_stop=1) AND t.route_id=ISNULL(@route_id, t.route_id) AND t.device_number = ISNULL(@device_number, t.device_number)
	ORDER BY stop_id, dt_created

	IF (@hour IS NOT NULL) 
	BEGIN 
		DELETE FROM #car_stop WHERE hour<@hour OR hour>@hour; 
	END
	-->q6
	
	--SELECT * FROM #car_stop

	--<q3                   
	CREATE TABLE #car_stop_n (id_car_stop BIGINT, stop_id  BIGINT, dt_created DATETIME, time TIME, hour INT, device_number NVARCHAR(16), route_id NVARCHAR(32), id_car_stop_start BIGINT, speed INT, id_car_type BIGINT)
	CREATE CLUSTERED INDEX I_id_car_stop ON #car_stop_n (id_car_stop)

	INSERT #car_stop_n (id_car_stop, stop_id, dt_created, time, hour, device_number, route_id, id_car_stop_start, speed, id_car_type)
	SELECT              id_car_stop, stop_id, dt_created, time, hour, device_number, route_id, id_car_stop_start, speed, id_car_type FROM
	(SELECT              id_car_stop, stop_id, dt_created, time, hour, device_number, route_id, id_car_stop_start, speed, id_car_type, ROW_NUMBER() OVER (PARTITION BY id_car_stop_start ORDER BY time DESC)i_order_id_start FROM
	 (SELECT              id_car_stop, stop_id, dt_created, time, hour, device_number, route_id 
	  , (SELECT id_car_stop FROM #car_stop p WHERE p.i_type=0 AND p.device_number=t.device_number AND p.stop_id=t.stop_id AND p.route_id=t.route_id AND p.id_car_stop=(SELECT MAX(id_car_stop) FROM #car_stop p WHERE p.i_type=0 AND p.device_number=t.device_number AND p.stop_id=t.stop_id AND p.route_id=t.route_id AND p.id_car_stop < t.id_car_stop)) id_car_stop_start
	  ,  speed, id_car_type
	  FROM #car_stop t WHERE t.i_type=1
	 )t
	)t WHERE i_order_id_start=1
	ORDER BY stop_id, dt_created
	-->q3
	
	--<q2 ������� ����
	INSERT #out(i_mode,    stop_id,                    hour, arrival_time, departure_time,                     delta_time_min, route_short_name, garage_num, quantity_car, speed, device_number, route_id)
	SELECT           1, ta.stop_id, DATEPART(hour, td.time),      ta.time,        td.time, DATEDIFF(minute, ta.time, td.time)
	, (SELECT route_short_name FROM dbo.picas_routes r WHERE (r.route_id COLLATE SQL_Latin1_General_CP1_CI_AS)=(ta.route_id COLLATE SQL_Latin1_General_CP1_CI_AS)) route_short_name
	, (SELECT garage_num FROM dbo.ate_3_book b WHERE (b.device_number COLLATE SQL_Latin1_General_CP1_CI_AS)=(ta.device_number COLLATE SQL_Latin1_General_CP1_CI_AS))  garage_num
	, 1
	,  (ta.speed + td.speed)/2 speed
	, ta.device_number
	,  ta.route_id
	FROM #car_stop ta, #car_stop_n td WHERE ta.i_type=0 AND ta.id_car_stop=td.id_car_stop_start
	ORDER BY stop_id, ta.time

	IF (@f_time_limit=1) DELETE FROM #out WHERE hour>=0 AND hour<5
	-->q2

	DROP TABLE #car_stop_n