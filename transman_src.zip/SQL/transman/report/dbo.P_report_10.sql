CREATE PROC dbo.P_report_10
( @i_mode TINYINT=0 /*YUIL YUIL 2017-10-05 0: ���� ��� ��������
					�������� 1: ������� �������  ����������					
                    */
, @dt DATETIME=NULL
) 
AS
------------------------------------------------------------------------------------------------------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_report_10

SET NOCOUNT ON;  --DECLARE @sz NVARCHAR(MAX);

IF (@i_mode=1) BEGIN print N'Clearing'; TRUNCATE TABLE dbo._rep_10_out; RETURN; END

IF (@dt IS NULL) BEGIN print 'Param''s is empty'; RETURN; END

--<q5  cr
IF (OBJECT_ID('dbo._rep_10_out')IS NULL) 
BEGIN
  --DROP TABLE dbo._rep_10_out
 CREATE TABLE dbo._rep_10_out(id_rep_out BIGINT IDENTITY(1,1), agency_name NVARCHAR(64), route_name_rus NVARCHAR(32), device_number NVARCHAR(16), dt_last DATETIME, delta_minutes INT); 

 CREATE CLUSTERED INDEX I_id_out ON dbo._rep_10_out(id_rep_out)
END
-->q5

DECLARE @dev_list AS TABLE(device_number NVARCHAR(16), dt_created DATETIME, route_id NVARCHAR(32),  delta_minutes INT)

DECLARE @max_diff_minutes INT; SET @max_diff_minutes=15;

INSERT @dev_list(device_number, dt_created, route_id, delta_minutes)
SELECT           device_number, dt_created, route_id, delta_minutes FROM 
(SELECT device_number, dt_created, route_id, DATEDIFF(minute, dt_created, @dt)delta_minutes FROM 
 (SELECT device_number, 'rostov_'+ct.name_short_en+'_'+t.route_en route_id, MAX(t.dt_created) dt_created FROM dbo.ate_3 t, dbo.car_type ct 
  WHERE t.dt_created<=@dt AND t.id_car_type=ct.id_car_type AND ISNULL(t.route_en,'')!=''
  GROUP BY device_number, ct.name_short_en, t.route_en
 )t 
 WHERE DATEDIFF(minute, dt_created, @dt) > @max_diff_minutes
)t
ORDER BY delta_minutes  DESC

INSERT dbo._rep_10_out(device_number, agency_name,                                                route_name_rus,      dt_last, delta_minutes)
SELECT                 device_number,      a.name, dbo.FN_route_type_string(r.route_type)+' '+r.route_short_name, t.dt_created, delta_minutes
FROM @dev_list t, dbo.picas_routes r, dbo.picas_agents a
WHERE (t.route_id COLLATE SQL_Latin1_General_CP1_CI_AS) = (r.route_id COLLATE SQL_Latin1_General_CP1_CI_AS) AND (r.agency_id COLLATE SQL_Latin1_General_CP1_CI_AS) = (a.id COLLATE SQL_Latin1_General_CP1_CI_AS)
ORDER BY delta_minutes  DESC


SELECT * FROM dbo._rep_10_out
