CREATE FUNCTION dbo.FN_q_stop_by_picas_stop_times
(@dt DATETIME
,@shape_id NVARCHAR(32)
)
RETURNS INT
AS --D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.FN_q_stop_by_picas_stop_times
BEGIN
	DECLARE @q_stop INT

	SET @q_stop=ISNULL((SELECT COUNT(DISTINCT stop_sequence) FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1 AND shape_id=@shape_id), 0)

	RETURN @q_stop;
END

