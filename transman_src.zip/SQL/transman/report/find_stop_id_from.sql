--D:\users\yuil\JOB\EWES\SQL\transman\report\find_stop_id_from
DECLARE   @dt  DATETIME='2017-09-21T23:59:59'
DECLARE @stop_id BIGINT; SET @stop_id=1813
DECLARE @shape_id NVARCHAR(32); SET @shape_id='rostov_bus_96_a-b'

DECLARE @enabled_service AS TABLE(service_id BIGINT, f_enabled_picas_calendar BIT);

	SELECT            stop_sequence,  t.stop_id, t.hour,  t.arrival_time, t.departure_time, t.service_id FROM
	(SELECT DISTiNCT t.stop_sequence, t.stop_id, t.hour, t.arrival_time, t.departure_time, t.service_id FROM
	 (SELECT st.stop_sequence, st.stop_id, DATEPART(hour, st.departure_time)hour, st.arrival_time, st.departure_time, DATEPART(hour, st.arrival_time) hour_arrival_time, DATEPART(hour, st.departure_time) hour_departure_time,  t.service_id	   
	   FROM  dbo.picas_stop_times st, dbo.picas_trips t
	  WHERE st.trip_id=t.trip_id AND st.stop_id=ISNULL(@stop_id, st.stop_id) AND t.shape_id=ISNULL(@shape_id, t.shape_id)
	  AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
	 )t
	)t
	ORDER  BY stop_id, t.arrival_time

--select  top  1 * from dbo.picas_stop_times