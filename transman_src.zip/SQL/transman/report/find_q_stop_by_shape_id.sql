--D:\users\yuil\JOB\EWES\SQL\transman\report\find_q_stop_by_shape_id
DECLARE @dt DATETIME; SET @dt='2017-09-21T00:00:00';

DECLARE @shape_id NVARCHAR(32); SET @shape_id='rostov_bus_96_a-b'

SELECT DISTINCT stop_sequence, stop_id FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
AND shape_id=@shape_id 
ORDER BY stop_sequence


SELECT COUNT(DISTINCT stop_sequence) FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
AND shape_id=@shape_id 



