--D:\users\yuil\JOB\EWES\SQL\transman\report\exec_dbo.P_report_8_plane

EXEC dbo.P_report_8_plane  @i_mode=1; EXEC dbo.P_report_8_plane  @i_mode=0,  @dt_from='2017-09-21T00:00:00', @dt_to='2017-09-21T00:00:00', @route_id='rostov_bus_96', @agent_id='agency_49'
