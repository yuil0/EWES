ALTER PROC dbo.P_enabled_shape_stops (@dt  DATETIME=NULL,  @shape_id NVARCHAR(32)) AS --//YUIL 2017-09-28 : D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_shape_stops
------------------
DECLARE @enabled_service AS TABLE(service_id BIGINT, f_enabled_picas_calendar BIT);

--<q1
INSERT @enabled_service (service_id,                         f_enabled_picas_calendar) 
SELECT                   service_id, dbo.FN_enabled_picas_calendar(@dt, t.service_id) FROM (SELECT DISTINCT service_id FROM dbo.picas_trips)t

DELETE FROM @enabled_service WHERE f_enabled_picas_calendar=0
-->q1                   


DECLARE @t AS TABLE(stop_sequence INT, stop_id NVARCHAR(32), service_id BIGINT)

INSERT @t (stop_sequence, stop_id, service_id)
SELECT DISTINCT st.stop_sequence, st.stop_id, service_id 
FROM  dbo.picas_stop_times st, dbo.picas_trips t, dbo.picas_routes r 
WHERE st.trip_id=t.trip_id AND t.route_id=r.route_id AND t.shape_id=ISNULL(@shape_id, t.shape_id)

DELETE FROM @t WHERE service_id NOT IN (SELECT service_id FROM @enabled_service)

SELECT t.*, s.stop_name FROM  @t t, dbo.picas_stops s WHERE t.stop_id=s.stop_id  ORDER BY stop_sequence--, st.stop_sequence