--D:\users\yuil\JOB\EWES\SQL\transman\report\exec_dbo.P_report_6

DECLARE @out AS TABLE (min_len FLOAT, min_shape_id NVARCHAR(32), max_len FLOAT, max_shape_id NVARCHAR(32))
INSERT @out EXEC dbo.P_street_len_meters @id_file_stop_street=133
SELECT * FROM @out

SELECT dbo.FN_get_dist (4419684.347118, 5990122.867005, 4419792.327024, 5989477.862464)+dbo.FN_get_dist (4419792.327024, 5989477.862464, 4419970.438209, 5988841.111101) -- 1315,17329820312

EXEC dbo.P_report_6 @i_mode=1; EXEC dbo.P_report_6 @i_mode=2, @id_file_stop_street=133 --get len

EXEC dbo.P_report_6 @i_mode=1; EXEC dbo.P_report_6 @i_mode=3, @dt='2017-09-21T23:59:59', @id_file_stop_street=133 --//YUIL 2017-10-23
EXEC dbo.P_report_6 @i_mode=1; EXEC dbo.P_report_6 @i_mode=3, @dt='2017-11-21T23:59:59', @id_file_stop_street=133 --//YUIL 2017-10-23

SELECT * FROM [dbo].[file_stop_streets] WHERE id_file_stop_street=133