ALTER PROC dbo.P_report_1_op_0
(                                      --@user_name NVARCHAR(32)='user'
  @dt  DATETIME=NULL
, @stop_id BIGINT=NULL --//YUIL 2017-09-22 @stop_id IS NULL : ��� ���� ���������
, @hour INT=NULL --//YUIL 2017-09-22 . ����� ��� ��������� ����-����, ����� ������� ��������� ����������� 
, @route_id NVARCHAR(32)=NULL --, @f_out BIT=NULL
, @f_time_limit BIT=1 --//YUIL 2017-09-27 ����������� �� �������
) 
AS --���� dbo.P_report_1 :D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_report_1_op_0
------------------
	DECLARE @enabled_service AS TABLE(service_id BIGINT, f_enabled_picas_calendar BIT);

	--<q1
	INSERT @enabled_service (service_id,                         f_enabled_picas_calendar) 
	SELECT                   service_id, dbo.FN_enabled_picas_calendar(@dt, t.service_id) FROM (SELECT DISTINCT service_id FROM dbo.picas_trips)t

	DELETE FROM @enabled_service WHERE f_enabled_picas_calendar=0
	-->q1

	INSERT #out (i_mode,   stop_id,   hour,    arrival_time,   departure_time,                                     delta_time_min,   route_short_name,       garage_num,      quantity_car,                                                       f_enabled_picas_calendar,   service_id)
	SELECT            0, t.stop_id, t.hour,  t.arrival_time, t.departure_time, DATEDIFF(minute, t.arrival_time, t.departure_time), t.route_short_name, '' AS garage_num, 1 AS quantity_car, ISNULL((SELECT 1 FROM @enabled_service es WHERE es.service_id=t.service_id),0), t.service_id FROM
	(SELECT DISTiNCT t.stop_id, t.hour, t.arrival_time, t.departure_time, t.route_short_name, t.service_id FROM
	 (SELECT st.stop_id, DATEPART(hour, st.departure_time)hour, st.arrival_time, st.departure_time, r.route_short_name, DATEPART(hour, st.arrival_time) hour_arrival_time, DATEPART(hour, st.departure_time) hour_departure_time,  t.service_id	   
	   FROM  dbo.picas_stop_times st, dbo.picas_trips t, dbo.picas_routes r 
	  WHERE st.trip_id=t.trip_id AND t.route_id=r.route_id AND st.stop_id=ISNULL(@stop_id, st.stop_id) AND t.route_id=ISNULL(@route_id, t.route_id)
	 )t
	 WHERE (@f_time_limit=0 OR NOT(hour>=0 AND hour<5)) AND t.hour=ISNULL(@hour, t.hour)
	)t
	ORDER  BY stop_id, t.arrival_time

	DELETE  FROM  #out  WHERE i_mode=0 AND f_enabled_picas_calendar=0