--D:\users\yuil\JOB\EWES\SQL\transman\report\exec_dbo.P_report_8_fact

EXEC dbo.P_report_8_fact @i_mode=1; EXEC dbo.P_report_8_fact @i_mode=0, @dt='2017-09-21T23:59:59', @route_id='rostov_bus_96'

EXEC dbo.P_report_8_fact @i_mode=1; EXEC dbo.P_report_8_fact @i_mode=0, @dt='2017-09-21T23:59:59', @device_number='K715BX', @agent_id='agency_49'


SELECT DISTINCT device_number FROM dbo.ate_3 --ORDER BY device_number