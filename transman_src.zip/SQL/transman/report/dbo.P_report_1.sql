ALTER PROC dbo.P_report_1
(                                      --@user_name NVARCHAR(32)='user'
  @dt  DATETIME=NULL
, @i_mode TINYINT=0 /*YUIL 2017-09-21 0:�� �����, 1:�� �����. C�������� ����-���� ������� ������ �������� @i_mode IN(0,1). 
				    �������� 2 ��� ��������������� ������ ���-����, ������ ����� ������ � ���������� 0 � 1 ��� �������  ���� @hour IN(5..23)
					�������� 3: ������� �������  ����������
					�������� 4: ����� 1 � ������������ �� ���������, �������, �������� �����
					�������� 5: ����� 1 ��� ��������� ������ ��������� ��� ���������� ��������
					�������� 6: ����� 1 ��� ��������� ������ ������ ��� ���������� �������� � ��� ���������
                    */
, @stop_id BIGINT=NULL --//YUIL 2017-09-22 @stop_id IS NULL : ��� ���� ���������
, @hour INT=NULL --//YUIL 2017-09-22
, @route_id NVARCHAR(32)=NULL --, @f_out BIT=NULL
, @f_time_limit BIT=1 --//YUIL 2017-09-27 ����������� �� �������
) 
AS
------------------------------------------------------------------------------------------------------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_report_1
--1. ����� �� ������������ � ������������ �������

SET NOCOUNT ON

DECLARE @sz NVARCHAR(MAX);
DECLARE @table NVARCHAR(128); SET  @table='dbo._rep_1_out'; print '@table: '+@table;

IF (@i_mode=3)
BEGIN
	print N'Clearing';

	SET  @sz='TRUNCATE TABLE '+@table+';;';

	IF CHARINDEX(';;',@sz)=0 BEGIN RAISERROR('Error 5',18,5); RETURN; END

	EXEC sp_executesql @sz;

	RETURN; 
END

IF (@dt IS  NULL)  SET @dt=GETDATE();

SET @f_time_limit=ISNULL(@f_time_limit, 0)

--<q5  cr
SET  @sz=
'IF (OBJECT_ID('''+@table+''')IS NULL) '+
'BEGIN '+
 'CREATE TABLE '+@table+'(id_rep_out BIGINT IDENTITY(1,1), stop_id BIGINT, stop_name NVARCHAR(64), route_short_name NVARCHAR(8), hour INT, service_id BIGINT, arrival_time NVARCHAR(12), departure_time NVARCHAR(12), delta_time_min INT, garage_num NVARCHAR(8), quantity_car INT, arrival_time_1 NVARCHAR(12), departure_time_1 NVARCHAR(12), delta_time_min_1 INT, garage_num_1 NVARCHAR(8), quantity_car_1 INT, stop_x FLOAT, stop_y FLOAT); '+ 
 'CREATE CLUSTERED INDEX I_id_out ON '+@table+'(id_rep_out) '+
'END;;';

IF CHARINDEX(';;',@sz)=0 BEGIN RAISERROR('Error 1',18,1); RETURN; END

EXEC sp_executesql @sz;
-->q5

--<q6  sel
DECLARE @f_rows INT;

SET @sz='SET @f_rows=ISNULL((SELECT TOP 1 1 FROM '+@table+'), 0);;';

IF CHARINDEX(';;',@sz)=0 BEGIN RAISERROR('Error 4',18,4); RETURN; END

EXEC sp_executesql @sz, N'@f_rows INT OUTPUT', @f_rows OUTPUT;

IF (@f_rows=1) BEGIN print 'Already exec'; RETURN; END
-->q6

CREATE TABLE #out (i_mode TINYINT,  stop_id BIGINT, hour INT, arrival_time TIME, departure_time TIME, delta_time_min INT, route_short_name NVARCHAR(8), garage_num NVARCHAR(8), quantity_car INT, f_enabled_picas_calendar  BIT, service_id BIGINT, speed INT, device_number NVARCHAR(16), route_id NVARCHAR(32));

--<q2 fill
IF @i_mode IN (0)
BEGIN
	EXEC dbo.P_report_1_op_0 @dt=@dt, @stop_id=@stop_id, @hour=@hour, @route_id=@route_id, @f_time_limit=@f_time_limit
END ELSE
IF @i_mode IN (1, 4, 5, 6)
BEGIN
	EXEC dbo.P_report_1_op_1 @dt=@dt, @stop_id=@stop_id, @hour=@hour, @route_id=@route_id, @f_time_limit=@f_time_limit
END ELSE
IF @i_mode IN (2)
BEGIN
	EXEC dbo.P_report_1_op_0 @dt=@dt, @stop_id=@stop_id, @hour=@hour, @route_id=@route_id, @f_time_limit=@f_time_limit
	EXEC dbo.P_report_1_op_1 @dt=@dt, @stop_id=@stop_id, @hour=@hour, @route_id=@route_id, @f_time_limit=@f_time_limit
END
-->q2

ALTER TABLE #out DROP  COLUMN f_enabled_picas_calendar 

SET  @sz='';

IF @i_mode IN (0, 1)
BEGIN
	SET  @sz=
	'INSERT '+@table+' (stop_id,                                                                     stop_name, hour, arrival_time, departure_time, delta_time_min, route_short_name, garage_num, quantity_car, service_id) '+  --hour_arrival, min_arrival, sec_arrival, hour_departure, min_departure, sec_departure
	'SELECT             stop_id, (SELECT stop_name+'' (''+CONVERT(NVARCHAR(10), stop_lat)+'', ''+CONVERT(NVARCHAR(10), stop_lon)+'')''  FROM dbo.picas_stops s WHERE s.stop_id=o.stop_id)stop_name, hour '+
	', CONVERT(NVARCHAR(12), arrival_time)arrival_time '+
	', CONVERT(NVARCHAR(12), departure_time)departure_time '+
	', delta_time_min, route_short_name, garage_num, quantity_car, service_id FROM #out o;;';
END ELSE
IF @i_mode IN (2)
BEGIN

	--SELECT *, ROW_NUMBER() OVER (PARTITION BY stop_id,  route_short_name ORDER BY arrival_time)i_order FROM #out WHERE i_mode=0
	--stop_id, arrival_hour, arrival_time, departure_time, route_short_name, garage_num, quantity_car, f_enabled_picas_calendar, service_id
	
	CREATE TABLE #out_b (stop_id BIGINT, route_short_name NVARCHAR(8), arrival_time NVARCHAR(12), departure_time NVARCHAR(12), delta_time_min INT, garage_num NVARCHAR(8), quantity_car INT, arrival_time_1 NVARCHAR(12), departure_time_1 NVARCHAR(12), delta_time_min_1 INT, garage_num_1 NVARCHAR(8), quantity_car_1 INT, service_id BIGINT);

	INSERT #out_b (stop_id, route_short_name, arrival_time, departure_time, delta_time_min, garage_num, quantity_car, arrival_time_1, departure_time_1, delta_time_min_1, garage_num_1, quantity_car_1, service_id)
	SELECT  
 		ISNULL(m0.stop_id, m1.stop_id) stop_id  
		, ISNULL(m0.route_short_name, m1.route_short_name) route_short_name 
		, ISNULL(CONVERT(NVARCHAR(12), m0.arrival_time),'') arrival_time,   ISNULL(CONVERT(NVARCHAR(12), m0.departure_time),'') departure_time,   m0.delta_time_min, ISNULL(m0.garage_num,'') garage_num,   ISNULL(m0.quantity_car,0) quantity_car 
		, ISNULL(CONVERT(NVARCHAR(12), m1.arrival_time),'') arrival_time_1, ISNULL(CONVERT(NVARCHAR(12), m1.departure_time),'') departure_time_1, m1.delta_time_min, ISNULL(m1.garage_num,'') garage_num_1, ISNULL(m1.quantity_car,0) quantity_car_1 
		, m0.service_id
		FROM 
		(SELECT *, ROW_NUMBER() OVER (PARTITION BY stop_id,  route_short_name ORDER BY arrival_time)i_order FROM #out WHERE i_mode=0) m0 
		FULL JOIN  
		(SELECT *, ROW_NUMBER() OVER (PARTITION BY stop_id,  route_short_name ORDER BY arrival_time)i_order FROM #out WHERE i_mode=1) m1 
		ON (m1.stop_id = m0.stop_id AND m1.route_short_name = m0.route_short_name AND m1.i_order= m0.i_order) 
	
	--SELECT * FROM #out;SELECT * FROM #out_b

	SET  @sz=
	'INSERT '+@table+' (stop_id,                                                                      stop_name, route_short_name, arrival_time, departure_time, delta_time_min, garage_num, quantity_car, arrival_time_1, departure_time_1, delta_time_min_1, garage_num_1, quantity_car_1, service_id) '+
	'SELECT             stop_id, (SELECT stop_name+'' (''+CONVERT(NVARCHAR(10), stop_lat)+'', ''+CONVERT(NVARCHAR(10), stop_lon)+'')'' FROM dbo.picas_stops s WHERE s.stop_id=o.stop_id) stop_name, route_short_name, arrival_time, departure_time, delta_time_min, garage_num, quantity_car, arrival_time_1, departure_time_1, delta_time_min_1, garage_num_1, quantity_car_1, service_id FROM '+
	'#out_b o;;'
	
END ELSE
IF @i_mode IN (4)
BEGIN
	SET  @sz=
	'INSERT '+@table+' (stop_id,                                                            stop_name, route_short_name, garage_num, delta_time_min, arrival_time, departure_time, quantity_car) '+
	'SELECT             stop_id, (SELECT stop_name+'' (''+CONVERT(NVARCHAR(10), stop_lat)+'', ''+CONVERT(NVARCHAR(10), stop_lon)+'')'' FROM dbo.picas_stops s WHERE s.stop_id=o.stop_id), route_short_name, garage_num, delta_time_min,            0,              0,            0 FROM '+
	'(SELECT stop_id, route_short_name, garage_num, SUM(delta_time_min)delta_time_min FROM #out o GROUP BY stop_id, route_short_name, garage_num)o '+
	'ORDER BY stop_id, route_short_name, garage_num;;';
END ELSE
IF @i_mode IN (5)
BEGIN
	--SELECT *FROM #out o
	--SELECT DISTINCT stop_id FROM #out o

	SET  @sz=
	'INSERT '+@table+' (stop_id,                                                                                                    stop_name, stop_x, stop_y) '+
	'SELECT           o.stop_id, (SELECT s.stop_name+'' (''+CONVERT(NVARCHAR(10), s.stop_lat)+'', ''+CONVERT(NVARCHAR(10), s.stop_lon)+'')''),    s.x,    s.y FROM '+
	'(SELECT DISTINCT stop_id FROM #out o)o, dbo.picas_stops s WHERE s.stop_id=o.stop_id '+
	'ORDER BY o.stop_id;;';

	--print '@sz='+@sz
END ELSE
IF @i_mode IN (6)
BEGIN
	SET  @sz=
	'INSERT '+@table+' (departure_time, delta_time_min) '+
	'SELECT             departure_time, DATEDIFF(minute, 0, departure_time) FROM '+
	'(SELECT DISTINCT departure_time FROM #out o)o '+
	'ORDER BY departure_time;;';
END 

IF (@sz!='')
BEGIN
	IF CHARINDEX(';;',@sz)=0 BEGIN RAISERROR('Error 2',18,2); RETURN; END
	EXEC sp_executesql @sz;
END

--<q3  out
SET @sz='SELECT * FROM '+@table+';;';
IF CHARINDEX(';;',@sz)=0 BEGIN RAISERROR('Error 3',18,3); RETURN; END
EXEC sp_executesql @sz;

-->q3