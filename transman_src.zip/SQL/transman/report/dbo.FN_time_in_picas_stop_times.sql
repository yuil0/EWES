CREATE FUNCTION dbo.FN_time_in_picas_stop_times
(@dt DATETIME
,@stop_id BIGINT
,@shape_id NVARCHAR(32)
,@arrival_time TIME
,@departure_time TIME
)
RETURNS BIT
AS --D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.FN_time_in_picas_stop_times
BEGIN
	DECLARE @f_in BIT; 

	DECLARE @valid_dev_sec int; SET @valid_dev_sec = ISNULL((SELECT valid_dev_sec FROM dbo.const), 30) --YUIL 2017-10-06. ���������� ����������  � ��������

	/* ������� :
	SELECT arrival_time, departure_time FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
	AND stop_id=@stop_id  AND shape_id=@shape_id 
	ORDER BY arrival_time, departure_time
	*/

	--��������� �� �����
	SET @f_in=
	ISNULL((SELECT TOP 1 1 FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
			AND stop_id=@stop_id  AND shape_id=@shape_id 
			AND (@arrival_time >= DATEADD(second, - @valid_dev_sec, arrival_time) AND @arrival_time <= DATEADD(second, @valid_dev_sec, arrival_time))
			AND (@departure_time >= DATEADD(second, - @valid_dev_sec, departure_time) AND @departure_time <= DATEADD(second, @valid_dev_sec, departure_time))
			), 0)

	RETURN @f_in;
END