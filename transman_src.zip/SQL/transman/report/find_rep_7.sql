--D:\users\yuil\JOB\EWES\SQL\transman\report\find_rep_7
DECLARE @dt  DATETIME; SET @dt='2017-09-21T23:59:59'
DECLARE @f_night BIT; SET @f_night=NULL
-----------------------------------
DECLARE @dt_only DATETIME; SET @dt_only = dbo.FN_get_date(@dt) 

DECLARE @delta_time_stop_sec INT; SET @delta_time_stop_sec=300 --second == 5*60

/*
SELECT * FROM dbo.car_chrono WHERE lat IS NULL OR lng IS NULL ORDER  BY id_car_chrono

SELECT count(1) FROM dbo.car_chrono WHERE lat IS NULL OR lng IS NULL;
EXEC sp_spaceused 'dbo.car_chrono';

SELECT * FROM dbo.picas_agents 
SELECT * FROM dbo.picas_trips
SELECT * FROM dbo.picas_routes
*/

DECLARE @car_time AS TABLE  (id_car_time BIGINT IDENTITY(1,1), device_number NVARCHAR(16), i_order INT, route_id NVARCHAR(32), agency_name NVARCHAR(64), lat FLOAT, lng FLOAT, time TIME)

INSERT @car_time(device_number, i_order, route_id, agency_name, lat, lng, time)
SELECT device_number, i_order, t.route_id, a.name agency_name, lat, lng, time FROM
(SELECT device_number, 'rostov_'+ct.name_short_en+'_'+c.route_en route_id, dbo.FN_get_time(c.dt_created)time, DATEPART(hour, c.dt_created) hour, c.lat, c.lng
 , ROW_NUMBER() OVER (PARTITION BY device_number ORDER BY c.dt_created) i_order
 FROM dbo.car_chrono c, dbo.car_type ct
 WHERE ISNULL(route_en,'')!='' AND c.id_car_type=ct.id_car_type AND dbo.FN_get_date(c.dt_created) = @dt_only AND c.dt_created<=@dt AND c.lat IS NOT NULL AND c.lng IS NOT NULL
)t, dbo.picas_agents a, dbo.picas_routes r
WHERE (@f_night IS NULL OR (t.hour>=0 AND t.hour<5)) AND t.route_id=r.route_id AND r.agency_id=a.id
ORDER BY device_number

SELECT device_number, r.route_short_name, a.name agency_name, lat, lng, min_time, max_time, delta_time_sec FROM
(SELECT device_number, route_id, lat, lng, min_time, max_time, DATEDIFF(second, min_time, max_time)delta_time_sec FROM 
 (SELECT device_number, route_id, lat, lng, MIN(time)min_time, MAX(time)max_time FROM @car_time
  GROUP BY device_number, route_id, lat, lng
  HAVING count(1)>1
 )t
)t, dbo.picas_agents a, dbo.picas_routes r
WHERE t.delta_time_sec > @delta_time_stop_sec AND t.route_id=r.route_id AND r.agency_id=a.id
ORDER BY device_number, t.route_id, min_time

---SELECT t.*, DATEDIFF(second, p.time, t.time) delta_time_sec FROM @car_time t, @car_time p WHERE t.i_order>1 ANd p.id_car_time = t.id_car_time - 1 ORDER BY t.device_number, t.i_order