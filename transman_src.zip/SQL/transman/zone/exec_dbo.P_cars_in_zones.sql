--D:\users\yuil\JOB\EWES\SQL\transman\zone\exec_dbo.P_cars_in_zones


exec dbo.P_cars_in_zones
