ALTER PROC dbo.P_car_in_zones(@id_ate_3 BIGINT) AS
--//YUIL 2017-10-11 : D:\users\yuil\JOB\EWES\SQL\transman\zone\dbo.P_car_in_zones
	
DECLARE @x FLOAT, @y FLOAT; SELECT @x = x, @y = y FROM dbo.ate_3 WHERE id_ate_3 = @id_ate_3

--<q5 ���� �� �����
DECLARE @id_zone BIGINT; SET @id_zone=(SELECT MIN(id_zone) FROM dbo.zones);
	
DECLARE @f_in BIT; SET @f_in=0;

WHILE (@id_zone IS NOT NULL)AND(@f_in=0)
BEGIN
	EXEC dbo.P_in_zone @id_zone=@id_zone, @x=@x, @y=@y, @f_in=@f_in OUTPUT

	EXEC dbo.P_car_zone @id_ate_3=@id_ate_3, @id_zone=@id_zone, @f_in=@f_in

	SET @id_zone=(SELECT MIN(id_zone) FROM dbo.zones WHERE id_zone > @id_zone);
END

-->q5

