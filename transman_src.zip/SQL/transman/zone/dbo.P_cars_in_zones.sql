ALTER PROC dbo.P_cars_in_zones AS
--//YUIL 2017-10-11 : D:\users\yuil\JOB\EWES\SQL\transman\zone\dbo.P_cars_in_zones

SET NOCOUNT ON

DECLARE @id_ate_3 BIGINT; SET @id_ate_3=(SELECT MIN(id_ate_3) FROM dbo.ate_3);

--<q1  ���� �� �������
WHILE @id_ate_3 IS NOT NULL
BEGIN
	EXEC dbo.P_car_in_zones @id_ate_3=@id_ate_3;

	SET @id_ate_3=(SELECT MIN(id_ate_3) FROM dbo.ate_3 WHERE id_ate_3 > @id_ate_3);
END
-->q1