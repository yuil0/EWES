--D:\users\yuil\JOB\EWES\SQL\transman\zone\cr_table
--<q1
DROP TABLE dbo.zones
CREATE TABLE dbo.zones
(id_zone BIGINT IDENTITY(1,1)
, dt_created DATETIME --YUIL. ����/����� ��������  ������
, name NVARCHAR(32)
, quantity INT
, latitude_0 DECIMAL(10,6)
, longitude_0 DECIMAL(10,6)
, latitude_1 DECIMAL(10,6)
, longitude_1 DECIMAL(10,6)
, latitude_2 DECIMAL(10,6)
, longitude_2 DECIMAL(10,6)
, latitude_3 DECIMAL(10,6)
, longitude_3 DECIMAL(10,6)
)

ALTER  TABLE  dbo.zones ADD x_0 FLOAT, y_0 FLOAT, x_1 FLOAT, y_1 FLOAT, x_2 FLOAT, y_2 FLOAT, x_3 FLOAT, y_3 FLOAT
ALTER  TABLE  dbo.zones ADD id_zone_type BIGINT

CREATE CLUSTERED INDEX I_id_zone ON dbo.zones(id_zone) 

sp_spaceused 'dbo.zones'

SELECT * FROM dbo.zones --order  by id_zone

UPDATE z SET id_zone_type=1
FROM dbo.zones z WHERE name=N'���-3'

SELECT name, quantity, latitude_0, longitude_0, latitude_1, longitude_1, latitude_2, longitude_2, latitude_3, longitude_3 FROM dbo.zones

TRUNCATE TABLE dbo.zones 

INSERT dbo.zones(dt_created ,        name, quantity, latitude_0, longitude_0, latitude_1, longitude_1, latitude_2, longitude_2, latitude_3, longitude_3)
           SELECT GETDATE() , N'��������',        3,     47.31965,  39.68382,     47.26003,  39.67552,     47.21824,  39.71289,       NULL,        NULL
				 
/*
DROP TABLE dbo.zone_points
CREATE TABLE dbo.zone_points
(id_zone_point BIGINT IDENTITY(1,1)
, dt_created DATETIME --YUIL. ����/����� ��������  ������
, name NVARCHAR(32)
, latitude DECIMAL(10,6)
, longitude DECIMAL(10,6)
, id_zone_point_prev BIGINT --// YUIL. ���� 0 �� ������
)

CREATE CLUSTERED INDEX I_id_zone ON dbo.zone_points(id_zone_point) 

sp_spaceused 'dbo.zone_points'

SELECT * FROM dbo.zone_points --order  by id_zone

SELECT id_zone_point, name, latitude, longitude, id_zone_point_prev FROM dbo.zone_points

TRUNCATE TABLE dbo.zone_points 

INSERT dbo.zone_points(dt_created ,          name,  latitude, longitude, id_zone_point_prev)
                 SELECT GETDATE() , N'��������11',  47.31965,  39.68382,                  0 UNION
				 SELECT GETDATE() , N'��������12',  47.26003,  39.67552,                  1 UNION
				 SELECT GETDATE() , N'��������13',  47.21824,  39.71289,                  2
*/				 
-->q1

