ALTER PROC dbo.P_in_zones(@x FLOAT, @y FLOAT, @id_zone BIGINT OUTPUT) AS
--//YUIL 2017-10-11 : D:\users\yuil\JOB\EWES\SQL\transman\zone\dbo.P_in_zones
	
--<q5 ���� �� �����
SET @id_zone=(SELECT MIN(id_zone) FROM dbo.zones);
	
DECLARE @f_in BIT; SET @f_in=0;

WHILE (@id_zone IS NOT NULL)AND(@f_in=0)
BEGIN
	EXEC dbo.P_in_zone @id_zone=@id_zone, @x=@x, @y=@y, @f_in=@f_in OUTPUT

	IF (@f_in=0)
	BEGIN
		SET @id_zone=(SELECT MIN(id_zone) FROM dbo.zones WHERE id_zone > @id_zone);
	END 
END

-->q5

