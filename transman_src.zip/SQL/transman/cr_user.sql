CREATE USER [transman_user] FOR LOGIN [transman_user] WITH DEFAULT_SCHEMA=[dbo]



