CREATE FUNCTION dbo.FN_route_type_string(@route_type INT)
RETURNS NVARCHAR(6)
AS
BEGIN -- D:\users\yuil\JOB\EWES\SQL\transman\from_picas\dbo.FN_route_type_string
	DECLARE @sz NVARCHAR(6); 
	
	SET @sz= 
	CASE @route_type 
		WHEN 704	THEN N'���.'
		WHEN 800	THEN N'����.'
		WHEN 900	THEN N'����.'
		WHEN 1501	THEN N'����.'
	END;

	RETURN  @sz;
END