--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\picas_calendar_dates
--<q1

DROP TABLE dbo.picas_calendar_dates
CREATE TABLE dbo.picas_calendar_dates   --  197665,20180101,2
(id_calendar_date BIGINT IDENTITY(1,1)
, dt_created DATETIME --YUIL. ����/����� ��������  ������
, service_id BIGINT
, date DATETIME
, exception_type INT
)

CREATE CLUSTERED INDEX I_id_calendar_date ON dbo.picas_calendar_dates(id_calendar_date) 
CREATE NONCLUSTERED INDEX I_service_id ON dbo.picas_calendar_dates(service_id) 

sp_spaceused 'dbo.picas_calendar_dates'

SELECT * FROM dbo.picas_calendar_dates --order  by id_calendar_date

--SELECT name, quantity, latitude_0, longitude_0, latitude_1, longitude_1, latitude_2, longitude_2, latitude_3, longitude_3 FROM dbo.picas_calendar_dates

TRUNCATE TABLE dbo.picas_calendar_dates 

INSERT dbo.picas_calendar_dates(dt_created,  service_id, date, exception_type)
                    SELECT GETDATE(),        1234,  N'',              1
				 

-->q1

