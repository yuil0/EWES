--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\cr_tables.sql

--1. from_picas\routes.txt
--<q1
DROP TABLE dbo.picas_routes
CREATE TABLE dbo.picas_routes
(id_picas_route BIGINT IDENTITY(1,1)
, route_id NVARCHAR(32)
, agency_id NVARCHAR(16)
, route_short_name NVARCHAR(8)
,route_long_name NVARCHAR(256)
,route_desc NVARCHAR(8)
,route_type INT --YUIL 2017-09-05 . ��� ��� : NVARCHAR(8)
,route_url NVARCHAR(4)
,route_color NVARCHAR(2)
,route_text_color NVARCHAR(16)
)
-->q1
/*
YUIL 2017-08-09 15:49 ��������  ������ �� transman_srv :
//����� � �������. � ������� ����. � �������������.
[route_id][max_size:17] = 17*3/2 = 25,5  => 32
[agency_id][max_size:9] =>16
[route_short_name][max_size:3] = 3*3/2 = 4.5 => 8
[route_long_name][max_size:57] = 57*3/2 = 85,5  =>  128
[route_desc][max_size:3]
[route_type][max_size:3]
[route_url][max_size:1]
[route_color][max_size:0]
[route_text_color][max_size:5]
*/

--SET IDENTITY_INSERT dbo.picas_stops ON

CREATE CLUSTERED INDEX I_id_picas_route ON dbo.picas_routes(id_picas_route)
CREATE INDEX I_route_id ON dbo.picas_routes(route_id)
CREATE INDEX I_agency_id ON dbo.picas_routes(agency_id)


--2. from_picas\stops.txt
DROP TABLE dbo.picas_stops
CREATE TABLE dbo.picas_stops
(id_picas_stop BIGINT IDENTITY(1,1)
,stop_id BIGINT
,stop_code NVARCHAR(8)
,stop_name NVARCHAR(64)
,stop_desc NVARCHAR(32)
,stop_lat DECIMAL(10,6) --47.23235
,stop_lon DECIMAL(10,6) --39.77025
,stop_url NVARCHAR(16)
,location_type NVARCHAR(4)
,parent_station NVARCHAR(8)
,x FLOAT --YUIL 2017-09-07 � ������
,y FLOAT
)

SELECT * from sys.columns where OBJECT_ID=OBJECT_ID('dbo.picas_stops')

CREATE CLUSTERED INDEX I_id_picas_stop ON dbo.picas_stops(id_picas_stop)
CREATE INDEX I_stop_id ON dbo.picas_stops(stop_id)

--<w1
SELECT id_picas_route, route_id, agency_id, route_short_name, route_long_name, route_type FROM dbo.picas_routes --where LEN(ISNULL(route_short_name, ''))<1

SELECT id_picas_route, route_id, agency_id, dbo.FN_get_short_name(route_id, route_short_name)route_short_name, route_long_name, route_type FROM dbo.picas_routes

SELECT * FROM dbo.picas_stops --WHERE stop_name like N'%������%'

SELECT stop_id, count(1) FROM dbo.picas_stops
group by stop_id
having count(1)>1
order  by stop_id --�����

exec  sp_spaceused 'dbo.picas_routes'; -- rows =  130                 
exec  sp_spaceused 'dbo.picas_stops'; -- rows = 1196                

-->w1

DELETE FROM dbo.picas_routes
DELETE FROM dbo.picas_stops

--<q2
EXEC dbo.P_identity_insert_table @sz_table='dbo.picas_routes', @f_on=1
EXEC dbo.P_identity_insert_table @sz_table='dbo.picas_routes', @f_on=0
-->q2

GRANT EXEC ON dbo.P_identity_insert_table  TO [transman_user]