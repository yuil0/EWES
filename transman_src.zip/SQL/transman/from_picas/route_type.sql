--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\route_type
SELECT r.route_type, (SELECT TOP 1 route_id FROM dbo.picas_routes s WHERE s.route_type=r.route_type) route_id FROM 
(SELECT DISTINCT route_type FROM dbo.picas_routes)r


SELECT *, dbo.FN_route_type_string(r.route_type)  FROM dbo.picas_routes r