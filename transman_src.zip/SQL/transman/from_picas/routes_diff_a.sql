--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\routes_diff_a
SELECT r.* FROM dbo.picas_routes r, dbo.car_type ct WHERE r.route_id!='rostov_'+ct.name_short_en+'_'+route_short_name AND r.route_type=ct.picas_type

/*
SELECT * FROM [dbo].[car_type]

SELECT ASCII('a')
SELECT ASCII('�') --RU
SELECT ASCII('�') --RU from XLSX


UPDATE [dbo].[car_type] SET picas_type=800
WHERE id_car_type=1




*/