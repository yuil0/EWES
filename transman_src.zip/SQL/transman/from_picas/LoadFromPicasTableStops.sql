CREATE PROC dbo.LoadFromPicasTableStops
( @stop_id NVARCHAR(8)
,@stop_code NVARCHAR(4)
,@stop_name NVARCHAR(64)
,@stop_desc NVARCHAR(32)
,@stop_lat DECIMAL(10,6) --47.23235
,@stop_lon DECIMAL(10,6) --39.77025
,@stop_url NVARCHAR(16)
,@location_type NVARCHAR(4)
,@parent_station NVARCHAR(8))
AS --D:\users\yuil\JOB\EWES\SQL\transman\from_picas\LoadFromPicasTableStops.sql