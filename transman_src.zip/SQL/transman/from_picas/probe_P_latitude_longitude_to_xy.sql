--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\probe_P_latitude_longitude_to_xy
DECLARE @shape_id NVARCHAR(32); SET @shape_id='rostov_bus_1_a-b'

SELECT * FROM dbo.picas_shapes WHERE (x IS NULL OR y IS NULL) AND @shape_id

--<q1
DECLARE @x FLOAT;
DECLARE @y FLOAT;
EXEC dbo.P_latitude_longitude_to_xy @lat=47.31965, @lng=39.68382, @x=@x OUTPUT, @y=@y OUTPUT;

SELECT  @x[@x], @y[@y]
