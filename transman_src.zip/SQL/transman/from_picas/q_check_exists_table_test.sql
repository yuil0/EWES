--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\q_check_exists_table_test
DECLARE @sz_table NVARCHAR(64); SET @sz_table='dbo.picas_stops' --'dbo.picas_stop_times'
DECLARE @sz_table_test NVARCHAR(64); SET @sz_table_test=@sz_table+'_test'

SELECT CONVERT(BIT, CASE WHEN OBJECT_ID(@sz_table) IS NOT NULL THEN 1 ELSE 0 END) [table]
SELECT CASE WHEN OBJECT_ID(@sz_table_test) IS NOT NULL THEN 1 ELSE 0 END [table_test]