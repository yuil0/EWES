--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\cr_route_shape
--<q1
DROP TABLE dbo.route_shape
CREATE TABLE dbo.route_shape
(
 id_route_shape BIGINT --IDENTITY(1,1)
,dt_create DATETIME
,id_picas_route BIGINT
,f_direct BIT -- 1:������ �����������, 0:��������
,shape_id NVARCHAR(32)
)

-->q1

CREATE CLUSTERED INDEX I_id_route_shape  ON dbo.route_shape(id_route_shape)
CREATE NONCLUSTERED INDEX I_id_picas_route  ON dbo.route_shape(id_picas_route)  INCLUDE(f_direct)

--select* from dbo.picas_routes
--select* from dbo.picas_shapes
--select* from dbo.picas_shapes WHERE shape_id LIKE '%_a-b%'