ALTER  PROC dbo.P_fill_picas_shape_ids
AS -- D:\users\yuil\JOB\EWES\SQL\transman\from_picas\dbo.P_fill_picas_shape_ids.sql
BEGIN
	TRUNCATE TABLE dbo.picas_shape_ids; --DECLARE id_max BIGINT; SET id_max=ISNULL((SELECT id_picas_shape_id), 0) + 1;

	--fill
	DECLARE @t AS TABLE(id BIGINT IDENTITY(1,1), shape_id NVARCHAR(32));
 
	INSERT @t(shape_id) SELECT distinct shape_id FROM dbo.picas_shapes order  by  1

	SET IDENTITY_INSERT dbo.picas_shape_ids  ON 

	INSERT dbo.picas_shape_ids(id_picas_shape_id, shape_id) SELECT id, shape_id FROM @t

	SET IDENTITY_INSERT dbo.picas_shape_ids  OFF

	--update src

	UPDATE s SET 
	s.id_shape_id = (SELECT id_picas_shape_id FROM dbo.picas_shape_ids i WHERE i.shape_id = s.shape_id)
	FROM dbo.picas_shapes s  

	--<q3 lines	


	--exec sp_spaceused 'dbo.picas_shape_lines' --rows=62846               
	
	TRUNcATE TABLE dbo.picas_shape_lines

	INSERT dbo.picas_shape_lines(shape_id,   route_long_name,       from_lat ,       from_lon ,       from_sequence ,          to_lat ,         to_lon ,                     to_sequence, direct, route_short_name)
	SELECT s.shape_id, r.route_long_name, s.shape_pt_lat from_lat, s.shape_pt_lon from_lon,  s.shape_pt_sequence from_sequence,  p.shape_pt_lat to_lat, p.shape_pt_lon to_lon, ISNULL(p.shape_pt_sequence,- 1) to_sequence
	 ,CASE WHEN SUBSTRING(s.shape_id, LEN(s.shape_id)-2, LEN(s.shape_id))='a-b' THEN 1 ELSE 0 END direct
	 ,dbo.FN_get_short_name(r.route_id, r.route_short_name)route_short_name
	FROM dbo.picas_shapes s 
	LEFT JOIN dbo.picas_shapes p ON (p.id_picas_shape = s.id_prev)
	LEFT JOIN dbo.picas_routes r ON (r.route_id = dbo.GetPartName(s.shape_id, 3))
	--LEFT JOIN dbo.picas_routes r2 ON (SUBSTRING(r.route_id,1, LEN(r.route_id)-1) = dbo.GetPartName(s.shape_id, 3))
	WHERE s.shape_pt_sequence>0
	
	
	UPDATE sl SET sl.route_long_name=r.route_long_name,  route_short_name=dbo.FN_get_short_name(r.route_id, r.route_short_name)
	FROM dbo.picas_shape_lines sl LEFT JOIN dbo.picas_routes r ON (SUBSTRING(r.route_id, 1, LEN(r.route_id)-1) = dbo.GetPartName(sl.shape_id, 3))
	WHERE sl.route_long_name IS NULL

	/*
	SELECT s.shape_id , count(distinct r.route_long_name)  --r.route_long_name
	FROM dbo.picas_shapes s , dbo.picas_routes r WHERE r.route_id = dbo.GetPartName(s.shape_id)+'_'+CONVERT(NVARCHAR(10), r.route_short_name) 
	group by s.shape_id
	having count(distinct r.route_long_name)>1
	order  by s.shape_id--- , r.route_long_name

	SELECT r.route_long_name FROM dbo.picas_routes r WHERE r.route_id = dbo.GetPartName('rostov_bus_1_a-b')+'_'+CONVERT(NVARCHAR(10), r.route_short_name)

	shape_id='rostov_bus_1_a-b'
	*/

	--SELECT dbo.GetPartName('rostov_bus_1_a-b')

 /*
 DECLARE @r AS TABLE(id_order BIGINT IDENTITY(1,1), id_picas_shape BIGINT)

 INSERT @r (id_picas_shape) SELECT id_picas_shape FROM dbo.picas_shapes ORDER BY id_shape_id, shape_pt_sequence

 DECLARE @n AS  TABLE 
	(id_picas_shape BIGINT IDENTITY(1,1)
	,shape_id NVARCHAR(32)     
	,shape_pt_lat DECIMAL(10,6)
	,shape_pt_lon DECIMAL(10,6)
	/*,shape_pt_sequence INT
	,shape_dist_traveled NVARCHAR(2)     
	,id_shape_id BIGINT*/
	,id_prev BIGINT )

 INSERT @n(shape_id , shape_pt_lat , shape_pt_lon /*, shape_pt_sequence , shape_dist_traveled , id_shape_id*/ , id_prev)
    SELECT shape_id , shape_pt_lat , shape_pt_lon -- , shape_pt_sequence , shape_dist_traveled , id_shape_id  
	       ,ISNULL((SELECT id_picas_shape FROM @r r WHERE r.id_order = (SELECT id_order FROM @r x WHERE x.id_picas_shape = s.id_picas_shape) - 1),  0)
	FROM dbo.picas_shapes s
	*/
 /* UPDATE s SET 
  s.id_prev = (SELECT id_picas_shape FROM @r r WHERE r.id_order = (SELECT id_order FROM @r x WHERE x.id_picas_shape = s.id_picas_shape) - 1) -- ISNULL((SELECT id_picas_shape FROM dbo.picas_shapes i 
				--	  WHERE i.id_shape_id = s.id_shape_id 
				--	   AND  i.shape_pt_sequence = (SELECT MAX(x.shape_pt_sequence) FROM dbo.picas_shapes x WHERE x.id_shape_id = s.id_shape_id AND x.shape_pt_sequence < s.shape_pt_sequence)
                --     ), 0)
 FROM dbo.picas_shapes s   */

END

