--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\find_near_pn_by_shape

DECLARE @shape_id NVARCHAR(32); SET @shape_id='rostov_bus_96_b-a';

DECLARE @stop_id BIGINT; SET @stop_id=835
--
DECLARE @stop_x FLOAT,  @stop_y FLOAT; SELECT @stop_x=x, @stop_y=y FROM dbo.picas_stops WHERE stop_id=@stop_id

SELECT x, y, dist, sign_d_x, sign_d_y FROM
(SELECT x, y, dist, sign_d_x, sign_d_y, ROW_NUMBER() OVER(ORDER BY dist)i_order FROM  --PARTITION BY sign_d_x, sign_d_y
 (SELECT x, y, dbo.FN_get_dist(@stop_x, @stop_y, x, y)dist, SIGN(@stop_x - x)sign_d_x, SIGN(@stop_y - y)sign_d_y FROM dbo.picas_shapes s WHERE s.shape_id=@shape_id)t
 WHERE dist!=0 
)t WHERE i_order<=2
ORDER BY dist

/*
SELECT x, y, shape_pt_sequence, dbo.FN_get_dist(@stop_x, @stop_y, x, y)dist, (@stop_x - x)d_x, (@stop_y - y)d_y
FROM dbo.picas_shapes s WHERE s.shape_id=@shape_id
ORDER BY 4
*/