--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\picas_stop_times
--<q1

DROP TABLE dbo.picas_stop_times
CREATE TABLE dbo.picas_stop_times   --  1,05:28:00,05:30:00,6374,1,0,0
(id_stop_time BIGINT IDENTITY(1,1)
, dt_created DATETIME --YUIL. ����/����� ��������  ������
, trip_id BIGINT
, arrival_time TIME
, departure_time TIME
, stop_id BIGINT
, stop_sequence INT
, pickup_type INT
, drop_off_type TINYINT

)

CREATE CLUSTERED INDEX I_id_stop_time ON dbo.picas_stop_times(id_stop_time) 

sp_spaceused 'dbo.picas_stop_times'

SELECT * FROM dbo.picas_stop_times --order  by id_stop_time

--SELECT name, quantity, latitude_0, longitude_0, latitude_1, longitude_1, latitude_2, longitude_2, latitude_3, longitude_3 FROM dbo.picas_stop_times

TRUNCATE TABLE dbo.picas_stop_times 

INSERT dbo.picas_stop_times(dt_created,  trip_id, arrival_time, departure_time, stop_id, stop_sequence, pickup_type, drop_off_type)
                SELECT GETDATE(),      123,          N'',            N'',     123,             1,           1,             1
				 

-->q1

