CREATE FUNCTION dbo.FN_get_near_car(@route_id NVARCHAR(32), @x FLOAT, @y FLOAT)
RETURNS BIGINT
AS -- D:\users\yuil\JOB\EWES\SQL\transman\common\dbo.FN_get_near_car
BEGIN
	DECLARE @id_ate_3 BIGINT 

	SET @id_ate_3=
	(SELECT id_ate_3 FROM
	 (SELECT c.id_ate_3, ROW_NUMBER() OVER (ORDER BY c.dist)i_order FROM (SELECT id_ate_3, dbo.FN_get_dist(c.x, c.y, @x,  @y) dist FROM dbo.ate_3 c WHERE route_id=@route_id)c
	 )c WHERE c.i_order=1
	)

	RETURN @id_ate_3;
END