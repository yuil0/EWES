CREATE PROC dbo.P_latitude_longitude_to_xy(@lat FLOAT, @lng FLOAT, @x FLOAT OUTPUT, @y FLOAT OUTPUT) AS
-----//YUIL 2017-10-13 : D:\users\yuil\JOB\EWES\SQL\transman\common\dbo.P_latitude_longitude_to_xy

DECLARE @R FLOAT; SET @R = 6378137; --//YUIL � ������ ������  �����          --DECLARE @MAX_LATITUDE FLOAT; SET @MAX_LATITUDE = 85.0511287798;

DECLARE @d FLOAT; SET @d = PI() / 180;

DECLARE @dMax FLOAT; SET @dMax = 85.0511287798; -- @MAX_LATITUDE;

DECLARE @min_dMax_lat FLOAT; SET @min_dMax_lat=CASE WHEN @dMax < @lat THEN @dMax ELSE @lat END;

DECLARE @t_lat FLOAT; SET @t_lat = CASE WHEN @min_dMax_lat > (- @dMax) THEN @min_dMax_lat ELSE (- @dMax) END; --max( min(@dMax, @lat), - @dMax);

DECLARE @dSin FLOAT; SET @dSin = SIN(@t_lat * @d);

SET @x = @R * @lng * @d;

SET @y = @R * LOG((1 + @dSin) / (1 - @dSin)) / 2;