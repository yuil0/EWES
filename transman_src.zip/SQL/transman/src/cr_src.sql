--D:\users\yuil\JOB\EWES\SQL\transman\src\cr_src
--<q1
DROP TABLE dbo.src
CREATE TABLE dbo.src
(id_src BIGINT IDENTITY(1,1)
, name NVARCHAR(32) --YUIL 2017-09-15 dbo.picas_routes
)
-->q1


CREATE CLUSTERED INDEX I_id_src ON dbo.src(id_src) 

SELECT * FROM dbo.src

INSERT dbo.src(name) SELECT 'dbo.raw_car'