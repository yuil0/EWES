--D:\users\yuil\JOB\EWES\SQL\transman\exec\date_format

DECLARE @i_format INT; SET @i_format=100;
DECLARE @i_format_max INT; SET @i_format_max=299;

DECLARE @dt DATETIME; SET @dt=GETDATE();

WHILE @i_format<=@i_format_max
BEGIN
 BEGIN TRY 
	print '@i_format='+CONVERT(NVARCHAR(10), @i_format)+' result='+CONVERT(NVARCHAR(60), @dt, @i_format);
 END TRY 
 BEGIN CATCH 
	print '@i_format='+CONVERT(NVARCHAR(10), @i_format)+' not valid';
 END CATCH 

 SET @i_format=@i_format+1;
END