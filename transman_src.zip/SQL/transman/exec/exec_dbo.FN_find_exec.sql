--D:\users\yuil\JOB\EWES\SQL\transman\exec\exec_dbo.FN_find_exec

SELECT r.session_id,t.text FROM sys.dm_exec_requests r CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) t WHERE r.session_id!=@@SPID


SELECT dbo.FN_find_exec('1=1') 