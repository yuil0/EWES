--D:\users\yuil\JOB\EWES\SQL\transman\EXEC_dbo.P_day_back


EXEC dbo.P_day_back @i_days_back=2