--D:\users\yuil\JOB\EWES\sql\transman\raw_car\find_set_ate_3_by_raw
--SELECT * FROM dbo.raw_car

SELECT device_number, dt_create, latitude, longitude, azimut, speed, ISNULL(id_agent,0)id_agent FROM
(SELECT device_number, dt_create, latitude, longitude, azimut, speed, id_agent
 ,ROW_NUMBER() OVER(PARTITION BY device_number ORDER BY dt_create DESC)i_order  FROM dbo.raw_car WHERE latitude!=0 AND longitude!=0
)r WHERE i_order=1

--GROUP BY device_number
