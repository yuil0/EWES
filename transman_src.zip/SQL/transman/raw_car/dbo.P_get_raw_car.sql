ALTER PROC [dbo].[P_get_raw_car]
AS
----------------------------------------
--D:\users\yuil\JOB\EWES\sql\transman\raw_car\dbo.P_get_raw_car
SELECT device_number, REPLACE(latitude,',','.')latitude, REPLACE(longitude,',','.')longitude, azimut, speed, ISNULL(id_agent,0)id_agent FROM
(SELECT device_number, latitude, longitude, azimut, speed, id_agent
 ,ROW_NUMBER() OVER(PARTITION BY device_number ORDER BY dt_create DESC)i_order  FROM dbo.raw_car WHERE latitude!=0 AND longitude!=0
)r WHERE i_order=1
