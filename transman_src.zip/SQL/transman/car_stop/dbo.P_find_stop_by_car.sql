ALTER PROC dbo.P_find_stop_by_car(@dt DATETIME, @id_ate_3 BIGINT, @route_id NVARCHAR(32), @x FLOAT, @y FLOAT)AS
------------------------------------------- //YUIL 2017-10-13 : D:\users\yuil\JOB\EWES\SQL\transman\car_stop\dbo.P_find_stop_by_car
DECLARE @stop_radius FLOAT; SELECT @stop_radius=stop_radius FROM dbo.const

DECLARE @stop AS TABLE(i_stop BIGINT IDENTITY(1,1), stop_id BIGINT)

INSERT @stop(stop_id) SELECT s.stop_id FROM dbo.picas_stops s WHERE dbo.FN_cross(@x, @y, s.x, s.y, @stop_radius)=1 
AND s.id_picas_stop IN (SELECT DISTINCT id_picas_stop FROM dbo.check_points cp, dbo.picas_routes r WHERE cp.id_picas_route = r.id_picas_route AND r.route_id = @route_id)  --SELECT s.stop_id FROM () s --, (SELECT DISTINCT st.stop_id FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND t.route_id=@route_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1) t WHERE s.stop_id=t.stop_id

IF NOT EXISTS(SELECT * FROM @stop) RETURN

DECLARE @stop_id_1 BIGINT; SET @stop_id_1=(SELECT stop_id FROM @stop WHERE i_stop=1)
DECLARE @stop_id_2 BIGINT; SET @stop_id_2=(SELECT stop_id FROM @stop WHERE i_stop=2)

DECLARE @id_car_last_stop BIGINT; SET @id_car_last_stop=(SELECT id_car_last_stop FROM dbo.car_last_stops WHERE id_ate_3=@id_ate_3 AND route_id=@route_id)

IF @id_car_last_stop IS NULL
BEGIN
	INSERT dbo.car_last_stops(dt_created,  id_ate_3,  route_id,  stop_id_1,  stop_id_2, car_x, car_y) 
	SELECT                           @dt, @id_ate_3, @route_id, @stop_id_1, @stop_id_2,    @x,    @y
END ELSE
BEGIN
	UPDATE dbo.car_last_stops
	SET dt_update = @dt
	, stop_id_1_prev = stop_id_1
	, stop_id_2_prev = stop_id_2
	, stop_id_1 = @stop_id_1
	, stop_id_2 = @stop_id_2
	,     car_x = @x
	,     car_y = @y
	WHERE id_car_last_stop= @id_car_last_stop AND stop_id_1 NOT IN (SELECT stop_id FROM @stop) AND (stop_id_2 IS NULL OR stop_id_2 NOT IN (SELECT stop_id FROM @stop))
END
