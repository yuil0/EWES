ALTER  PROC dbo.P_view_mes_by_type
( @id_user BIGINT
, @id_user_type_to BIGINT
) AS 
------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\chat\dbo.P_view_mes_by_type
SELECT TOP 14 h.id_chat_mes_head, REPLACE(CONVERT(NVARCHAR(40), dt_create, 120),':000', '') dt_create
, ISNULL((SELECT user_name FROM dbo.users u WHERE u.id_user = h.id_user_from), '') user_from
, ISNULL((SELECT user_name FROM dbo.users u WHERE u.id_user = h.id_user_to), '') user_to
, id_chat_mes_type
, mes 
,ISNULL
 ((SELECT b.garage_num FROM dbo.ate_3_book b, dbo.users u WHERE b.device_number = u.device_number 
   AND 
   (   u.id_user = h.id_user_to AND h.id_user_to IN (SELECT id_user FROM dbo.users u WHERE u.id_user_type = @id_user_type_to)
    OR u.id_user = h.id_user_from AND h.id_user_from IN (SELECT id_user FROM dbo.users u WHERE u.id_user_type = @id_user_type_to)
   )
 ), N'') garage_num

FROM dbo.chat_mes_head h, dbo.chat_mes m WHERE h.id_chat_mes_head=m.id_chat_mes_head 
AND 
(   (@id_user = h.id_user_from AND h.id_user_to IN (SELECT id_user FROM dbo.users u WHERE u.id_user_type = @id_user_type_to))  --//YUIL 2017-02-14 
 OR (@id_user = h.id_user_to AND h.id_user_from IN (SELECT id_user FROM dbo.users u WHERE u.id_user_type = @id_user_type_to))
)

ORDER BY h.id_chat_mes_head DESC

