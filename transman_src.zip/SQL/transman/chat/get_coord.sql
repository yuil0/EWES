--D:\users\yuil\JOB\EWES\SQL\transman\chat\get_coord

DECLARE @id_user BIGINT; SET @id_user=8

SELECT mes FROM dbo.chat_mes WHERE id_chat_mes_head=(SELECT MAX(id_chat_mes_head) FROM dbo.chat_mes_head h WHERE id_chat_mes_type=4 AND id_user_to=@id_user)


/*SELECT * FROM dbo.chat_mes
SELECT * FROM dbo.users*/
