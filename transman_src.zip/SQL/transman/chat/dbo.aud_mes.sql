
--D:\users\yuil\JOB\EWES\SQL\transman\chat\dbo.aud_mes

--<q1
DROP TABLE dbo.aud_mes
CREATE TABLE dbo.aud_mes
( id_aud_mes BIGINT IDENTITY(1,1)
, id_chat_mes_head BIGINT
, duration_seconds INT
, aud_file NVARCHAR(512)
, dt_start DATETIME
, dt_end DATETIME
)

-->q1

CREATE CLUSTERED INDEX I_id_aud_mes ON dbo.aud_mes(id_aud_mes)
CREATE INDEX I_id_chat_mes_head ON dbo.aud_mes(id_chat_mes_head)

ALTER TABLE dbo.aud_mes ADD asterisk_id NVARCHAR(15)

SELECT * FROM  dbo.aud_mes
asterisk_id NVARCHAR(15)