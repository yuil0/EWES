--D:\users\yuil\JOB\EWES\SQL\transman\chat\cr_aud_states
--<q0
DROP TABLE dbo.aud_states
CREATE TABLE dbo.aud_states
( id_aud_state BIGINT IDENTITY(1,1)
, name NVARCHAR(32)
, name_en NVARCHAR(32)
)
-->q0
CREATE CLUSTERED INDEX I_id_aud_state ON dbo.aud_states(id_aud_state)

TRUNCATE TABLE dbo.aud_states
INSERT dbo.aud_states(name, name_en) SELECT N'������', N'Answer'
INSERT dbo.aud_states(name, name_en) SELECT N'�����', N'Busy'
INSERT dbo.aud_states(name, name_en) SELECT N'��������', N'Not answer'
INSERT dbo.aud_states(name, name_en) SELECT N'� ��������', N'Process'

SELECT * FROM dbo.aud_states
