ALTER PROC dbo.P_add_chat_mes
(
  @id_user_from BIGINT
, @id_user_to BIGINT=NULL
, @id_chat_mes_state BIGINT
, @id_chat_mes_type BIGINT
, @mes NVARCHAR(1024) 
, @f_all BIT=0 --//YUIL 2017-01-24 ����
) AS --D:\users\yuil\JOB\EWES\SQL\transman\chat\dbo.P_add_chat_mes
------------------------------------
SET NOCOUNT ON;

--<q5 ��������� ��� ��������
SET NOCOUNT ON 

DECLARE @id_chat_mes BIGINT; SET @id_chat_mes=ISNULL((SELECT MAX(id_chat_mes) FROM dbo.chat_mes), 0)

DECLARE @id_chat_mes_head BIGINT; SET @id_chat_mes_head=ISNULL((SELECT MAX(id_chat_mes_head) FROM dbo.chat_mes_head), 0)

IF (@id_user_to IS NULL)
BEGIN
	IF (@f_all=0)
	BEGIN
		DECLARE @list_coll AS TABLE(id_coll BIGINT IDENTITY(1,1), id_user BIGINT);

		INSERT @list_coll(id_user) SELECT id_user FROM dbo.user_binds WHERE id_user_one=@id_user_from;

		SET IDENTITY_INSERT dbo.chat_mes ON
		INSERT dbo.chat_mes(id_chat_mes,              id_chat_mes_head,  mes)
		SELECT @id_chat_mes + c.id_coll, @id_chat_mes_head + c.id_coll, @mes FROM @list_coll c
		SET IDENTITY_INSERT dbo.chat_mes OFF

		SET IDENTITY_INSERT dbo.chat_mes_head ON
		INSERT dbo.chat_mes_head(id_chat_mes_head,  dt_create,  id_user_from,  id_user_to,  id_chat_mes_state,  id_chat_mes_type)
		SELECT      @id_chat_mes_head + c.id_coll,  GETDATE(), @id_user_from,   c.id_user, @id_chat_mes_state, @id_chat_mes_type FROM @list_coll c
		SET IDENTITY_INSERT dbo.chat_mes_head OFF
	END ELSE
	BEGIN
		SET IDENTITY_INSERT dbo.chat_mes ON
		INSERT dbo.chat_mes(id_chat_mes,      id_chat_mes_head,  mes)
		SELECT         @id_chat_mes + 1, @id_chat_mes_head + 1, @mes
		SET IDENTITY_INSERT dbo.chat_mes OFF

		SET IDENTITY_INSERT dbo.chat_mes_head ON
		INSERT dbo.chat_mes_head(id_chat_mes_head,  dt_create,  id_user_from,  id_chat_mes_state,  id_chat_mes_type)
		SELECT              @id_chat_mes_head + 1,  GETDATE(), @id_user_from, @id_chat_mes_state, @id_chat_mes_type
		SET IDENTITY_INSERT dbo.chat_mes_head OFF		
	END	
END
ELSE
BEGIN
	SET IDENTITY_INSERT dbo.chat_mes ON
	INSERT dbo.chat_mes(id_chat_mes,      id_chat_mes_head,  mes)
	SELECT         @id_chat_mes + 1, @id_chat_mes_head + 1, @mes
	SET IDENTITY_INSERT dbo.chat_mes OFF

	SET IDENTITY_INSERT dbo.chat_mes_head ON
	INSERT dbo.chat_mes_head(id_chat_mes_head,  dt_create,  id_user_from,  id_user_to,  id_chat_mes_state,  id_chat_mes_type)
	SELECT              @id_chat_mes_head + 1,  GETDATE(), @id_user_from, @id_user_to, @id_chat_mes_state, @id_chat_mes_type
	SET IDENTITY_INSERT dbo.chat_mes_head OFF
END
-->q5