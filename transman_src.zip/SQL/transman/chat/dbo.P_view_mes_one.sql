ALTER PROC dbo.P_view_mes_one 
( @id_user BIGINT
, @i_quantity INT=NULL --, @id_user_type_to BIGINT=NULL --//YUIL 2017-02-13 ��� ������������ : ����
) AS --//YUIL 2017-02-14 ��� ���������
------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\chat\dbo.P_view_mes_one

--EXEC dbo.P_clear_mes

IF  (@i_quantity IS NULL)
BEGIN
	SET @i_quantity=(SELECT COUNT(1) FROM dbo.chat_mes)
END

SELECT TOP (@i_quantity) h.id_chat_mes_head, REPLACE(CONVERT(NVARCHAR(40), dt_create, 120),':000', '') dt_create
, ISNULL((SELECT user_name FROM dbo.users u WHERE u.id_user = h.id_user_from), '') user_from
, ISNULL((SELECT user_name FROM dbo.users u WHERE u.id_user = h.id_user_to), '') user_to
, id_chat_mes_type
, mes 
FROM dbo.chat_mes_head h, dbo.chat_mes m WHERE h.id_chat_mes_head=m.id_chat_mes_head 
AND 
(   (@id_user = h.id_user_from AND h.id_user_to IN (SELECT id_user FROM dbo.users u WHERE u.id_user_type!=4))  --//YUIL 2017-02-14 ��� ���������
 OR (@id_user = h.id_user_to AND h.id_user_from IN (SELECT id_user FROM dbo.users u WHERE u.id_user_type!=4))
)

ORDER BY h.id_chat_mes_head DESC

