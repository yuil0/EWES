﻿--D:\users\yuil\JOB\EWES\SQL\transman\common.sql

--<q2
CREATE TABLE dbo.state(id_state BIGINT IDENTITY(1,1), dt_created DATETIME, name NVARCHAR(32))
CREATE CLUSTERED INDEX I_id_state ON dbo.state(id_state)

INSERT dbo.state(dt_created , name ) SELECT GETDATE(), N'Работает'
INSERT dbo.state(dt_created , name ) SELECT GETDATE(), N'Не работает'
INSERT dbo.state(dt_created , name ) SELECT GETDATE(), N'Не известно'


TRUNCATE TABLE dbo.state

SELECT * FROM dbo.state
-->q2

--<q1
CREATE TABLE dbo.org(id_org BIGINT IDENTITY(1,1), dt_created DATETIME, id_state BIGINT, name NVARCHAR(32), name_long NVARCHAR(MAX))
CREATE CLUSTERED INDEX I_id_org ON dbo.org(id_org)

INSERT dbo.org(dt_created , id_state , name , name_long) SELECT GETDATE(), 3, N'Оргкомитет', N'АНО «Оргкомитет «Россия-2018»'
INSERT dbo.org(dt_created , id_state , name , name_long) SELECT GETDATE(), 3, N'ТрансДир', N'АНО «Транспортная дирекция-2018»'
INSERT dbo.org(dt_created , id_state , name , name_long) SELECT GETDATE(), 3, N'ФедПеревоз', N'Федеральный центр управления пассажирскими перевозками'
INSERT dbo.org(dt_created , id_state , name , name_long) SELECT GETDATE(), 3, N'ЮжВоздух', N'Южное межрегиональное территориальное управление воздушного транспорта Федерального агентства воздушного транспорта (Росавиация)'
INSERT dbo.org(dt_created , id_state , name , name_long) SELECT GETDATE(), 3, N'КавказЖД', N'Северо-Кавказская региональная дирекция железнодорожных вокзалов'
INSERT dbo.org(dt_created , id_state , name , name_long) SELECT GETDATE(), 3, N'ЮжНадзор', N'Управление государственного авиационного надзора и надзора за обеспечением транспортной безопасности по Южному федеральному округу Федеральной службы по надзору в сфере транспорта'
INSERT dbo.org(dt_created , id_state , name , name_long) SELECT GETDATE(), 3, N'МВД', N'Главное управление Министерства внутренних дел России по Ростовской области'
INSERT dbo.org(dt_created , id_state , name , name_long) SELECT GETDATE(), 3, N'ФедБез', N'Управление Федеральной службы безопасности России по Ростовской области'
INSERT dbo.org(dt_created , id_state , name , name_long) SELECT GETDATE(), 3, N'МЧС', N'Главное управление МЧС России по Ростовской области'
INSERT dbo.org(dt_created , id_state , name , name_long) SELECT GETDATE(), 3, N'ФедОхр', N'Федеральная служба охраны Российской Федерации'

SELECT * FROM dbo.org
SELECT id_org, name , name_long FROM dbo.org
-->q1

--<q3
CREATE TABLE dbo.module(id_module BIGINT IDENTITY(1,1), dt_created DATETIME, id_state BIGINT, name NVARCHAR(32), name_long NVARCHAR(MAX))
CREATE CLUSTERED INDEX I_id_module ON dbo.module(id_module)

TRUNCATE TABLE dbo.module

INSERT dbo.module(dt_created , id_state , name , name_long ) SELECT GETDATE(), 3, N'Монитор' , N'Телематическая транспортная система мониторинга местонахождения транспортных средств'
INSERT dbo.module(dt_created , id_state , name , name_long ) SELECT GETDATE(), 3, N'Оператор' , N'Система оперативного управления транспортными и пассажирскими потоками'
INSERT dbo.module(dt_created , id_state , name , name_long ) SELECT GETDATE(), 3, N'Прогнозер' , N'Система прогнозирования движения городского пассажирского транспорта'
INSERT dbo.module(dt_created , id_state , name , name_long ) SELECT GETDATE(), 3, N'Информер' , N'Система информационного взаимодействия'
INSERT dbo.module(dt_created , id_state , name , name_long ) SELECT GETDATE(), 3, N'Геоер' , N'Геоинформационная система'
INSERT dbo.module(dt_created , id_state , name , name_long ) SELECT GETDATE(), 3, N'Визуализатор' , N'Система визуализации информации'
INSERT dbo.module(dt_created , id_state , name , name_long ) SELECT GETDATE(), 3, N'Оповещатель' , N'Триггерная система оповещений'

SELECT id_module, name , name_long FROM dbo.module
-->q3

--Большие таблицы

--<q5 вечная таблица . данные не удалять
DROP TABLE dbo.driver_vehicle
CREATE TABLE dbo.driver_vehicle(id_driver_vehicle BIGINT IDENTITY(1,1), dt_created DATETIME, id_state BIGINT, id_org BIGINT, name NVARCHAR(64), mobile_number NVARCHAR(12))
CREATE CLUSTERED INDEX I_id_driver_vehicle ON dbo.driver_vehicle(id_driver_vehicle)

SELECT * FROM sys.columns WHERE OBJECT_ID=OBJECT_ID('dbo.driver_vehicle')
SELECT * FROM sys.types WHERE system_type_id=user_type_id

EXEC dbo.P_description @sz_table='dbo.driver_vehicle'
/*
SELECT ROW_NUMBER() OVER(ORDER BY c.column_id)[№], c.name[Имя поля],  UPPER(t.name)+CASE WHEN t.name IN ('text', 'varchar', 'char', 'nvarchar', 'nchar') THEN '('+CONVERT(NVARCHAR(10),c.max_length)+')' ELSE '' END [Тип]
,CASE 
  WHEN c.column_id=1 THEN 'Идентификатор записи' 
  WHEN c.name='dt_created' THEN 'Дата создания' 
  WHEN c.name='id_state' THEN 'Состояние' 
  WHEN c.name='id_org' THEN 'Организация' 
  WHEN c.name='name' THEN 'Имя' 
  WHEN c.name='mobile_number' THEN 'Номер мобильного телефона' 
  ELSE '' 
 END [Смысл поля]
FROM sys.columns c LEFT JOIN sys.types t ON (t.system_type_id=c.system_type_id AND t.system_type_id=t.user_type_id)
WHERE OBJECT_ID=OBJECT_ID('dbo.driver_vehicle')
*/
-->q5

--<q9
DROP TABLE dbo.route_type
CREATE TABLE dbo.route_type(id_route_type BIGINT IDENTITY(1,1), dt_created DATETIME, name NVARCHAR(32))
CREATE CLUSTERED INDEX I_id_route_type ON dbo.route_type(id_route_type)

EXEC dbo.P_description @sz_table='dbo.route_type'

INSERT dbo.route_type(dt_created , name ) SELECT GETDATE(), N'Железнодорожный'
INSERT dbo.route_type(dt_created , name ) SELECT GETDATE(), N'Автобусный междугородний'
INSERT dbo.route_type(dt_created , name ) SELECT GETDATE(), N'Автобусный городской'
INSERT dbo.route_type(dt_created , name ) SELECT GETDATE(), N'Маршрутное такси'
INSERT dbo.route_type(dt_created , name ) SELECT GETDATE(), N'Авиационный'
INSERT dbo.route_type(dt_created , name ) SELECT GETDATE(), N'Трамвайный'
INSERT dbo.route_type(dt_created , name ) SELECT GETDATE(), N'Троллейбусный'
INSERT dbo.route_type(dt_created , name ) SELECT GETDATE(), N'Автобусный пригородный'
INSERT dbo.route_type(dt_created , name ) SELECT GETDATE(), N'Шатл'
INSERT dbo.route_type(dt_created , name ) SELECT GETDATE(), N'Речной'


SELECT * FROM dbo.route_type
SELECT id_route_type, name FROM dbo.route_type
-->q9

--<q8
DROP TABLE dbo.route
CREATE TABLE dbo.route(id_route BIGINT IDENTITY(1,1), dt_created DATETIME, id_route_type BIGINT, id_state BIGINT, capacity INT, id_org BIGINT)
CREATE CLUSTERED INDEX I_id_route ON dbo.route(id_route)
-- capacity : максимальная пропускная способность

EXEC dbo.P_description @sz_table='dbo.route'
-->q8

--<q4
DROP TABLE dbo.vehicle
CREATE TABLE dbo.vehicle(id_vehicle BIGINT IDENTITY(1,1), dt_created DATETIME, id_route BIGINT, id_state BIGINT, capacity INT, id_driver_vehicle BIGINT)
CREATE CLUSTERED INDEX I_id_vehicle ON dbo.vehicle(id_vehicle)

EXEC dbo.P_description @sz_table='dbo.vehicle'
-->q4

--<q6
DROP TABLE dbo.point 
CREATE TABLE dbo.point(id_point BIGINT IDENTITY(1,1), dt_created DATETIME, id_state BIGINT, capacity INT, id_org BIGINT, name NVARCHAR(32), addr NVARCHAR(128)) -- значение capacity==-1 : емкость неизвестна или неизвестно ограничение
CREATE CLUSTERED INDEX I_id_point ON dbo.point(id_point)

EXEC dbo.P_description @sz_table='dbo.point'
-->q6

--<q6 таблица остановок маршрута
DROP TABLE dbo.route_point 
CREATE TABLE dbo.route_point(id_route_point BIGINT IDENTITY(1,1), dt_created DATETIME, id_state BIGINT, id_route BIGINT, id_point BIGINT, id_route_point_prev BIGINT) -- значение id_route_point_prev IS NULL : это стартовая остановка 
CREATE CLUSTERED INDEX I_id_route_point ON dbo.route_point(id_route_point)

EXEC dbo.P_description @sz_table='dbo.route_point'
-->q6

--<q7 большая таблица событий. Количество севших на остановке id_point_from с целью выйти на остановке id_point_to
DROP TABLE dbo.event 
CREATE TABLE dbo.event(id_event BIGINT IDENTITY(1,1), dt_created DATETIME, capacity INT, dt_offer_from DATETIME, dt_offer_to DATETIME, id_org_offer BIGINT, id_route BIGINT, id_vehicle BIGINT, id_driver_vehicle BIGINT, id_point_from BIGINT, id_point_to BIGINT)
CREATE CLUSTERED INDEX I_id_event ON dbo.event(id_event)
-- dt_offer: предложена предоставителем события
-- id_org_offer: организация предоставитель события
-- id_driver_vehicle : берем сами из dbo.vehicle по id_vehicle
EXEC dbo.P_description @sz_table='dbo.event'
-->q7