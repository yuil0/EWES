--D:\users\yuil\JOB\EWES\SQL\transman\zone\cr_table
--<q1
DROP TABLE dbo.check_points
CREATE TABLE dbo.check_points
(id_check_point BIGINT IDENTITY(1,1)
, dt_create DATETIME --YUIL. ����/����� ��������  ������
, dt_update DATETIME 
, id_picas_route BIGINT
, id_picas_stop BIGINT
, id_car_type BIGINT
, name NVARCHAR(64)
, lat FLOAT
, lng FLOAT
, x FLOAT
, y FLOAT
, f_forward BIT --1:������ �����������
, i_order INT
)

CREATE CLUSTERED INDEX I_id_check_point ON dbo.check_points(id_check_point) 
CREATE NONCLUSTERED INDEX I_id_picas_route ON dbo.check_points(id_picas_route) 
CREATE NONCLUSTERED INDEX I_id_car_type ON dbo.check_points(id_car_type) 

sp_spaceused 'dbo.check_points'

SELECT * FROM dbo.check_points WHERE id_check_point=3712 --id_picas_route=65
SELECT * FROM dbo.check_points WHERE id_picas_route=64 ORDER by f_forward DESC, i_order ASC
SELECT * FROM dbo.check_points WHERE id_picas_route=65 ORDER by f_forward DESC, i_order ASC

--<qw
SELECT route_id FROM dbo.picas_routes WHERE route_type=704 AND id_picas_route NOT IN (SELECT id_picas_route FROM dbo.check_points WHERE f_forward=1)


SELECT r.route_id, cp.id_picas_stop, id_car_type, name, f_forward, i_order FROM dbo.check_points cp, dbo.picas_routes r WHERE id_car_type IN (2) AND cp.id_picas_route=r.id_picas_route
ORDER BY cp.id_picas_route, f_forward, i_order
-->qw

SELECT cp.id_picas_route cp_id_picas_route, r.id_picas_route, r.route_id FROM dbo.picas_routes r FULL JOIN (SELECT DISTINCT id_picas_route FROM dbo.check_points)cp On (cp.id_picas_route=r.id_picas_route)
WHERE cp.id_picas_route IS NULL OR r.id_picas_route IS NULL

SELECT r.route_short_name, cp.id_car_type, ct.name, cp.f_forward, cp.i_order, cp.name, s.stop_code FROM dbo.check_points cp
LEFT JOIN dbo.picas_stops s ON (s.id_picas_stop=cp.id_picas_stop)
LEFT JOIN dbo.picas_routes r ON (r.id_picas_route=cp.id_picas_route)
LEFT JOIN dbo.car_type ct ON (ct.id_car_type=cp.id_car_type)
--WHERE cp.id_car_type=2
ORDER BY r.route_short_name, cp.id_car_type, cp.f_forward DESC, cp.i_order ASC

SELECT cp.id_car_type, COUNT(DISTINCT id_picas_route)q_route FROM dbo.check_points cp 
GROUP BY cp.id_car_type



--<q1 ������ �������� ������� �����
DELETE FROM dbo.check_points WHERE id_picas_stop IS NOT NULL
-->q1
