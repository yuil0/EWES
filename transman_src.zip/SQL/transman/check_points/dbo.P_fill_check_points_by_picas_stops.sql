CREATE PROC dbo.P_fill_check_points_by_picas_stops AS
----------------------------------------- D:\users\yuil\JOB\EWES\SQL\transman\check_points\dbo.P_fill_check_points_by_picas_stops

