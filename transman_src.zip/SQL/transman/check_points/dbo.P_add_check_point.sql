ALTER  PROC dbo.P_add_check_point
(@id_car_type BIGINT
,@route_short_name NVARCHAR(8) --@id_picas_route BIGINT
,@route_short_name_translit NVARCHAR(8) --�������� @route_short_name  RUS=>EN
,@stop_code NVARCHAR(8)
,@name NVARCHAR(64)
,@f_forward BIT
,@i_order INT
)AS
/* ������� :[i_result] : 0:������ 1:�� ������� ���. 2:�� ������ �������
*/
---------------- D:\users\yuil\JOB\EWES\SQL\transman\check_points\dbo.P_add_check_point
SET NOCOUNT ON; --SET IDENTITY_INSERT dbo.check_points ON; DECLARE @id_check_point_prev BIGINT; SET @id_check_point_prev=ISNULL((SELECT MAX(id_check_point) FROM dbo.check_points),0)

--<q1 find stop
DECLARE @id_picas_stop BIGINT, @lat FLOAT, @lng FLOAT, @x FLOAT, @y FLOAT; 

SELECT @id_picas_stop=id_picas_stop, @lat=stop_lat, @lng=stop_lon, @x=x, @y=y FROM dbo.picas_stops WHERE stop_code=@stop_code;

DECLARE @car_type_name NVARCHAR(32); SET @car_type_name=ISNULL((SELECT name FROM dbo.car_type WHERE id_car_type=@id_car_type),'');

IF (@id_picas_stop IS NULL) BEGIN RAISERROR('Error. @id_picas_stop IS NULL. @stop_code not found',18,1); SELECT 1[i_result], @car_type_name[car_type_name]; RETURN; END --print 'Error. @id_picas_stop IS NULL. @stop_code not found';
-->q1

--<q2 find route
DECLARE @id_picas_route BIGINT; SET @id_picas_route=(SELECT id_picas_route FROM dbo.picas_routes r, dbo.car_type ct WHERE (route_short_name=@route_short_name OR route_short_name=@route_short_name_translit) AND r.route_type=ct.picas_type AND ct.id_car_type=@id_car_type)

IF (@id_picas_route IS NULL) BEGIN print 'Notify. @id_picas_route IS NULL. @route_short_name not found'; SELECT 2[i_result], @car_type_name[car_type_name]; RETURN; END --RAISERROR('Error. @id_picas_route IS NULL. @route_short_name not found',18,1);
-->q2

DECLARE @id_check_point_prev BIGINT; SET @id_check_point_prev=ISNULL((SELECT MAX(id_check_point) FROM dbo.check_points),0);
SET IDENTITY_INSERT dbo.check_points ON

INSERT dbo.check_points(id_check_point, dt_create,  id_picas_route,  id_picas_stop,  id_car_type,  name,  lat,  lng,  x,  y,  f_forward,  i_order)
SELECT        @id_check_point_prev + 1, GETDATE(), @id_picas_route, @id_picas_stop, @id_car_type, @name, @lat, @lng, @x, @y, @f_forward, @i_order

SET IDENTITY_INSERT dbo.check_points OFF

SELECT 0[i_result], @car_type_name[car_type_name]; 
/*IF (@id_check_point IS NULL)
BEGIN
END ELSE
BEGIN
	UPDATE dbo.check_points SET
	  id_picas_route = @id_picas_route
	, id_car_type = @id_car_type
	,  name =  @name
	,  lat =  @lat
	,  lng = @lng
	,  x = @x
	,  y = @y
	,  i_order = @i_order
	WHERE id_check_point=@id_check_point
END*/

--SET IDENTITY_INSERT dbo.check_points OFF;

--SELECT * FROM dbo.picas_stops
--SELECT * FROM dbo.picas_routes WHERE route_id ='rostov_mimibus_46'
--SELECT * FROM dbo.picas_routes WHERE route_id ='rostov_bus_46'
--SELECT * FROM dbo.check_points
--SELECT * FROM dbo.car_type
--SELECT name FROM dbo.car_type WHERE id_car_type=@id_car_type