--D:\users\yuil\JOB\EWES\SQL\transman\set_log_size
ALTER DATABASE transman SET RECOVERY SIMPLE;

USE transman;
GO
CHECKPOINT;
GO
CHECKPOINT; -- run twice to ensure file wrap-around
GO
DBCC SHRINKFILE(transman_log, 200); -- unit is set in MBs
GO