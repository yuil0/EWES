--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\find_between_minutes
SET NOCOUNT ON;

DECLARE @delta_minutes INT;

DECLARE @id_picas_route BIGINT; SET @id_picas_route = 65; --DECLARE @f_no_stat_dt_prev BIT; SET @f_no_stat_dt_prev=0;

DECLARE @id_car_0 BIGINT; SET @id_car_0 = 5;

DECLARE @id_car_1 BIGINT; SET @id_car_1 = 14; --����� ������ � ����� i_order


/*DECLARE @param AS TABLE(id_ate_3 BIGINT, i_order INT, f_forward BIT, dt DATETIME)

INSERT @param (id_ate_3, i_order, f_forward, dt)
SELECT         id_ate_3, i_order, f_forward, dt FROM dbo.mnemoscheme_events e
WHERE id_ate_3 IN (@id_car_0, @id_car_1) AND dt = (SELECT MAX(dt) FROM dbo.mnemoscheme_events x WHERE x.id_picas_route = @id_picas_route AND x.id_ate_3 = e.id_ate_3)

DECLARE @q iNt; SET @q=ISNULL((SELECT COUNT(1) FROM @param), 0);

IF (@q<2) BEGIN print 'Not enough'; RETURN; END;

SELECT * FROM @param

SET @delta_minutes= ABS( DATEDIFF(minute, (SELECT dt FROM @param WHERE id_ate_3 = @id_car_0), (SELECT dt FROM @param WHERE id_ate_3 = @id_car_1) ) )
*/
/*
DECLARE @i_order_prev INT, @f_forward_prev BIT; 

IF (SELECT COUNT(1) FROM (SELECT DISTINCT f_forward, i_order FROM @param)x)=1
BEGIN
	--//��� � ����� �����
	
END ELSE
BEGIN
	IF (SELECT COUNT(DISTINCT f_forward) FROM @param)=1
	BEGIN
		--//���� ��� �  ����� �����������
		DECLARE @min_order INT; SET @min_order = (SELECT MIN(i_order) FROM @param);

		DECLARE @f_forward BIT; SET @f_forward = (SELECT f_forward FROM @param);

		DECLARE @id_car_min_order BIGINT; SET @id_car_min_order = (SELECT id_ate_3 FROM @param WHERE i_order = @min_order);

		SELECT dt FROM dbo.mnemoscheme_events e WHERE id_ate_3 IN (@id_car_0, @id_car_1) AND id_ate_3!=@id_car_min_order AND e.i_order = @min_order AND e.f_forward = @f_forward
		AND dt = (SELECT MAX(dt) FROM dbo.mnemoscheme_events x WHERE x.id_picas_route = @id_picas_route AND x.id_ate_3 = e.id_ate_3 AND x.i_order = @min_order AND x.f_forward = @f_forward)

	END ELSE
	BEGIN
		print '*';
	END	
END*/

--SELECT @delta_minutes [@delta_minutes]
