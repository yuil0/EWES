--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\find_lag_lead_no_time
DECLARE @id_picas_route BIGINT; SET @id_picas_route=65;

DECLARE @dt DATETIME; SET @dt = GETDATE();
DECLARE @date DATETIME; SET @date = dbo.FN_get_date(@dt);

DECLARE @time TIME; SET @time=dbo.FN_get_time(@dt);

DECLARE @stop_radius FLOAT, @valid_dev_sec INT; SELECT @stop_radius=stop_radius, @valid_dev_sec=valid_dev_sec FROM dbo.const -- --, CASE WHEN c.stop_id IN (cls.stop_id_1, cls.stop_id_2) THEN 1 ELSE 0 END

DECLARE @max_time_dist_minutes INT; SET @max_time_dist_minutes=5;
DECLARE @max_d_time INT; SET @max_d_time=60;

SELECT @dt[@dt], @time[@time]

SELECT c.id_picas_stop, c.stop_id, c.arrival_time, c.departure_time, c.id_ate_3, c.device_number, c.dist
,f_forward_stop, i_order_stop
FROM 
(SELECT c.id_picas_stop, c.stop_id, c.arrival_time, c.departure_time, c.id_ate_3, c.device_number, c.dist
 , ROW_NUMBER() OVER (PARTITION BY c.stop_id, cp_stop.f_forward ORDER BY dist) i_order_stop_dist
 ,cp_stop.f_forward f_forward_stop, cp_stop.i_order i_order_stop
 FROM 
 (SELECT DISTINCT s.id_picas_stop, s.stop_id, st.arrival_time, st.departure_time, c.id_ate_3, dbo.FN_get_dist(c.x, c.y, s.x, s.y) dist, c.device_number FROM 
  dbo.picas_stop_times st, dbo.picas_trips t, dbo.picas_stops s, dbo.ate_3 c, dbo.picas_routes r, dbo.car_type ct 
  WHERE s.stop_id=st.stop_id AND @time>=DATEADD(second, - @valid_dev_sec, st.arrival_time) AND @time<=DATEADD(second, @valid_dev_sec, st.departure_time) AND st.trip_id=t.trip_id AND t.route_id=r.route_id
  AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
  AND dbo.FN_cross(c.x, c.y, s.x, s.y, @stop_radius)=0 --���� ���� ������ �� �� ��������� 
  AND r.id_picas_route = @id_picas_route
  AND r.route_id = 'rostov_'+ct.name_short_en+'_'+c.route_en AND ISNULL(c.route_en,'')!='' AND c.id_car_type = ct.id_car_type 
  AND s.id_picas_stop IN (SELECT id_picas_stop FROM dbo.check_points cp WHERE cp.id_picas_route = @id_picas_route GROUP BY id_picas_stop HAVING count(1)=1) --������ ��������� ����� �������� --SELECT DISTINCT id_picas_stop FROM dbo.check_points cp WHERE cp.id_picas_route = @id_picas_route) 
 )c
 LEFT JOIN (SELECT stop_id, f_forward, i_order, id_check_point FROM dbo.check_points cp, dbo.picas_stops s WHERE cp.id_picas_stop = s.id_picas_stop AND cp.id_picas_route=@id_picas_route)cp_stop ON (cp_stop.stop_id = c.stop_id)
)c 
--WHERE i_order_stop_dist=1
ORDER BY c.id_picas_stop, c.arrival_time, c.id_ate_3