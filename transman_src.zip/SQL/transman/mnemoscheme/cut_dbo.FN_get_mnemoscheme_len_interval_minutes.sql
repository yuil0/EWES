--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\cut_dbo.FN_get_mnemoscheme_len_interval_minute
DECLARE @id_picas_route BIGINT, @f_forward BIT, @i_order INT
SET @id_picas_route=64;
SET @i_order=2
SET @f_forward=1

DECLARE @len INT, @q INT; --DECLARE @id_picas_route BIGINT; SET @id_picas_route=64; --//DECLARE @t_start AS TABLE(id_ate_3 BIGINT, dt DATETIME) //DECLARE @t_fin AS TABLE(id_ate_3 BIGINT, dt DATETIME)

DECLARE @i_order_max INT; SET @i_order_max=ISNULL((SELECT MAX(i_order) FROM dbo.check_points WHERE id_picas_route=@id_picas_route AND f_forward=@f_forward),0)

IF (@i_order_max=0) BEGIN SELECT -1; return  END;

DECLARE @i_order_next INT, @f_forward_next BIT; 
	
IF (@i_order=@i_order_max)
BEGIN
	SET @i_order_next=0;
	SET @f_forward_next= CASE WHEN @f_forward=1 THEN 0 ELSE 1 END;
END ELSE
BEGIN
	SET @i_order_next= @i_order + 1;
	SET @f_forward_next= @f_forward;
END	
		
DECLARE @t AS TABLE(i_order INT, f_forward BIT, id_ate_3 BIGINT, dt DATETIME, i_order_event INT) 
   
INSERT @t(i_order, f_forward, id_ate_3, dt, i_order_event) 
SELECT    i_order, f_forward, id_ate_3, dt, ROW_NUMBER() OVER(PARTITION BY id_ate_3 ORDER BY id_mnemoscheme_event)i_order_event FROM dbo.mnemoscheme_events WHERE id_picas_route = @id_picas_route

SELECT *
FROM @t t INNER JOIN @t n ON (n.id_ate_3 = t.id_ate_3 AND n.i_order_event = t.i_order_event + 1 AND n.i_order = @i_order_next AND n.f_forward = @f_forward_next)
WHERE t.f_forward = @f_forward AND t.i_order = @i_order


SELECT @len=sum(DATEDIFF(minute, t.dt, n.dt)), @q=COUNT(1) 
FROM @t t INNER JOIN @t n ON (n.id_ate_3 = t.id_ate_3 AND n.i_order_event = t.i_order_event + 1 AND n.i_order = @i_order_next AND n.f_forward = @f_forward_next)
WHERE t.f_forward = @f_forward AND t.i_order = @i_order
   
IF (@q IS NULL OR @q=0) BEGIN SELECT -2; RETURN  END;

SET @len = @len / @q;

SELECT @len;