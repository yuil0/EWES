--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\cr_mnemoscheme_events

DROP TABLE dbo.mnemoscheme_events
CREATE TABLE dbo.mnemoscheme_events
(id_mnemoscheme_event BIGINT IDENTITY(1,1)
, id_picas_route BIGINT
, id_ate_3 BIGINT
, f_forward BIT --1:������ �����������
, id_check_point BIGINT
, dt DATETIME --YUIL. ����/�����
)

ALTER TABLE dbo.mnemoscheme_events ADD i_order INT --ALTER TABLE dbo.mnemoscheme_events DROP COLUMN dt_created
ALTER TABLE dbo.mnemoscheme_events ADD dt_created DATETIME

CREATE CLUSTERED INDEX I_id_mnemoscheme_event ON dbo.mnemoscheme_events(id_mnemoscheme_event) 
CREATE NONCLUSTERED INDEX I_id_picas_route ON dbo.mnemoscheme_events(id_picas_route) 
CREATE NONCLUSTERED INDEX I_id_ate_3 ON dbo.mnemoscheme_events(id_ate_3) 
CREATE NONCLUSTERED INDEX I_id_check_point ON dbo.mnemoscheme_events(id_check_point) 

sp_spaceused 'dbo.mnemoscheme_events'

--TRUNCATE TABLE dbo.mnemoscheme_events 
SELECT * FROM dbo.mnemoscheme_events 
order  by ISNULL(dt_created, dt) 