--DROP  FUNCTION dbo.FN_get_forward_by_mnemoscheme_events
ALTER FUNCTION dbo.FN_get_forward_by_mnemoscheme_events(@id_ate_3 BIGINT, @dt DATETIME) 
------------------------------------------------------------------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\dbo.FN_get_forward_by_mnemoscheme_events

RETURNS BIT
AS
BEGIN
	DECLARE @f_forward BIT

	--DECLARE @date DATETIME; SET @date = dbo.FN_get_date(GETDATE());

	SET @f_forward= ( SELECT f_forward FROM dbo.mnemoscheme_events WHERE dt_created<=@dt AND id_ate_3 = @id_ate_3 --AND dbo.FN_get_date(dt_created) = @date 
	                  AND id_mnemoscheme_event=(SELECT MAX(id_mnemoscheme_event) FROM dbo.mnemoscheme_events WHERE dt_created<=@dt AND id_ate_3 = @id_ate_3) --AND dt_created=(SELECT MAX(dt_created) FROM dbo.mnemoscheme_events WHERE id_picas_route = @id_picas_route AND id_ate_3 = @id_ate_3) 
					);

	RETURN @f_forward;
END