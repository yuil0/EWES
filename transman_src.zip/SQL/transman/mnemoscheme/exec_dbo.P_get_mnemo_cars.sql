---- D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\exec_dbo.P_get_mnemo_cars


EXEC dbo.P_get_mnemo_cars @id_picas_route=64, @dt_max='2017-12-04T23:59:59.997'

EXEC dbo.P_get_mnemo_cars_b @id_picas_route=64, @dt_max='2017-12-04T23:59:59.997'