ALTER PROC dbo.P_get_mnemo_cars(@id_picas_route BIGINT) AS
------------------------------------------------------------------------------------
-- D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\dbo.P_get_mnemo_cars

--DECLARE @id_picas_route BIGINT; SET @id_picas_route=64;

SELECT id_ate_3, device_number, garage_num, dt_car, dt_event, f_forward, i_order, event_minutes, len_interval_minutes
, CASE WHEN len_interval_minutes>=0 AND ABS(event_minutes)<ABS(len_interval_minutes) THEN 1 ELSE 0 END f_draw_shift
FROM
(SELECT c.id_ate_3, c.device_number, cb.garage_num, c.dt dt_car, e.dt dt_event, e.f_forward, e.i_order
, DATEDIFF(minute, e.dt, c.dt) event_minutes
, dbo.FN_get_mnemoscheme_len_interval_minutes(@id_picas_route, e.f_forward, e.i_order) len_interval_minutes
 FROM dbo.car_type ct, dbo.picas_routes r, dbo.ate_3_book cb, dbo.ate_3 c
 INNER JOIN 
 (
  SELECT f_forward, i_order, id_check_point, id_ate_3, dt FROM 
  (SELECT f_forward, id_check_point, id_ate_3, dt, i_order, ROW_NUMBER() OVER (PARTITION BY id_ate_3 ORDER BY dt DESC) i_order_dt FROM dbo.mnemoscheme_events WHERE id_picas_route = @id_picas_route)e
  WHERE i_order_dt=1
 )e ON (e.id_ate_3 = c.id_ate_3) 
 WHERE ISNULL(route_en,'')!='' AND c.id_car_type=ct.id_car_type AND 'rostov_'+ct.name_short_en+'_'+c.route_en=r.route_id AND id_picas_route=@id_picas_route AND c.device_number=cb.device_number AND c.dt Is NOT NULL
)c
--WHERE c.len_interval_minutes>0

/*SELECT f_forward, i_order, id_check_point, id_ate_3, dt FROM 
(SELECT f_forward, id_check_point, id_ate_3, dt, i_order, ROW_NUMBER() OVER (PARTITION BY id_ate_3 ORDER BY dt DESC) i_order_dt FROM dbo.mnemoscheme_events WHERE id_picas_route = @id_picas_route)e
WHERE i_order_dt=1
*/

/*
EXEC dbo.P_get_mnemo_cars @id_picas_route=64
EXEC dbo.P_get_mnemo_cars @id_picas_route=65
*/