--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\find_forward
DECLARE @id_ate_3 BIGINT, @dt DATETIME, @route_id NVARCHAR(32)
SET @id_ate_3 = 8;
SET @dt=GETDATE()
SET @route_id='rostov_bus_96';

SELECT f_forward, i_order,  id_picas_stop FROM
(SELECT e.f_forward, e.i_order, cp.id_picas_stop, ROW_NUMBER() OVER(ORDER BY id_mnemoscheme_event DESC) i_order_event 
 FROM dbo.mnemoscheme_events e, dbo.picas_stop_times st, dbo.picas_stops s, dbo.picas_trips t, dbo.check_points cp
 WHERE e.id_ate_3 = @id_ate_3 AND st.trip_id = t.trip_id AND t.route_id=@route_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
 AND st.stop_id=s.stop_id
 AND s.id_picas_stop = cp.id_picas_stop AND cp.id_check_point = e.id_check_point --AND e.id_mnemoscheme_event = (SELECT MAX(id_mnemoscheme_event) FROM dbo.mnemoscheme_events WHERE id_ate_3 = @id_ate_3)
)e
WHERE i_order_event IN (1,2,3)