--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\find_data
DECLARE @id_picas_route BIGINT; SET @id_picas_route=65;
DECLARE @id_ate_3 BIGINT; SET @id_ate_3=4;
DECLARE @f_no_stat_dt_prev BIT; SET @f_no_stat_dt_prev=0;

-- SELECT * FROM [transman].dbo.mnemoscheme_events WHERE id_picas_route=@id_picas_route AND id_ate_3=@id_ate_3

DECLARE @dt_max DATETIME; SET @dt_max=(SELECT MAX(dt) FROM [transman].dbo.mnemoscheme_events WHERE id_picas_route=@id_picas_route AND id_ate_3=@id_ate_3)

IF (@dt_max IS NULL) BEGIN print 'Not found'; RETURN; END

DECLARE @i_order INT, @id_check_point BIGINT, @f_forward BIT;
DECLARE @i_order_max INT;

SELECT @i_order = i_order, @id_check_point = id_check_point, @f_forward = f_forward FROM [transman].dbo.mnemoscheme_events 
WHERE 
id_picas_route=@id_picas_route AND id_ate_3=@id_ate_3 AND dt=(@dt_max)

SELECT @i_order_max = max(i_order) FROM dbo.check_points WHERE id_picas_route=@id_picas_route AND f_forward = @f_forward

DECLARE @i_order_next INT, @f_forward_next BIT; 
DECLARE @i_order_prev INT, @f_forward_prev BIT; 

--<q1 calc next
IF (@i_order = @i_order_max)
BEGIN
	SET @i_order_next = 0

	SET @f_forward_next = CASE WHEN @f_forward=1 THEN 0 ELSE 1 END;
END ELSE
BEGIN
	SET @i_order_next = @i_order + 1

	SET @f_forward_next = @f_forward
END 
-->q1 calc next

--<q2 calc prev
IF (@i_order = 0)
BEGIN
	SET @f_forward_prev = CASE WHEN @f_forward=1 THEN 0 ELSE 1 END;

	SET @i_order_prev = (SELECT max(i_order) FROM dbo.check_points WHERE id_picas_route = @id_picas_route AND f_forward = @f_forward_prev)	
END ELSE
BEGIN
	SET @i_order_prev = @i_order - 1

	SET @f_forward_prev = @f_forward
END 
-->q2 calc prev

DECLARE @stat_dt DATETIME,  @stat_dt_prev DATETIME; --@stat_min_dt DATETIME, @stat_max_dt DATETIME, DECLARE @stat_min_dt_next DATETIME, @stat_max_dt_next DATETIME;

SELECT @stat_dt = CONVERT( DATETIME, (min(CONVERT(FLOAT, dt)) + max(CONVERT(FLOAT, dt)) ) / 2 ) FROM dbo.mnemoscheme_events WHERE id_picas_route=@id_picas_route AND f_forward = @f_forward AND i_order = @i_order

SELECT @stat_dt_prev = CONVERT( DATETIME, (min(CONVERT(FLOAT, dt)) + max(CONVERT(FLOAT, dt)) ) / 2 ) FROM dbo.mnemoscheme_events WHERE id_picas_route=@id_picas_route AND f_forward = @f_forward_prev AND i_order = @i_order_prev

--SELECT @stat_dt_next = CONVERT( DATETIME, max(CONVERT(FLOAT, dt)) /*+max(CONVERT(FLOAT, dt)) )/2*/ ) FROM dbo.mnemoscheme_events WHERE id_picas_route=@id_picas_route AND f_forward = @f_forward_next AND i_order = @i_order_next

IF (@stat_dt_prev IS NULL)
BEGIN
	SET @stat_dt_prev = DATEADD(minute, -20, @stat_dt);

	SET @f_no_stat_dt_prev=1;
END

SELECT 'all',* FROM dbo.mnemoscheme_events WHERE id_picas_route=@id_picas_route AND f_forward = @f_forward AND i_order = @i_order

SELECT 'all_next',* FROM dbo.mnemoscheme_events WHERE id_picas_route=@id_picas_route AND f_forward = @f_forward_next AND i_order = @i_order_next

--SELECT @stat_min_dt = min(dt),  @stat_max_dt = max(dt) FROM dbo.mnemoscheme_events WHERE id_picas_route=@id_picas_route AND f_forward = @f_forward AND i_order = @i_order
--SELECT @stat_min_dt_next = min(dt),  @stat_max_dt_next = max(dt) FROM dbo.mnemoscheme_events WHERE id_picas_route=@id_picas_route AND f_forward = @f_forward_next AND i_order = @i_order_next

DECLARE @dt_car DATETIME; SET @dt_car=(SELECT ISNULL(dt_update, dt_created)dt FROM [transman].dbo.ate_3 WHERE id_ate_3=@id_ate_3) --ISNULL(dt, 


SELECT @i_order [@i_order], @f_forward[@f_forward], @i_order_next [@i_order_next], @f_forward_next[@f_forward_next], @dt_max[@dt_max], @i_order_max[@i_order_max], @stat_dt[@stat_dt]/*,  @stat_dt_next [@stat_dt_next]*/, @dt_car [@dt_car], @f_no_stat_dt_prev [@f_no_stat_dt_prev]

--1. ���������� �� ��������� ��
SELECT DATEDIFF(minute, @stat_dt, @dt_car)delta_minutes

SELECT DATEDIFF(minute, @stat_dt_prev, @dt_car)delta_minutes_prev

