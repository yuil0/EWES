--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\test_2017_10_17
SELECT cll.* FROM dbo.car_lag_lead  cll, dbo.picas_stops s WHERE cll.stop_id = s.stop_id AND device_number='M178OH'


--<q1
DECLARE @dt DATETIME; SET @dt=GETDATE();

EXEC dbo.P_find_near_lag_lead_car @dt = @dt, @route_id = 'rostov_bus_96', @device_number = 'M178OH'
-->q1

SELECT stop_name from dbo.picas_stops where stop_id=1110

--<q2
DECLARE @dt DATETIME; SET @dt=GETDATE();

EXEC dbo.P_add_car_lag_lead @dt = @dt, @route_id = 'rostov_bus_96', @device_number = 'M178OH'

SELECT * FROM dbo.car_lag_lead
-->q2

SELECT stop_name, shape_id, CONVERT(NVARCHaR(8),arrival_time)arrival_time, CONVERT(NVARCHaR(8),departure_time)departure_time FROM dbo.car_lag_lead  cll, dbo.picas_stops s WHERE cll.stop_id = s.stop_id AND f_lag=1 AND device_number='M178OH'

--<q3
DECLARE @dt DATETIME; SET @dt=GETDATE();
EXEC dbo.P_view_stops_by_shape  @dt=@dt, @shape_id='rostov_bus_96_b-a'
-->q3