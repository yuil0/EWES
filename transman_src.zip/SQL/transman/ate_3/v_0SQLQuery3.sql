select (select garage_num from dbo.ate_3_book b WHERE b.device_number=c.device_number)garage_num, * from dbo.ate_3 c where route_id='rostov_bus_94'ORDER BY dt_update

select (select garage_num from dbo.ate_3_book b WHERE b.device_number=c.device_number)garage_num, * from dbo.ate_3 c where route_id='rostov_bus_96' ORDER BY dt_update