--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\exec_dbo.P_find_route_shape

EXEC dbo.P_find_route_shape

SELECT * FROM dbo.route_shape