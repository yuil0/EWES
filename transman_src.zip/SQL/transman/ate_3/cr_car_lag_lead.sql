--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\cr_car_lag_lead

--<q1
DROP TABLE dbo.car_lag_lead
CREATE TABLE dbo.car_lag_lead
(id_car_lag_lead BIGINT IDENTITY(1,1)
, dt_created DATETIME
, device_number NVARCHAR(16)
, stop_id BIGINT
, shape_id NVARCHAR(32)
, arrival_time TIME
, departure_time TIME
, f_lag BIT, f_lead BIT
)
-->q1


ALTER TABLE dbo.car_lag_lead ADD diff_minutes INT --//YUIL 2017-11-29 : >0 :����� ����������, <0: ����� ���������

CREATE CLUSTERED INDEX I_id_car_lag_lead ON dbo.car_lag_lead(id_car_lag_lead) 

CREATE  INDEX I_device_number ON dbo.car_lag_lead(device_number) 

SELECT * FROM dbo.car_lag_lead

---DELETE FROM dbo.car_lag_lead WHErE  id_car_lag_lead In (110659, 111993)
UPDATE dbo.car_lag_lead SET diff_minutes=NULL

SELECT stop_name, shape_id, arrival_time, departure_time, f_lag, f_lead   FROM dbo.car_lag_lead  cll, dbo.picas_stops s WHERE cll.stop_id = s.stop_id

SELECT stop_name, shape_id, arrival_time, departure_time FROM dbo.car_lag_lead  cll, dbo.picas_stops s WHERE cll.stop_id = s.stop_id AND f_lag=1
SELECT stop_name, shape_id, arrival_time, departure_time FROM dbo.car_lag_lead  cll, dbo.picas_stops s WHERE cll.stop_id = s.stop_id AND f_lead=1
