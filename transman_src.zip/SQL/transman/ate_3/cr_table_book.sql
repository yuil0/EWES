--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\cr_table_book

--<q1
DROP TABLE dbo.ate_3_book
CREATE TABLE dbo.ate_3_book
(id_ate_3_book BIGINT IDENTITY(1,1)
, device_number NVARCHAR(16)
, garage_num NVARCHAR(8)
, mark NVARCHAR(16)
, state_num NVARCHAR(16)
, dt_created DATETIME --YUIL. ����/����� ��������  ������ 
, agent_name NVARCHAR(64)
)
-->q1

--ALTER TABLE dbo.ate_3_book ADD agent_name NVARCHAR(64)
--ALTER TABLE dbo.ate_3_book DROP COLUMN dt_update

CREATE CLUSTERED INDEX I_id_ate_3_book ON dbo.ate_3_book(id_ate_3_book) 
CREATE  INDEX I_device_number ON dbo.ate_3_book(device_number) 


sp_spaceused 'dbo.ate_3_book'

SELECT * FROM dbo.ate_3_book --order  by id_ate_3_book
--TRUNCATE TABLE dbo.ate_3_book
SELECT * FROM dbo.ate_3_book ORDER BY 1 --ISNULL(dt_created, dt_update) desc

SELECT * FROM dbo.ate_3_book WHERE device_number=N'2389'
SELECT * FROM dbo.ate_3_book WHERE device_number=N'M180OH'