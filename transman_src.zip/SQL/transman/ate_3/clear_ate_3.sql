--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\clear_ate_3
--1.
SELECT * FROM dbo.ate_3 WHERE LEN(device_number)=1 AND device_number!='0' AND device_number!='1' AND device_number!='2' AND device_number!='3' AND device_number!='4' AND device_number!='5' AND device_number!='6' AND device_number!='7' AND device_number!='8' AND device_number!='9'

DELETE FROM dbo.ate_3 WHERE LEN(device_number)=1 AND device_number!='0' AND device_number!='1' AND device_number!='2' AND device_number!='3' AND device_number!='4' AND device_number!='5' AND device_number!='6' AND device_number!='7' AND device_number!='8' AND device_number!='9'

--2.
SELECT * FROM dbo.ate_3 WHERE CHARINDEX('0',device_number)=0 AND CHARINDEX('1',device_number)=0 AND CHARINDEX('2',device_number)=0 AND CHARINDEX('3',device_number)=0 AND CHARINDEX('4',device_number)=0 AND CHARINDEX('5',device_number)=0 AND CHARINDEX('6',device_number)=0 AND CHARINDEX('7',device_number)=0 AND CHARINDEX('8',device_number)=0 AND CHARINDEX('9',device_number)=0
DELETE FROM dbo.ate_3 WHERE CHARINDEX('0',device_number)=0 AND CHARINDEX('1',device_number)=0 AND CHARINDEX('2',device_number)=0 AND CHARINDEX('3',device_number)=0 AND CHARINDEX('4',device_number)=0 AND CHARINDEX('5',device_number)=0 AND CHARINDEX('6',device_number)=0 AND CHARINDEX('7',device_number)=0 AND CHARINDEX('8',device_number)=0 AND CHARINDEX('9',device_number)=0

--3.
SELECT * FROM dbo.ate_3 WHERE device_number LIKE N'3333%'
DELETE FROM dbo.ate_3 WHERE device_number LIKE N'3333%'

--4.
SELECT * FROM dbo.ate_3 WHERE SUBSTRING(device_number, LEN(device_number), 1)=N'�'
DELETE FROM dbo.ate_3 WHERE SUBSTRING(device_number, LEN(device_number), 1)=N'�'

--5.
SELECT * FROM dbo.ate_3 WHERE device_number LIKE N'ZA%'
DELETE FROM dbo.ate_3 WHERE device_number LIKE N'ZA%' 

--6.
SELECT * FROM dbo.ate_3 WHERE device_number LIKE N'ZB%'
DELETE FROM dbo.ate_3 WHERE device_number LIKE N'ZB%' 

