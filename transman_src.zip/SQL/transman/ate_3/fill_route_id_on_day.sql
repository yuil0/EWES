

select f_route, count(1)[count] FROM
(select dt_update, ISNULL((select 1 FROM dbo.picas_routes r WHERE r.route_id=c.route_id), 0)f_route from dbo.ate_3 c WHERE dt_update>=DATEADD(dd,DATEDIFF(dd, 0, GETDATE()),0))x
GROUP BY f_route


