--D:\users\yuil\JOB\EWES\SQL\transman\car_stop\cr_car_last_stop.sql

--<q1
DROP TABLE dbo.users
CREATE TABLE dbo.users
( id_user BIGINT IDENTITY(1,1)
, dt_create DATETIME
, id_user_type BIGINT
, user_name NVARCHAR(32)
, password VARBINARY(20)
,sip_name NVARCHAR(5)
,sip_psw NVARCHAR(32)
,device_number NVARCHAR(16)
)
-->q1

/*ALTER TABLE dbo.users ADD sip_name NVARCHAR(5)
ALTER TABLE dbo.users ADD sip_psw NVARCHAR(32)
ALTER TABLE dbo.users ADD device_number NVARCHAR(16)*/

UPDATE dbo.users SET sip_name='103' , sip_psw ='A1b2' --password=HASHBYTES ( 'SHA1', '12345' )  
WHERE id_user=2

CREATE CLUSTERED INDEX I_id_user ON dbo.users(id_user)
CREATE NONCLUSTERED INDEX I_id_user_type ON dbo.users(id_user_type)
CREATE NONCLUSTERED INDEX I_user_name ON dbo.users(user_name)
CREATE NONCLUSTERED INDEX I_device_number ON dbo.users(device_number)

DELETE FROM dbo.users WHERE id_user=9

SELECT * FROM dbo.users
SELECT user_name FROM dbo.users WHERE id_user_type=2
SELECT id_user FROM dbo.users WHERE user_name=N'����'

SELECT id_user_type FROM dbo.users WHERE user_name=N'����' AND password=HASHBYTES('SHA1', '12345')

UPDATE  dbo.users SET password=0x2F2416BA3BCF5DB18362CAD20CA90089515ABE0F

--<q2
DECLARE @id_user_prev BIGINT; SET @id_user_prev=ISNULL((SELECT MAX(id_user) FROM dbo.users),0);
DECLARE @f_our BIT; 

SET IDENTITY_INSERT dbo.users ON;
INSERT dbo.users(id_user, dt_created,  id_user_type,  user_name,  password)
SELECT @id_user_prev + 1,  GETDATE(), @id_user_type, @user_name, @password 
SET IDENTITY_INSERT dbo.users OFF;
-->q2
