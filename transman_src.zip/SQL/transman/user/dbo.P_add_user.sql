ALTER PROC dbo.P_add_user
( @user_name NVARCHAR(32)
, @password NVARCHAR(32)
, @id_user_type BIGINT
, @id_user BIGINT=NULL OUTPUT
) AS --D:\users\yuil\JOB\EWES\SQL\transman\user\dbo.P_add_user
------------------------------------
SET NOCOUNT ON;

SET @id_user=NULL;

IF (@user_name IS NULL) RETURN;

IF (LEN(@user_name)=0) RETURN;

SET @id_user=(SELECT id_user FROM dbo.users WHERE user_name = @user_name)

IF @id_user IS NULL
BEGIN
	--1. user
	--<q4
	DECLARE @id_user_prev BIGINT; SET @id_user_prev=ISNULL((SELECT MAX(id_user) FROM dbo.users),0);

	SET @id_user= @id_user_prev + 1;

	SET IDENTITY_INSERT dbo.users ON;

	DECLARE @hash_sha1 VARBINARY(20); SET @hash_sha1 = HASHBYTES ( 'SHA1', @password);

	INSERT dbo.users(id_user, dt_create,  user_name,   password,  id_user_type)
	SELECT          @id_user, GETDATE(), @user_name, @hash_sha1, @id_user_type

	SET IDENTITY_INSERT dbo.users OFF;
	-->q4

	SELECT @id_user [id_user] --//YUIL 2017-11-07
END