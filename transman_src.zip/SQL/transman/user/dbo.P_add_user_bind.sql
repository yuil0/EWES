ALTER PROC dbo.P_add_user_bind (@id_user_one BIGINT, @id_user BIGINT) AS
------------
-- D:\users\yuil\JOB\EWES\SQL\transman\user\dbo.P_add_user_bind

DELETE FROM dbo.user_binds WHERE id_user=@id_user;

DECLARE @id_user_bind_prev BIGINT;SET @id_user_bind_prev=ISNULL((SELECT MAX(id_user_bind) FROM dbo.user_binds),0);

SET IDENTITY_INSERT dbo.user_binds ON
INSERT dbo.user_binds(id_user_bind,   id_user_one,  id_user) 
SELECT        @id_user_bind_prev+1,  @id_user_one, @id_user
SET IDENTITY_INSERT dbo.user_binds OFF