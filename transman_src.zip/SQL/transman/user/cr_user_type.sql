--<q1
DROP TABLE dbo.user_types
CREATE TABLE dbo.user_types
( id_user_type BIGINT IDENTITY(1,1)
, dt_create DATETIME
, name NVARCHAR(32)
)
-->q1

CREATE CLUSTERED INDEX I_id_user_type ON dbo.user_types(id_user_type)

SELECT * FROM dbo.user_types

--<q3
INSERT dbo.user_types(dt_create,  name) SELECT GETDATE(), N'������� ���������'
INSERT dbo.user_types(dt_create,  name) SELECT GETDATE(), N'���������'
INSERT dbo.user_types(dt_create,  name) SELECT GETDATE(), N'���������'
INSERT dbo.user_types(dt_create,  name) SELECT GETDATE(), N'��������'
-->q3

--<q2
DECLARE @id_user_type_prev BIGINT; SET @id_user_type_prev=ISNULL((SELECT MAX(id_user_type) FROM dbo.user_types),0);

SET IDENTITY_INSERT dbo.user_types ON;
INSERT dbo.user_types(id_user_type, dt_create,  name)
SELECT      @id_user_type_prev + 1,  GETDATE(), @name
SET IDENTITY_INSERT dbo.user_types OFF;

-->q2