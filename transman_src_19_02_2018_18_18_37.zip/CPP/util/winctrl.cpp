#include <memory.h>
#include "winctrl.h"

SGDI_objects g_sGDI_objects;

bool SRect::In(POINT& pn)  //int xNew, int yNew)
{
	return pn.x >= x && pn.x <= x + w && pn.y >= y && pn.y <= y + h;
}

void SGDI_objects::Open()
{
	memset(this, 0, sizeof(SGDI_objects));

	h[EGDIO_COMBOBOX_BUTTON] = (HBITMAP)LoadImageA(0, "c:\\transman\\img\\combobox_0.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	h[EGDIO_STATIC] = (HBITMAP)LoadImageA(0, "c:\\transman\\img\\6_2.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	h[EGDIO_BUTTON_UP] = (HBITMAP)LoadImageA(0, "c:\\transman\\img\\7_0.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	h[EGDIO_BUTTON_DOWN] = (HBITMAP)LoadImageA(0, "c:\\transman\\img\\7_1.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	h[EGDIO_STATIC_WIDTH_204] = (HBITMAP)LoadImageA(0, "c:\\transman\\img\\8_8.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	h[EGDIO_BUTTON_X_UP] = (HBITMAP)LoadImageA(0, "c:\\transman\\img\\6_3.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	h[EGDIO_BUTTON_X_DOWN] = (HBITMAP)LoadImageA(0, "c:\\transman\\img\\6_4.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		
	h[EGDIO_V_OFF] = (HBITMAP)LoadImageA(0, "c:\\transman\\img\\8_1.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	h[EGDIO_V_ON] = (HBITMAP)LoadImageA(0, "c:\\transman\\img\\8_2.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	h[EGDIO_PEN_BACK_GROUND] = CreatePen(PS_SOLID, 0, 0xDED9B5); //������� �������� R-181 G-217 B-222=0xDED9B5;           //AddBitmapCtrls();
	h[EGDIO_BRUSH_BACK_GROUND] = CreateSolidBrush(0xDED9B5); //������� �������� R-181 G-217 B-222=0xDED9B5;

	h[EGDIO_FONT_EDIT] = win_e::Create_Font("Courier", ci_height_font_edit);

	m_fInit = true;
}
	
void SGDI_objects::Close()
{
	if (m_fInit == false) { return; }

	for (int i = 0; i < (int)EGDIO_QUANTITY; i++)
	{ DeleteObject(h[i]); }
}

void SCtrl::Clear()
{
	memset(this, 0, sizeof(SCtrl));

	row = -1; //YUIL . default

	col = -1;

	mul_w = 1;

	mul_h = 1;

	index_group = -1;

	id_ctrl_open_by_left_button = -1;

	id_ctrl_set_text_by_select = -1;
}

SCtrl::SCtrl() { Clear(); }

CWinCtrl::CWinCtrl() {}

CWinCtrl::~CWinCtrl() {}
	
bool CWinCtrl::Init(const SWinCtrlParam& param)
{
	m_fInit = false;

	try
	{
		memset(this, 0, sizeof(CWinCtrl));

		m_param = param;

		m_fInit = true;
	}
	catch (...) {}

	return m_fInit;
}

void CWinCtrl::Destroy()
{
	for (int i = 0; i < m_ctrlList.size(); i++)
	{
		SCtrl& o= m_ctrlList[i];

		if (o.eType == ETC_STANDARD)
		{
			DestroyWindow(o.hwnd);
		}else
		if (o.eType == ETC_WIN_E_EDIT)
		{			
			win_e::SEdit* p_edit = (win_e::SEdit*)o.p_obj;
			
			if (p_edit)
			{ p_edit->Close();  }
		}
		else
		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			win_e::SListBox* p= (win_e::SListBox*)o.p_obj;

			if (p)
			{ p->Close(); }
		}
	}

	m_ctrlList.clear();

	DestroyMenu(m_menu);	
}


void CWinCtrl::CalcPosSizeNewElement(SCtrl& ctrl)
{
	if (m_fInit == false) { return; }

	int& ident = m_param.ident;

	int wCtrl = m_param.wCtrl;

	int hCtrl = m_param.hCtrl; //int rowMax = m_param.rowMax; int colMax = m_param.colMax;
	
	int i_row=0;

	if (ctrl.f_no_calc_xy == false)
	{
		int xOrigin;
		int yOrigin;

		int qGr = m_groupList.size();
		bool fFoundGr = false;

		if (ctrl.index_group >= 0 && ctrl.index_group < qGr)
		{
			SGroup& s_group = m_groupList[ctrl.index_group];
			xOrigin = s_group.x;
			yOrigin = s_group.y + s_group.h_caption;
			i_row = s_group.m_i_row;

			fFoundGr = true;
		}

		if (fFoundGr == false)
		{
			xOrigin = m_param.xOrigin;
			yOrigin = m_param.yOrigin;
			i_row = m_row;
		}

		if (m_max_x == 0) { m_max_x = xOrigin; }

		int& x = ctrl.x;

		if (m_param.width == 0)
		{
			x = m_max_x + ident; // +(ctrl.col == -1 ? m_col : ctrl.col) * (wCtrl + ident);
		}
		else
		{
			x = m_ctrlList.size() * (wCtrl + ident);
		}

		ctrl.y = yOrigin + ident + i_row * (hCtrl + ident);
	}

	if (ctrl.f_no_calc_w == false) { ctrl.w = wCtrl * ctrl.mul_w + (ctrl.mul_w > 1 ? ident * (ctrl.mul_w - 1) : 0); }

	ctrl.h = hCtrl * ctrl.mul_h + (ctrl.mul_h > 1 ? ident * (ctrl.mul_h - 1) : 0);

	ctrl.row = i_row;
}

HWND CWinCtrl::Add(SCtrl& ctrl) //, SAddParam* p_add_param)
{
	if (m_fInit == false) { return 0; }

	DWORD dwStyle = WS_CHILD | ctrl.styleAdd; //if (m_param.fHide) { dwStyle&=~WS_VISIBLE; }

	if (m_param.fHide == false) { dwStyle|= WS_VISIBLE; }  //YUIL 2017-02-15

	char *p_class;

	if (ctrl.eType == ETC_STANDARD)
	{		
		p_class = (char *)ctrl.classWnd.c_str();

		if (m_param.fOwnerDraw)
		{
			if (!stricmp(p_class, "static"))
			{
				dwStyle |= SS_OWNERDRAW;
			}
			else
				if (!stricmp(p_class, "button"))
				{
					dwStyle |= BS_OWNERDRAW; //if (dwStyle & BS_CHECKBOX){}else{}
				}
		}
	}

	CalcPosSizeNewElement(ctrl);

	ctrl.id = m_ctrlList.size();

	if (ctrl.eType == ETC_STANDARD)
	{
		ctrl.hwnd = CreateWindowExA(0, p_class, ctrl.textWnd.c_str(), dwStyle, ctrl.x, ctrl.y, ctrl.w, ctrl.h, m_param.hwndParent, (HMENU)ctrl.id, m_param.hInstance, 0); //transman_wnd_class

		if (ctrl.hwnd == 0)
		{
			return 0;
		}
	}else
	if (ctrl.eType == ETC_WIN_E_EDIT)
	{
		RECT rc = { ctrl.x, ctrl.y, ctrl.x + ctrl.w, ctrl.y + ctrl.h };
		
		win_e::SEdit* p_edit = new win_e::SEdit;

		if (p_edit == 0) { return 0; }

		p_edit->Open(rc);

		p_edit->Set_hwnd(m_param.hwndParent);

		p_edit->SetId(ctrl.id);


		if (ctrl.textWnd.size())
		{
			p_edit->SetText((char*)ctrl.textWnd.c_str());
		}

		ctrl.p_obj = (void*)p_edit;

		if (dwStyle & ES_READONLY)
		{ p_edit->SetReadOnly(); }
	}
	else
	if (ctrl.eType == ETC_WIN_E_LIST_BOX)
	{
		RECT rc = { ctrl.x, ctrl.y, ctrl.x + ctrl.w, ctrl.y + ctrl.h };

		win_e::SListBox* p = new win_e::SListBox;

		if (p == 0) { return 0; }

		p->Open(rc, m_param.hCtrl);

		ctrl.p_obj = (void*)p;
	}

	m_max_x = ctrl.x + ctrl.w;
	
	int ctrl_h = ctrl.h;

	if (ctrl.eType == ETC_STANDARD)
	{
		if (!stricmp(p_class, "combobox") || (dwStyle & BS_GROUPBOX)) { ctrl_h = m_param.hCtrl; }
	}

	int max_y = ctrl.y + ctrl_h;

	if (m_stat_max_x < m_max_x) { m_stat_max_x = m_max_x; }

	if (m_ctrlList.size()==0 || m_stat_min_x > ctrl.x) { m_stat_min_x = ctrl.x; }

	if (m_stat_max_y < max_y) { m_stat_max_y = max_y; }

	m_ctrlList.push_back(ctrl);

	return ctrl.hwnd;
}

HWND CWinCtrl::Add(char *sz_name, char *sz_class_wnd, char *sz_text_wnd, DWORD styleAdd, int row, int col, FN_HANDLER handler)
{
	if (m_fInit == false) { return false; }

	SCtrl ctrl;
	ctrl.name = sz_name;
	ctrl.classWnd = sz_class_wnd;
	ctrl.textWnd = sz_text_wnd;
	ctrl.styleAdd = styleAdd;
	ctrl.row = row;
	ctrl.col = col;
	ctrl.handler = handler;
	return Add(ctrl);
}

bool CWinCtrl::Find(int id, SCtrl* *p_ctrl)
{
	if (m_fInit == false) { return false; }

	bool fFound = false;

	for (int i = 0; fFound == false && i < m_ctrlList.size(); i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.id == id) { fFound = true; if (p_ctrl) { *p_ctrl = &o; } }
	}

	return fFound;
}

bool CWinCtrl::Find(char *name, SCtrl* *p_ctrl)
{
	if (m_fInit == false) { return false; }
	
	if (name == 0) { return false; }

	if (strlen(name)==0) { return false; }

	bool fFound = false;

	for (int i = 0; fFound == false && i < m_ctrlList.size(); i++)
	{
		if (m_ctrlList[i].name == name) { fFound = true; if (p_ctrl) { *p_ctrl = &m_ctrlList[i]; } }
	}

	return fFound;
}

bool CWinCtrl::OnCommand(int iNotify, int id, void* p_param)
{
	if (m_fInit == false) { return false; }

	SCtrl *p_ctrl;

	if (Find(id, &p_ctrl) == false) { return false; }

	if (p_ctrl->handler) { p_ctrl->handler(iNotify, p_param); } //(int)hwnd, 

	return true;
}

int CWinCtrl::SendMes(int id, UINT uMes, WPARAM wParam, LPARAM lParam)
{
	if (m_fInit == false) { return false; }

	SCtrl *p_ctrl;

	if (Find(id, &p_ctrl) == false) { return false; }	

	return SendMessageA(p_ctrl->hwnd, uMes, wParam, lParam);
}

int CWinCtrl::SendMes(char *name, UINT uMes, WPARAM wParam, LPARAM lParam)
{
	if (m_fInit == false) { return false; }

	SCtrl *p_ctrl;

	if (Find(name, &p_ctrl) == false) { return false; }	

	return SendMessageA(p_ctrl->hwnd, uMes, wParam, lParam);
}

void CWinCtrl::SendMesAll(UINT uMes, WPARAM wParam, LPARAM lParam)
{
	for (int i = 0; i < m_ctrlList.size(); i++)
	{
		SCtrl& ctrl= m_ctrlList[i];

		if (ctrl.hwnd)
		{
			SendMessageA(ctrl.hwnd, uMes, wParam, lParam);
		}
	}
}

bool CWinCtrl::AdjustParentWnd(HWND hwndParent)
{
	if (m_fInit == false) { return false; }

	int ident = m_param.ident;

	int max_x=0;

	int max_y=0;

	for (int i = 0; i < m_ctrlList.size(); i++)
	{
		SCtrl& ctrl= m_ctrlList[i];

		if (i == 0)
		{
			max_x = ctrl.x + ctrl.w;

			max_y = ctrl.y + ctrl.h;
		}
		else
		{
			if (max_x < ctrl.x) { max_x = ctrl.x + ctrl.w; }

			if (max_y < ctrl.y) { max_y = ctrl.y + ctrl.h; }
		}
	}

	RECT  rc;
	RECT  crc;

	if (GetWindowRect(hwndParent, &rc) == FALSE) { return false; }
	if (GetClientRect(hwndParent, &crc) == FALSE) { return false; }
	
	//int w_inner =

	int shiftX= ((rc.right - rc.left) - crc.right);
	
	int shiftY = ((rc.bottom - rc.top) - crc.bottom);

	int w = max_x + shiftX + ident;
	int h = max_y + shiftY + ident;

	int x = (GetSystemMetrics(SM_CXSCREEN) - w) / 2;
	int y = (GetSystemMetrics(SM_CYSCREEN) - h) / 2;

	MoveWindow(hwndParent, x, y, w, h, TRUE);

	return true;
}

void CWinCtrl::Update()
{
	if (m_fInit == false) { return; }
	
	/*RECT rc;

	if (win_e::GetClientRectAbs(m_param.hwndParent, rc) == false) { return; }

	POINT mouse_pos_src;

	GetCursorPos(&mouse_pos_src);

	bool fChMouseCurPos = false;*/

	for (int i = 0; i < m_ctrlList.size(); i++)
	{
		SCtrl& ctrl = m_ctrlList[i];
		
		if (ctrl.hwnd)
		{
			UpdateWindow(ctrl.hwnd);

			/*if (ctrl.eType == ETC_STANDARD)
			{
				if (!stricmp(ctrl.classWnd.c_str(), "combobox"))
				{
					
					POINT pn = { rc.left + ctrl.x + ctrl.w / 2 , rc.top + ctrl.y + ctrl.h / 2 };

					SetCursorPos(pn.x, pn.y); 
					
					mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_ABSOLUTE, pn.x, pn.y, 0, 0);

					mouse_event(MOUSEEVENTF_LEFTUP | MOUSEEVENTF_ABSOLUTE, pn.x, pn.y, 0, 0);

					fChMouseCurPos = true;
				}
			}*/
		}
	}

	/*if (fChMouseCurPos)
	{
		SetCursorPos(mouse_pos_src.x, mouse_pos_src.y);
	}*/

	UpdateWindow(m_param.hwndParent);
}

void CWinCtrl::ShowAll(bool fShow, std::vector<SIndexRange>* p_list_range)
{
	if (m_fInit == false) { return ; }

	for (int i = 0; i < m_ctrlList.size(); i++)
	{
		SCtrl& ctrl = m_ctrlList[i];
		
		bool fShowL = fShow;

		if (p_list_range && fShow)
		{
			fShowL=false;

			for (int k=0; fShowL==false && k < p_list_range->size(); k++)
			{
				SIndexRange& r= p_list_range->at(k);

				fShowL= (i >= r.index_from) && (i <= r.index_to);
			}			
		}

		if (ctrl.hwnd)
		{
			ShowWindow(ctrl.hwnd, fShowL ? SW_SHOW : SW_HIDE);
		}
	}
}

void CWinCtrl::ShowAllUpdate(bool fShow, std::vector<SIndexRange>* p_list_range)
{
	if (m_fInit == false) { return ; }

	ShowAll(fShow, p_list_range);

	Update();
}

SWinCtrlParam::SWinCtrlParam() { Clear(); }

void SWinCtrlParam::Clear() 
{ 
	memset(this, 0, sizeof(SWinCtrlParam)); 
}

void CWinCtrl::NewRow(char *sz_name_by_max_x)
{ 
	if (m_fInit == false) { return ; }

	SCtrl *p_ctrl = 0;
	
	if (Find(sz_name_by_max_x, &p_ctrl))
	{
		m_max_x = p_ctrl->GetMaxX();
	}else
	{
		m_max_x = 0;
	}	

	m_row++; 
}

void CWinCtrl::NewRows(int q_rows)
{
	m_row+=q_rows; 
}

void SGroup::NewRows(int q_rows) {m_i_row += q_rows;}

void CWinCtrl::SetFocus(char *name, bool f)
{
	if (m_fInit == false) { return; }

	SCtrl *p_ctrl;

	if (Find(name, &p_ctrl) == false) { return; }	

	SendMessageA(p_ctrl->hwnd, WM_SETFOCUS, (WPARAM)p_ctrl->hwnd, 0);
}

/*void CWinCtrl::SetFocusActive()
{
	if (m_fInit == false) { return; }

	int q= m_ctrlList.size();

	if (q==0) { return; }

	int i_over=0;

	while (IsWindowVisible(m_ctrlList[m_id_ctrl_active].hwnd)==FALSE && i_over<q)
	{
		m_id_ctrl_active = (m_id_ctrl_active==q-1) ? 0 : m_id_ctrl_active + 1;

		i_over++;
	}

	::SetFocus(m_ctrlList[m_id_ctrl_active].hwnd);
}*/

bool CWinCtrl::IsWndTab(HWND hwnd)
{
	if  (IsWindowVisible(hwnd)==FALSE) {return false;}

	char sz_class[MAX_PATH+1];

	int c= GetClassNameA(hwnd, sz_class, MAX_PATH);

	if (c)
	{
		if (!stricmp(sz_class, "static")) {return false;}
		if (!stricmp(sz_class, "edit")) 
		{																																		
			DWORD dStyle= (DWORD)GetWindowLong(hwnd, GWL_STYLE);

			if (dStyle & ES_READONLY) 
			{
				return false;
			}
		}
	}

	return true;
}

void CWinCtrl::GroupNewRows(int index, int q_rows)
{
	int q = m_groupList.size();

	if (index >= q) { return;}

	m_groupList[index].NewRows(q_rows);

	m_max_x = 0;
}

void CWinCtrl::NextFocusActive()
{
	if (m_fInit == false) { return; }

	int q= m_ctrlList.size();

	if (q==0) { return; }

	int i_count=0;

	while (IsWndTab(m_ctrlList[m_id_ctrl_active].hwnd)==false && i_count<q)
	{
		m_id_ctrl_active = (m_id_ctrl_active==q-1) ? 0 : m_id_ctrl_active + 1;

		i_count++;
	}
	
	if (i_count==0)  
	{
		m_id_ctrl_active = (m_id_ctrl_active==q-1) ? 0 : m_id_ctrl_active + 1;
	}

	::SetFocus(m_ctrlList[m_id_ctrl_active].hwnd);
}

void CWinCtrl::SendMes_CB_RESETCONTENT(char *sz_name)
{
	SendMes(sz_name, CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);
}

void CWinCtrl::OpCheckbox(char  *sz_checkbox, bool* pfCheck)
{
	if (m_param.fOwnerDraw)
	{
	}
	else
	{
		bool f = GetCheckbox(sz_checkbox);

		f = f ? false : true;

		SetCheckbox(sz_checkbox, f);

		if (pfCheck) { *pfCheck = f; }
	}
}

void CWinCtrl::SetCheckbox(char  *sz_checkbox, bool fCheck)
{	
	if (m_param.fOwnerDraw)
	{
		SCtrl* p_ctrl;

		if (Find(sz_checkbox, &p_ctrl))
		{ p_ctrl->fPressed = fCheck; }
	}
	else
	{
		SendMes(sz_checkbox, BM_SETCHECK, (WPARAM)(fCheck ? BST_CHECKED : BST_UNCHECKED), (LPARAM)0);
	}
	
}

bool CWinCtrl::GetCheckbox(char  *sz_checkbox)
{
	bool fChecked=false;

	if (m_param.fOwnerDraw)
	{
		SCtrl* p_ctrl;

		if (Find(sz_checkbox, &p_ctrl))
		{ fChecked = p_ctrl->fPressed;	}
	}
	else
	{
		fChecked = SendMes(sz_checkbox, BM_GETCHECK, (WPARAM)0, (LPARAM)0) == BST_CHECKED;
	}

	return fChecked;
}


bool CWinCtrl::AddMenuItemText(char* pData, int* p_id, UINT uAddFlags, SCtrl* *p_ctrl)
{
	if (!m_menu) 
	{ 
		m_menu = CreatePopupMenu(); 

		if (m_menu == 0) { return false; }
	}	

	int id = m_ctrlList.size();

	UINT uFlags = MF_STRING | uAddFlags;

	BOOL bAdd = AppendMenuA(m_menu, uFlags, (UINT_PTR)id, pData);
	
	SCtrl ctrl; //ctrl.styleAdd = uFlags;

	ctrl.textWnd = pData;

	ctrl.id = id;

	m_ctrlList.push_back(ctrl);

	if (p_id) { *p_id = id; }

	if (p_ctrl)
	{
		int q = m_ctrlList.size();
		
		if (q)
		{
			*p_ctrl = &m_ctrlList[q - 1];
		}
	}

	return true;
}


bool CWinCtrl::TrackMenu(HWND hwnd, POINT& pn)
{
	if (m_menu == 0) { return false; }

	UINT fuFlags = TPM_LEFTALIGN | TPM_BOTTOMALIGN | TPM_LEFTBUTTON;  //TPM_RETURNCMD |  TPM_VERTICAL// | TPM_NOANIMATION //LPTPMPARAMS lptmp = 0;

	BOOL bTrack = TrackPopupMenu(m_menu, fuFlags, pn.x, pn.y, 0, hwnd, 0);

	return bTrack == TRUE;
}

bool CWinCtrl::MarkMenuItem(int id, bool fMark)
{
	if (m_menu == 0) { return false; }
	
	BOOL fByPositon = FALSE;

	MENUITEMINFOA mii;
	mii.cbSize = sizeof(MENUITEMINFOA);
	mii.fMask = MIIM_STATE;
 mii.fState = fMark ? MFS_CHECKED : MFS_UNCHECKED;

	return SetMenuItemInfoA(m_menu, id, fByPositon, &mii)==TRUE;
}


/*bool CWinCtrl::AddGroup(SGroup& s_group)
{
	m_groupList.push_back(s_group);
	return true;
}*/

void SGroup::Clear()
{
	memset(this, 0, sizeof(SGroup));
}

bool CWinCtrl::AddGroup(char* sz_name, SAddGroupParam& param)
{
	int& w = param.w;
	int& h = param.h;
	int& h_caption = param.h_caption;
	int index_from = param.index_from;
	EAddGroupDirect& eDirect = param.eDirect;
	int& ident = m_param.ident;

	POINT pn;
	int q = m_groupList.size();
	if (q == 0)
	{
		pn.x = m_param.xOrigin;
		pn.y = m_param.yOrigin;
	}
	else
	{
		if (index_from < 0) { index_from = q - 1; }

		SGroup& prev =  m_groupList[index_from];
		
		if (eDirect == EAGD_BOTTOM)
		{
			pn.x = prev.x;
			pn.y = prev.y + prev.h + ident;
		}
		else
		{
			pn.x = prev.x + prev.w + ident;
			pn.y = prev.y;
		}

	}

	SGroup s_group;
	s_group.x = pn.x;
	s_group.y = pn.y;
	s_group.w = w;
	s_group.h = h;
	s_group.name = sz_name;
	s_group.h_caption = h_caption;
	m_groupList.push_back(s_group); //return AddGroup(s_group);

	return true;
}

void CWinCtrl::DrawGroups(HDC hdc)
{
	for (int i = 0; i < m_groupList.size(); i++)
	{
		SGroup& o = m_groupList[i];

		win_e::DrawGroupBox(hdc, o.x, o.y, o.w, o.h, (char*)o.name.c_str(), o.h_caption);
	}
}

void CWinCtrl::DrawBackGroundByCtrl(HDC hdc, SCtrl& o)
{
	HGDIOBJ* p_gdi_obj = g_sGDI_objects.h;

	SelectObject(hdc, (HPEN)p_gdi_obj[EGDIO_PEN_BACK_GROUND]);
	SelectObject(hdc, (HBRUSH)p_gdi_obj[EGDIO_BRUSH_BACK_GROUND]);
	Rectangle(hdc, o.x, o.y, o.x + o.w, o.y + o.h);
}

void CWinCtrl::DrawOp(HDC hdc, bool fTop)
{
	HGDIOBJ* p_gdi_obj= g_sGDI_objects.h;

	for (int i = 0; i < m_ctrlList.size(); i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.fNeedDrawBackGround)
		{
			o.fNeedDrawBackGround = false;
			DrawBackGroundByCtrl(hdc, o);
			m_fDrawTop = false;
			continue;
		}
		else
		{
			if (fTop != o.fTop) { continue; } //YUIL 2017-02-13
		}
		
		if (o.fHide) { continue; }

		if (o.eType == ETC_STANDARD)
		{
			if (o.classWnd == "combobox")
			{
				POINT pn = { o.x + o.w - 22 + 3, o.y + 3 };
				POINT size = { 17, 19 };
				bool fDraw = win_e::DrawBitmap(hdc, (HBITMAP)p_gdi_obj[EGDIO_COMBOBOX_BUTTON], pn, &size);
			}
			else
				if (o.classWnd == "static")
				{
					o.DrawStatic(hdc);

					/*int y_shift = 1;

					POINT pn = { o.x, o.y-3 + y_shift };
					POINT size = { 144, 27 };
					bool fStretch = true;
					POINT sizeCtrl = { o.w, o.h+5 };
					bool fDraw = win_e::DrawBitmap(hdc, p_hbitmap[EGDIO_STATIC], pn, &size, &sizeCtrl, fStretch);

					win_e::Text_out(hdc, pn, sizeCtrl, (char*)o.textWnd.c_str(), o.textWnd.size());*/
				}
				else
					if (o.classWnd == "button")
					{
						if (o.styleAdd & BS_CHECKBOX)
						{
							o.DrawCheckbox(hdc);
						}
						else
						{
							o.DrawButton(hdc);
						}
					}
		}
		else
			if (o.eType == ETC_WIN_E_EDIT)
			{
				win_e::SEdit* p_edit = (win_e::SEdit*)o.p_obj;

				if (p_edit)
				{
					p_edit->Draw(hdc, ci_height_font_edit, (HFONT)p_gdi_obj[EGDIO_FONT_EDIT]);
				}
			}
			else
				if (o.eType == ETC_WIN_E_LIST_BOX)
				{
					win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

					if (p)
					{
						p->Draw(hdc, ci_height_font_edit, (HFONT)p_gdi_obj[EGDIO_FONT_EDIT], (HBITMAP)p_gdi_obj[EGDIO_V_ON], (HBITMAP)p_gdi_obj[EGDIO_V_OFF]);
					}
				}
	}

}

void CWinCtrl::Draw(HDC hdc)
{
	if (g_sGDI_objects.m_fInit == false) { return; }

	bool fTop;

	if (m_fDrawTop == false)
	{
		fTop = false;

		DrawGroups(hdc);

		DrawOp(hdc, fTop);
	}

	fTop = true;

	DrawOp(hdc, fTop);
}

void SCtrl::DrawStatic(HDC hdc, int i_mode)
{
	HGDIOBJ* p_gdi_obj = g_sGDI_objects.h;

	POINT pn = { x, y - 2 };
	
	bool f_204 = w >= 204;

	POINT size = { f_204 ? 204 : 144, f_204 ? 27 : 26 };
	bool fStretch = true;
	POINT sizeCtrl = { w, h + 5 };
	bool fDraw = win_e::DrawBitmap(hdc, (HBITMAP)p_gdi_obj[f_204 ? EGDIO_STATIC_WIDTH_204 : EGDIO_STATIC], pn, &size, &sizeCtrl, fStretch);

	if (i_mode == 0)
	{
		win_e::Text_out(hdc, pn, sizeCtrl, (char*)textWnd.c_str(), textWnd.size());
	}
}

void SCtrl::DrawVLeft(HDC hdc)
{
	HGDIOBJ* p_gdi_obj = g_sGDI_objects.h;
	
	int ident = 4;
	
	POINT size = { 20, 20 };
	
	int y_shift = 2;

	POINT pn = { x+ ident, y + (h- size.y)/2+ y_shift };
	
	bool fDraw = win_e::DrawBitmap(hdc, (HBITMAP)p_gdi_obj[fPressed ? EGDIO_V_ON : EGDIO_V_OFF], pn, &size);

	int x_delta = 2 * ident + size.x;

	POINT pn_text = { x+ x_delta, pn.y- y_shift };
	POINT sizeCtrl = { w - x_delta, h + 5 };

	win_e::Text_out(hdc, pn_text, sizeCtrl, (char*)textWnd.c_str(), textWnd.size());
}

void SCtrl::DrawCheckbox(HDC hdc)
{
	int i_mode = 1;

	DrawStatic(hdc, i_mode);

	DrawVLeft(hdc);

}

void SCtrl::DrawButton(HDC hdc)
{
	HGDIOBJ* p_gdi_obj = g_sGDI_objects.h;

	if (textWnd == "X" || textWnd == "x")
	{		
		POINT pn = { x, y };
		POINT size = { 20, 20 };
		bool fStretch = true;
		POINT sizeCtrl = { w, h };
		bool fDraw = win_e::DrawBitmap(hdc, (HBITMAP)p_gdi_obj[fPressed ? EGDIO_BUTTON_X_DOWN : EGDIO_BUTTON_X_UP], pn, &size, &sizeCtrl, fStretch);
	}
	else
	{
		int y_shift = 1;

		/*if (fPressed)
		{
			int k = 0;
			k++;
		}*/

		POINT pn = { x, y - 3 + y_shift };
		POINT size = { 144, 27 };
		bool fStretch = true;
		POINT sizeCtrl = { w, h + 5 };
		bool fDraw = win_e::DrawBitmap(hdc, (HBITMAP)p_gdi_obj[fPressed ? EGDIO_BUTTON_DOWN : EGDIO_BUTTON_UP], pn, &size, &sizeCtrl, fStretch);

		win_e::Text_out(hdc, pn, sizeCtrl, (char*)textWnd.c_str(), textWnd.size());
	}
}

char* SCtrl::GetText()
{
	if (eType == ETC_STANDARD) 
	{ 
		return (char*)textWnd.c_str(); 
	}
	else
	if (eType == ETC_WIN_E_EDIT)
	{
		win_e::SEdit* p_edit = (win_e::SEdit*)p_obj;

		if (p_edit)
		{
			p_edit->GetText();
		}
	}
}

CWinCtrl::SAddGroupParam::SAddGroupParam()
{
	Clear();
}

void CWinCtrl::SAddGroupParam::Clear()
{
	memset(this, 0, sizeof(CWinCtrl::SAddGroupParam));

	h_caption = 22;

	index_from = -1;
}


bool CWinCtrl::FindByHWND(HWND hwnd, SCtrl* *pCtrl)
{
	bool fFound = false;

	for (int i = 0; fFound==false && i < m_ctrlList.size(); i++)
	{
		SCtrl& ctrl = m_ctrlList[i];

		fFound = ctrl.hwnd == hwnd;

		if (fFound)
		{
			*pCtrl = &ctrl;
		}
	}

	return fFound;
}

void SCtrl::SetState(bool fDown)
{
	fPressed = fDown;
}

void SCtrl::InvertState(bool& fDown)
{
	fPressed = !fPressed;

	fDown = fPressed;
}

void CWinCtrl::SetState(HWND hwnd, POINT& pn, bool fDown)
{
	SCtrl* pCtrl;

	if (FindByHWND(hwnd, &pCtrl))
	{ pCtrl->SetState(fDown); }
}

void CWinCtrl::ListBox_Draw(HDC hdc, win_e::SListBox& lb)
{
	HGDIOBJ* p_gdi_obj = g_sGDI_objects.h;

	lb.Draw(hdc, ci_height_font_edit, (HFONT)p_gdi_obj[EGDIO_FONT_EDIT], (HBITMAP)p_gdi_obj[EGDIO_V_ON], (HBITMAP)p_gdi_obj[EGDIO_V_OFF]);
}

bool CWinCtrl::KeyDown(int vk)
{
	bool fFound = false;

	int q = m_ctrlList.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];
		
		if (o.eType == ETC_WIN_E_EDIT)
		{
			win_e::SEdit* p_edit = (win_e::SEdit*)o.p_obj;

			if (p_edit)
			{
				fFound = p_edit->KeyDown(vk);
			}
		}

	}

	return fFound;
}

bool CWinCtrl::WM__LBUTTONDOWN_op(POINT& pn, HWND hwnd, SCtrl* *pFoundCtrl, bool fTop)
{
	bool fFound = false;

	int q = m_ctrlList.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.fHide) { continue; }

		if (fTop != o.fTop) { continue; }

		if (o.eType == ETC_WIN_E_EDIT)
		{
			win_e::SEdit* p = (win_e::SEdit*)o.p_obj;

			if (p)
			{
				fFound = p->CheckIn(pn);
			}
		}
		else
			if (o.eType == ETC_WIN_E_LIST_BOX)
			{
				win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

				if (p)
				{
					fFound = p->Sel(pn);										

					if (fFound && p->IsBarSelected()==false)
					{
						SetListBoxTextOp(p, o);

						/*if (o.id_ctrl_set_text_by_select >= 0)
						{
							SCtrl& c = m_ctrlList[o.id_ctrl_set_text_by_select];

							if (c.eType == ETC_WIN_E_EDIT)
							{
								win_e::SEdit* pc = (win_e::SEdit*)c.p_obj;

								if (pc)
								{									
									win_e::SListBoxItem* p_item;
									p->GetSelItem(&p_item);
									pc->SetText((char*)p_item->sz_text.c_str());
								}
							}

						}*/

						if (o.fTop)
						{
							o.fHide = true;
							o.fNeedDrawBackGround = true;
						}
					}

				}
			}

		if (fFound)
		{
			if (pFoundCtrl) { *pFoundCtrl = &o; }

			if (o.id_ctrl_open_by_left_button >= 0)
			{
				SCtrl& c = m_ctrlList[o.id_ctrl_open_by_left_button];

				c.fHide = !c.fHide;

				if (c.fHide)
				{
					c.fNeedDrawBackGround = true; //if (pfNeedDrawBkGr) { *pfNeedDrawBkGr = true; }					
				}
			}
		}

	}

	return fFound;
}

bool CWinCtrl::WM__LBUTTONDOWN(POINT& pn, HWND hwnd, SCtrl* *pFoundCtrl) //, bool* pfNeedDrawBkGr)
{
	bool fTop = true;
	bool fFound = WM__LBUTTONDOWN_op(pn, hwnd, pFoundCtrl, fTop);

	if (fFound == false)
	{
		fTop = false;

		fFound = WM__LBUTTONDOWN_op(pn, hwnd, pFoundCtrl, fTop);
	}
	else
	{
		m_fDrawTop = true;
	}


	//<q1
	bool fDown = true;

	SetState(hwnd, pn, fDown);
	//>q1

	return fFound;
}

bool CWinCtrl::WM__RBUTTONDOWN_op(POINT& pn, HWND hwnd, SCtrl* *pFoundCtrl, win_e::SListBoxItem* *pItem, bool fTop)
{
	bool fFound = false;

	int q = m_ctrlList.size();

	bool fChState = false;
	bool fMove = false;

	for (int i = 0; fFound == false && i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.fHide) { continue; }

		if (o.fTop != fTop) { continue; }

		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

			if (p)
			{
				fFound = p->Sel(pn, fChState, pItem, fMove);
			}

			if (fFound)
			{
				if (pFoundCtrl) { *pFoundCtrl = &o; }
			}
		}

	}

	return fFound;
}

bool CWinCtrl::WM__RBUTTONDOWN(POINT& pn, HWND hwnd, SCtrl* *pFoundCtrl, win_e::SListBoxItem* *pItem)
{
	bool fTop = true;
	bool fFound = WM__RBUTTONDOWN_op(pn, hwnd, pFoundCtrl, pItem, fTop);

	if (fFound == false)
	{
		fTop = false;

		fFound = WM__RBUTTONDOWN_op(pn, hwnd, pFoundCtrl, pItem, fTop);
	}
	else
	{
		m_fDrawTop = true;
	}


	return fFound;
}

char* CWinCtrl::GetText(char* name)
{
	int q = m_ctrlList.size();

	for (int i = 0; i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.eType == ETC_WIN_E_EDIT)
		{
			win_e::SEdit* p_edit = (win_e::SEdit*)o.p_obj;

			if (p_edit)
			{
				if (!stricmp(name, o.name.c_str()))
				{
					return p_edit->GetText();
				}
			}
		}

	}

	return 0;
}

void CWinCtrl::SetText(char* name, char* sz_new)
{
	int q = m_ctrlList.size();

	for (int i = 0; i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.eType == ETC_WIN_E_EDIT)
		{
			win_e::SEdit* p_edit = (win_e::SEdit*)o.p_obj;

			if (p_edit)
			{
				if (!stricmp(name, o.name.c_str()))
				{
					p_edit->SetText(sz_new);

					return;
				}
			}
		}

	}
}

void CWinCtrl::ClearList(char* name, SCtrl* *pFoundCtrl)
{
	int q = m_ctrlList.size();

	for (int i = 0; i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

			if (p)
			{
				if (!stricmp(name, o.name.c_str()))
				{
					p->ClearList();

					if (pFoundCtrl) { *pFoundCtrl = &o; }

					return;
				}
			}
		}

	}
}

void CWinCtrl::AddToList(char* name, char* sz_new, bool fSelected, char* id_new, char* name_new , char *param_1_new , void* p_ptr_1_new )
{
	int q = m_ctrlList.size();

	for (int i = 0; i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];
		
		if (o.name.size() == 0) { continue; }

		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

			if (p)
			{
				if (!stricmp(name, o.name.c_str()))
				{
					p->Add(sz_new, fSelected, id_new, name_new, param_1_new, p_ptr_1_new);

					return;
				}
			}
		}

	}
}

/*void CWinCtrl::SelectItem(char* name, int index)
{
	int q = m_ctrlList.size();

	for (int i = 0; i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

			if (p)
			{
				if (!stricmp(name, o.name.c_str()))
				{
					p->SelectItem(index);

					return;
				}
			}
		}

	}
}*/

win_e::SListBox* SCtrl::GetListBoxPointer()
{
	if (eType != ETC_WIN_E_LIST_BOX) { return 0; }
	
	return (win_e::SListBox*)p_obj;
}

bool CWinCtrl::WM__MOUSEMOVE_op(POINT& pn, SCtrl* *pFoundCtrl, bool fTop)
{
	bool fFound = false;

	int q = m_ctrlList.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.fHide) { continue; }

		if (o.fTop != fTop) { continue; }

		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

			if (p)
			{
				fFound = p->InScrollOp(pn);

				if (fFound)
				{
					if (pFoundCtrl) { *pFoundCtrl = &o; }
				}
			}
		}
	}

	return fFound;
}

bool CWinCtrl::WM__MOUSEMOVE(POINT& pn, SCtrl* *pFoundCtrl)
{
	bool fTop = true;
	bool fFound = WM__MOUSEMOVE_op(pn, pFoundCtrl, fTop);

	if (fFound == false)
	{
		fTop = false;

		fFound = WM__MOUSEMOVE_op(pn, pFoundCtrl, fTop);
	}
	else
	{
		m_fDrawTop = true;
	}

	return fFound;
}

bool CWinCtrl::WM__LBUTTONUP_op(POINT& pn, HWND hwnd, bool fTop)
{
	bool fFound = false;

	int q = m_ctrlList.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.fHide) { continue; }

		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

			if (p)
			{
				p->SetMove(false);
			}
		}

	}

	return fFound;
}

bool CWinCtrl::WM__LBUTTONUP(POINT& pn, HWND hwnd)
{
	bool fTop = true;
	bool fFound = WM__LBUTTONUP_op(pn, hwnd, fTop);

	if (fFound == false)
	{
		fTop = false;

		fFound = WM__LBUTTONUP_op(pn, hwnd, fTop);
	}
	else
	{
		m_fDrawTop = true;
	}


	//<q1
	bool fDown = false;

	SetState(hwnd, pn, fDown);
	//>q1

	return true;
}


int CWinCtrl::GetCountSel(char* name, bool& fAll, std::vector<long>& list_index_sel)
{
	bool fFound = false;

	int q = m_ctrlList.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

			if (p)
			{
				if (!stricmp(name, o.name.c_str()))
				{
					return p->GetCountSel(fAll, list_index_sel);
				}
			}
		}

	}

	return 0;
}


void CWinCtrl::SelectAll(char* name, bool fSel)
{
	bool fFound = false;

	int q = m_ctrlList.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

			if (p)
			{
				if (!stricmp(name, o.name.c_str()))
				{
					fFound = true;

					p->SelAll(fSel);
				}
			}
		}
	}	
}



bool CWinCtrl::GetSelItem(char* name, win_e::SListBoxItem* *p_item)
{
	bool fFound = false;

	int q = m_ctrlList.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

			if (p)
			{
				if (!stricmp(name, o.name.c_str()))
				{
					p->GetSelItem(p_item);

					fFound = true;
				}
			}
		}

	}

	return fFound;
}

void CWinCtrl::SetListBoxTextOp(win_e::SListBox* p, SCtrl& o)
{
	if (p == 0) {return;}

	if (o.id_ctrl_set_text_by_select >= 0)
	{
		SCtrl& c = m_ctrlList[o.id_ctrl_set_text_by_select];

		if (c.eType == ETC_WIN_E_EDIT)
		{
			win_e::SEdit* pc = (win_e::SEdit*)c.p_obj;

			if (pc)
			{
				win_e::SListBoxItem* p_item;
				p->GetSelItem(&p_item);
				pc->SetText((char*)p_item->sz_text.c_str());
			}
		}
	}
}

bool CWinCtrl::SelByIndex(char* name, int index)
{
	bool fFound = false;

	int q = m_ctrlList.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			if (!stricmp(name, o.name.c_str()))
			{
				win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

				if (p)
				{
					p->SetSelIndex(index);

					SetListBoxTextOp(p, o);
				}	

				fFound = true;
			}
		}
	}

	return fFound;
}

void CWinCtrl::AddCombobox(char* name_edit, char* name_list, int w, int index_group)
{
	SCtrl ctrl;
	ctrl.name = name_edit;
	ctrl.w = w;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = index_group;
	ctrl.eType = ETC_WIN_E_EDIT;
	Add(ctrl); //win_e::SEdit* p_edit = (win_e::SEdit*)ctrl.p_obj; if (p_edit) { p_edit->SetReadOnly(); }

	int id_edit_car_agent = ctrl.id;

	ctrl.y += m_param.hCtrl;
	ctrl.f_no_calc_xy = true;
	ctrl.name = name_list;
	ctrl.mul_h = 6;
	ctrl.eType = ETC_WIN_E_LIST_BOX;
	ctrl.fHide = true;
	ctrl.fTop = true;

 Add(ctrl);

	win_e::SListBox* p_list = (win_e::SListBox*)ctrl.p_obj;
	if (p_list)
	{
		p_list->SetOneSel();
		p_list->SetTextOnly();
	}

	m_ctrlList[id_edit_car_agent].id_ctrl_open_by_left_button = ctrl.id;
	m_ctrlList[ctrl.id].id_ctrl_set_text_by_select = id_edit_car_agent;
	
}

bool CWinCtrl::GetSelIndex(char* name, int& index)
{
	bool fFound = false;

	int q = m_ctrlList.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.eType == ETC_WIN_E_LIST_BOX)
		{
			if (!stricmp(name, o.name.c_str()))
			{
				win_e::SListBox* p = (win_e::SListBox*)o.p_obj;

				index = p ? p->GetSelIndex() : -1;								

				fFound = true;
			}
		}
	}

	return fFound;
}

void CWinCtrl::AddListbox(char* name, int w, int index_group)
{
	SCtrl ctrl;
	ctrl.name = name;
	ctrl.w = w;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = index_group;
	ctrl.eType = ETC_WIN_E_LIST_BOX;
	Add(ctrl);
}

void CWinCtrl::Show(char* name, bool fShow, bool fActive)
{
	bool fFound = false;

	int q = m_ctrlList.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SCtrl& o = m_ctrlList[i];

		if (o.eType == ETC_STANDARD) { continue; }

		if (!stricmp(name, o.name.c_str()))
		{
			fFound = true;
			o.fHide = !fShow;
			
			if (o.eType == ETC_WIN_E_EDIT)
			{
				if (o.p_obj)
				{
					win_e::SEdit* p_edit = (win_e::SEdit*)o.p_obj;

					p_edit->SetActive(fActive);
				}
			}

			if (o.fTop && o.fHide)
			{
				o.fNeedDrawBackGround = true;
			}
		}

	}

}


void CWinCtrl::SetState(char *name, bool fStateNew)
{
	if (m_fInit == false) { return; }

	SCtrl *p_ctrl;

	if (Find(name, &p_ctrl) == false) { return; }

	p_ctrl->SetState(fStateNew);

	SendMessageA(p_ctrl->hwnd, BM_SETCHECK, (WPARAM)(fStateNew ? BST_CHECKED : BST_UNCHECKED), (LPARAM)0);
}

void CWinCtrl::InvertState(char *name, bool& fState)
{
	if (m_fInit == false) { return; }

	SCtrl *p_ctrl;

	if (Find(name, &p_ctrl) == false) { return; }

	p_ctrl->InvertState(fState);

	SendMessageA(p_ctrl->hwnd, BM_SETCHECK, (WPARAM)(p_ctrl->fPressed ? BST_CHECKED : BST_UNCHECKED), (LPARAM)0);
}
