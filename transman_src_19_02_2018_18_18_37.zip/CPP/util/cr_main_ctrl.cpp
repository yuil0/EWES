#include "main.h"
#include "u_color.h"

void cr_main_ctrl(HINSTANCE hInstance)
{
	SWinCtrlParam wcp;
	wcp.hInstance = hInstance;
	wcp.hwndParent = gWndMain.GetHWND();
	wcp.wCtrl = 80;
	wcp.hCtrl = 22;
	wcp.ident = 5;
	g_WinCtrl.Init(wcp);

	SCtrl ctrl;

	/*g_WinCtrl.NewRow();

	ctrl.Clear();
	ctrl.classWnd = "button";
	ctrl.textWnd = "Get";
	ctrl.name = "cb_get";
	ctrl.styleAdd = BS_CHECKBOX;
	g_WinCtrl.Add(ctrl);*/

	g_WinCtrl.NewRow();

	ctrl.Clear();
	ctrl.classWnd = "static";
	ctrl.textWnd = "Step color:";
	ctrl.styleAdd = SS_CENTER;
	g_WinCtrl.Add(ctrl);

	ctrl.Clear();
	ctrl.classWnd = "edit";
	ctrl.textWnd = "16";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT;
	g_WinCtrl.Add(ctrl);

	g_WinCtrl.NewRow();

	ctrl.Clear();
	ctrl.classWnd = "static";
	ctrl.textWnd = "Blue:";
	ctrl.styleAdd = SS_CENTER;
	g_WinCtrl.Add(ctrl);

	
	ctrl.Clear();
	ctrl.classWnd = "button";
	ctrl.textWnd = "+";
	ctrl.handler = blue_plus_handler;
	g_WinCtrl.Add(ctrl);

	ctrl.Clear();
	ctrl.classWnd = "button";
	ctrl.textWnd = "-";
	ctrl.handler = blue_minus_handler;
	g_WinCtrl.Add(ctrl);

	g_WinCtrl.NewRow();

	ctrl.Clear();
	ctrl.classWnd = "static";
	ctrl.textWnd = "Green:";
	ctrl.styleAdd = SS_CENTER;
	g_WinCtrl.Add(ctrl);

	ctrl.Clear();
	ctrl.classWnd = "button";
	ctrl.textWnd = "+";
	ctrl.handler = green_plus_handler;
	g_WinCtrl.Add(ctrl);

	ctrl.Clear();
	ctrl.classWnd = "button";
	ctrl.textWnd = "-";
	ctrl.handler = green_minus_handler;
	g_WinCtrl.Add(ctrl);

	g_WinCtrl.NewRow();

	ctrl.Clear();
	ctrl.classWnd = "static";
	ctrl.textWnd = "Red:";
	ctrl.styleAdd = SS_CENTER;
	g_WinCtrl.Add(ctrl);

	ctrl.Clear();
	ctrl.classWnd = "button";
	ctrl.textWnd = "+";
	ctrl.handler = red_plus_handler;
	g_WinCtrl.Add(ctrl);

	ctrl.Clear();
	ctrl.classWnd = "button";
	ctrl.textWnd = "-";
	ctrl.handler = red_minus_handler;
	g_WinCtrl.Add(ctrl);

	g_WinCtrl.NewRow();

	ctrl.Clear();
	ctrl.classWnd = "static";
	ctrl.textWnd = "BGR (HEX): ";
	ctrl.styleAdd = SS_CENTER;
	g_WinCtrl.Add(ctrl);

	ctrl.Clear();
	ctrl.classWnd = "edit";
	ctrl.textWnd = "000000";
	ctrl.name= "edit_color";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT; // | ES_READONLY;
	g_WinCtrl.Add(ctrl);

	ctrl.Clear();
	ctrl.classWnd = "static";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER;
	g_WinCtrl.Add(ctrl);

	/*ctrl.classWnd = "static";
	ctrl.textWnd = "Blue:";

	g_WinCtrl.Add(ctrl);*/

}
