#include <memory.h>
#include "MnemoScheme.h"

#include "draw_data.h"
#include "main.h"
#include "BookMarks.h"

#include "MesWnd.h"

const char* csz_MnemoScheme_menu_item_name[EMSMI_QUANTITY]=
{
};

void CMnemoScheme::WM__RBUTTONDOWN(POINT& pn)
{
	if (m_fInit == false) { return; }

	m_ctrls.TrackMenu(m_hwnd, pn); //CrContextMenu();TrackContextMenu(pn);
}

/*void CMnemoScheme::CrContextMenu()
{
	if (m_menu) { return; }
	
	m_menu = CreatePopupMenu();

	if (m_menu==0) 
	{ gMesWnd.Mes("CMnemoScheme::CrContextMenu(). ������ �������� ���� : %d", GetLastError()); return; }

	BOOL fByPosition = TRUE;
	
	const char* csz_text = "Text";
	
	UINT uFlags = MF_STRING;

	BOOL bAdd= AppendMenuA(m_menu, uFlags, (UINT_PTR)EMSMI_SHOW_RECT, (LPCSTR)csz_text);

	m_q_menu_item++;	
}

void CMnemoScheme::TrackContextMenu(POINT& pn)
{
	UINT fuFlags = TPM_LEFTALIGN | TPM_BOTTOMALIGN | TPM_LEFTBUTTON;  //TPM_RETURNCMD |  TPM_VERTICAL// | TPM_NOANIMATION //LPTPMPARAMS lptmp = 0;

	BOOL bTrack = TrackPopupMenu(m_menu, fuFlags, pn.x, pn.y, 0, m_hwnd, 0);

	if (bTrack == FALSE) 
	{ gMesWnd.Mes("CMnemoScheme::TrackContextMenu(). ������ ������ ���� : %d", GetLastError()); return; }
}
*/