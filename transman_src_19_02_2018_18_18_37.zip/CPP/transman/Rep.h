#ifndef _Rep_h_
#define _Rep_h_

#include <windows.h>
#include "..\\util\\winctrl.h"
#include "MSSQL.h"
#include "login_wnd.h"
#include "ms_inet.h"
#include "..\\transman_srv\\std_str.h"
#include "date_time.h"
#include "win_e.h"

typedef enum
{
	ERGDIO_PEN_DEVIDER = 0,
	ERGDIO_PEN_WHITE,
	ERGDIO_BRUSH_WHITE,
	//
	ERGDIO_QUANTITY,
}ERepGDIObject;

typedef enum
{
	ECR_0_1_2=0,
	ECR_3,
	ECR_4,
	ECR_5,
	ECR_6,
	ECR_7,
	ECR_8,
	ECR_9
}ECtrlsReps;

/*struct SRepCtrls
{
	CWinCtrl ctrls;
	
	std::vector<int> list_i_rep;

	void add_i_rep(int i_rep) { list_i_rep.push_back(i_rep); }
	bool find_i_rep(int i_rep);

	//void Clear() {list_i_rep.clear(); }
};*/

class CRep
{
	bool m_fInit;
	POINT m_wnd_size; //CWinCtrl m_ctrls;
	HGDIOBJ m_gdi_obj[ERGDIO_QUANTITY];
	bool m_f_refresh;     //std::vector<SRepCtrls> m_list_ctrls; //CWinCtrl m_ctrls_rep; //CWinCtrl* m_p_rep_ctrls_active;
	int m_i_rep;
	HINSTANCE m_hInstance;
	HWND m_hwndParent;

	bool m_f_show_rep; 
	std_string m_dt_rep_date;
	win_e::SRowButtons m_row_but_reps;
	win_e::SRowButtons::SGroundPenBrush m_gpb;

	void PaintDevider(HDC hdc, int x);
	void cr_m_gdi_obj();
	void del_m_gdi_obj();	//void CrButReps();
	void cr_ctrls_rep(ECtrlsReps eCtrlsReps);
	void but_rep(); //void AddCtrls(ECtrlsReps eCtrlsReps, int& i_start_id);

	public:
	CRep();
	~CRep();
	bool Open(HINSTANCE hInstance, HWND hwndParent, int w, int h);
	void Close(); //	void CrControls(); //void CrControlsR(HINSTANCE hInstance, HWND hwndParent);
	void Show(bool fShow);
	void OnCmd(int id, int notify); //void Paint(HDC hdc);
	void Paint(HDC hdc);
	void StartFill();
	void Tab(); //int GetBottom(); bool IsShowRep() { return m_f_show_rep; } //int GetButReptMaxY();
	void Update(); //bool find_m_ctrls_by_i_rep(int i_rep, SRepCtrls* *pRepCtrls=0);

	struct S_fill_dt_rep_date_param
	{
		CRep *p_rep;
		CWinCtrl *p_ctrls;
		std_string name;
	};

	void subtract_day_func(date_time::SDate& date, CRep::S_fill_dt_rep_date_param* p_param); //void fill_dt_rep_date_add(FldsPtr fp);
	void fill_dt_rep_date(char *sz_name, CWinCtrl *p_ctrls_new = 0);
	void SelCombo(char *sz_combo, int  index, CWinCtrl* p_ctrls=0);
	void CallPaint();
	void WM__LBUTTONDOWN(POINT& pn);
};



#endif