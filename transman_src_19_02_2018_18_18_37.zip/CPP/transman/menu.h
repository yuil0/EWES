#ifndef _menu_h_
#define _menu_h_

#include <windows.h>
#include <vector>

struct SMenuItem
{
};

class CMenu
{
	bool m_fInit;
	HMENU m_menu;
	public:
	CMenu();
	bool Open();
	void Close();
};

#endif