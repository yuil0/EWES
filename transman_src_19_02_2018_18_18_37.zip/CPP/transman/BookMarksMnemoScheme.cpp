#include <memory.h>
#include <windows.h>
#include "BookMarks.h"
#include "main.h"
#include "math_e.h"
#include "MesWnd.h"

CWinCtrl g_mnemo_scheme_ctrls;

void CBookMarks::MnemoSchemeCrControls(HINSTANCE hInstance, HWND hwndParent)
{
	const int cl_ident_from_left=5;
	const int cl_ident_from_top=5;

	SWinCtrlParam wcp;
	wcp.Clear();
	wcp.rowMax = 5;
	wcp.colMax = 5;
	wcp.hInstance = hInstance;
	wcp.hwndParent = hwndParent;
	wcp.wCtrl = 70;
	wcp.hCtrl = 22;
	wcp.ident = 5;
	wcp.xOrigin = cl_ident_from_left;
	wcp.yOrigin = ci_book_mark_height + cl_ident_from_top;

	g_mnemo_scheme_ctrls.Init(wcp);

	SCtrl ctrl;

	ctrl.Clear();
	ctrl.name = "static_route";
	ctrl.classWnd = "static";
	ctrl.textWnd = "�������";
	ctrl.styleAdd = SS_CENTER;
	g_mnemo_scheme_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "combo_route";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.mul_w = 2;
	ctrl.mul_h = 6;
	g_mnemo_scheme_ctrls.Add(ctrl);

	MnemoScheme_fill_combo_route();

	g_mnemo_scheme_ctrls.Update();
}


void CBookMarks::MnemoScheme_fill_combo_route()
{
	int index = 0;

	SRoute o;
	
	g_mnemo_scheme_ctrls.SendMes("combo_route", CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);

	while (gDrawWnd.NextRoute(index, o))
	{
		char *p_name = (char *)o.route_short_name.c_str();

		g_mnemo_scheme_ctrls.SendMes("combo_route", CB_ADDSTRING, (WPARAM)0, (LPARAM)p_name);
	}

	g_mnemo_scheme_ctrls.SendMes("combo_route", CB_SETCURSEL, (WPARAM)0, (LPARAM)0);
}