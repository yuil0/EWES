#ifndef _ControlPanelWnd_h_
#define _ControlPanelWnd_h_

#include "window.h"
#include "..\\util\\winctrl.h" //#include "point.h"
#include "mssql.h"
#include "..\\transman_srv\\std_str.h"

const long cl_panel_y = 31; // 8;//90; // 

const long cl_panel_h = 300;

const long cl_panel_no_expand_w = 40;

const long cl_panel_expand_w = 300;

const long cl_panel_ident = 7; //-52; // 0;//11; // 

const long cl_panel_ident_y = -8;

extern RECT g_ControlPanel_rc;

extern long g_ControlPanel_ch;

extern const char *csz_report_query;

const int ci_control_panel_rep_quantity = 10;

extern CWinCtrl* g_cp_p_ctrls;

typedef enum
{
	ER3M_STOP=0,
	ER3M_AREA,
	ER3M_STREET,	
}ERep3Mode;

struct SReadReportSQLResultRow
{
	int stop_id;
	std_string stop_name;
	std_string route_short_name;

	std_string arrival_time;
	std_string departure_time;
	int delta_time_min;
	std_string garage_num;
	int quantity_car;

	std_string arrival_time_1;
	std_string departure_time_1;
	int delta_time_min_1;
	std_string garage_num_1;
	int quantity_car_1;

	int speed;

	std_string area; //YUIL 2017-10-04  ����� 5
	std_string street;
	std_string stop_num;
	std_string lat;
	std_string lng;


	std_string hour;   //YUIL 2017-10-04 ����� 6
	std_string quantity_car_s;
	std_string speed_s;
	std_string delta_time_min_s;

	std_string device_number; //YUIL 2017-10-04 ����� 7
	std_string agency_name;
	std_string min_time;
	std_string max_time;
	std_string in_zone_agency_name;
	
	std_string dt; //YUIL 2017-10-05 ����� 8 ����
	int q_race;
	std_string type_day;

	std_string shape_id;   //YUIL 2017-10-06 ���� 8 ����
	bool f_time_in_picas_stop_times;
};

typedef  enum
{
	ERHTMLOT_SIMPLE=0,
	ERHTMLOT_SCREEN_2_FIT,
}EReportHTMLOutType;

struct SReport
{
	int i_rep; //YUIL 2017-09-25 ����� ������
	EReportHTMLOutType eHTMLOutType; //YUIL 2017-11-13

	int i_rep_mode;
	int i_rep_step; //����� �������
	int q_rep_row_write; //YUIL 2017-09-25 �����  �������� � ����
	std_string sz_file;//FILE *fo;
	void  Clear();
	void fill_sz_file();
	
	static const int ci_buf_size = 4096;

	char buf[ci_buf_size + 1];
	std_string sz_rep;
	std_string sz_rep_mode;
	std_string sz_rep_hour;
	std_string sz_dt;
	std_string sz_route;

	std_string sz_stop_from;
	std_string sz_stop_to;
	std_string sz_time_from;
	std_string sz_time_to;

	std_string stop_name;
	std_string area;
	std_string street;

	bool WriteReportToFile(SReadReportSQLResultRow* p=0);
	void WriteToFile(char *sz_in);
	int fo;   //std::vector<SReadReportSQLResultRow> rows;

	int quantity_car_sum;
	int quantity_car_1_sum;
	int delta_dtime_sum;
	int q_race_summ;

	std_string max_len;
	std_string sz_dt_to;
	
	WORD day_week;

	std_string device_number; //YUIL 2017-10-09
	std_string agent_name; //YUIL 2017-10-24
};

struct S_fill_combo_rep_shape 
{ 
	void Add(FldsPtr fp); 
};

struct S_fill_combo_rep_shape_stop_row
{
	std_string stop_id;
	std_string stop_name;
	double x, y;
};

struct S_fill_combo_rep_shape_stop
{
	std::vector<S_fill_combo_rep_shape_stop_row> list;

	void Add(FldsPtr fp);
};

struct S_fill_combo_rep_shape_stop_time 
{
	std_string sz_combo_time;

	std::vector<int> list_dtime;

	void Add(FldsPtr fp, char *sz_field_dtime= "departure_time_min");
};

struct SStopRep
{
	std_string stop_id;
	
	std_string stop_name;

	double x,  y;
};

struct S_fill_combo_rep_stops_by_dyn
{
	std::vector<SStopRep> list;

	void Add(FldsPtr fp);
};

struct SAgent
{
	std_string id;
	std_string name;
};

struct S_fill_combo_agent
{
	std::vector<SAgent> list;
};

class CControlPanelWnd
{
	bool m_fInit; //RECT m_rc; //bool m_f_expand; //long m_f_expand; //

	CWindow wnd; //HWND map_hwnd; HWND draw_hwnd; //bool m_event_size;

	HWND m_hwndDP;

	int GetH(); 

	SReport m_report;

	SReadReportSQLResultRow m_row;

	int m_q_row;

	CWinCtrl m_ctrls;

	void Ch();

	void SetFirst(SWindowCreateParam& wcp);  //void Expand();

	void Rep(int index_rep);
	

	void fill_combo_rep_shape();
	void fill_combo_rep_stops_by_dyn();
	void fill_combo_rep_shape_stop();
	void fill_combo_rep_shape_stop_time(char *sz_combo_stop, char *sz_combo_time, S_fill_combo_rep_shape_stop_time& s);
	bool GetDateTimeShapeId(char *sz_dt, char *shape_id, int i_max_shape_id);
	void fill_combo_rep_shape_stop_time_by_dyn(char *sz_combo_stop, char *sz_combo_time, S_fill_combo_rep_shape_stop_time& s);
	void fill_combo_rep_area();
	void fill_combo_rep_street();
	void SQL_exec(char *sz_query); // void SQL_P_report_1_clear_out(); void SQL_P_report_4_clear_out();
	
	void AddCtrlsAudio();
	void fill_combo_device(char* sz_combo = "combo_rep_device");
	void AddCtrlsFindNearCar();
	void fill_combo_agent();

	void fill_combo_rep();
public:
	CControlPanelWnd();
	~CControlPanelWnd();

	bool Create(HINSTANCE hInstance, wchar_t *wsz_app); // , HWND draw_hwnd_new);

	void Destroy();

	void WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam); 
	
	void WM__COMMAND(int id, int notify, int index_rep=-1); //WPARAM wParam, LPARAM lParam);

	bool IsInit() { return m_fInit; }

	//void SetByExpand(); //RECT& rcWnd  
	
	void CrControls(HINSTANCE hInstance);

	void Paint(int x, int y, int w, int h);
	
	//bool GetEventSize() { return m_event_size; } //void SetEventSize() { m_event_size=true; }

	void OnChMap();

	CWindow& GetWindow() { return wnd; }

	int SendMes(char *name, UINT uMes, WPARAM wParam, LPARAM lParam);

	CWinCtrl& GetCtrls() { return (CWinCtrl&)m_ctrls; }

	bool Find(char *name, SCtrl* *p_ctrl = 0);

	HWND GetHWND() { return wnd.GetHWND(); }
	
	void Update();

	void ReadReportSQLResultRow(FldsPtr fp);

	void RepOp();
	
	void SetStaticText(char *sz_text);

	void AddCtrlsRep8();

	void fill_combo_rep_stop();
	void fill_combo_rep_hour(int hour_from=0, int hout_to=23);
	void fill_combo_rep_route();
	void combo_rep_op(int index);
	void fill_combo_rep_mode(char *sz_mode_param=0);

	void set_p_ctrls(CWinCtrl* p_ctrls_new);
	CWinCtrl* get_p_ctrls() { return g_cp_p_ctrls; }
	const char* get_control_panel_rep_name(int index);
	
	char* GetDateTime(char *sz_date_time, char *sz_check = "check_rep_date", char *sz_dt= "dt_rep_date", WORD* p_day_week=0);
	void FillStaticTextByCombo(char *sz_name_combo_src);
	void AddCtrlsMap(float mul=1, int mode=0);
	void AddCtrlsFormalizeMes(float mul = 1, int mode = 0);
	void AfterExecSQL(bool f_exec);  //void SetWndBrowserTop();
	void AddCtrlsCarLagLead();
	void Fill_combo_route();

	void Fill_combo_stop();

	void Fill_combo_zone();

	void AddCtrlsReps();

	void FillCtrlsReps();
	void fill_combo_car_lag_lead();

	void Set_but_cr_zone_text_close()
	{
		m_ctrls.SendMes("but_cr_zone", WM_SETTEXT, (WPARAM)0, (LPARAM)"������");
	}

};


extern S_fill_combo_rep_shape_stop_time g_fill_combo_rep_shape_stop_from_time_by_dyn;
extern S_fill_combo_rep_shape_stop_time g_fill_combo_rep_shape_stop_to_time_by_dyn; 
extern S_fill_combo_rep_stops_by_dyn g_fill_combo_rep_stops_by_dyn;

extern S_fill_combo_rep_shape_stop_time g_fill_combo_rep_shape_stop_from_time;	
extern S_fill_combo_rep_shape_stop_time g_fill_combo_rep_shape_stop_to_time;
extern S_fill_combo_rep_shape_stop g_fill_combo_rep_shape_stop;	
extern S_fill_combo_agent g_fill_combo_agent;
#endif