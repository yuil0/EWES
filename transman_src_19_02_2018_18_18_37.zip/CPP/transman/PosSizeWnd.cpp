#include <memory.h>
#include "PosSizeWnd.h"

CPosSizeWnd::CPosSizeWnd() { } //m_fInit=false; memset(this, 0, sizeof(CPosSizeWnd)); m_fInit=true;


void CPosSizeWnd::Clear()
{
	memset(this, 0, sizeof(CPosSizeWnd));
}

void CPosSizeWnd::Read(HWND h_wnd, bool fSaveBegin)
{
	ClearEvents();

	RECT rc;
	
	WINDOWPLACEMENT placement;
	
	if (GetWindowRect(h_wnd, &rc) == FALSE) { return; }
	
	placement.length = sizeof(WINDOWPLACEMENT);

	if (GetWindowPlacement(h_wnd, &placement) == FALSE) { return; }

	
	if (m_fRead)
	{
		m_delta[ERS_LEFT] = rc.left - m_rc.left;

		m_delta[ERS_TOP] = rc.top - m_rc.top;

		m_delta[ERS_RIGHT] = rc.right - m_rc.right;

		m_delta[ERS_BOTTOM] = rc.bottom - m_rc.bottom;

		m_event = DeltaIsOver();

		CmpPlacement(placement);

		if (m_event) 
		{ 
			if (fSaveBegin==false) {m_rc = rc; }
			else
			{
				MoveWindow(h_wnd, m_rc.left, m_rc.top, m_rc.right - m_rc.left, m_rc.bottom - m_rc.top, TRUE); 
			}
		}
	}
	else
	{
		m_fRead = true;

			m_rc = rc;          
	}

	m_f_state = placement.flags;
}

bool CPosSizeWnd::DeltaIsOver()
{
	for (int i = 0; i < (int)ERS_QUANTITY; i++)
	{
		if (m_delta[i]) 
		{ return true; }
	}
	return false;
}

bool CPosSizeWnd::GetDelta(ERectSide eSide, int& iDeltaVal)
{ 
	if (eSide < 0 || eSide>=(int)ERS_QUANTITY) { return false; }
	iDeltaVal  = m_delta[eSide];
	return true;
}

void CPosSizeWnd::ClearEvents()
{
	m_event = false;
	m_eventState = false;
}

void CPosSizeWnd::CmpPlacement(const WINDOWPLACEMENT& placement)
{
	m_eventState = m_f_state != placement.flags;
}
