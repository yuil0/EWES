#include <memory.h>
#include <windows.h>
#include "draw_wnd.h"
#include "leaflet.h"
#include "math_e.h"
#include "main.h"
#include "MSSQL.h"

//////////////////////////////////////////////////////////////////////////////
void CDrawWnd::LoadStops()
{
	SDrawObject object;

	CMSSQL cMSSQL;

	bool f_open = cMSSQL.Open();

	if (f_open) 
	{ 
		RecPtr rec=cMSSQL.Execute("SELECT id_picas_stop, stop_id, stop_name, stop_lat, stop_lon FROM dbo.picas_stops");               //long i_rows = rec->RecordCount; //YUIL ������ -1

		while (rec->EndOfFile == VARIANT_FALSE)
		{
			STableStopFRow sRow;

			ETableStopField eField = ETSF_ID_PICAS_STOP; //_variant_t& val = rec->Fields->Item[0]->Value;

			long i_fields = rec->Fields->Count;

			VARIANT v_id_picas_stop = rec->Fields->Item["id_picas_stop"]->Value; //.decVal.Lo32

			_bstr_t bstr_stop_id(rec->Fields->Item["stop_id"]->Value);

			_bstr_t bstr_stop_name(rec->Fields->Item["stop_name"]->Value);

			VARIANT v_stop_lat = rec->Fields->Item["stop_lat"]->Value;  //.decVal.Lo32 , scale

			VARIANT v_stop_lon = rec->Fields->Item["stop_lon"]->Value;  //.decVal.Lo32 , scale
			
			//<w1
			object.eType = ETDO_STOP;

			object.id = v_id_picas_stop.decVal.Lo32;

			object.id_in = (char*)bstr_stop_id;

			object.name = (char*)bstr_stop_name;
			
			object.latlng.lat = v_stop_lat.decVal.Lo32 / pow(10, v_stop_lat.decVal.scale);
			
			object.latlng.lng = v_stop_lon.decVal.Lo32 / pow(10, v_stop_lon.decVal.scale);

			m_object_list.push_back(object);
			//>w1

			/*
			FILE *fo = fopen("LoadStops.txt", "wb");
			if (fo)
			{
				fprintf(fo, "v_id_picas_stop: vt:%d fltVal:%g dblVal:%g {wReserved : %u , scale : %d , sign : %d, Hi32: %u, Lo32: %u, Mid32: %u} %c%c", v_id_picas_stop.vt, v_id_picas_stop.fltVal, v_id_picas_stop.dblVal, v_id_picas_stop.decVal.wReserved, v_id_picas_stop.decVal.scale, v_id_picas_stop.decVal.sign, v_id_picas_stop.decVal.Hi32, v_id_picas_stop.decVal.Lo32, v_id_picas_stop.decVal.Mid32, 13, 10);

				fprintf(fo, "stop_id: '%s' %c%c", bstr_stop_id, 13, 10);

				fprintf(fo, "v_stop_lat: vt:%d fltVal:%g dblVal:%g {wReserved : %u , scale : %d , sign : %d, Hi32: %u, Lo32: %u, Mid32: %u} %c%c", v_stop_lat.vt, v_stop_lat.fltVal, v_stop_lat.dblVal, v_stop_lat.decVal.wReserved, v_stop_lat.decVal.scale, v_stop_lat.decVal.sign, v_stop_lat.decVal.Hi32, v_stop_lat.decVal.Lo32, v_stop_lat.decVal.Mid32, 13, 10);

				//fprintf(fo, "v_stop_lon {wReserved : %u , scale : %d , sign : %d}%c%c", v_stop_lon.decVal.wReserved, v_stop_lon.decVal.scale, v_stop_lon.decVal.sign, 13, 10);

				fclose(fo);
			}*/

			rec->MoveNext();
		}		

	}

	cMSSQL.Close();
}

void CDrawWnd::LoadProbeStop()
{
	SDrawObject object;

	object.latlng.lat = 47.281320;

	object.latlng.lng = 39.707210;

	object.eType = ETDO_STOP;

	m_object_list.push_back(object);
}

//////////////////////////////////////////////////////////////////////////////
void CDrawWnd::LoadShapes()
{
	SDrawObject object;

	CMSSQL cMSSQL;

	bool f_open = cMSSQL.Open();

	if (f_open)
	{
		RecPtr rec = cMSSQL.Execute("SELECT id_picas_shape, shape_id, shape_pt_lat, shape_pt_lon, shape_pt_sequence FROM dbo.picas_shapes");               //long i_rows = rec->RecordCount; //YUIL ������ -1

		while (rec->EndOfFile == VARIANT_FALSE)
		{
			STableStopFRow sRow;

			ETableStopField eField = ETSF_ID_PICAS_STOP; //_variant_t& val = rec->Fields->Item[0]->Value;

			long i_fields = rec->Fields->Count;

			VARIANT v_id = rec->Fields->Item["id_picas_shape"]->Value; //.decVal.Lo32

			_bstr_t bstr_shape_id(rec->Fields->Item["shape_id"]->Value);

			VARIANT v_lat = rec->Fields->Item["shape_pt_lat"]->Value;  //.decVal.Lo32 , scale

			VARIANT v_lon = rec->Fields->Item["shape_pt_lon"]->Value;  //.decVal.Lo32 , scale

	        //<w1
			object.eType = ETDO_ROUTE_POINT;

			object.id = v_id.decVal.Lo32;

			object.id_in = (char*)bstr_shape_id;

			object.name = "";

			object.latlng.lat = v_lat.decVal.Lo32 / pow(10, v_lat.decVal.scale);

			object.latlng.lng = v_lon.decVal.Lo32 / pow(10, v_lon.decVal.scale);

			m_object_list.push_back(object);
			//>w1

			rec->MoveNext();
		}

	}

	cMSSQL.Close();
}

