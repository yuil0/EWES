#ifndef _leaflet_h_
#define _leaflet_h_

#include <math.h>
#include <corecrt_math_defines.h>

// http://leafletjs.com/
// http://leafletjs.com/reference-1.2.0.html

namespace Leaflet
{
	struct LatLng
	{
		double lat, lng;
	};

	struct Point
	{
		double x, y;

		Point() {}

		Point(double xNew, double yNew);
	};

	struct Transformation
	{
		double _a;
		double _b;
		double _c;
		double _d;

		Transformation(double a, double b, double c, double d)
		{
			_a = a;
			_b = b;
			_c = c;
			_d = d;
		}

		Point _transform(Point point, double scale);
	};

	struct Bounds
	{
		Point min;
		Point max;

		Bounds() {}

		Bounds(Point minNew, Point maxNew) { min = minNew, max = maxNew; }
	};

	struct projection
	{
		virtual Point project(const LatLng& latlng) = 0;

		virtual Transformation transformation() = 0;
		
		virtual Bounds bounds()=0;
	};

	struct SphericalMercator : projection
	{
		const double R = 6378137;

		const double MAX_LATITUDE = 85.0511287798;

		Point project(const LatLng& latlng);

		Transformation transformation() //EPSG3857
		{
			double scale = 0.5 / (M_PI * R);

			return Transformation(scale, 0.5, -scale, 0.5);
		}

		Bounds bounds()
		{
			double d = 6378137 * M_PI;

			Bounds boundsLocal;

			boundsLocal.min.x = -d;

			boundsLocal.min.y = -d;

			boundsLocal.max.x = d;

			boundsLocal.max.y = d;

			return boundsLocal;
		}
	};

	template<typename projectionType>

	class CRS
	{
		projectionType projection;

		double scale(double zoom)
		{
			return 256 * pow(2, zoom);
		}

		public:

		Point latLngToPoint(const LatLng& latlng, double zoom) // Projects geographical coordinates into pixel coordinates for a given zoom.
		{
			Point projectedPoint = projection.project(latlng);

			double dScale = scale(zoom);

			Transformation transformation = projection.transformation();

			return transformation._transform(projectedPoint, dScale);

		}

		projectionType& getProjection() { return (projectionType&)projection; }

		Bounds getProjectedBounds(double zoom)
		{
			Bounds b = projection.bounds();

			double s = scale(zoom);

			Transformation transformation = projection.transformation();

			Point pnMin = transformation._transform(b.min, s);

			Point pnMax = transformation._transform(b.max, s);

			return Bounds(pnMin, pnMax);
		}
	};
}

#endif