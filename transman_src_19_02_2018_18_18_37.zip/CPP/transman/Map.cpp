#include <memory.h>
#include "main.h"
#include "Map.h"

#include "BookMarks.h"
#include "login_wnd.h"
#include "MesWnd.h"
#include <commctrl.h>
#include "..\\transman_srv\\time_e.h"
#include "win_e.h"
#include "FormMes.h"  
#include "ini_file.h"  
#include <Windowsx.h>

const int cl_rep_ident_from_left=5;
const int cl_rep_quantity = 10;
const int ci_map_height_font = 14;
const int ci_map_read_mes_sleep = 1000;

CMap::CMap() {}

CMap::~CMap() {}

bool CMap::Open(HINSTANCE hInstance, HWND hwndParent, int w, int h)
{
	memset(this, 0, sizeof(CMap)); //m_hwndParent = hwndParent;

	ReadIni();

	m_wnd_size.x= w; m_wnd_size.y= h;
	
	cr_m_gdi_obj(); 
	
	m_hInstance = hInstance;
	m_hwndParent = hwndParent;
	
	m_hfont_edit = win_e::Create_Font("Courier", ci_map_height_font);

	CrControls();	//AddBitmapCtrls();


	AfterSet();

	m_fInit=true;

	return m_fInit;
}

void CMap::ReadIni()
{
	CIniFile ini;
	
	char sz_val[MAX_PATH + 1];

	/*if (ini.Get("c:\\transman\\transman.ini", "bookmark_map_form_mes_name", sz_val, MAX_PATH))
	{
		if (!stricmp(sz_val, "garage")) 
		{ m_eFormMesName = EFMN_GARAGE; }
		else 
		{ m_eFormMesName = EFMN_DEVICE; }
	}*/
}

void CMap::AfterSet()
{
	fill_list_show_route_car();
	
	m_ctrls.SetCheckbox("cb_show_cars", true);

	m_ctrls.SetCheckbox("cb_form_mes_re", true);

	SelCarsToList();

	SetReadMes();

	if (gBookMarks.GetActive() == EBMN_MAP)
	{
		CallPaint();
	}
}


void CMap::Close()
{
	DeleteObject(m_hfont_edit);

	del_m_gdi_obj();

	m_ctrls.Destroy(); //m_bitmapCtrls.Close(); //lb_routeCar.Close(); lb_carTypes.Close(); lb_selCars.Close(); //edit_zone_new_name.Close();
}

void CMap::cr_m_gdi_obj()
{
	m_gdi_obj[EMGDIO_PEN_DEVIDER]=CreatePen(PS_SOLID, 0, 0x0);
	m_gdi_obj[EMGDIO_BRUSH_WHITE]=CreateSolidBrush(0xFFFFFF);
	m_gdi_obj[EMGDIO_PEN_WHITE]=CreatePen(PS_SOLID, 0, 0xFFFFFF);

	m_gdi_obj[EMGDIO_HBITMAP_STATIC_6_2] = LoadImageA(0, "C:\\transman\\img\\6_2.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);	
	
}

void CMap::del_m_gdi_obj()
{
	for (int i=0; i<(int)EMGDIO_QUANTITY; i++)
	{
		DeleteObject(m_gdi_obj[i]);
	}
}

/*void CMap::AddBitmapCtrls()
{
	if (g_f_bitmap_interface == false) { return; }

	if (m_bitmapCtrls.Open() == false) { return; }

	win_e::SMonitors& sm = gMonitors;
	int wScr = sm.rc[1].right - sm.rc[1].left; //int y = m_params.i_top; //int h = m_params.i_height - m_params.i_top;
	SBookMarksParams& bm_params = gBookMarks.GetParams();
	int ident_x = bm_params.i_ident_x;
	win_e::SBitmapCtrl o;

	POINT start = {13, bm_params.i_height + 28};

	o.id = (int)EBMC_BUT_CLOSE;
	o.size.x = 150; o.size.y = 32; //prev : 460 92
	o.pn.x = start.x; o.pn.y = start.y + 29;
	o.hbitmapUp = (HBITMAP)m_gdi_obj[EMGDIO_HBITMAP_STATIC_6_2];
	o.text = "���������";
	m_bitmapCtrls.Add(o);
}*/

void CMap::Tab()
{
	m_ctrls.NextFocusActive();
}

void CMap::CrControls()
{
	extern win_e::SMonitors gMonitors;
	
	SBookMarksParams& bm_params = gBookMarks.GetParams();

	SWinCtrlParam wcp;
	wcp.Clear();
	wcp.hInstance = m_hInstance;
	wcp.hwndParent = m_hwndParent;
	wcp.wCtrl = 70;
	wcp.hCtrl = 22;
	wcp.ident = 5; 
	wcp.xOrigin = 10; 
	wcp.yOrigin = bm_params.i_height + cl_chat_ident_from_top; //wcp.fHide=true; //wcp.i_start_id = gControlPanelWnd.GetCtrls().GetSize() + 1;
	wcp.fOwnerDraw=true;
	m_ctrls.Init(wcp);

	gControlPanelWnd.set_p_ctrls(&m_ctrls);
	
	CWinCtrl::SAddGroupParam sgp;
	sgp.w = 400;
	sgp.h = 340;
	sgp.h_caption = 22;
	sgp.index_from = -1;
	sgp.eDirect = CWinCtrl::EAGD_RIGHT;

	m_ctrls.AddGroup("�������", sgp);
	m_ctrls.AddGroup("����� ����", sgp);
	m_ctrls.AddGroup("������������ ��������", sgp);

	//<q2
	int index_gr = 2;
	SGroup g2;
	if (m_ctrls.GetGroup(index_gr, g2))
	{
		sgp.w = (gMonitors.rc[1].right- gMonitors.rc[1].left) - g2.x - g2.w-20;
		sgp.h = 340 + 500+4;
		
		m_ctrls.AddGroup("���������", sgp);
	}
	//>q2

	sgp.index_from = 0; sgp.eDirect = CWinCtrl::EAGD_BOTTOM; sgp.w = 1208; sgp.h = 500; m_ctrls.AddGroup("������� � ���������", sgp);

	CrGrSt();
	CrGrNewZone(); //gControlPanelWnd.AddCtrlsMap(mul, mode);
	CrGrMobile(); //CrCtrlsExt(); 
	CrGrSelected();
	CrGrMes();
	
	m_ctrls.Update(); //m_ctrls.SetFocusActive();
}

void CMap::CrGrSt()
{
	m_ctrls.SetMaxX(0);

	SCtrl ctrl;
	/*if (gDrawWnd.GetData().m_f_shape_lines)
	{
		ctrl.Clear();
		ctrl.name = "static_route";
		ctrl.classWnd = "static";
		ctrl.textWnd = "���������� �����";
		ctrl.styleAdd = SS_CENTER;
		ctrl.f_no_calc_w = true;
		ctrl.w = 140;
		ctrl.index_group = 0;
		m_ctrls.Add(ctrl);

		ctrl.Clear();
		ctrl.name = "combo_route";
		ctrl.classWnd = "combobox";
		ctrl.textWnd = "";
		ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
		ctrl.f_no_calc_w = true;
		ctrl.w = 200;
		ctrl.mul_h = 6;
		ctrl.index_group = 0;
		m_ctrls.Add(ctrl);
	}*/

	m_ctrls.GroupNewRows(0);
	ctrl.Clear();
	ctrl.name = "static_stop";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������";
	ctrl.styleAdd = SS_CENTER; // | SS_OWNERDRAW;
	ctrl.f_no_calc_w = true;
	ctrl.w = 140;
	ctrl.index_group = 0;
	m_ctrls.Add(ctrl);

	m_ctrls.AddCombobox("edit_stop", "combo_stop", 200, 0);
	
	/*ctrl.Clear();
	ctrl.name = "combo_stop"; 
	ctrl.classWnd = "combobox";	//ctrl.textWnd = ""; 
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.f_no_calc_w = true;
	ctrl.w = 200;
	ctrl.mul_h = 6;
	ctrl.index_group = 0; //ctrl.eType = ETC_WIN_E_COMBO_BOX;
	m_ctrls.Add(ctrl);*/

	/* HWND hwnd_combo_stop = {
		HDC hdc = GetDC(hwnd_combo_stop);
		
		HBRUSH hbrushGround = gBookMarks.Get_HBRUSH_Ground();

		SelectObject(hdc, hbrushGround);

		Rectangle(hdc, ctrl.x, ctrl.y, ctrl.w, ctrl.h);
		
		ReleaseDC(hwnd_combo_stop, hdc);
	}*/

	m_ctrls.GroupNewRows(0);
	ctrl.Clear();
	ctrl.name = "static_zone";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����";
	ctrl.styleAdd = SS_CENTER;
	ctrl.f_no_calc_w = true;
	ctrl.w = 140;
	ctrl.index_group = 0;
	m_ctrls.Add(ctrl);

	m_ctrls.AddCombobox("edit_zone", "combo_zone", 180, 0);

	/*ctrl.Clear();
	ctrl.name = "combo_zone";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.f_no_calc_w = true;
	ctrl.w = 180;
	ctrl.index_group = 0;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);*/

	ctrl.Clear();
	ctrl.name = "but_zone_del";
	ctrl.classWnd = "button";
	ctrl.textWnd = "X";
	ctrl.f_no_calc_w = true;
	ctrl.w = 20;
	ctrl.index_group = 0;
	m_ctrls.Add(ctrl);

	//gControlPanelWnd.Fill_combo_route();  
	fill_combo_stop(); //fill_combo_stop();
	fill_combo_zone();
}


void CMap::fill_combo_stop()
{
	int index = 0;

	SStop o;
	m_ctrls.ClearList("combo_stop");

	m_ctrls.AddToList("combo_stop", "���");
	m_ctrls.AddToList("combo_stop", "���������");

	while (gDrawWnd.NextStop(index, o))
	{
		m_ctrls.AddToList("combo_stop", (char *)o.stop_name.c_str());
	}

	m_ctrls.SelByIndex("combo_stop", 0);
}

void CMap::fill_combo_zone()
{
	int index = 0;

	SZone o;

	m_ctrls.ClearList("combo_zone");

	m_ctrls.AddToList("combo_zone", "���");
	m_ctrls.AddToList("combo_zone", "���������");

	while (gDrawWnd.NextZone(index, o))
	{
		m_ctrls.AddToList("combo_zone", (char *)o.name.c_str());
	}

	m_ctrls.SelByIndex("combo_zone", 0);
}

/*void CMap::fill_combo_stop()
{
	m_ctrls.ClearList("combo_stop");
	m_ctrls.AddToList("combo_stop", "���");
	m_ctrls.AddToList("combo_stop", "����.");

	int index = 0;
	SStop o;

	while (gDrawWnd.NextStop(index, o))
	{
		char *p_name = (char *)o.stop_name.c_str();

		m_ctrls.AddToList("combo_stop", p_name);
	}
}*/

void CMap::CrGrNewZone()
{
	m_ctrls.SetMaxX(0);

	SCtrl ctrl;

	ctrl.Clear();
	ctrl.name = "static_zone_new_name";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���";
	ctrl.w = 140;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 1;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "edit_zone_new_name"; //ctrl.classWnd = "edit";
	ctrl.textWnd = "���������";
	ctrl.w = 200;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 1; //ctrl.styleAdd = WS_BORDER | ES_RIGHT;
	ctrl.eType = ETC_WIN_E_EDIT;
	m_ctrls.Add(ctrl);

	/*ctrl.w = 200;
	m_ctrls.CalcPosSizeNewElement(ctrl);
	RECT rc1 = { ctrl.x, ctrl.y, ctrl.x + ctrl.w, ctrl.y + ctrl.h };
	edit_zone_new_name.Open(rc1);
	edit_zone_new_name.SetText("���������");*/

	m_ctrls.GroupNewRows(1);
	ctrl.Clear();
	ctrl.name = "but_cr_zone";
	ctrl.classWnd = "button";
	ctrl.textWnd = "������";
	ctrl.f_no_calc_w = true;
	ctrl.w = 140;
	ctrl.index_group = 1;
	m_ctrls.Add(ctrl);

	m_ctrls.GroupNewRows(1);
	ctrl.Clear();
	ctrl.name = "but_zone_new_save";
	ctrl.classWnd = "button";
	ctrl.textWnd = "���������";
	ctrl.f_no_calc_w = true;
	ctrl.w = 140;
	ctrl.index_group = 1;
	m_ctrls.Add(ctrl);
}

void CMap::CrGrMobile()
{
	int h_element = 22;

	m_ctrls.SetMaxX(0);

	SCtrl ctrl;

	/*ctrl.Clear();
	ctrl.name = "static_text";
	ctrl.classWnd = "static";
	ctrl.textWnd = "*";
	ctrl.w = 240;
	ctrl.f_no_calc_w = true;
	ctrl.mul_h = 2;
	ctrl.index_group = 3;
	ctrl.styleAdd = SS_CENTER | WS_BORDER;
	m_ctrls.Add(ctrl);*/

	/*ctrl.Clear();
	ctrl.name = "static_form_mes";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����. �����.";
	ctrl.w = 100;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 3;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "combo_form_mes";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.w = 200;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 3;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_form_mes_send";
	ctrl.classWnd = "button";
	ctrl.w = 70;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 3;
	ctrl.textWnd = "�������"; // > "; //YUIL 2017-09-21 ������� //ctrl.mul_w = 0.27;
	m_ctrls.Add(ctrl);  //gControlPanelWnd.AddCtrlsFormalizeMes(1, 1);
	*/
	ctrl.Clear();
	ctrl.name = "static_car_lag_lead";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���������/�����������";
	ctrl.w = 200;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);

	m_ctrls.AddCombobox("edit_car_lag_lead", "combo_car_lag_lead", 124, 2); //180 - h_element - 2 * m_ctrls.m_param.ident

	/*ctrl.Clear();
	ctrl.name = "combo_car_lag_lead";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.w = 180 - h_element- 2*m_ctrls.m_param.ident;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	ctrl.mul_h = 6;
	m_ctrls.Add(ctrl);*/

	ctrl.Clear();
	ctrl.name = "but_car_lag_lead";
	ctrl.classWnd = "button";
	ctrl.textWnd = ">";
	ctrl.w = 50;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	m_ctrls.Add(ctrl);

	m_ctrls.GroupNewRows(2);
	ctrl.Clear();
	ctrl.name = "static_find_near_car";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����� �������� ��";
	ctrl.w = 200;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "edit_find_near_car"; //ctrl.classWnd = "edit";
	ctrl.w = 124;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	ctrl.styleAdd = ES_READONLY; // | ES_RIGHT | WS_BORDER;
	ctrl.eType = ETC_WIN_E_EDIT;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "but_find_near_car";
	ctrl.classWnd = "button";
	ctrl.textWnd = "���";
	ctrl.w = 50;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	m_ctrls.Add(ctrl);

	m_ctrls.GroupNewRows(2);
	/*ctrl.Clear();
	ctrl.name = "cb_show_cars";
	ctrl.textWnd = "�������� ��";
	ctrl.classWnd = "button";
	ctrl.w = 200;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 3;
	ctrl.styleAdd = BS_CHECKBOX;
	m_ctrls.Add(ctrl);
	*/
	ctrl.Clear();
	ctrl.name = "static_car_agent";
	ctrl.classWnd = "static";
	ctrl.textWnd = "����������"; //YUIL 2017-01-30 : ��� �����
	ctrl.w = 200;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);

	m_ctrls.AddCombobox("edit_car_agent", "combo_car_agent", 180, 2);

	/*ctrl.Clear();
	ctrl.name = "edit_car_agent";
	ctrl.w = 180;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	ctrl.eType = ETC_WIN_E_EDIT;
	m_ctrls.Add(ctrl); //win_e::SEdit* p_edit = (win_e::SEdit*)ctrl.p_obj; if (p_edit) { p_edit->SetReadOnly(); }
	
	int id_edit_car_agent = ctrl.id;

	ctrl.y += m_ctrls.m_param.hCtrl;
	ctrl.f_no_calc_xy = true;
	ctrl.name = "combo_car_agent";
	ctrl.mul_h = 6;
	ctrl.eType = ETC_WIN_E_LIST_BOX;
	ctrl.fHide = true;
	ctrl.fTop = true;
	
	m_ctrls.Add(ctrl);

	win_e::SListBox* p_list = (win_e::SListBox*)ctrl.p_obj;
	if (p_list)
	{
		p_list->SetOneSel();
		p_list->SetTextOnly();
	}

	m_ctrls[id_edit_car_agent].id_ctrl_open_by_left_button = ctrl.id;
	m_ctrls[ctrl.id].id_ctrl_set_text_by_select = id_edit_car_agent;*/

	/*ctrl.Clear();
	ctrl.name = "combo_car_agent";
	ctrl.classWnd = "combobox";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | CBS_DROPDOWNLIST | WS_VSCROLL;
	ctrl.w = 180;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	ctrl.mul_h = 6;
	g_cp_p_ctrls->Add(ctrl);
	*/

	/*ctrl.Clear();
	ctrl.name = "check_agent_bind";
	ctrl.classWnd = "button";
	ctrl.textWnd = "�������";
	ctrl.styleAdd = BS_CHECKBOX;
	ctrl.w = 100;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 3;
	g_cp_p_ctrls->Add(ctrl);*/

	m_ctrls.GroupNewRows(2);
	ctrl.Clear();
	ctrl.name = "static_car_types";
	ctrl.classWnd = "static";
	ctrl.textWnd = "���� ��";
	ctrl.w = 200;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "lb_carTypes";
	ctrl.w = 180;
	ctrl.f_no_calc_w = true;
	ctrl.mul_h = 4;
	ctrl.index_group = 2;
	ctrl.eType= ETC_WIN_E_LIST_BOX;
	m_ctrls.Add(ctrl);

	if (ctrl.p_obj)
	{ ((win_e::SListBox*)ctrl.p_obj)->ExecSQL_query("SELECT id_car_type id, name FROM dbo.car_type"); }

	/*m_ctrls.CalcPosSizeNewElement(ctrl);
	ctrl.w = 180;
	ctrl.h = 4 * h_element + 9;
	RECT rc = { ctrl.x, ctrl.y, ctrl.x + ctrl.w, ctrl.y + ctrl.h };
	lb_carTypes.Open(rc, h_element, );*/

	m_ctrls.GroupNewRows(2);	
	m_ctrls.GroupNewRows(2);
	m_ctrls.GroupNewRows(2);
	m_ctrls.GroupNewRows(2);//gControlPanelWnd.AddCtrlsCarLagLead();m_ctrls.GroupNewRows(2); 	//gControlPanelWnd.AddCtrlsCarLagLead();

	ctrl.Clear();
	ctrl.name = "static_show_route_car";
	ctrl.classWnd = "static";
	ctrl.textWnd = "��������"; //YUIL 2017-01-30 ���: �� ���������
	ctrl.w = 200;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);

	ctrl.Clear();
	ctrl.name = "lb_routeCar";
	ctrl.w = 180;
	ctrl.f_no_calc_w = true;
	ctrl.mul_h = 4;
	ctrl.index_group = 2; 
	ctrl.eType = ETC_WIN_E_LIST_BOX;
	m_ctrls.Add(ctrl);

	/*m_ctrls.CalcPosSizeNewElement(ctrl);	
	ctrl.w = 180;
	ctrl.h = 5 * h_element + 9;
	RECT rc2 = { ctrl.x, ctrl.y, ctrl.x + ctrl.w, ctrl.y + ctrl.h };
	lb_routeCar.Open(rc2, h_element);*/
	

	m_ctrls.GroupNewRows(2);
	ctrl.Clear();
	ctrl.name = "but_show_cars_sel_all";
	ctrl.textWnd = "������� ����";
	ctrl.classWnd = "button";
	ctrl.w = 120;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	m_ctrls.Add(ctrl);

	m_ctrls.GroupNewRows(2);
	ctrl.Clear();
	ctrl.name = "but_show_cars_desel_all";
	ctrl.textWnd = "�������� ����";
	ctrl.classWnd = "button";
	ctrl.w = 120;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 2;
	m_ctrls.Add(ctrl);

	/*INITCOMMONCONTROLSEX icex;        
	icex.dwICC = ICC_LISTVIEW_CLASSES;
	InitCommonControlsEx(&icex);

	ctrl.Clear();
	ctrl.name = "list_show_route_car";
	ctrl.classWnd = WC_LISTVIEWA;
	ctrl.textWnd = "";
	ctrl.styleAdd = LVS_REPORT | WS_BORDER | WS_VSCROLL | LVS_EDITLABELS; //; //LBS_EXTENDEDSEL  //
	ctrl.w = 180;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 3;
	ctrl.mul_h = 6;
	HWND hwnd = m_ctrls.Add(ctrl);
	

	if (hwnd)
	{
		ListView_SetExtendedListViewStyle(hwnd, LVS_EX_CHECKBOXES );//LVS_EX_FULLROWSELECT | |	LVS_EX_ONECLICKACTIVATE | LVS_EX_GRIDLINES
		LVCOLUMN col;
		col.mask = LVCF_TEXT | LVCF_WIDTH;
		col.cx = 170;
		col.pszText = TEXT("�������");
		ListView_InsertColumn(hwnd, 0, &col);
	}*/
	
	fill_combo_car_agent();
	fill_combo_car_lag_lead();
}


void CMap::fill_combo_car_lag_lead()
{
	m_ctrls.AddToList("combo_car_lag_lead", "���");
	m_ctrls.AddToList("combo_car_lag_lead", "���������");
	m_ctrls.AddToList("combo_car_lag_lead", "�����������");
	m_ctrls.AddToList("combo_car_lag_lead", "�����");
	m_ctrls.SelByIndex("combo_car_lag_lead", 0);
}

void CMap::fill_list_show_route_car(int id_agent)
{                                                //char *sz_combo = "list_show_route_car\0";
	m_ctrls.ClearList("lb_routeCar"); //lb_routeCar.list.clear();

	int index = 0; // gDrawWnd.GetRouteSize() - 1; //SCtrl* p_ctrl; //if (m_ctrls.Find(sz_combo, &p_ctrl) == false) { return; }

	SRoute s_route; //bool fBack = true;

	while (gDrawWnd.NextRoute(index, s_route))
	{
		if (id_agent == 0 || s_route.id_agent== id_agent)
		{
			bool f_select = true; //win_e::SListBoxItem item; item.f_select = true;item.sz_text = s_route.route_short_name;

			m_ctrls.AddToList("lb_routeCar", (char*)s_route.route_short_name.c_str(), f_select); //lb_routeCar.list.push_back(item);
		}
	}
	
}


void CMap::CrGrSelected()
{
	m_ctrls.SetMaxX(0);
	
	const int ci_mul_h_edit = 2;

	SCtrl ctrl;

	int index_gr = 3;
	SGroup g3;
	if (m_ctrls.GetGroup(index_gr, g3) == false) { return; }

	int h_element = 22;
	int w_element = g3.w - 10;
	int h_input_edit= h_element*ci_mul_h_edit;
	
	int h_list = g3.h - 31 - h_input_edit - h_element * 2;

	ctrl.Clear();
	ctrl.name = "lb_selCars";
	ctrl.w = w_element;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = 3;
	ctrl.mul_h = (h_list)/ (h_element)-2;
	ctrl.eType = ETC_WIN_E_LIST_BOX;
	m_ctrls.Add(ctrl);

	if (ctrl.p_obj)
	{ ((win_e::SListBox*)ctrl.p_obj)->SetTextOnly(); }
	
	/*ctrl.index_group = 3;
	ctrl.f_no_calc_w = true;
	m_ctrls.CalcPosSizeNewElement(ctrl);
	ctrl.w = w_element;

	ctrl.h = h_list;//40 * h_element + 9
	RECT rc = { ctrl.x, ctrl.y, ctrl.x + ctrl.w, ctrl.y + ctrl.h };
	bool f_text_only = true;
	lb_selCars.Open(rc, h_element, 0, f_text_only);*/

	
	int q_rows = g3.h/(h_element+10) + (4-ci_mul_h_edit);//
	m_ctrls.GroupNewRows(3, q_rows);
	ctrl.Clear();
	ctrl.f_no_calc_xy = true;
	ctrl.name = "edit_gr_sel_input"; //ctrl.classWnd = "edit";
	ctrl.w = w_element;

	ctrl.x = (m_wnd_size.x - w_element) / 2;
	ctrl.y = (m_wnd_size.y - ci_mul_h_edit*h_element) / 2;

	ctrl.f_no_calc_w = true;
	ctrl.index_group = 3;
	ctrl.mul_h = ci_mul_h_edit; //ctrl.styleAdd = WS_BORDER | ES_MULTILINE | WS_VSCROLL;
	ctrl.eType = ETC_WIN_E_EDIT;
	ctrl.fTop = true;
	ctrl.fHide = true;
	m_ctrls.Add(ctrl);

	/*if (ctrl.p_obj)
	{
		win_e::SEdit *p_edit = (win_e::SEdit*)ctrl.p_obj;
		p_edit->Set_hwnd(m_hwndParent);
		p_edit->SetId(ctrl.id);
	}*/

	/* //YUIL 2017-02-01 ��������� �� �������� �����
	if (gLoginWnd.GetUserType() == EUT_DISP_HI)
	{
		ctrl.Clear();
		ctrl.name = "cb_out_to_video_wall";
		ctrl.textWnd = "����� �� ����������";
		ctrl.classWnd = "button";
		ctrl.w = 200;
		ctrl.f_no_calc_w = true;
		ctrl.index_group = 4;
		ctrl.styleAdd = BS_CHECKBOX;
		m_ctrls.Add(ctrl);
	} */
	
} 

void CMap::CrGrMes()
{
	m_ctrls.SetMaxX(0);
	SCtrl ctrl; //m_ctrls.GroupNewRows(4);	

	int index_gr = 4;
	SGroup g4;
	if (m_ctrls.GetGroup(index_gr, g4) == false) { return; }


	ctrl.name = "list_mes";
	ctrl.w = g4.w - 6;
	ctrl.f_no_calc_w = true;
	ctrl.index_group = index_gr;
	ctrl.eType = ETC_WIN_E_LIST_BOX;
	ctrl.mul_h = g4.h / m_ctrls.m_param.hCtrl - 5;
	m_ctrls.Add(ctrl);

	if (ctrl.p_obj)
	{
		win_e::SListBox* p_list = (win_e::SListBox*)ctrl.p_obj;

		if (p_list)
		{
			p_list->SetTextOnly();
			p_list->SetOneSel();
			p_list->SetBackOrder();
			p_list->SetCaption("���� � �����#�����������#����������#��������#�����#");
			p_list->SetNoScroll();

			int width_col = 120;

			p_list->AddWidth(width_col+45);
			p_list->AddWidth(width_col);
			p_list->AddWidth(width_col);			
			p_list->AddWidth(width_col-45);

			p_list->InitBarY();
		}
	}

	//CrThreadMes();
}

/*DWORD WINAPI CMap_CrThreadMes_proc(LPVOID p_param)
{
	CMap* p_this = (CMap*)p_param;

	while (1)
	{
		p_this->ReadMes();

		Sleep(ci_map_read_mes_sleep);
	}
	return 1;
}

void CMap::CrThreadMes()
{
	CreateThread(0, 0, CMap_CrThreadMes_proc, this, 0, 0);
}*/

void CMap::set_edit_find_near_car(char *sz_text)
{
	m_ctrls.SetText("edit_find_near_car", sz_text); //m_ctrls.SendMes("edit_find_near_car", WM_SETTEXT, (WPARAM)0, (LPARAM)sz_text);	
	CallPaint();
}

void CMap::StartFill()
{
}

void CMap::Show(bool fShow)
{
	m_ctrls.ShowAllUpdate(fShow); 	
}


void CMap::WM__NOTIFY(WPARAM wParam, LPARAM lParam)
{
	if (wParam == LVN_ITEMCHANGED)
	{
		NMLISTVIEW* pnmv = (LPNMLISTVIEW)lParam;

		if (pnmv == 0) { return; }

		NMHDR& hdr = pnmv->hdr;

		int id = hdr.idFrom;

		SCtrl* p_ctrl;

		if (m_ctrls.Find(id, &p_ctrl))
		{
			if (p_ctrl->name == "list_show_route_car")
			{
				gMesWnd.Mes("hdr.code = %d", hdr.code);//if (hdr.code == 2){}
			}
		}
	}
}

void CMap::sel_al_routes()
{
	m_ctrls.SelectAll("lb_routeCar", true); //lb_routeCar.SelAll(true);

	Syn_to_listBox_routeCar();
}

void CMap::unsel_al_routes()
{
	m_ctrls.SelectAll("lb_routeCar", false);

	Syn_to_listBox_routeCar();
}

//void CMap::sel_routes_by_agent(int id_agent) {}

void CMap::edit_gr_sel_input_op()
{
	m_ctrls.Show("edit_gr_sel_input", false);

	char* p_text = m_ctrls.GetText("edit_gr_sel_input");//char sz_val[MAX_PATH+1];

	win_e::SListBoxItem* p_item;

	if (m_ctrls.GetSelItem("lb_selCars", &p_item))
	{
		if (strlen(p_text)) //m_ctrls.SendMes("edit_gr_sel_input", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val))
		{
			ESendMesMode eMode = ESMM_ONE;

			CChat& chat = gBookMarks.GetChat();

			chat.but_send_new_mes((char*)csz_chat_mes_type[ECMT_TEXT], eMode, (char*)p_item->name.c_str(), p_text);
		}
	}

}

void CMap::OnCmd(int id, int notify)
{
	SCtrl* p_ctrl;

	if (m_ctrls.Find(id, &p_ctrl))
	{
		char sz_val[MAX_PATH + 1];

		if (p_ctrl->name.size() == 0) { strcpy(sz_val, " "); }
		else
		{ strcpy(sz_val, p_ctrl->name.c_str()); }


		if (p_ctrl->name == "cb_out_to_video_wall") { m_ctrls.OpCheckbox("cb_out_to_video_wall"); } else					
		if (p_ctrl->name == "but_car_lag_lead")
		{
			int index;
			
			if (m_ctrls.GetSelIndex("combo_car_lag_lead", index))
			{
				if (index >= 0) { gDrawWnd.SetCarLagLeadView((ECarLagLeadView)index); }

				SelCarsToList(); //CallPaint();
			}
		}else

		/*if (p_ctrl->name == "combo_car_agent")
		{
			if (notify == CBN_SELCHANGE) {}
		}else

		if (p_ctrl->name == "cb_show_cars")
		{
			bool fCheck = gDrawWnd.OpDraw();

			m_ctrls.SetCheckbox("cb_show_cars", fCheck);
		}else*/

		if (p_ctrl->name == "combo_stop")
		{                                
			int index;
			if (m_ctrls.GetSelIndex("combo_stop", index))
			{
				gDrawWnd.SelectStop(index);                   //CP_OnCmd(id, notify);
			}
		}else

		if (p_ctrl->name == "cb_form_mes_re")
		{
			m_ctrls.OpCheckbox("cb_form_mes_re");
		}		
		else
		if (p_ctrl->name == "but_show_cars_sel_all") 
		{ 
			sel_al_routes();
		}
		else
		if (p_ctrl->name == "but_show_cars_desel_all") 
		{ 
			unsel_al_routes();
		}else
 	
		if (p_ctrl->name == "edit_gr_sel_input")
		{
			edit_gr_sel_input_op();
		}
		else

		if (p_ctrl->name == "menu_SendText")
		{
			bool fShow = true;
			bool fActive = true;

			m_ctrls.Show("edit_gr_sel_input", fShow, fActive);
		}		
		else
		if (p_ctrl->name == "menu_CallPhone")
		{
			win_e::SListBoxItem* p_item;

			if (m_ctrls.GetSelItem("lb_selCars", &p_item))
			{
				CChat& chat = gBookMarks.GetChat();
				
				chat.CallPhone((char*)p_item->param_1.c_str());
			}
		}

		else
		if (p_ctrl->name == "menu_SwitchToAddRoute")
		{
			win_e::SListBoxItem* p_item;

			if (m_ctrls.GetSelItem("lb_selCars", &p_item))
			{
				CChat& chat = gBookMarks.GetChat();

				CIniFile ini;

				if (ini.Get("c:\\transman\\transman.ini", "msg_to_driver_about_change_route", sz_val, MAX_PATH))
				{
					ESendMesMode eMode = ESMM_ONE;

					chat.but_send_new_mes((char*)csz_chat_mes_type[ECMT_TEXT], eMode, (char*)p_item->name.c_str(), sz_val);

					SDeviceATE_3* pCar = (SDeviceATE_3*)p_item->p_ptr_1;
					if (pCar)
					{
						g_count_ch_route++;
						
						LoadVisibleShapePoints(g_count_ch_route == 0 ? "_a-b" : "_a-b_option1", gDrawWnd.GetZoom());
					}

				}
			}
		}
		else
		if (p_ctrl->name == "but_cr_zone")
		{
			if (gDrawWnd.SetTool(EDWT_ZONE_POINT_NEW) == EDWT_ZONE_POINT_NEW)
			{
				//������ ������ ����  ���� ����� ���������  ����� �� ������				
				char* p_name = m_ctrls.GetText("edit_zone_new_name");//char sz_name[MAX_PATH + 1]; //m_ctrls.SendMes("edit_zone_new_name", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_name);//set_str(sz_name, MAX_PATH, ); //set_str(sz_name, MAX_PATH, edit_zone_new_name.m_text);

				if (gDrawWnd.ZoneNameExists(p_name))
				{
					gMesWnd.Mes("��� ���� ���� � ����� ������. ������� �����.");			

					gDrawWnd.SetTool(EDWT_NONE);
				}
				else
				{
					gDrawWnd.ZoneNewClear(p_name);

					m_ctrls.SendMes("but_cr_zone", WM_SETTEXT, (WPARAM)0, (LPARAM)"���������");

					gMesWnd.Mes("������� ����� ������ ���� �� ����� ��� �������� �����, ���� ��������");
				}
			}
			else
			{
				m_ctrls.SendMes("but_cr_zone", WM_SETTEXT, (WPARAM)0, (LPARAM)"������");
			}

		}
		else
		{
			CP_OnCmd(id, notify); //gControlPanelWnd.set_p_ctrls(&m_ctrls); gControlPanelWnd.WM__COMMAND(id, notify);
		}

		CallPaint();
		m_ctrls.Update();
	}
}

void CMap::WM__KEYDOWN(WPARAM wParam, LPARAM lParam)
{
	int vk = wParam;

	bool fPaint = false;

	if (m_ctrls.KeyDown(vk))
	{
		fPaint = true;
	}

	/*if (edit_zone_new_name.KeyDown(vk))
	{
		fPaint = true;		
	}*/

	if (fPaint)
	{
		CallPaint();
	}
}

void CMap::WM__CHAR(WPARAM wParam, LPARAM lParam)
{
	char vk = wParam;
}

void CMap::WM__MOUSEWHEEL(WPARAM wParam, LPARAM lParam)
{
	int v = wParam>>16;

	POINT pn = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
	
	//*In(POINT& pn)
}

/////////////////////////////////////////////////////
void CMap::SelCarsToList()
//
{
	int i = 0;
	SDeviceATE_3* pCar;
	
	m_ctrls.ClearList("lb_selCars");
	
	char sz_val[MAX_PATH + 1];
	char sz_name[MAX_PATH + 1];
	char param_1[MAX_PATH + 1];
		
	CDrawATE_3& cars = gDrawWnd.GetDrawATE_3();

	while (cars.NextVisiblePtr(i, &pCar))
	{
		
		if (pCar->user_name[0])
		{
			sprintf(sz_val, "������������: %s", pCar->user_name);
		}
		else
		{
			sprintf(sz_val, "����������: %s", pCar->name);
		}

		bool  fsel = false;
		
		strcpy(sz_name, pCar->user_name);
		strcpy(param_1, pCar->sip_name);
		
		m_ctrls.AddToList("lb_selCars", sz_val, fsel, 0, sz_name, param_1, pCar);
	}
	
}

void CMap::CP_OnCmd(int id, int notify)
{
 gControlPanelWnd.set_p_ctrls(&m_ctrls);

 gControlPanelWnd.WM__COMMAND(id, notify);
}

void CMap::CallPaint()
{
	if (!m_hwndParent) { return; }

	HDC hdc = GetDC(m_hwndParent);

	Paint(hdc);

	ReleaseDC(m_hwndParent, hdc);
}

void CMap::WM__LBUTTONDOWN_combo_car_agent(SCtrl* pCtrl)
{
	win_e::SListBox* p_list = (win_e::SListBox*)pCtrl->p_obj;

	if (p_list==0) { return; }
	
	int index = p_list->GetSelIndex(); //m_ctrls.SendMes("combo_car_agent", CB_GETCURSEL, 0, 0);

	if (index >= 0)
	{

		if (index == 0)
		{
			gDrawWnd.SetDraw(true);

			gDrawWnd.GetDrawATE_3().Set_id_agent(0);

			fill_list_show_route_car();

			sel_al_routes(); //������� ��� ��������  //if (m_ctrls.GetCheckbox("check_agent_bind")) {	}
		}
		else
			if (index == 1)
			{
				gDrawWnd.SetDraw(false);

				fill_list_show_route_car();

				unsel_al_routes(); //�������� ��� �������� //if (m_ctrls.GetCheckbox("check_agent_bind")) {}
			}
			else
			{
				gDrawWnd.SetDraw(true);

				int id_agent = m_id_agent_list[index - 2];

				gDrawWnd.GetDrawATE_3().Set_id_agent(id_agent);

				fill_list_show_route_car(id_agent);

				sel_al_routes(); //sel_routes_by_agent(id_agent); //������� �������� ������
			}
	}
}

void CMap::WM__LBUTTONDOWN(POINT& pn, HWND hwnd)
{
	bool fPaint = false;
	SCtrl* pCtrl;       //bool fNeedDrawBkGr; //bool fNeedDrawBkGr=false;

	if (m_ctrls.WM__LBUTTONDOWN(pn, hwnd, &pCtrl)) // , &fNeedDrawBkGr, fNeedDrawBkGr)) //edit_zone_new_name.CheckIn(pn);
	{                                     
		if (pCtrl->name == "lb_routeCar")
		{
			Syn_to_listBox_routeCar(); //if (lb_routeCar.Sel(pn)) {  } 
		}else
		if (pCtrl->name == "lb_carTypes")
		{
			win_e::SListBox* p = (win_e::SListBox*)pCtrl->p_obj;
			bool* pDrawCarTypes = gDrawWnd.GetDrawCarTypes();

			if (p && pDrawCarTypes)
			{
				for (int i = 0; i < (int)ECT_QUANTITY; i++)
				{ pDrawCarTypes[i] = p->list[i].f_select; }

   }
		}
		else
		if (pCtrl->name == "combo_car_agent")
		{
			WM__LBUTTONDOWN_combo_car_agent(pCtrl);
		}
		else
		if (pCtrl->name == "combo_zone")
		{
			int index = 0;

			if (m_ctrls.GetSelIndex("combo_zone", index))
			{
				gDrawWnd.SelectZone(index);
			}
		}		
		else
		if (pCtrl->name == "combo_stop")
		{
			int index = 0;

			if (m_ctrls.GetSelIndex("combo_stop", index))
			{
				gDrawWnd.SelectStop(index);
			}
		}

		fPaint = true;
	}                                              //else if (lb_selCars.Sel(pn)) {}


	if (fPaint)
	{                   
		CallPaint();
	}

	/*else
	if (lb_selCars.Sel(pn))
	{
		CallPaint();
	}*/
}

//////////////////////////////////////////////////////
void CMap::WM__RBUTTONDOWN(POINT& pn)
//
{
	win_e::SMonitors& mon = gMonitors;

	win_e::SListBoxItem* pItem; //bool fChState = false;bool fMove = false;
	bool fPaint = false;

	SCtrl *pCtrl;

	if (m_ctrls.WM__RBUTTONDOWN(pn, 0, &pCtrl, &pItem)) //if (lb_selCars.Sel(pn, fChState, &pItem, fMove))
	{
		if (pCtrl->name == "lb_selCars")
		{
			static bool fStart = false;
			if (fStart == false)
			{
				fStart = true;
				int id;
				SCtrl* p_ctrl;
				m_ctrls.AddMenuItemText("������� �����", &id, 0, &p_ctrl); p_ctrl->name = "menu_SendText";
				m_ctrls.AddMenuItemText("������ �� ��������", &id, 0, &p_ctrl);  p_ctrl->name = "menu_CallPhone";
				m_ctrls.AddMenuItemText("������������ �� ���. �������", &id, 0, &p_ctrl);  p_ctrl->name = "menu_SwitchToAddRoute";
			}

			POINT pn_menu = { mon.rc[1].left + pn.x,  pn.y };

			m_ctrls.TrackMenu(m_hwndParent, pn_menu);


			SDeviceATE_3* pCar = (SDeviceATE_3*)pItem->p_ptr_1;
			if (pCar)
			{
				LoadVisibleShapePoints(g_count_ch_route == 0 ? "_a-b" : "_a-b_option1", gDrawWnd.GetZoom());

				CDrawATE_3& cars = gDrawWnd.GetDrawATE_3();

				cars.UnSelAll();

				pCar->fSel = true;
			}
			fPaint = true;
		}//lb_selCars

	}
	
	if (fPaint)
	{ CallPaint(); }
}

void CMap::Syn_to_listBox_routeCar()
{
	bool fAll;
	
	CDrawATE_3& ate_3 = gDrawWnd.GetDrawATE_3();

	std::vector<long> list_index_sel;
	
	int q_sel = m_ctrls.GetCountSel("lb_routeCar", fAll, list_index_sel);
	
	gDrawWnd.SetDraw(q_sel != 0);
	
	if (q_sel)
	{		
		ate_3.list_enable_routes_clear();

		if (!fAll)
		{
			int q = list_index_sel.size();

			SRoute s_route;

			for (int i = 0; i < q; i++)
			{
				int index = list_index_sel[i];

				if (gDrawWnd.GetRoute(index, s_route))
				{					
					ate_3.list_enable_routes_add(s_route.id_picas_route);
				}
			}
		}
	}


}

void CMap::WM__MOUSEMOVE(POINT pn, WPARAM wParam)
{
	bool fLeft = wParam & MK_LBUTTON;

	if (fLeft)
	{
		bool fPaint = false;  //if (lb_routeCar.InScrollOp(pn)) { fPaint = true; } else//if (lb_carTypes.InScrollOp(pn)) { fPaint = true; } else //if (lb_selCars.InScrollOp(pn)) { fPaint = true; } else
		
		SCtrl *pCtrl;

		if (m_ctrls.WM__MOUSEMOVE(pn, &pCtrl)) 
		{ 
			/*win_e::SListBox* p_list = pCtrl->GetListBoxPointer();

			if (p_list)
			{
				const char* csz_file = "C:\\transman\\CMap_WM__MOUSEMOVE.txt";

				static bool fStart = false;
				if (fStart == false)
				{
					fStart = true;
					unlink(csz_file);
				}

				FILE *fo=0;
				fopen_s(&fo, csz_file, "ab");
				if (fo)
				{
					fprintf(fo,"ScrollMouseY:%d BarY:%d IndexView:%d\r\n", p_list->GetScrollMouseY(), p_list->GetBarY(), p_list->GetIndexView());
					fclose(fo);
				}
			}*/

			fPaint = true; 
		}

		if (fPaint)
		{ CallPaint(); }
	}
}

void CMap::WM__LBUTTONUP(POINT& pn, HWND hwnd)
{                                 //lb_carTypes.SetMove(false); //lb_selCars.SetMove(false);
	m_ctrls.WM__LBUTTONUP(pn, hwnd);
}

void CMap::PaintDevider(HDC hdc, int x)
{
	SBookMarksParams& bm_params = gBookMarks.GetParams();

	//<q1 ctrls devider r
	int y = bm_params.i_height + cl_chat_ident_from_top;
	int h = gMonitors.rc[1].bottom - cl_mes_wnd_h- 50;

	SelectObject(hdc, m_gdi_obj[EMGDIO_PEN_DEVIDER]);

	MoveToEx(hdc, x, y, 0); LineTo(hdc, x, y + h);
	//>q1
}

void CMap::Paint(HDC hdc, int i_mode)
{
	/*SelectObject(hdc, m_gdi_obj[i_mode == 0 ? EMGDIO_PEN_DEVIDER : ]);
	if ()
	{

	}*/

	m_ctrls.Draw(hdc); //m_ctrls.ListBox_Draw(hdc, lb_routeCar); //lb_routeCar.Draw(hdc, ); //lb_formMes.Draw(hdc); //m_bitmapCtrls.Draw(hdc); //m_ctrls.ListBox_Draw(hdc, lb_carTypes);//	m_ctrls.ListBox_Draw(hdc, lb_selCars);
	
	//win_e::SEdit::SDrawParam sEditParam; //sEditParam.height_font = ci_map_height_font; sEditParam.hfont = m_hfont_edit;              //edit_zone_new_name.Draw(hdc,  &sEditParam);

	//bool fShow = true; //Show(fShow);
}

void CMap::Update() { m_ctrls.Update(); }

void CMap::SelCombo(char *sz_combo, int  index)
{
	m_ctrls.SendMes(sz_combo, CB_SETCURSEL, (WPARAM)index, (LPARAM)0);

	int index_readed = m_ctrls.SendMes(sz_combo, CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

	if (index_readed != index)
	{
		gMesWnd.Mes("CMap::SelCombo. ������. �� ���������� ������ ����������� ������");
	}
}

void CMap::OnSelStopOnMap(int index_stop)
{	
	m_ctrls.SelByIndex("combo_stop", index_stop + 2);
	
	/*if (m_eCheckPoint == ECP_COMBO_STOP)
	{		
		  
	}
	else
	{
		if (m_pCtrlStop == 0) { return; }

		SStop* p_stop;

		bool fGet = gDrawWnd.GetStopPtr(index_stop, &p_stop);  //char sz_val[MAX_PATH + 1]; strcpy(sz_val, s_stop.stop_name.c_str());

		SendMessageA(m_pCtrlStop->hwnd, WM_SETTEXT, (WPARAM)0, (LPARAM)p_stop->stop_name.c_str());

		if (m_eCheckPoint == ECP_FROM) { m_p_stop_from = p_stop; } else
		if (m_eCheckPoint == ECP_TO) { m_p_stop_to = p_stop; }
	}*/

	/*HWND hwndFocused = gBookMarks.GetFocused();

	SCtrl* pCtrl;

	if (m_ctrls.FindByHWND(hwndFocused, &pCtrl) == false) { return; }

	char sz_val[MAX_PATH + 1];

	strcpy(sz_val, s_stop.stop_name.c_str());

	SendDlgItemMessage(m_hwndParent, pCtrl->id, WM_SETTEXT, (WPARAM)0, (LPARAM)sz_val); //SendMessage(hwndFocused, WM_SETTEXT, (WPARAM)0, (LPARAM)sz_val);
	*/
	/*HWND hwndFocus = GetFocus();

	SCtrl* pCtrl;

	if (m_ctrls.FindByHWND(hwndFocus, &pCtrl) == false) { return; }
	
	if (pCtrl->name== "combo_stop")
	{
		
	}
	else{}
	*/


	Update();
}

void CMap::WM__DRAWITEM(WPARAM wParam, LPARAM lParam)
{
	/*SCtrl* p_ctrl;
	
	int id = wParam;
	DRAWITEMSTRUCT* pdi = (DRAWITEMSTRUCT*)lParam;

	if (m_ctrls.Find(id, &p_ctrl))
	{
		if (p_ctrl->name == "static_stop") 
		{			
			p_ctrl->DrawStatic(pdi->hDC);
		}
	}

	m_ctrls.Update();
	*/
}