#include <memory.h>
#include "mouse_event.h"
#include <stdio.h>  
#include <stdlib.h>  

CMouseEvent::CMouseEvent() { } //m_fInit=false; memset(this, 0, sizeof(CMouseEvent)); m_fInit=true;


void CMouseEvent::Clear()
{
	memset(this, 0, sizeof(CMouseEvent));
}

void CMouseEvent::Read(time_t time_interval_event, time_t time_interval_no_event)
{
	//ClearEvent();

	POINT point;

	if (GetCursorPos(&point) == FALSE) { return; }
	
	if (m_fRead)
	{
		m_event = m_point.x != point.x || m_point.y != point.y;

		if (m_event)
		{
			m_lock_no_event = false;

			m_time_no_event = 0;

			time_t time = clock();

			if (m_time_event)
			{
				if (time - m_time_event >= time_interval_event) 
				{ m_event_interval = true; }
			}

			m_time_event = time;
		}
		else
		{
			m_time_event = 0;

			if (m_lock_no_event == false)
			{
				time_t time = clock();

				if (m_time_no_event)
				{
					if (time - m_time_no_event >= time_interval_no_event) { m_event_no_event = true; m_lock_no_event = true; }
				}

				m_time_no_event = time;
			}
		}
	}
	else
	{
		m_fRead = true;
	}

	m_point = point;
}

void CMouseEvent::ClearEvent()
{
	m_event = false;

	m_event_no_event = false;

	m_event_interval = false;
}

bool CMouseEvent::GetEvent() { return m_event; }

bool CMouseEvent::GetEventNoEvent() { return m_time_no_event; }

bool CMouseEvent::GetEventInterval() { return m_event_interval; }
