#include <memory.h>
#include "MnemoScheme.h"

#include "draw_data.h"
#include "main.h"
#include "BookMarks.h"

#include "MesWnd.h"

const char * csz_file_sql_query_LoadCheckPointEvents = "C:\\transman\\mnemo_scheme\\sql_query_LoadCheckPointEvents.txt";

void CMnemoScheme_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesWnd.Mes("CMnemoScheme. ������ MS SQL : %s", sz_text);
}

void CMnemoScheme_fill_by_sel_combo_route_add(void *p_param, FldsPtr fp)
{
	SMnemoCheckPointRows* p_this = (SMnemoCheckPointRows*)p_param;

	if (p_this) { p_this->add(fp);  }
}

void SMnemoCheckPointRows::add(FldsPtr fp)
{
	SMnemoCheckPointRow o;

	_bstr_t bstr_name(fp->Item["name"]->Value);

	o.name = (char*)bstr_name;

	o.i_order = fp->Item["i_order"]->Value.intVal;

	list.push_back(o);
}

void CMnemoScheme::fill_by_sel_combo_route()
{
	char sz_val[MAX_PATH + 1];

	const int ci_max = 1024;

	char sz_query[ci_max + 1];
	
	set_str(sz_query, MAX_PATH, "SELECT name, i_order FROM dbo.check_points WHERE id_picas_route="); 
	
	itoa(m_route.id_picas_route, sz_val, 10); 
	
	add_str(sz_query, MAX_PATH, sz_val);

	add_str(sz_query, MAX_PATH, " AND f_forward=1 ORDER BY i_order");

	m_list_check_point_AB.list.clear();

	bool fExec = MSSQL_Exec(sz_query, CMnemoScheme_fill_by_sel_combo_route_add, CMnemoScheme_FN_MSSQL_MES_ERR, &m_list_check_point_AB);
}

void CMnemoScheme::fill_by_sel_combo_route_BA()
{
	char sz_val[MAX_PATH + 1];

	const int ci_max = 1024;

	char sz_query[ci_max + 1]; 
	
	set_str(sz_query, MAX_PATH, "SELECT name, i_order FROM dbo.check_points WHERE id_picas_route="); 
	
	itoa(m_route.id_picas_route, sz_val, 10); 
	
	add_str(sz_query, MAX_PATH, sz_val);

	add_str(sz_query, MAX_PATH, " AND f_forward=0 ORDER BY i_order");

	m_list_check_point_BA.list.clear();

	bool fExec = MSSQL_Exec(sz_query, CMnemoScheme_fill_by_sel_combo_route_add, CMnemoScheme_FN_MSSQL_MES_ERR, &m_list_check_point_BA);
}



void CMnemoScheme_LoadCheckPointEventsFromDB_add(void *p_param, FldsPtr fp)
{
	SMnemoCars* p_this = (SMnemoCars*)p_param;

	if (p_this) { p_this->add(fp); }
}

void SMnemoCars::add(FldsPtr fp)
{
	SMnemoCar o;

	o.i_event = fp->Item["i_event"]->Value.intVal;
	_bstr_t bstr_garage_num(fp->Item["garage_num"]->Value); 	o.garage_num = (char*)bstr_garage_num;
	o.f_forward = fp->Item["f_forward"]->Value.boolVal == VARIANT_TRUE;	
	o.i_order = fp->Item["i_order"]->Value.intVal;
	o.id_ate_3 = fp->Item["id_ate_3"]->Value.intVal;
	_bstr_t bstr_stop_name(fp->Item["stop_name"]->Value); 	o.stop_name = (char*)bstr_stop_name;
	o.time_minutes = fp->Item["time_minutes"]->Value.intVal; //o.i_place_order = fp->Item["i_place_order"]->Value.intVal;

	list.push_back(o);
}

bool CMnemoScheme::LoadCheckPointEventsFromDB()
{
	char sz_val[MAX_PATH + 1]; //bool f_date = m_ctrls.GetCheckbox("combo_route");

	const int ci_max = 1024;

	char sz_query[ci_max + 1];
	
	set_str(sz_query, MAX_PATH, "EXEC dbo.P_get_mnemo_cars_b @id_picas_route="); 
	
	itoa(m_route.id_picas_route, sz_val, 10); 
	
	add_str(sz_query, MAX_PATH, sz_val);

	if (m_ctrls.GetCheckbox("check_rep_date"))
	{		
		if (m_ctrls.SendMes("dt_rep_date", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val) == 0) { gMesWnd.Mes("CMnemoScheme::LoadCheckPointEventsFromDB(). ������ ������ ����"); return false; }
		add_str(sz_query, MAX_PATH, ", @dt_max='");
		
		add_str(sz_query, MAX_PATH, sz_val);
		
		add_str(sz_query, MAX_PATH, "'");
	}

	//unlink(csz_file_sql_query_LoadCheckPointEvents); //static bool f_start = false; if (f_start == false) {  f_start = true; }

	FILE * fo = fopen(csz_file_sql_query_LoadCheckPointEvents, "wb");
	if (fo) { fprintf(fo,"%s\r\n", sz_query); fclose(fo); }

	m_mnemoCars.Clear();

	bool fRes = MSSQL_Exec(sz_query, CMnemoScheme_LoadCheckPointEventsFromDB_add, CMnemoScheme_FN_MSSQL_MES_ERR, &m_mnemoCars);

	if (fRes)
	{
		if (CalcPoints() == false) { m_mnemoCars.Clear(); }
	}
	return fRes;
}