//D:\users\yuil\JOB\EWES\CPP\transman\formula_point_to_latlng.cpp

	void ScreenPointToLatitudeLongitude(int xScr, int yScr, double zoom, double& lat, double& lng)
	{                                     //pointToLatLng: function (point, zoom) 
 	const double R = 6378137;

		double dScale = 256 * pow(2, zoom);  //untransformedPoint = this.transformation.untransform(point, scale); //untransform: function (point, scale) {
		
		if (dScale == 0) { dScale = 1; } //scale = scale || 1;
		
		double t_scale = 0.5 / (M_PI * R);

		double _a = t_scale;

		double _b = 0.5;

		double _c = -t_scale;

		double _d = 0.5;
		
		double xUntr = (xScr / dScale - _b) / _a;
		
		double yUntr = (yScr / dScale - _d) / _c);   //unproject: function (point) {
			
		double d = 180 / M_PI;

		lat = (2 * atan( exp(yUntr / R) ) - (M_PI / 2)) * d;			
			
		lng =	xUntr * d /R;	                         //return this.projection.unproject(untransformedPoint);
 
	}
