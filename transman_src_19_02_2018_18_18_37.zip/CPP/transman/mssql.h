#ifndef _MSSQL_h_
#define _MSSQL_h_

typedef enum { EMSSQLS_START = 0, EMSSQLS_CON, EMSSQLS_EXEC, EMSSQLS_READ } EMSSQLState;

#import "c:\\Program Files\\Common Files\\System\\ADO\\msado15.dll" \
        rename("EOF", "EndOfFile")

typedef ADODB::_RecordsetPtr  RecPtr;
typedef ADODB::_ConnectionPtr ConPtr;
typedef ADODB::_CommandPtr CmdPtr;
typedef ADODB::FieldPtr FldPtr;
typedef ADODB::FieldsPtr FldsPtr;

typedef void(*FN_MSSQL_ADD)(void *p_param, FldsPtr fp); //void Class_Function_ADD(void *p_param, FldsPtr fp) {	Class* p_this = (Class*)p_param; if (p_this) { p_this->Function_ADD(fp); } }
typedef void(*FN_MSSQL_END)(void *p_param);
typedef void(*FN_MSSQL_CON_STR)(void *p_param, char *sz_con);
typedef void(*FN_MSSQL_MES_ERR)(void *p_param, char *sz_text, EMSSQLState eState); //void Class_MSSQL_MES_ERR(void *p_param, char *sz_text){ gMesWnd.Mes("SDrawData_MSSQL_MES_ERR(). ������ MS SQL: %s", sz_text); }
/*void SDrawData_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesWnd.Mes("SDrawData_MSSQL_MES_ERR(). ������ MS SQL: %s", eState== EMSSQLS_START ? "��� �����. ��������� ����� ������� ����� 3 ���" : sz_text);

	if (eState == EMSSQLS_START) { Sleep(3000); DestroyExit();}
}

void CATE3Load_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
 gMesLog.Mes("CATE3Load:: ������ MSSQL : %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
}

*/

void OnException(_com_error &e, FN_MSSQL_MES_ERR fn_mes_err, void *p_param, EMSSQLState eState);
bool MSSQL_Exec(char *sz_cmd, FN_MSSQL_ADD fn_add, FN_MSSQL_MES_ERR fn_mes_err, void *p_param, char * sz_con_name = "ms_con", int *p_i_rec_aff = 0, bool f_query_in_err = false, FN_MSSQL_END fn_end = 0, FN_MSSQL_CON_STR fn_con_str=0);

_variant_t get_bstr(_variant_t& v);
_variant_t get_int(_variant_t& v);

#endif