#ifndef _map_timer_h_
#define _map_timer_h_
#include <vector>
#include "keyb.h" //#include "flags.h"
#include "PosSizeWnd.h"
#include "MapAddr.h"
#include "mouse_event.h"

struct SChieldWnd
{
	HWND hWnd;                                                    //wchar_t  wszChildWndType[MAX_PATH + 1];
	RECT rc;
	wchar_t  wszChildClassName[MAX_PATH + 1];
	wchar_t  wszChildWndText[MAX_PATH + 1];
	DWORD dClassStyle;
};

/*typedef enum
{
	EMTF_KEYBOARD_READED=0,
}EMapTimerFlag; */

class CMapTimer
{
	bool m_fNotFirst;

	int m_iCntClickLBut;

	HWND m_hWnd_Child;

	POINT m_MousePoint;	

	std::vector<SChieldWnd> m_ListChield;	
	
	CKeyb m_keyb;  /*CFlags m_cFlags; // YUIL �����. //BYTE m_baKey[ci_max];*/
	CPosSizeWnd m_posSizeWnd;
	CMapAddr m_MapAddr;
	CMouseEvent m_MouseEvent;
	
	int m_iCntEventMagnify;
	int m_iCntEventLatitude;
	int m_iCntEventLongitude;       //double  m_multiplerWidth;	double  m_multiplerHeight;

	void SetCaptionText();
	void AddTextWndFromPoint(wchar_t *wsz_text);
	void AddTextLocationURL(wchar_t *wsz_text);
	void AddCaptionText(wchar_t *wsz_text, wchar_t *wsz_title, int iVal); //void ReWidthWndByMult(HWND hwnd, double multipler); void ReHeightWndByMult(HWND hwnd, double multipler);
	
	public:
	CMapTimer();
	~CMapTimer();

	void Clear();
	bool Open();
	bool Close();
	void TimerFn();
	void CheckChildWnd(HWND hwnd);
	bool GetChildWndWithMouse(HWND hParent_hWnd);
	void Set_hWnd_Child(HWND hNew) { m_hWnd_Child = hNew; }
	void SetMousePoint(const POINT& pNew) { m_MousePoint= pNew; }
	
	void AddChield(const SChieldWnd& sNew);

	bool ConvertPointToClient(HWND hWnd, const POINT& pnScr, POINT& pnClient);
	void DrawOnPoint(HWND hWnd, const POINT& pn);
	
};

#endif