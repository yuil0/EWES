#ifndef _CFormMes_h_
#define _CFormMes_h_

#include <windows.h>
#include "..\\transman_srv\\std_str.h"
#include <vector>
#include "mssql.h"

const int ci_max_red_steps=5;

struct SFormMesRow
{
	std_string id_ate_3;
	std_string device_number;
	std_string stop_name_from;
	std_string stop_name_to;
	std_string time_cmd_minute_from;
	std_string time_cmd_minute_to;
	std_string id_picas_stop_from;
	std_string id_picas_stop_to;
	std_string state_num;
	std_string garage_num;
	/*long id_formalize_message;
	std_string dt_created;
	std_string route_short_name;
	std_string garage_num;
	std_string state_num; 
	std_string stop_name_from;
	*/
};

class CFormMes
{
	bool m_fInit;

	std::vector<SFormMesRow> m_list; //SMSSQLAgentRow m_row;

	long m_l_enabled_fill_list; //YUIL 2017-09-21 ���� ���������� ����������  

	void FillList();
	void Fill_ControlPanel_combo(); //void DelRow(int index);

	HPEN m_pen[ci_max_red_steps];
	HBRUSH m_brush[ci_max_red_steps];
	int m_i_red_step;

	void CrPenBrush();
	void DelPenBrush();
	void IncRedStep();
	void PaintOp(HWND hwnd, RECT rc);

public:
	CFormMes();
	~CFormMes();
	bool Open();
	void Close();
	
	void Exec();
	void Add(FldsPtr fp);
	bool GetNextRow(int& index, SFormMesRow* p_row); //char* GetRowLongText(int index, char *sz_buf);bool Send(int index);
	void Paint();
	std::vector<SFormMesRow>& GetList() { return m_list; }

	void Fill_ControlPanel_combo_device();
	void Fill_ControlPanel_combo_device_db();
	void Fill_ControlPanel_combo_device_db(FldsPtr fp);
};

extern CFormMes gFormMes;

#endif