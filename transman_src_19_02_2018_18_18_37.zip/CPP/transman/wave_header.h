#ifndef _wave_header_h
#define _wave_header_h_

#include <windows.h>

struct SWaveHeader
{
	char chunkId[4];

	DWORD chunkSize;

	char charformat[4];

	char subchunk1Id[4];

	DWORD subchunk1Size;

	WORD audioFormat;

	WORD numChannels;

	DWORD sampleRate;

	DWORD byteRate;

	WORD blockAlign;

	WORD bitsPerSample;

	char subchunk2Id[4];

	DWORD subchunk2Size;


};

#endif