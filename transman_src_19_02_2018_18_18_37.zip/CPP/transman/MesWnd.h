#ifndef _MesWnd_h_
#define _MesWnd_h_

#include "window.h"

#include "..\\util\\winctrl.h" //#include "mssql.h"
#include "win_e.h"

const int cl_mes_wnd_h = 100;

class CMesWnd
{
	typedef enum
	{
		//EC_LIST=0,
		EC_BUT_CLEAR=0,
		//
		EC_QUANTITY,
	}ECtrl;

	HWND m_hwnd[EC_QUANTITY]; //struct SCtrl{HWND hwnd;}; //SCtrl m_ctrls[EC_QUANTITY]; //std::vector<SCtrl> m_ctrls;

	bool m_fInit; //RECT m_rc; //bool m_f_expand; //long m_f_expand; //

	CWindow wnd; //HWND map_hwnd; HWND draw_hwnd; //bool m_event_size;

	HWND m_hwndDP;

	RECT m_rc;
	win_e::SListBox m_lb;	
	RECT m_rc_client;

	int m_ident;

	int m_but_size;
	win_e::SBorder m_border;

	int GetH(); 

	void SetFirst(SWindowCreateParam& wcp);  //void Expand();//void calc_edit_XYWH(int& x, int& y, int& w, int& h);

	void SetForI2(SWindowCreateParam& wcp);

	void ListClear();
	
	void Set_rc_childs();
	void Log(char *sz_new);
	public:
	CMesWnd();

	~CMesWnd();
	
	
	bool Create(HINSTANCE hInstance, wchar_t *wsz_app); // , HWND draw_hwnd_new);

	void Destroy();

	void WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam); 	
	void WM__COMMAND(WPARAM wParam, LPARAM lParam);
	void WM__MOUSEMOVE(WPARAM wParam, LPARAM lParam);
	void WM__MOUSEWHEEL(WPARAM wParam, LPARAM lParam);

	bool IsInit() { return m_fInit; }

	void CrControls(HINSTANCE hInstance);

	void Paint(HDC hdc);
	
	void OnChMap();

	CWindow& GetWindow() { return wnd; }

	HWND GetHWND() { return wnd.GetHWND(); }

	void Mes(char *szFormat, ...);
	void MesB(char *szFormat, ...);

	void ChShow() {wnd.ChShow();}
	void SetWnd_I2();

	void CallPaint();

};

extern CMesWnd gMesWnd;

#endif