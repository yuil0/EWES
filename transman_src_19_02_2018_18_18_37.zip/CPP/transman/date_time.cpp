//YUIL 2017 yuil@mail.ru

#include "date_time.h"
#include <stdio.h>  

namespace date_time
{
	bool SubtractDays(SDate& date, int nDays, void* p_param, SUBTRACT_DAY_FUNC func)
	{
		for (int i=0; i<nDays; i++)
		{
			if (func) { (func)(p_param, date); }
			
		 SubtractDay(date);						
		}	
		
	 return true;
	}
	
	bool IsHiYear(int year) //sample hi year : 2016
	{
		bool fHi = year%4==0;		
		
		if (!fHi)
		{
 		int d=year/100;
		
	 	bool fLastTwoNull = year == d*100;		
			
   if (fLastTwoNull) {fHi=true;}
		}
		
	 return fHi;
	}
	
	int GetMonthMaxDay(SDate& date)
	{
		int n;
		
		bool fHiYear = IsHiYear(date.year);
		
		switch (date.month)
		{
		 case 1: n=31;	break;
			case 2: n= fHiYear ? 29 : 28;	break;
		 case 3: n=31;	break;
			case 4: n=30;	break;
		 case 5: n=31;	break;
			case 6: n=30;	break;
		 case 7: n=31;	break;
			case 8: n=31;	break;
		 case 9: n=30;	break;
			case 10: n=31;	break;
		 case 11: n=30;	break;
			case 12: n=31;	break;
		}
		
		return n;
	}
	
	bool SubtractDay(SDate& date)
	{				
		if (date.day==1)
		{
			//cross month
			if (date.month==1)
			{
				//cross year
				date.month=12;	
				date.year--;
			}
			else
			{
			 date.month--;	
				date.day=GetMonthMaxDay(date);
			}			
		}
		else
		{
			date.day--;
		}		
		
  return true;	
	}
}