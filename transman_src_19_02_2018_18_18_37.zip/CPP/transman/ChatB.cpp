#include <memory.h>
#include "main.h"
#include "chat.h"
#include "MesWnd.h"

#include "BookMarks.h"
#include "login_wnd.h"

void CChat_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{ 
	gMesWnd.Mes("CChat. ������ MS SQL : %s", sz_text); 
}

//<disp
void CChat::CrNewDisp()
{
	char sz_val[MAX_PATH+1];

	std_string sz_name;

	std_string sz_psw;

	if (m_ctrls.SendMes("edit_new_disp_name", WM_GETTEXT,  (LPARAM)MAX_PATH, (WPARAM)sz_val)==0) 
	{gMesWnd.Mes("CChat. ������ ��������� ����� ����������"); return;}

	m_ctrls.SendMes("edit_new_disp_name", WM_SETTEXT,  (LPARAM)0, (WPARAM)"");

	sz_name=sz_val;

	if (m_ctrls.SendMes("edit_new_disp_psw", WM_GETTEXT,  (LPARAM)MAX_PATH, (WPARAM)sz_val)==0) {gMesWnd.Mes("CChat. ������ ��������� ������ ����������"); return;}

	m_ctrls.SendMes("edit_new_disp_psw", WM_SETTEXT,  (LPARAM)0, (WPARAM)"");

	sz_psw=sz_val;

 std_string sz_query = "EXEC dbo.P_add_user @user_name=N'"; sz_query.append(sz_name.c_str()); sz_query.append("', @password=N'"); sz_query.append(sz_psw.c_str()); sz_query.append("', @id_user_type=2");

	bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), 0, CChat_FN_MSSQL_MES_ERR, this);		

	if  (f_exec)
	{
		fill_combo_new_coll_disp();
	}else
	{ gMesWnd.Mes("CChat. ������ ������ � ��"); }
}

void CChat_fill_combo_new_coll_disp(void *p_param, FldsPtr fp)
{
	CChat* p_this=(CChat*)p_param;

	if (p_this) { p_this->fill_combo_new_coll_disp_add(fp); }
}

void CChat::fill_combo_new_coll_disp_add(FldsPtr fp)
{
	_bstr_t bstr_user_name(fp->Item["user_name"]->Value);
		
	std_string user_name=(char*)bstr_user_name;
	
	const char *p_name= user_name.c_str();

	m_ctrls.SendMes("combo_new_coll_disp", CB_ADDSTRING, (WPARAM)0,  (LPARAM)p_name);
	m_ctrls.SendMes("combo_bind_disp", CB_ADDSTRING, (WPARAM)0,  (LPARAM)p_name);	
	m_ctrls.SendMes("combo_show_disp", CB_ADDSTRING, (WPARAM)0,  (LPARAM)p_name);	
}

void CChat::fill_combo_new_coll_disp()
{
	m_ctrls.SendMes("combo_new_coll_disp", CB_RESETCONTENT, 0,  0);
	m_ctrls.SendMes("combo_bind_disp", CB_RESETCONTENT, 0,  0);
	m_ctrls.SendMes("combo_show_disp", CB_RESETCONTENT, 0,  0);
	
 std_string sz_query = "SELECT user_name FROM dbo.users WHERE id_user_type=2";

	bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), CChat_fill_combo_new_coll_disp, CChat_FN_MSSQL_MES_ERR, this);		

	if (f_exec)
	{
		m_ctrls.SendMes("combo_new_coll_disp", CB_SETCURSEL, 0,  0);
		//m_ctrls.SendMes("combo_bind_disp", CB_SETCURSEL, 0,  0); //�� ����� ���������� ���� ���������. ����� ������� ������������ ������.
		m_ctrls.SendMes("combo_show_disp", CB_SETCURSEL, 0,  0);
	}
}
//>disp

//<coll
void CChat_get_id_user_add(void *p_param, FldsPtr fp)
{
	CChat* p_this=(CChat*)p_param;

	if (p_this) { p_this->get_id_user_add(fp); }
}

void CChat::get_id_user_add(FldsPtr fp)
{
	_bstr_t bstr_id_user(fp->Item["id_user"]->Value);
		
	m_sz_id_user=(char*)bstr_id_user;
}

bool CChat::get_id_user(char *sz_val, std_string* p_id_user)
{
	m_sz_id_user.clear();

 std_string sz_query = "SELECT id_user FROM dbo.users WHERE user_name=N'"; sz_query.append(sz_val); sz_query.append("'");

	bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), CChat_get_id_user_add, CChat_FN_MSSQL_MES_ERR, this);		

	if (f_exec==false) {return false;}
	
	if (p_id_user) {*p_id_user=m_sz_id_user;}

	return m_sz_id_user.size()!=0;
}

void CChatCrNewColl_add(void *p_param, FldsPtr fp)
{
	CChat* p_this=(CChat*)p_param;

	if (p_this) { p_this->CrNewColl_add(fp); }
}

void CChat::CrNewColl_add(FldsPtr fp)
{
	_bstr_t bstr_id_user(fp->Item["id_user"]->Value);
		
	m_sz_id_user=(char*)bstr_id_user;
}

void CChat::CrNewColl()
{
	char sz_val[MAX_PATH+1];
	
	m_sz_id_user.clear();

	if (m_ctrls.SendMes("edit_new_coll_name", WM_GETTEXT,  (LPARAM)MAX_PATH, (WPARAM)sz_val)==0) {gMesWnd.Mes("CChat. ������ ��������� ����� ����������"); return;}

	m_ctrls.SendMes("edit_new_coll_name", WM_SETTEXT,  (LPARAM)0, (WPARAM)"");

	std_string sz_name=sz_val;

	if (m_ctrls.SendMes("edit_new_coll_psw", WM_GETTEXT,  (LPARAM)MAX_PATH, (WPARAM)sz_val)==0) {gMesWnd.Mes("CChat. ������ ��������� ������ ����������"); return;}

	m_ctrls.SendMes("edit_new_coll_psw", WM_SETTEXT,  (LPARAM)0, (WPARAM)"");

	std_string sz_psw=sz_val;
	
 std_string sz_query = "EXEC dbo.P_add_user @user_name=N'"; sz_query.append(sz_name.c_str()); sz_query.append("', @password=N'"); sz_query.append(sz_psw.c_str()); sz_query.append("', @id_user_type=3");

	bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), CChatCrNewColl_add, CChat_FN_MSSQL_MES_ERR, this);		

	if  (f_exec)
	{
		if (m_sz_id_user.size()==0) { gMesWnd.Mes("CChat. ������ ��������� id_user �� ��"); return; }

		std_string id_user_coll= m_sz_id_user;

		fill_combo_bind_coll();

		if (m_ctrls.SendMes("combo_new_coll_disp", WM_GETTEXT,  (LPARAM)MAX_PATH, (WPARAM)sz_val)==0) 
		{gMesWnd.Mes("CChat. ������ ��������� ����� ����������"); return;}

		if (get_id_user(sz_val))
		{			
			sz_query = "INSERT dbo.user_binds(id_user_one, id_user) SELECT "; sz_query.append(m_sz_id_user.c_str()); sz_query.append(", "); sz_query.append(id_user_coll.c_str()); 

			bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), 0, CChat_FN_MSSQL_MES_ERR, this);		

			if (f_exec==false) { gMesWnd.Mes("CChat. ������ ������������  ����� � �� "); }
		}
		else
		{ gMesWnd.Mes("CChat. �� ������ � ��  ��������� '%s'",  sz_val); }

	}else
	{ gMesWnd.Mes("CChat. ������ ������ � ��"); }
}

void CChat_fill_combo_bind_coll(void *p_param, FldsPtr fp)
{
	CChat* p_this=(CChat*)p_param;

	if (p_this) { p_this->fill_combo_bind_coll_add(fp); }
}

void CChat::fill_combo_bind_coll_add(FldsPtr fp)
{
	_bstr_t bstr_user_name(fp->Item["user_name"]->Value);
		
	std_string user_name=(char*)bstr_user_name;
	
	const char *p_name= user_name.c_str();

	m_ctrls.SendMes("combo_bind_coll", CB_ADDSTRING, (WPARAM)0,  (LPARAM)p_name);
}

void CChat::fill_combo_bind_coll()
{
	m_ctrls.SendMes("combo_bind_coll", CB_RESETCONTENT, 0,  0);
	
 std_string sz_query = "SELECT user_name FROM dbo.users WHERE id_user_type=3";

	bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), CChat_fill_combo_bind_coll, CChat_FN_MSSQL_MES_ERR, this);		

	if (f_exec)
	{
		//m_ctrls.SendMes("combo_bind_coll", CB_SETCURSEL, 0,  0); //�� ����� ���������� ���� ���������. ����� ������� ������������ ������.
		
	}
}
//>coll

bool CChat::get_id_user_by_combo(char *sz_combo, std_string& sz_user_id)
{
	 char sz_val[MAX_PATH+1];

		if (m_ctrls.SendMes(sz_combo, WM_GETTEXT,  (LPARAM)MAX_PATH, (WPARAM)sz_val)==0) {gMesWnd.Mes("CChat::get_id_user_by_combo(). ������ ��������� �� ������������ �� �������� %s", sz_combo); return false;}

		if (get_id_user(sz_val)==false) {return false;}

		sz_user_id= m_sz_id_user;

		return true;
}

//<bind
void CChat::Bind()
{
	std_string sz_user_id_one;
	std_string sz_user_id;

	if (get_id_user_by_combo("combo_bind_disp", sz_user_id_one)==false) {return;}
	if (get_id_user_by_combo("combo_bind_coll", sz_user_id)==false) {return;}

 std_string sz_query = "EXEC dbo.P_add_user_bind @id_user_one="; sz_query.append(sz_user_id_one.c_str()); sz_query.append(", @id_user="); sz_query.append(sz_user_id.c_str());

	bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), 0, CChat_FN_MSSQL_MES_ERR, this);		

}
//>bind

void CChat_fill_combo_show_coll_add(void *p_param, FldsPtr fp)
{
	CChat* p_this=(CChat*)p_param;

	if (p_this) { p_this->fill_combo_show_coll_add(fp); }
}

void CChat::fill_combo_show_coll_add(FldsPtr fp)
{
	_bstr_t bstr_user_name(fp->Item["user_name"]->Value);
		
	std_string user_name=(char*)bstr_user_name;
	
	const char *p_name= user_name.c_str();

	m_ctrls.SendMes("list_show_coll", LB_ADDSTRING, (WPARAM)0,  (LPARAM)p_name);
}

void CChat::fill_combo_show_coll()
{
	m_ctrls.SendMes("list_show_coll", LB_RESETCONTENT, 0,  0);
	
	std_string sz_id_user_disp;
	
	if (get_id_user_by_combo("combo_show_disp", sz_id_user_disp)==false) {return;}

 std_string sz_query = "SELECT user_name FROM dbo.users WHERE id_user_type=3 AND id_user in (SELECT id_user FROM dbo.user_binds WHERE id_user_one="; sz_query.append(sz_id_user_disp.c_str()); sz_query.append(")");

	bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), CChat_fill_combo_show_coll_add, CChat_FN_MSSQL_MES_ERR, this);		

	if (f_exec)
	{
		m_ctrls.SendMes("list_show_coll", LB_SETCURSEL, 0,  0); 
		m_ctrls.Update();
	}

}

//<a1
void CChat_fill_combo_coll_by_id_disp_add(void *p_param, FldsPtr fp)
{
	CChat* p_this=(CChat*)p_param;

	if (p_this) { p_this->fill_combo_coll_by_id_disp_add(fp); }
}

void CChat::fill_combo_coll_by_id_disp_add(FldsPtr fp)
{
	_bstr_t bstr_user_name(fp->Item["user_name"]->Value);
		
	std_string user_name=(char*)bstr_user_name;
	
	const char *p_name= user_name.c_str();
	
	char* p_combo = (char*)m_sz_combo.c_str(); //int q = m_ctrls.SendMes(p_combo, CB_GETCOUNT, (WPARAM)0, (LPARAM)0);//if (q == 0){m_ctrls.SendMes(p_combo, CB_ADDSTRING, (WPARAM)0, (LPARAM)"���");	}

	m_ctrls.SendMes(p_combo, CB_ADDSTRING, (WPARAM)0, (LPARAM)p_name);
}

void CChat::fill_combo_coll_by_id_disp(char* sz_combo_coll, std_string& id_disp)
{
	m_ctrls.SendMes(sz_combo_coll, CB_RESETCONTENT, 0,  0);
	
 std_string sz_query = "SELECT user_name FROM dbo.users WHERE id_user_type=3 AND id_user in (SELECT id_user FROM dbo.user_binds WHERE id_user_one="; sz_query.append(id_disp.c_str()); sz_query.append(")");

 m_sz_combo=sz_combo_coll;

	bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), CChat_fill_combo_coll_by_id_disp_add, CChat_FN_MSSQL_MES_ERR, this);		

	if (f_exec) {  m_ctrls.SendMes(sz_combo_coll, CB_SETCURSEL, 0,  0); }
}
//>a1

//<q3
void CChat::fill_combo_disp_coll()
{
	fill_combo_coll_by_id_disp("combo_disp_coll", gLoginWnd.GetIdUser());
}

void CChat::fill_combo_disp_templ_mes()
{
	m_ctrls.SendMes("combo_disp_templ_mes", CB_RESETCONTENT, 0,  0); 
	
	char sz_val[MAX_PATH+1];

	m_ctrls.SendMes("combo_disp_templ_mes", CB_ADDSTRING, 0, (LPARAM)"�� ������");

	for (int i=0; i<(int)ECMT_QUANTITY; i++)
	{
	 EChatMessageTemplate eTemplate=(EChatMessageTemplate)i;	 

	 if (eTemplate==ECMT_ROAD_CONDITION)
	 {
			strcpy(sz_val,"������ �������� ������� ?");
	 }else
	 if (eTemplate==ECMT_FASTER)
	 {
			strcpy(sz_val,"��������� ��������");
		}else
	 if (eTemplate==ECMT_LOWER)
		{			
			strcpy(sz_val,"��������� ��������");
		}
		m_ctrls.SendMes("combo_disp_templ_mes", CB_ADDSTRING, 0, (LPARAM)sz_val);
	}
 
	m_ctrls.SendMes("combo_disp_templ_mes", CB_SETCURSEL, 0,  0); 
}
//>q3

void CChat::set_edit_disp_mes_by_combo(char *sz_combo)
{
	int index= m_ctrls.SendMes(sz_combo, CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

	if  (index<1) {return;}

	char sz_val[MAX_PATH+1];

	if (m_ctrls.SendMes(sz_combo, WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val)==0) {return;}

	m_ctrls.SetText("edit_disp_mes", sz_val);

	CallPaint();

	m_ctrls.Update();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void CChat::but_send_new_mes(char *id_chat_mes_type, ESendMesMode eMode, char* sz_user_to, char* sz_message)
//
{
	char sz_val[MAX_PATH + 1];

	char sz_user_to_L[MAX_PATH+1] = { 0 };
	char sz_message_L[MAX_PATH + 1] = {0};
	
	const int ci_max = 1024;

	char sz_query[ci_max + 1] = "EXEC dbo.P_add_chat_mes @id_user_from="; 
	
	add_str(sz_query, ci_max, (char*)gLoginWnd.GetIdUser().c_str());
	
	if (eMode == ESMM_ONE)
	{ 
		std_string id_user;

		//�� ����
		if (sz_user_to == 0)
		{
			if (m_ctrls.SendMes("combo_disp_coll", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val) == 0) { gMesWnd.Mes("CChat. ������ ������ ����������"); return; } //����� ���

			set_str(sz_user_to_L, MAX_PATH,   sz_val);
		}
		else
		{
			set_str(sz_user_to_L, MAX_PATH, sz_user_to);
		}

		if (get_id_user(sz_user_to_L, &id_user) == false) { gMesWnd.Mes("CChat. ������ ����������� id_user ��� ������������ %s", sz_user_to_L); return; }

		add_str(sz_query, ci_max, ", @id_user_to="); 

		add_str(sz_query, ci_max, (char*)id_user.c_str());
	}
	
	if (eMode == ESMM_ALL)
	{ 
		add_str(sz_query, ci_max, ", @f_all=1"); 
	}

	add_str(sz_query, ci_max, ", @id_chat_mes_state=1, @id_chat_mes_type="); 
	
	add_str(sz_query, ci_max, id_chat_mes_type); 
	
	add_str(sz_query, ci_max, ", @mes=N'");
	
	bool f_type_1 = !stricmp(id_chat_mes_type, "1");
	bool f_type_5 = !stricmp(id_chat_mes_type, "5");

	if (f_type_1 || f_type_5) //����� ���������
	{
		if (sz_message == 0)
		{
			set_str(sz_message_L, MAX_PATH, m_ctrls.GetText("edit_disp_mes")); 			//if (.SendMes("edit_disp_mes", WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz_val) == 0) { gMesWnd.Mes("CChat. ������ ������ ��������� �� ����"); return; }
		}
		else
		{
			set_str(sz_message_L, MAX_PATH, sz_message);
		}

		add_str(sz_query, ci_max, sz_message_L);
	}

	add_str(sz_query, ci_max, "'");

	FILE *fo = fopen("C:\\transman\\chat\\SQL_query_send_mes.txt", "wb");
	if (fo) { fprintf(fo, "%s\r\n", sz_query); fclose(fo); }

	bool f_exec= MSSQL_Exec(sz_query, 0, CChat_FN_MSSQL_MES_ERR, this);

	if (f_exec==false) {  gMesWnd.Mes("CChat. ������ ������ ������ ��������� � ��"); }
	else
	{
		const int ci_max_mes_view = 50;

		if (strlen(sz_message_L) > ci_max_mes_view)
		{
			sz_message_L[ci_max_mes_view + 0] = '.';
			sz_message_L[ci_max_mes_view + 1] = '.';
			sz_message_L[ci_max_mes_view + 2] = 0;
		}
		gMesWnd.Mes("������������ %s ���������� ��������� %s", sz_user_to_L, sz_message_L);
	}

	m_ctrls.SetText("edit_disp_mes", ""); 

	CallPaint();
}

