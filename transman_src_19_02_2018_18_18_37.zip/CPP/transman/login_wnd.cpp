#include <memory.h>
#include "login_wnd.h"
#include "main.h"
#include "mes_wnd.h"
#include "MesWnd.h"
#include "ini_file.h"
#include "BookMarks.h"
#include "car_zone.h"  
#include "audio_device.h"

void CLoginWnd_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesWnd.Mes("CLoginWnd_MSSQL_MES_ERR(). ������ MS SQL: %s", sz_text);
}

CLoginWnd::CLoginWnd() {}

bool CLoginWnd::Open() //HINSTANCE hInstance)
{
	memset(this, 0, sizeof(CLoginWnd));
	
	m_fInit=true;

	CrThread();	

	return true;
}


DWORD WINAPI CLoginWnd_thread_proc(LPVOID lpThreadParameter)
{
	gLoginWnd.CrLoginWnd(); //gBookMarks.fill_list();	

	MSG msg;
	
	while (GetMessage(&msg, 0, 0, 0)) //gBookMarks.GetHWND()
	{	

		if  (msg.message==WM_KEYDOWN) 
		{
			gLoginWnd.WM__KEYDOWN(msg.hwnd, msg.wParam, msg.lParam);
		}

		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return 1;
}

void CLoginWnd::CrThread()
{                                                                     //InterlockedExchange((long*)&m_hInstance,  (long)hInstance);
	HANDLE h = CreateThread(0, 0, CLoginWnd_thread_proc, 0, 0, 0 );
}     

void CLoginWnd::Close()
{
}



void CLoginWnd::CrLoginWndControls()
{
	SWinCtrlParam wcp;
	wcp.Clear();
	wcp.hwndParent = wnd.GetHWND();
	wcp.wCtrl = 70;
	wcp.hCtrl = 22;
	wcp.ident = 5;
	wcp.xOrigin = 5;
	wcp.yOrigin = 5;

	m_ctrls.Init(wcp);

	SCtrl ctrl;

	ctrl.Clear();
	ctrl.name = "static_user";
	ctrl.classWnd = "static";
	ctrl.textWnd = "������������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "edit_user";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "���";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT;
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow();


	ctrl.Clear();
	ctrl.name = "static_password";
	ctrl.classWnd = "static";
	ctrl.textWnd = "������";
	ctrl.mul_w = 1.6;
	ctrl.styleAdd = SS_CENTER;
	m_ctrls.Add(ctrl);	

	ctrl.Clear();
	ctrl.name = "edit_password";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "12345";
	ctrl.styleAdd = WS_BORDER | ES_RIGHT | ES_PASSWORD;
	ctrl.mul_w = 2.4;
	m_ctrls.Add(ctrl);

	m_ctrls.NewRow();
	m_ctrls.NewRow();

	ctrl.Clear();
	ctrl.name = "edit_hint";
	ctrl.classWnd = "edit";
	ctrl.textWnd = "";
	ctrl.styleAdd = WS_BORDER | ES_LEFT | ES_READONLY;
	ctrl.mul_w = 4;
	m_ctrls.Add(ctrl);

	

	m_ctrls.AdjustParentWnd(wnd.GetHWND());

	m_ctrls.Update();	

	set_from_ini(); //m_ctrls.SetFocusActive();
}

void CLoginWnd::set_from_ini()
{
	CIniFile ini;

	char sz_val[MAX_PATH+1];

	if (ini.Get("C:\\transman\\transman.ini", "user_input", sz_val, MAX_PATH))
	{
		m_ctrls.SendMes("edit_user", WM_SETTEXT, 0, (LPARAM)sz_val);
		
		m_ctrls.SendMes("edit_password", WM_SETTEXT, 0, (LPARAM)0);
	}
}

void CLoginWnd::WM__CLOSE(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	DestroyExit();
}

void CLoginWnd::WM__DESTROY(WPARAM wParam, LPARAM lParam)
{
}


void CLoginWnd::WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam)
{
}

void CLoginWnd::WM__COMMAND(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	int notify= HIWORD(wParam);
	int id = LOWORD(wParam);
	HWND hwndChild = (HWND)lParam;

	SCtrl* p_ctrl;
	/*
	if (m_ctrls.Find(id, &p_ctrl))
	{
		
		if (p_ctrl->name == "edit_user")
		{
		}

	}	*/
}


void CLoginWnd::Tab()
{
	m_ctrls.NextFocusActive();
}

void CLoginWnd::WM__KEYDOWN(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	 int vk= wParam;

		if (vk==VK_RETURN) { ReadCtrls(); } else
		if (vk==VK_TAB) 
		{ 
			Tab(); 
		}else
		{}
}

void CLoginWnd::ReadCtrls()
{
	char sz_val[MAX_PATH+1];

	if (m_ctrls.SendMes("edit_user", WM_GETTEXT, (WPARAM)MAX_PATH,  (LPARAM)sz_val)) 
	{m_data.user=sz_val;}

	if (m_ctrls.SendMes("edit_password", WM_GETTEXT, (WPARAM)MAX_PATH,  (LPARAM)sz_val)) 
	{m_data.psw=sz_val;}

	if (m_data.user.size()==0)
	{
		//m_ctrls.SetFocus("edit_user", true);
	}else
	if (m_data.psw.size()==0)
	{
		//m_ctrls.SetFocus("edit_password", true);
	}else
	{
		Success();
		
	}
}

void CLoginWnd::Mes(char *szFormat, ...)
{	
	va_list va;

	va_start(va, szFormat);  //int len = _vscprintf(szFormat, va);

	char buf [MAX_PATH + 1];//len + strlen(g_szmapp)+ ci_time_len +2 if (buf == 0) { return; }

	memset(buf, 0, MAX_PATH + 1);

	vsprintf(buf, szFormat, va);

	m_ctrls.SendMes("edit_hint", WM_SETTEXT, (WPARAM)0,  (LPARAM)buf);
}

void CLoginWnd__FindUser_ADD(void *p_param, FldsPtr fp)
{
	CLoginWnd* p_this = (CLoginWnd*)p_param;

	if (p_this) {p_this->FindUserInDB_Add(fp);}
}

void CLoginWnd::FindUserInDB_Add(FldsPtr fp)
{
	m_eUserType= (EUserType)fp->Item["id_user_type"]->Value.intVal;

	_bstr_t bstr_id_user(fp->Item["id_user"]->Value);
	
	m_sz_id_user=(char*)bstr_id_user;

	/*VARIANT v_id_user= fp->Item["id_user"]->Value;

	m_id_user= v_id_user.decVal.Lo32/pow(10, v_id_user.decVal.scale);*/

	m_fFoundUserInDB=true;
}

bool CLoginWnd::FindUserInDB()
{
	m_fFoundUserInDB=false;

 std_string sz_query = "SELECT id_user_type, id_user FROM dbo.users WHERE user_name=N'"; sz_query.append(m_data.user.c_str()); sz_query.append("' AND password=HASHBYTES('SHA1', N'"); sz_query.append(m_data.psw.c_str()); sz_query.append("')");
		
	bool f_exec= MSSQL_Exec((char*)sz_query.c_str(), CLoginWnd__FindUser_ADD, CLoginWnd_FN_MSSQL_MES_ERR, this);		

	return m_fFoundUserInDB;
}

void CLoginWnd::Success()
{
	 const char * p_user=  m_data.user.c_str();

  CIniFile ini; 
		
		ini.Set("C:\\transman\\transman.ini", "user_input", (char*)p_user, strlen(p_user));

		bool fFindDB = FindUserInDB();

		if (fFindDB==false) {Mes("������������ �� ������", p_user); return;}

		if (!(m_eUserType==EUT_DISP_HI || m_eUserType==EUT_DISP)) {Mes("��� ������������ �� �������������", p_user); return;}

  wnd.Show(false);
		
		//<q1
		ShowLeftScr(SW_SHOW); //InitSec();
		ShowRightScr(SW_SHOW); //InitSec()

		bool fVisible = true;

		gDrawWnd.Create(g_hInstance, L"", gWndMain.GetHWND(), (HMENU)1, fVisible);

		gMapTimer.Open(); //gFormMes.Open();

		gBookMarks.Open();

		gAudioDevice.Open();

		gCarZone.Open();

		CWindow::MouseOp(g_hWndMap);
		//>q1

		CWindow::ClickLButton(g_hWndMap);
		CWindow::ClickKey(g_hWndMap, VK_F5);
		gMesWnd.CallPaint();
		
		ChLogicalScreen();
}

LRESULT CLoginWnd::MesOp(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_CLOSE: WM__CLOSE(hwnd, wParam, lParam); break;
	case WM_DESTROY: WM__DESTROY(wParam, lParam); break;
	case WM_LBUTTONDOWN: WM__LBUTTONDOWN(wParam, lParam); break;
 case WM_COMMAND: WM__COMMAND(hwnd, wParam, lParam); break;
	case WM_KEYDOWN: WM__KEYDOWN(hwnd, wParam, lParam); break;
		
	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK CLoginWnd_WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	return gLoginWnd.MesOp(gLoginWnd.GetHWND(), uMsg, wParam, lParam);
}

void CLoginWnd::CrLoginWnd() //YUIL 2017-11-02 . ���� �����
{
		//<q1 YUIL ��������� ����
	SWindowCreateParam wcp;

	wcp.hInstance = g_hInstance;	
	wcp.wndProc = CLoginWnd_WindowProc;
	wcp.fVisible = true;
	wcp.hWndParent= 0; //gLoginWnd.GetHWND();

	wcp.wsz_name = g_wz_name;
	wcp.w = 200; //sm.rc[1].right - sm.rc[1].left;
	wcp.h = 100; //sm.rc[1].bottom - sm.rc[1].top;
	wcp.fCalc_xy=true;
	wcp.dwStyleEx = WS_EX_TOPMOST;

	if (wnd.Create(wcp)==false) {MessageBox(0, L"������ �������� ���� �����", g_sz_app, MB_OK | MB_ICONERROR); return;}

	CrLoginWndControls();

	HWND hwndParent = wnd.GetHWND();

	win_e::RemoveWndStyle(hwndParent, WS_MAXIMIZEBOX | WS_MINIMIZEBOX);
	
	UpdateWindow(wnd.GetHWND());	

	CWindow::ClickLButton(hwndParent);

	/*SetFocus(hwndParent);

	RECT rc;

	GetWindowRect(hwndParent, &rc);

	SetWindowPos(hwndParent, HWND_TOP, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, SWP_SHOWWINDOW);*/
}

CLoginWnd gLoginWnd;