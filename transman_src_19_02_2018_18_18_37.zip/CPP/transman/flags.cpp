#include <memory.h>
#include "flags.h"

CFlags::CFlags(){}

void CFlags::Clear() { m_flags = 0; }

bool InIsValid(int iPos)
{
	int i_max_pos = sizeof(unsigned int) - 1;

	return iPos >= 0 && iPos <= i_max_pos;
}

void CFlags::SetFlag(int iPos, bool fNewVal)
{
	if (InIsValid(iPos)==false) { return; }

	bool f_true = m_flags &  (1 << iPos);

	if (f_true)
	{
		if (fNewVal) 
		{} //YUIL ��� �����  true
		else
		{ m_flags &=  ~(1 << iPos); }
	}
	else
	{
		if (fNewVal)
		{ m_flags |= 1 << iPos; } 
		else
		{} //YUIL ��� �����  false
	}
}

bool CFlags::GetFlag(int iPos)
{
	if (InIsValid(iPos) == false) { return false; }

	bool f_true = m_flags &  (1 << iPos);

	return f_true;
}