#include "win_e.h"
#include "math_e.h"
#include "ini_file.h" //#include "MesWnd.h"
#include "..\\transman_srv\\str.h"

#ifndef GWL_WNDPROC
#define GWL_WNDPROC         (-4)
#endif

namespace win_e
{
	HGDIOBJ g_penBrush[EPB_QUNATITY];

	void Mes(char* sz)
	{
		MessageBoxA(0, sz, "*", 0); //gMesWnd.Mes("SListBox(). ������ MS SQL: %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
	}

	void SListBox_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
	{
		char sz[MAX_PATH+1];

		sprintf_s(sz, MAX_PATH, "SListBox(). ������ MS SQL: %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
		
		Mes(sz); //gMesWnd.Mes("SListBox(). ������ MS SQL: %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
	}

	bool IsAlreadyRun(char *sz_class_name, char *sz_wnd_name)
	{
		HWND hwnd = FindWindowA(sz_class_name, sz_wnd_name);

		return hwnd != 0;
	}


	BOOL CALLBACK MonitorEnumProc(HMONITOR hMonitor, HDC hdcMonitor, LPRECT lprcMonitor, LPARAM dwData)
	{
		SMonitors* p=(SMonitors*)dwData;

		if (p) { p->Add(lprcMonitor); }

		return TRUE;
	}


 SMonitors::SMonitors() 
	{
		memset(this, 0 , sizeof(SMonitors));

		i_monitor = -1;

		BOOL f_enum_mon = EnumDisplayMonitors(NULL, 0, MonitorEnumProc, (LPARAM)this);

		if (f_enum_mon == TRUE)
		{
			if (q_monitor == 2)
			{
				if (rc[0].left > rc[1].left)
				{
					RECT c = rc[0]; rc[0] = rc[1]; rc[1] = c;
				}
			}

			ReadIni();
		}
	}

	void SMonitors::ReadIni()
	{
		CIniFile ini;
		
		char sz_val[MAX_PATH + 1];

		if (ini.Get("C:\\transman\\transman.ini", "index_monitor", sz_val, MAX_PATH))
		{
			int i_val = atoi(sz_val);

			if (i_val>=0) {i_monitor = i_val;}
		}
	}

	BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
	{
		S_MSWindows *p=(S_MSWindows*)lParam;
	
		if (p) {p->Add(hwnd);}

		return TRUE;
	}

	S_MSWindows::S_MSWindows() 
	{
		memset(this, 0 , sizeof(S_MSWindows));
		
		BOOL f_enum = EnumWindows(EnumWindowsProc, (LPARAM)this);
	}

	void ShowWndByClass(char *sz_class, bool f_show)
	{
		HWND hwnd= FindWindowA(sz_class,  0);
			
		if (hwnd) { ShowWindow(hwnd, f_show ? SW_SHOW : SW_HIDE); }
	}

	void ShowSysTray(bool f_show)
	{
		ShowWndByClass("Shell_TrayWnd", f_show);
		
		ShowWndByClass("Shell_SecondaryTrayWnd", f_show);		
	}

	void RemoveWndStyle(HWND hwnd, LONG lRemoveStyle)
	{
		LONG lStyle = GetWindowLong(hwnd, GWL_STYLE);

		lStyle &= ~lRemoveStyle;

		SetWindowLong(hwnd, GWL_STYLE, lStyle);
	}

	void AddWndStyle(HWND hwnd, LONG lAddStyle, bool fExt)
	{
		int iIndex = fExt == false ? GWL_STYLE : GWL_EXSTYLE;

		LONG lStyle = GetWindowLong(hwnd, iIndex);

		lStyle |= lAddStyle;

		SetWindowLong(hwnd, iIndex, lStyle);
	}

	void ChWndProc(HWND hwnd, WNDPROC procNew, WNDPROC* procPrev)
	{
				*procPrev  = (WNDPROC)GetWindowLong(hwnd, GWL_WNDPROC);				

				int i_res= SetWindowLong(hwnd, GWL_WNDPROC, (LONG)procNew);
	}

	bool DrawBitmap(HDC hdc, HBITMAP hbitmap, POINT& pn, POINT* pSize, POINT* pSizeCtrl, bool fStretch)
	{
		HDC hmem = CreateCompatibleDC(hdc);

		if (hmem == 0) { return false; }

		POINT size;
		
		if (pSize)
		{
			size = *pSize;
		}
		else
		{
			BITMAP bitmap;

			int iRes = GetObjectA((HBITMAP)hbitmap, sizeof(hbitmap), &bitmap);

			if (iRes == 0) { return false; }

			size.y = bitmap.bmWidth;

			size.y = bitmap.bmHeight;
		}

		SelectObject(hmem, hbitmap);

		BOOL fRes; 
		
		if (fStretch && pSizeCtrl)
		{
			fRes = StretchBlt(hdc, pn.x, pn.y, pSizeCtrl->x, pSizeCtrl->y, hmem, 0, 0, size.x, size.y, SRCCOPY);
		}
		else
		{
			fRes = BitBlt(hdc, pn.x, pn.y, size.x, size.y, hmem, 0, 0, SRCCOPY);
		}

		DeleteDC(hmem);

		return fRes == TRUE;
	}

	bool GetBitmapSize(HBITMAP hbitmap, POINT& size)
	{
		BITMAP bitmap;

		int iRes = GetObjectA((HBITMAP)hbitmap, sizeof(hbitmap), &bitmap);

		if (iRes == 0) { return false; }

		size.x = bitmap.bmWidth;
		size.y = bitmap.bmHeight;

		return true;
	}

	void CreatePenBrush()
	{
		g_penBrush[EPB_PEN_WHITE] = CreatePen(PS_SOLID, 0, 0xFFFFFF);
		g_penBrush[EPB_PEN_GRAY_DD] = CreatePen(PS_SOLID, 0, 0xDDDDDD);
		g_penBrush[EPB_PEN_GRAY_E0] = CreatePen(PS_SOLID, 0, 0xE0E0E0);
		g_penBrush[EPB_PEN_GRAY_CC] = CreatePen(PS_SOLID, 0, 0xCCCCCC);
		g_penBrush[EPB_PEN_GRAY_EE] = CreatePen(PS_SOLID, 0, 0xEEEEEE);
		g_penBrush[EPB_PEN_GRAY_55] = CreatePen(PS_SOLID, 0, 0x555555);

		g_penBrush[EPB_PEN_GRAY_55_W2] = CreatePen(PS_SOLID, 2, 0x555555);
		g_penBrush[EPB_PEN_GRAY_E0_W2] = CreatePen(PS_SOLID, 2, 0xE0E0E0);

		g_penBrush[EPB_BRUSH_WHITE] = CreateSolidBrush(0xFFFFFF);
		g_penBrush[EPB_BRUSH_GRAY_CC] = CreateSolidBrush(0xCCCCCC);
		g_penBrush[EPB_BRUSH_GRAY_E0] = CreateSolidBrush(0xE0E0E0);
	}

	void DestroyPenBrush()
	{
		for (int i = 0; i < (int)EPB_QUNATITY; i++) { DeleteObject(g_penBrush[i]); }
	}

	////////////////////////////////////////////////////////////////
	bool SRowButtons::Open(char *sz_name_template_new, RECT& rc_new, int i_ident_betw_new, int quantity_new, int index_sel_new)
 //
	{
		memset(this, 0, sizeof(SRowButtons));
		
		rc = rc_new;

		sz_name_template = sz_name_template_new;

		i_ident_betw = i_ident_betw_new;
		quantity = quantity_new;
		index_sel = index_sel_new;

		int w = rc.right - rc.left;
		size_but = w / quantity;

		fInit=true;

		return fInit;
	}

	void SRowButtons::Close()
	{
	}

	void SRowButtons_FN_DRAW(void* p_param,   HDC hdc)
	{
		SRowButtons* p_this = (SRowButtons*)p_param;

		if (p_this && p_this!=nullptr)
		{ p_this->DrawA(hdc); }
	}


	void SRowButtons::Draw(HDC hdc, SGroundPenBrush* p_gpb)
	{
		if (fInit == false) { return; }
		if (m_f_hide) { return; }
		

		int w = rc.right - rc.left;
		int h = rc.bottom - rc.top;

		HDC hMem = CreateCompatibleDC(hdc);
		HBITMAP memBM = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hMem, memBM);

		if (!p_gpb)
		{
			SelectObject(hMem, g_penBrush[EPB_PEN_WHITE]);
			SelectObject(hMem, g_penBrush[EPB_BRUSH_WHITE]);
		}
		else
		{
			SelectObject(hMem, p_gpb->hpen);
			SelectObject(hMem, p_gpb->hbrush);
		}

		Rectangle(hMem, 0, 0, w, h);

		DrawA(hMem);

		BitBlt(hdc, rc.left, rc.top, w, h, hMem, 0, 0, SRCCOPY);

		DeleteObject(memBM);
		DeleteObject(hMem);
	}

	void SRowButtons::DrawA(HDC hdc)
	{
		POINT start = {0, 0}; // { rc.left, rc.top };

		int h = rc.bottom - rc.top; //POINT size_but = { w / quantity - i_ident_betw, h };

		for (int i = 0; i < quantity; i++)
		{
			POINT pn = { start.x + i*size_but, start.y };
			
			DrawOp(hdc, pn, size_but, h, i== index_sel, i);
		}
	}

	void SRowButtons::DrawOp(HDC hdc, POINT& pn, int size_but, int h, bool fSel, int index)
	{
		SelectObject(hdc, g_penBrush[fSel ? EPB_PEN_GRAY_E0 : EPB_PEN_WHITE]);
		SelectObject(hdc, g_penBrush[fSel ? EPB_BRUSH_GRAY_E0 : EPB_BRUSH_WHITE]);
		Rectangle(hdc, pn.x + 2, pn.y + 2, pn.x + size_but - i_ident_betw - 2, pn.y + h - 2);

		//<
		SelectObject(hdc, g_penBrush[fSel ? EPB_PEN_GRAY_55_W2 : EPB_PEN_GRAY_E0_W2]);
		MoveToEx(hdc, pn.x, pn.y + h, 0); LineTo(hdc, pn.x, pn.y); LineTo(hdc, pn.x + size_but - i_ident_betw, pn.y);

		SelectObject(hdc, g_penBrush[fSel ? EPB_PEN_GRAY_E0_W2 : EPB_PEN_GRAY_55_W2]);
		LineTo(hdc, pn.x + size_but - i_ident_betw, pn.y + h); LineTo(hdc, pn.x, pn.y + h);
		//>

		/*//<
		int s = 1;
		SelectObject(hdc, penBrush[fSel ? EPB_PEN_GRAY_55 : EPB_PEN_GRAY_E0]);
		MoveToEx(hdc, pn.x + s, pn.y + h - s, 0); LineTo(hdc, pn.x + s, pn.y + s); LineTo(hdc, pn.x + size_but - i_ident_betw - s, pn.y + s);

		SelectObject(hdc, penBrush[fSel ? EPB_PEN_GRAY_E0 : EPB_PEN_GRAY_55]);
		LineTo(hdc, pn.x + size_but - i_ident_betw, pn.y + h); LineTo(hdc, pn.x, pn.y + h);
		//>*/

		char sz_val[MAX_PATH + 1]; //std_string sz_text= sz_name_template; 
		sprintf_s(sz_val, MAX_PATH, "%s%d", sz_name_template.c_str(), index+1);

		int len_text = strlen(sz_val);
		POINT char_size = {12, 18};
		POINT text_size = { len_text*char_size.x, char_size.y };
		POINT pnText = { pn.x + (size_but - text_size.x) / 2, pn.y + (h - text_size.y) / 2, };
		
		SetBkMode(hdc, TRANSPARENT); //SetTextColor(hdc, fSel ? 0xFFFFFF: 0);
		TextOutA(hdc, pnText.x, pnText.y, sz_val, len_text);
	}

	bool SRowButtons::Sel(POINT& pn)
	{
		if (pn.y < rc.top || pn.y > rc.bottom) { return false; }
		if (pn.x < rc.left || pn.x > rc.right) { return false; }

		index_sel = (pn.x - rc.left) / size_but; //bool f_in = math_e::inRectInt(pn.x, pn.y, x - c_draw_radius, y - c_draw_radius, x + c_draw_radius, y + c_draw_radius);
		return true;
	}

	void DrawGroupBox(HDC hdc, int x,	int y, int w, int h, char *sz_text,  int h_caption)
	{
		int L = 4;
		MoveToEx(hdc, x + L, y, NULL); LineTo(hdc, x + w - L, y);
		LineTo(hdc, x + w, y + L); 
		LineTo(hdc, x + w, y + h - L);
		LineTo(hdc, x + w - L, y + h);
		LineTo(hdc, x + L, y + h); 
		LineTo(hdc, x, y + h - L);
		LineTo(hdc, x, y + L);
		LineTo(hdc, x + L, y);

		SetBkMode(hdc, TRANSPARENT);

		int len_text = strlen(sz_text); /*POINT char_size = { 16,  22 };POINT text_size = { len_text*char_size.x,  char_size.y };*/
		POINT text_ident = { 10,  4 };
		POINT text_pos= { x + text_ident.x,  y + text_ident.y };
		TextOutA(hdc, text_pos.x, text_pos.y, sz_text, len_text);

		MoveToEx(hdc, x, y+ h_caption, NULL); LineTo(hdc, x + w, y+ h_caption);
		
	}

	SListBoxItem::SListBoxItem()
	{
		memset(this, 0, sizeof(SListBoxItem));
	}

	////////////////////////////////////////////////
	bool SListBox::Open(RECT& rc_new, int h_element_new, char* sz_sql_query_to_fill, bool f_text_only, bool f_no_draw) //, bool f_bitmap_interface)
	//
	{
		memset(this, 0, sizeof(SListBox)); //m_f_bitmap_interface = f_bitmap_interface;
		
		m_f_need_redraw = true;

		m_sel_index = -1;

		m_f_text_only = f_text_only;

		m_f_no_draw = f_no_draw;

		h_element = h_element_new;

		if (h_element < 1) { return false; }

		rc = rc_new;
			
		h = rc.bottom - rc.top; //POINT size_but = { w / quantity - i_ident_betw, h };

		q_view = h / h_element;

		m_bar_y = h_element; //rel top

		fInit = true;

		ExecSQL_query(sz_sql_query_to_fill);

		return fInit;
	}

	void SListBox::Close()
	{

		list.clear();
	}

	void SListBox_add(void *p_param, FldsPtr fp)
	{
		SListBox *p_this = (SListBox *)p_param;

		if (p_this) { p_this->add(fp); }
	}

	void SListBox::add(FldsPtr fp)
	{
		_bstr_t bstr_id(fp->Item["id"]->Value);
		_bstr_t bstr_name(fp->Item["name"]->Value);

		SListBoxItem o;

		o.sz_text = (char*)bstr_name;
		o.f_select = true;
		o.id = (char*)bstr_id;

		list.push_back(o);
	}

	void SListBoxItem::operator=(const SListBoxItem& p)
	{
		memcpy(this, &p, sizeof(SListBoxItem));
	}

	void SListBox::Add(char* sz_new, bool f_select, char* id_new, char* name_new, char *param_1_new, void* p_ptr_1_new)
	{
		SListBoxItem o;

		o.sz_text = sz_new;
		o.f_select = f_select;
		o.id = id_new;
		o.name = name_new;
		o.param_1 = param_1_new;
		o.p_ptr_1 = p_ptr_1_new;

		list.push_back(o);

		/*
		bool fToBack = true;

		if (m_f_back_order)
		{
			if (list.size())
			{
				fToBack = false;
			}
		}

		if (fToBack)
		{}
		else
		{
			//int q = list.size();

			//list.reserve(q + 1);

			std::vector<SListBoxItem>::iterator it= list.begin();

			list.insert(it, 1, o);
		}
		*/
	}

	void SListBox::ExecSQL_query(char* sz_query)
	{
		if (sz_query == 0) { return; }
		if (strlen(sz_query) == 0) { return; }

		bool f_exec = MSSQL_Exec(sz_query, SListBox_add, SListBox_FN_MSSQL_MES_ERR, this);
		
		if (f_exec == false)
		{
			Mes("SListBox::ExecSQL_query(). ������ SQL �������.");
		}
	}

	void SListBox::DrawCaption(HDC hdc, int i_height_font, HFONT hfont, int ident)
	{
		if (IsCaption() == false) { return; }

		DrawDevideStrInList(hdc, i_height_font, hfont, ident, sz_caption, listWidth, h_element, 0, rc.right - rc.left - h_element);

		/*char *p_pos = (char*)sz_caption.c_str();
		char *p_posSub;

		int index_col = 0;
		int sum_width_col = 0;
		while (NextSubStr(&p_pos, &p_posSub))
		{
			int width_col = listWidth[index_col];

			SDrawTextParam  tp;
			tp.hfont = hfont;
			tp.height_font = i_height_font;
			tp.p_text = p_posSub;
			tp.len_text = strlen(p_posSub);
			tp.ident = ident;
			tp.x = sum_width_col;
			tp.y = ident;
			tp.w = width_col;// rc.right - rc.left - h_element;
			tp.h = h_element;
			Draw_Text(hdc, tp);

			sum_width_col += width_col;
			index_col++;
		}*/

	}

	void DrawDevideStrInList(HDC hdc, int i_height_font, HFONT hfont, int ident, std_string& sz, std::vector<int>& list_width, int h_element, int indexItem, int max_x)
	{
		char *p_pos = (char*)sz.c_str();
		char *p_posSub;

		int qw = list_width.size();

		int index_col = 0;
		int sum_width_col = 0;
		
		char szSub[MAX_PATH + 1];
		char cDevider = '#';

		while (NextSubStr(&p_pos, cDevider, szSub))
		{
			int width_col = index_col < qw ? list_width[index_col] : max_x - sum_width_col;

			SDrawTextParam  tp;
			tp.hfont = hfont;
			tp.height_font = i_height_font;
			tp.p_text = szSub;
			tp.len_text = strlen(szSub);
			tp.ident = ident;
			tp.x = sum_width_col;
			tp.y = ident + indexItem * h_element;
			tp.w = width_col; 
			tp.h = h_element;
			Draw_Text(hdc, tp);

			sum_width_col += width_col;
			index_col++;
		}
	}

	void SListBox::DrawGrid(HDC hdc, int ident)
	{
		if (IsCaption() == false) {return;	}

		int qw = listWidth.size();
		
		int sum_width_col = 0;

		SelectObject(hdc, (HPEN)g_penBrush[EPB_PEN_GRAY_55]);

		for (int i=0; i<qw; i++)
		{
			int width_col = listWidth[i];

			sum_width_col += width_col;

			MoveToEx(hdc, sum_width_col, 0, 0); LineTo(hdc, sum_width_col, h);
		}

		MoveToEx(hdc, 0, h_element, 0); LineTo(hdc, rc.right - rc.left, h_element);
	}

	void SListBox::DrawBkGrItem(HDC hdc, EPenBrush ePen, EPenBrush eBrush, int y)
	{
		SelectObject(hdc, (HPEN)g_penBrush[ePen]);
		SelectObject(hdc, (HBRUSH)g_penBrush[eBrush]);
		Rectangle(hdc, 2, y, rc.right - rc.left - 2 - h_element, y + h_element);
	}

	void SListBox::DrawBkGrItem_sel(HDC hdc, int y)
	{
		DrawBkGrItem(hdc, EPB_PEN_GRAY_CC, EPB_BRUSH_GRAY_CC, y);
	}

	void SListBox::DrawA(HDC hdc, int i_height_font, HFONT hfont, HBITMAP hbitmapOn, HBITMAP hbitmapOff)
	{
		POINT start = { 0, 0 }; // { rc.left, rc.top };

		int ident = 4; //int x = rc.left + ident;int y = rc.top + ident;//MoveToEx(hdc, 10, y, NULL); LineTo(hdc, x + h, y); //int n;int step_y = get_step_y(n);
		
		bool fCaption = IsCaption();

		DrawCaption(hdc, i_height_font, hfont, ident);
		
		int q = list.size();
		
		int k = fCaption ? 1 : 0;

		for (int i = index_view, p2=0; i < q && k < q_view; i++, k++) //*q_view
		{
			SListBoxItem o = list.at(m_f_back_order ? q - 1 - i : i); //try{ 			}catch (...){ break; }

			int x = ident;

			int y = h_element * k + ident;

			int w = rc.right - rc.left - 2 * ident;
			
			bool fBkGr = fCaption == false && m_sel_index == i;

			if (fBkGr) //selection 
			{ DrawBkGrItem_sel(hdc, y); }
			
		 SelectObject(hdc, (HPEN)g_penBrush[EPB_PEN_GRAY_55]); 

			if (fCaption == false)
			{
				DrawCheckBox(hdc, i_height_font, hfont, x, y, w, h_element, (char*)o.sz_text.c_str(), m_f_one_sel ? i == m_sel_index : o.f_select, m_f_text_only, hbitmapOn, hbitmapOff); //DrawOp(hdc, pn, size_but, h, i == index_sel, i);
			}
			else
			{
				if (p2 == 1)
				{ DrawBkGrItem_sel(hdc, y); p2 = 0; }
				else
				{ p2=1; }
				

				DrawDevideStrInList(hdc, i_height_font, hfont, ident, o.sz_text, listWidth, h_element, k, rc.right - rc.left - h_element);
			}
		}

		DrawGrid(hdc, ident);

	}
	
	void SListBox::Draw(HDC hdc, int i_height_font, HFONT hfont, HBITMAP hbitmapOn, HBITMAP hbitmapOff)
	{
		if (fInit == false) { return; }
		if (m_f_no_draw) { return; }
		
		if (m_f_need_redraw == false) { return; }

		int w = rc.right - rc.left;
		int h = rc.bottom - rc.top;

		HDC hMem = CreateCompatibleDC(hdc);
		HBITMAP memBM = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hMem, memBM);

		SelectObject(hMem, g_penBrush[EPB_PEN_GRAY_55]);
		SelectObject(hMem, g_penBrush[EPB_BRUSH_WHITE]);
		Rectangle(hMem, 0, 0, w, h);
		
		DrawScroll(hMem);

		DrawA(hMem, i_height_font, hfont, hbitmapOn, hbitmapOff);

		MoveToEx(hMem, 0, h, 0); LineTo(hMem, w, h); //bottom line

		BitBlt(hdc, rc.left, rc.top, w, h, hMem, 0, 0, SRCCOPY);

		DeleteObject(memBM);
		DeleteObject(hMem);
	}

	/*float SListBox::get_step_y(int& n)
	{
		if (q_view <= 0) { return 0; }
		int q = list.size();
		n = q / q_view; //windows's
		if (q_view != q) { n++; }
		return ((float)(h - h_element)) / ((float)n);
	}*/

	void SListBox::DrawBar(HDC hdc)
	{
		int w = rc.right-rc.left;

		MoveToEx(hdc, w - h_element, m_bar_y - h_element, NULL);
		LineTo(hdc, w, m_bar_y - h_element);
		LineTo(hdc, w, m_bar_y);
		LineTo(hdc, w - h_element, m_bar_y);
		LineTo(hdc, w - h_element, m_bar_y - h_element);

		//2.2 ��� ������ ����
		int s = 1;
		SelectObject(hdc, (HPEN)g_penBrush[EPB_PEN_GRAY_E0]);
		MoveToEx(hdc, w - h_element + s, m_bar_y - s, NULL);
		LineTo(hdc, w - h_element + s, m_bar_y - h_element + s);
		LineTo(hdc, w - s, m_bar_y - h_element + s);

		//2.3 ��� ������ ���		
		SelectObject(hdc, (HPEN)g_penBrush[EPB_PEN_GRAY_CC]);
		MoveToEx(hdc, w - h_element + s, m_bar_y - s, NULL);
		LineTo(hdc, w - s, m_bar_y - s);
		LineTo(hdc, w - s, m_bar_y - h_element + s);

		SelectObject(hdc, (HBRUSH)g_penBrush[EPB_BRUSH_GRAY_E0]);
		s = 2;
		Rectangle(hdc, w - h_element + s, m_bar_y - h_element + s, w - s, m_bar_y - s);
	}

	void SListBox::DrawScroll(HDC hdc)
	{
		if (m_f_no_scroll) { return; }

		SelectObject(hdc, (HPEN)g_penBrush[EPB_PEN_GRAY_55]);

		int w = rc.right - rc.left;

		//1.vertic line
		MoveToEx(hdc, w - h_element, 0, NULL);
		LineTo(hdc, w - h_element, h);

		//2.bar //int n;float step_y = get_step_y(n); //int y = m_pn.y- h_element/2; // index_view * step_y;
		DrawBar(hdc);
	}

	void SListBox::ScrollOp(POINT& pn)
	{
		if (m_f_no_scroll) { return; }
		if (m_f_move == 0) { return; }
		if (pn.y==0) { return; }

		m_scroll_mouse_y = (int)pn.y;

		m_bar_y = (int)pn.y - (int)rc.top + h_element / 2;

		int min_bar_y = h_element;
		
		if (IsCaption()) { min_bar_y += h_element; }

		if (m_bar_y <= min_bar_y)
		{ 
			m_bar_y = min_bar_y;

			index_view = 0;
		}
		else
		{
			if (m_bar_y > h - 1) { m_bar_y = h - 1; }

			int q = list.size();

			if (q <= 0) { return; }

			float decrement = h - min_bar_y;

			if (decrement == 0) { return; }

			int index_view_new = (q - 1) * (m_bar_y - min_bar_y) / decrement; //m_pn_start = pn;

			if (index_view_new >= q) { index_view_new = q - 1; }
			else
				if (index_view_new < 0) { index_view_new = 0; }

			index_view = index_view_new;
		}

		m_f_need_redraw = true;
	}

	bool SListBox::InScrollOp(POINT& pn)
	{
		if (m_f_no_draw) { return false; }		

		if (!(pn.y >= rc.top && pn.y <= rc.bottom && pn.x >= rc.right - 2*h_element && pn.x <= rc.right + h_element)) { return false; }

		ScrollOp(pn);

		return true;
	}
	
	void SListBox::IncIndexView()
	{		
		int q = list.size();  //int n;float step_y = get_step_y(n);

		if (index_view + 1 >= q) { return; }

		index_view++;
	}

	void SListBox::DecIndexView()
	{
		if (index_view - 1 < 0) { return; }

		index_view--;
	}

	bool SListBox::In(POINT& pn)
	{
		return pn.x >= rc.left &&  pn.y >= rc.top && pn.x <= rc.right &&  pn.y <= rc.bottom;
	}

	bool SListBox::InScrollBar(POINT& pn)
	{
		return pn.x >= rc.right - (long)h_element && pn.x <= rc.right && pn.y >= rc.top + (long)m_bar_y - (long)h_element && pn.y <= rc.top + (long)m_bar_y;
	}

	void DrawCheckBox(HDC hdc, int i_height_font, HFONT hfont, int x, int y, int w, int h, char *sz_text, bool f_select, bool f_text_only, HBITMAP hbitmapOn, HBITMAP hbitmapOff)
	{
		int ident = 2;

		if (!f_text_only)
		{
			if (hbitmapOn && hbitmapOff)
			{
				int ident = 4;

				POINT size = { 20, 20 };

				int x_shift = -2;
				int y_shift = 0;

				POINT pn = { x + ident + x_shift, y + (h - size.y) / 2 + y_shift };

				bool fDraw = win_e::DrawBitmap(hdc, f_select ? hbitmapOn : hbitmapOff, pn, &size);
			}
			else
			{
				//1.bar
				MoveToEx(hdc, x + ident, y + ident, NULL);
				LineTo(hdc, x + h - ident, y + ident);
				LineTo(hdc, x + h - ident, y + h - ident);
				LineTo(hdc, x + ident, y + h - ident);
				LineTo(hdc, x + ident, y + ident);

				if (f_select)
				{
					//2. V
					MoveToEx(hdc, x + 2 * ident, y + 2 * ident, NULL);
					LineTo(hdc, x + h / 2, y + h - 2 * ident);
					LineTo(hdc, x + h - 2 * ident, y + 2 * ident);
				}
			}
		}

		//2. text
		if (sz_text == 0) { return; }		
		
		int len_text = strlen(sz_text);
		
		if (len_text == 0) { return; }

		SDrawTextParam tp;

		tp.hfont = hfont;
		tp.height_font = i_height_font;
		tp.p_text = sz_text;
		tp.len_text = len_text;
		tp.x = x;
		tp.y = y;
		tp.w = w-h;
		tp.h = h;
		tp.ident = h + ident;

		Draw_Text(hdc, tp);

		/*SetBkMode(hdc, TRANSPARENT);
		POINT char_size = { 16,  22 };
		POINT text_pos = { x + h + ident,  y + (h- char_size.y)/2 };
		TextOutA(hdc, text_pos.x, text_pos.y, sz_text, len_text);*/
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	bool SListBox::Sel(POINT& pn, bool fChState, SListBoxItem* *pElement, bool fMoveNew)
	//
	{
		if (m_f_no_scroll) { return false; }

		m_f_bar_selected = false;

		if (fMoveNew == false) 
		{ SetMove(false);			}		
		
		if (InScrollBar(pn))
		{                      
			if (fMoveNew) 
			{ SetMove(fMoveNew); }
			
			m_f_bar_selected = true;

			return true;
		}		

		if (pn.y < rc.top || pn.y > rc.bottom) { return false; }
		if (pn.x < rc.left || pn.x > rc.right - h_element) { return false; } //int n; float step_y = get_step_y(n); 
		
		int q = list.size();

		if (q)
		{
			int index = index_view + (pn.y - rc.top) / h_element;

			if (index >= q) { return false; }

			m_sel_index = index;
			
			m_f_need_redraw = true;

			if (m_f_one_sel == false)
			{
				if (fChState)
				{
					SelItemOp(index);
				}
			}

			if (pElement)
			{
				*pElement = &list[index];
			}
		}

		return true;
	}

	bool SListBox::InMouseWheel(POINT& pn, int v)
	{
		bool fCh = false;

		if (In(pn))
		{
			if (v > 0)
			{
				DecIndexView();
			}
			else
			{
				IncIndexView();
			}

			if (v)
			{
				fCh=true;
			}
		}

		return fCh;
	}

	void SListBox::SelItemOp(int index)
	{
		int q = list.size();

		if (index < 0 || index >= q) { return; }

		bool& f_select = list[index].f_select;

		f_select = !f_select;
	}

	void SListBox::SelAll(bool f)
	{
		int q = list.size();

		for (int i = 0; i < q; i++) { list[i].f_select = f; }
	}

	int SListBox::GetCountSel(bool& fAll, std::vector<long>& list_index_sel)
	{
		int c = 0;
		
		int q = list.size();

		list_index_sel.clear();

		for (int i = 0; i < q; i++) 
		{ 
			if (list[i].f_select) { c++; list_index_sel.push_back(i); }
		}

		fAll = c == q;

		return c;
	}

	HFONT Create_Font(char* sz_font_family, int h_font, float part_h)
	{				
		LOGFONTA lf;

		lf.lfHeight= h_font;
		lf.lfWidth = h_font * part_h;
		lf.lfEscapement=0;
		lf.lfOrientation=0;
		lf.lfWeight= FW_NORMAL;
		lf.lfItalic=0;
		lf.lfUnderline=0;
		lf.lfStrikeOut=0;
		lf.lfCharSet= RUSSIAN_CHARSET;
		lf.lfOutPrecision = OUT_DEFAULT_PRECIS; // OUT_CHARACTER_PRECIS;
		lf.lfClipPrecision = CLIP_DEFAULT_PRECIS; // CLIP_CHARACTER_PRECIS;
		lf.lfQuality= DEFAULT_QUALITY;
		lf.lfPitchAndFamily= DEFAULT_PITCH;
		strcpy_s(lf.lfFaceName, 32, sz_font_family);

		HFONT hfont=CreateFontIndirectA(&lf);

		return hfont;
	}


	bool SBorder::Open(RECT& rc_new, int iThick_new)
	{
		memset(this, 0, sizeof(SBorder));

		rc = rc_new;
		iThick = iThick_new;


		fInit = true;

		return fInit;
	}

	void SBorder::Close()
	{
	}

	void SBorder::Draw(HDC hdc)
	{                                    //int t_center = iThick*0.8;
		//int t_step = iThick*0.05;

		for (int i = 0; i < iThick; i++)
		{
			if (i == 0 || i== iThick-1) { SelectObject(hdc, g_penBrush[EPB_PEN_GRAY_55]); } else
			if (i == 1 || i == iThick - 2) { SelectObject(hdc, g_penBrush[EPB_PEN_GRAY_CC]); }	else
			if (i == 2 || i == iThick - 3) { SelectObject(hdc, g_penBrush[EPB_PEN_GRAY_DD]); } else
			if (i == 3 || i == iThick - 4) { SelectObject(hdc, g_penBrush[EPB_PEN_GRAY_EE]); }
			else { SelectObject(hdc, g_penBrush[EPB_PEN_WHITE]); }

			//LEFT
			MoveToEx(hdc, rc.left + i, rc.top + i, 0);
			LineTo(hdc, rc.left + i, rc.bottom- i);
			//RIGHT
			MoveToEx(hdc, rc.right - i, rc.top + i, 0);
			LineTo(hdc, rc.right - i, rc.bottom - i);
			//TOP
			MoveToEx(hdc, rc.left + i, rc.top + i, 0);
			LineTo(hdc, rc.right - i, rc.top + i);
			//BOTTOM
			MoveToEx(hdc, rc.left + i, rc.bottom - i, 0);
			LineTo(hdc, rc.right - i, rc.bottom - i);
		}
	}

	void Set_Cursor(LPCTSTR lpCursorName) //IDC_WAIT //IDC_ARROW//HINSTANCE hInstance, 
	{
		HCURSOR hCursor = LoadCursor(0, lpCursorName);

		SetCursor(hCursor);
	}

	///////////////////////////////////////////////////////////
	bool SWaitIndicator::Open(RECT& rc_new, int q_items_new)
	//
	{
		memset(this, 0, sizeof(SWaitIndicator));

		rc= rc_new;
		q_items= q_items_new;
		
		fInit = true;

		return fInit;
	}

	void SWaitIndicator::Close()
	{
	}

	void SWaitIndicator::Draw(HDC hdc, HBRUSH hbrushGround)
	{
		int w = rc.right - rc.left;
		int step_x = w / q_items;
		int i_ident = 2;
		int i_len_x = step_x - i_ident;
		POINT pn;
		pn.y = rc.top;
		int h = rc.bottom - rc.top;

		SelectObject(hdc, (HPEN)g_penBrush[EPB_PEN_WHITE]);
		int i;

		//0. ground
		SelectObject(hdc, hbrushGround);
		Rectangle(hdc, rc.left- i_ident, rc.top- i_ident, rc.right+ i_ident, rc.bottom+ i_ident);

		//1. full
		SelectObject(hdc, (HBRUSH)g_penBrush[EPB_BRUSH_WHITE]);
		for (i = 0; i <index; i++)
		{
			pn.x = rc.left + i*step_x;
			Rectangle(hdc, pn.x, pn.y, pn.x + i_len_x, pn.y + h);
		}

		//2.empty
		for (i = index; i < q_items; i++)
		{
			pn.x = rc.left + i*step_x;
			MoveToEx(hdc, pn.x, pn.y, 0);
			LineTo(hdc, pn.x + i_len_x, pn.y);
			LineTo(hdc, pn.x + i_len_x, pn.y + h);
			LineTo(hdc, pn.x, pn.y + h);
			LineTo(hdc, pn.x, pn.y);
		}
	}

	void SWaitIndicator::IndexOp()
	{
		if (index == q_items - 1) 
		{ index = 0; } 
		else 
		{ index++; }
	}


	void SetFont(HDC hdc, char *fontName, long nFontSize, bool  fBold, HFONT& hFont)
	{
		LOGFONTA logFont = { 0 };
		logFont.lfHeight = -MulDiv(nFontSize, GetDeviceCaps(hdc, LOGPIXELSY), 72);
		logFont.lfWeight = fBold ? FW_BOLD : FW_NORMAL;
		logFont.lfCharSet = RUSSIAN_CHARSET; // ANSI_CHARSET;
		strcpy_s(logFont.lfFaceName, 32, fontName);

		hFont = CreateFontIndirectA(&logFont);
	}

	///////////////////////////////////////////////////////////////		
	SBitmapCtrl::SBitmapCtrl()
	{
		memset(this, 0, sizeof(SBitmapCtrl));
	}

	void SBitmapCtrl::Init(char *szFileUp, char *szFileDown)
	{
		hbitmapUp = (HBITMAP)LoadImageA(0, szFileUp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		hbitmapDown = (HBITMAP)LoadImageA(0, szFileDown, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	}
	
	void SBitmapCtrl::Close()
	{
		if (hbitmapUp) { DeleteObject(hbitmapUp); }
		if (hbitmapDown) { DeleteObject(hbitmapDown); }
	}

	void SBitmapCtrl::Draw(HDC hdc)
	{
		DrawOp(hdc);

		/*HDC hMem = CreateCompatibleDC(hdc);

		HBITMAP memBM = CreateCompatibleBitmap(hdc, size.x, size.y);

		SelectObject(hMem, memBM);

		DrawOp(hMem);

		BitBlt(hdc, pn.x, pn.y, size.x, size.y, hMem, 0, 0, SRCCOPY);

		DeleteObject(memBM);

		DeleteObject(hMem);		*/
	}

	void Text_out(HDC hdc, POINT& pn, POINT& size, char *sz_text, int len_text)
	{
		if (len_text < 1) { return; }

		POINT char_size = { 8,  18 };

		int len_text_pix = len_text * char_size.x;

		SetBkMode(hdc, TRANSPARENT);

		TextOutA(hdc, pn.x + size.x / 2 - len_text_pix / 2, pn.y + size.y / 2 - char_size.y / 2, sz_text, len_text);
	}

	void SBitmapCtrl::DrawOp(HDC hdc)
	{
		//POINT pnL = { 0, 0 };

		bool fDrawBitmap = DrawBitmap(hdc, fDown ? hbitmapDown : hbitmapUp, pn, &size);

		Text_out(hdc, pn, size, (char*)text.c_str(), text.size());

		/*if (text.size())
		{			
			POINT char_size = { 8,  18 };

			int len_text = text.size() * char_size.x;

			TextOutA(hdc, pn.x + size.x / 2 - len_text / 2, pn.y + size.y / 2 - char_size.y / 2, (char*)text.c_str(), text.size());
		}*/
	}

	bool SBitmapCtrl::In(POINT& n)
	{
		bool fIn = n.x >= pn.x && n.x <= pn.x + size.x && n.y >= pn.y && n.y <= pn.y + size.y;

		if (fIn)
		{
			fDown = fDown ? false : true;
		}

		return fIn; 
	}

	///////////////////////////////////////////////////////////////
	bool CBitmapCtrls::Open()
	//
	{
		memset(this, 0, sizeof(CBitmapCtrls));

		m_fInit=true;

		return m_fInit;
	}

	void CBitmapCtrls::Close()
	{
		if (m_fInit == false) { return; }

		m_fInit = false;
		
		int q = m_list.size();

		for (int i = 0; i < q; i++)
		{
			m_list[i].Close();
		}
	}
	
	bool CBitmapCtrls::Add(SBitmapCtrl& sNew)
	{
		if (m_fInit == false) { return false; }
		
		m_list.push_back(sNew);

		return true;
	}

	void CBitmapCtrls::Draw(HDC hdc)
	{
		int q = m_list.size();

		for (int i = 0; i < q; i++)
		{
			m_list[i].Draw(hdc);
		}
	}

	bool CBitmapCtrls::Click(POINT& pn)
	{
		m_fInit = false;

		int q = m_list.size();
		
		bool fIn = false;

		for (int i = 0; fIn == false && i < q; i++)
		{
			if (m_list[i].In(pn)) { fIn = true; }
		}

		return fIn;
	}


	bool GetMouseClientCoord(HWND hwnd, POINT& pn_out)
	{
		POINT pt;

		if (GetCursorPos(&pt) == FALSE) { return false; }

		RECT rc;

		BOOL fRes = GetWindowRect(hwnd, &rc);

		if (fRes == false) { return false; }

		pn_out.x = pt.x - rc.left;

		pn_out.y = pt.y - rc.top;

		return true;
	}

	
	///////////////////////////////////////////////////////////////
	CToolhelpSnapshot::CToolhelpSnapshot(DWORD dwFlags)
	//
	{
		memset(this, 0, sizeof(CToolhelpSnapshot));

		DWORD th32ProcessID = 0;

		m_hSnapshot = CreateToolhelp32Snapshot(dwFlags, th32ProcessID);

		if (m_hSnapshot == INVALID_HANDLE_VALUE) { return; }

		m_fInit = true;
	}

	bool CToolhelpSnapshot::Next(int&  i, PROCESSENTRY32& pe)
	{
		if (m_fInit == false) { return false; }

		bool fRes;

		if (i == 0)
		{
			BOOL fCopy = Process32First(m_hSnapshot, &pe);

			fRes = fCopy == TRUE;
		}
		else
		{
			BOOL fCopy = Process32Next(m_hSnapshot, &pe);

			fRes = fCopy == TRUE;
		}

		i++;

		return fRes;
	}

	//////////////////////////////////////////////////////////////////////
	bool ProcessExists(wchar_t* wz_proc_name)
	//
	{
		CToolhelpSnapshot s;
		
		int i = 0;
		
		PROCESSENTRY32 pe;
		
		pe.dwSize = sizeof(PROCESSENTRY32);

		int iCnt = 0; //bool fFound = false;

		while (iCnt <2 && s.Next(i, pe))
		{
			if (!wcsicmp(wz_proc_name, pe.szExeFile))
			{
				iCnt++; // fFound = true;
			}			
		}

		return iCnt>1;
	}


	void DrawFootball(HDC hdc, POINT& pn, int rad)
	{
		//1.
		SelectObject(hdc, GetStockObject(BLACK_PEN));
		SelectObject(hdc, GetStockObject(WHITE_BRUSH));

		Ellipse(hdc, pn.x - rad, pn.y - rad, pn.x + rad, pn.y + rad);

		//2.
		SelectObject(hdc, GetStockObject(BLACK_BRUSH));
		const int ci_max_pn = 5;
		const int ci_max_b = 4;
		POINT a[ci_max_pn];
		POINT b[ci_max_b];
		
		double dist_to_side = rad / 4;
		

		double angle_step = 2*M_PI/ ci_max_pn;
		double x, y;
		double rad_center = rad*2 / 4;
		double angle = 0;

		double dist_along = rad * 3 / 4;
		double thick_along = rad / 5;
		BOOL fRes;

		for (int i=0; i<ci_max_pn; i++)
		{			
			math_e::TurnRelCenter(pn.x, pn.y, rad_center, angle, x, y);

			a[i].x = x;
			a[i].y = y;
			
			//<b
			int k = 0;
			math_e::TurnRelCenterSide(pn.x, pn.y, dist_along, angle, dist_to_side, x, y); b[k].x = x; b[k].y = y; k++;
			math_e::TurnRelCenterSide(pn.x, pn.y, dist_along, angle, -dist_to_side, x, y); b[k].x = x; b[k].y = y; k++;
			math_e::TurnRelCenterSide(pn.x, pn.y, dist_along + thick_along, angle, -dist_to_side, x, y); b[k].x = x; b[k].y = y; k++;
			math_e::TurnRelCenterSide(pn.x, pn.y, dist_along + thick_along, angle, dist_to_side, x, y); b[k].x = x; b[k].y = y; k++;
			fRes = Polygon(hdc, b, ci_max_b);
			//>b

			angle += angle_step;
		}
		fRes = Polygon(hdc, a, ci_max_pn);

	}

	//////////////////////////////////////////////////////////////////////////////
	bool SEdit::Open(RECT& rc_new, int i_text_max_new)
	{
		memset(this,  0,  sizeof(SEdit));
		
		rc= rc_new;

		w = rc.right - rc.left;

		h = rc.bottom - rc.top;

		i_text_max = i_text_max_new;

		if (i_text_max < 1) { return false; }

		m_text = new char[i_text_max + 1];

		if (m_text==0) { return false; }

		fInit=true;
		
		return fInit;
	}

	void SEdit::Close()
	{
		if (m_text)
		{
			delete m_text; 
			
			m_text = 0;
		}
	}


	SDrawTextParam::SDrawTextParam()
	{
		memset(this, 0, sizeof(SDrawTextParam));

		ident = 5;
	}

	void Draw_Text(HDC hdc, SDrawTextParam& param)
	{
		int q = param.len_text;

		if (q == 0) { return; } 		//std_string m_text;
		
		SetBkMode(hdc, TRANSPARENT);

		SetTextColor(hdc, 0);
		
		SelectObject(hdc, param.hfont);

		POINT char_size = { 11,  22 };

		int x_ident = 1;
		char_size.x = param.height_font * cfl_font_part_h + x_ident;
		char_size.y = param.height_font;

		int y = param.y + (param.h - char_size.y) / 2;
		
		char szOne[1 + 1];

		int x_max = param.x + param.w;

		for (int i = 0; i < q; i++)
		{
			int x = param.x + param.ident + i * char_size.x;

			if (x + char_size.x > x_max) { break; }

			memcpy(szOne, 	param.p_text + i, 1); szOne[1] = 0;

			TextOutA(hdc, x, y, szOne, 1);
		}

	}

	void DrawPenFrame(HDC hdc, RECT& rc, int i_shift)
	{
		int s = i_shift;

		long& x = rc.left;
		long& y = rc.top;
		long& xe = rc.right;
		long& ye = rc.bottom;

		MoveToEx(hdc, x + s, y + s, 0);
		LineTo(hdc, xe - s, y + s);
		LineTo(hdc, xe - s, ye - s);
		LineTo(hdc, x + s, ye - s);
		LineTo(hdc, x + s, y + s);
	}

	void SEdit::DrawOp(HDC hdc, int i_height_font, HFONT hfont)
	{
		SelectObject(hdc, (HPEN)GetStockObject(BLACK_PEN));
		SelectObject(hdc, (HPEN)GetStockObject(WHITE_BRUSH));

		Rectangle(hdc, 0, 0, w, h);
		
		if (m_f_active)
		{
			RECT rc = { 1, 1, w-1, h-1 };
			RECT rc1 = { 2, 2, w - 2, h - 2 };
			RECT rc2 = { 3, 3, w - 3, h - 3 };

			SelectObject(hdc, (HPEN)g_penBrush[EPB_PEN_GRAY_55]);
			DrawPenFrame(hdc, rc);
			
			SelectObject(hdc, (HPEN)g_penBrush[EPB_PEN_GRAY_CC]);
			DrawPenFrame(hdc, rc1);

			SelectObject(hdc, (HPEN)g_penBrush[EPB_PEN_GRAY_E0]);
			DrawPenFrame(hdc, rc2);
		}

		SDrawTextParam tp;
		
		tp.hfont = hfont;
		tp.height_font = i_height_font;
		tp.p_text = m_text;
		tp.len_text = q_text;
		tp.w = w;
		tp.h = h;

		Draw_Text(hdc, tp);
	}

	void SEdit::Draw(HDC hdc, int i_height_font, HFONT hfont)
	{
		if (fInit == false) { return; }

		HDC hMem = CreateCompatibleDC(hdc);
		HBITMAP memBM = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hMem, memBM);

		DrawOp(hMem, i_height_font, hfont);

 	BitBlt(hdc, rc.left, rc.top, w, h, hMem, 0, 0, SRCCOPY);

		DeleteObject(memBM);

		DeleteObject(hMem);
	}

	bool SEdit::IsValid_VK(int& vk, bool fShift)
	{
		bool fSpec= vk==VK_OEM_4 || vk== VK_OEM_6 || vk== VK_OEM_7 || vk== VK_OEM_1 || vk== VK_OEM_COMMA || vk== VK_OEM_PERIOD || vk== VK_OEM_2 || vk== VK_OEM_3 || vk== VK_OEM_5 || vk==VK_SPACE;
		bool fSigns = vk== VK_OEM_PLUS || vk== VK_OEM_MINUS;
		bool fNum = vk >= '0' && vk <= '9';

		if (vk == VK_OEM_4) { vk = '['; } else
		if (vk == VK_OEM_6) { vk = ']'; }		else
		if (vk == VK_OEM_7) { vk = '\''; }		else
		if (vk == VK_OEM_1) { vk = ';'; }	else
		if (vk == VK_OEM_COMMA) { vk = ','; }		else
		if (vk == VK_OEM_PERIOD) { vk = '.'; }	else
		if (vk == VK_OEM_2) { vk = '/'; }	else
		if (vk == VK_OEM_PLUS) { vk = '+'; }	else
		if (vk == VK_OEM_MINUS) { vk = '-'; }	else
		if (vk == VK_OEM_3) { vk = '`'; }	else
		if (vk == VK_OEM_5) { vk = '\\'; }
		
		if (fShift)
		{
			if (vk == '0') { vk = ')'; }	else
			if (vk == '1') { vk = '!'; }	else
			if (vk == '2') { vk = '@'; }	else
			if (vk == '3') { vk = '#'; }	else
			if (vk == '4') { vk = '$'; }	else
			if (vk == '5') { vk = '%'; }	else
			if (vk == '6') { vk = '^'; }	else
			if (vk == '7') { vk = '&'; }	else
			if (vk == '8') { vk = '*'; }	else
			if (vk == '9') { vk = '('; }
		}

		return fNum || (vk >= 'A' && vk <= 'Z') || fSpec || fSigns; // || (vk == '[' || vk == ']' || vk == ';' || vk == '\'' || vk == '\'' || vk == ',' || vk == '.' || vk == '/')
	}

	bool SEdit::KeyDown(int vk)
	{
		if (fInit == false) { return false; }
		if (m_f_read_only) { return false; }
		
		if (m_f_active == false) { return false; }		

		bool fCh = false;

		LANGID primLangId = GetPrimLangId();

		bool fShift = GetKeyState(VK_SHIFT)&8000;

		if (vk == VK_BACK)
		{ fCh = DelLast(); } else
		if (vk == VK_RETURN)
		{
			if (m_hwnd && m_id)
			{
				WORD notify = 0; // HIWORD(wParam);
				WPARAM wParam = (notify << 16) + m_id & 0xFFFF;

				SendMessage(m_hwnd, WM_COMMAND, wParam, 0);
			}
		}
		else
		{
			if (IsValid_VK(vk, fShift))
			{
				if (primLangId == LANG_RUSSIAN)
				{
					vk = GetRusCharByKey(vk, fShift);
				}
				else
				{
					if (fShift == false)
					{
						vk = tolower(vk);
					}
				}

				fCh = Add(vk);
			}
		}

		

		return fCh;
	}

	/*
	if (vk >= '0' && vk <= '9')
	{
	fCh = Add(vk);
	}
	else
	if (vk >= 'A' && vk <= 'Z')
	{
	*/
	bool SEdit::DelLast()
	{
		if (q_text <= 0) {return false;}
		
		m_text[q_text] = 0;

		q_text--;
		
		return true;
	}

	bool SEdit::Add(int vk)
	{
		if (q_text >= i_text_max) { return false; }

		m_text[q_text] = vk;

		q_text++;
		
		m_text[q_text] = 0;

		return true;
	}

	void SEdit::SetText(char* sz_new)
	{
		if (sz_new == 0) { return; }

		int len_new = strlen(sz_new);

		if (len_new == 0) { return; }

		if (len_new > i_text_max) { len_new = i_text_max; }

		memcpy(m_text, sz_new, len_new); m_text[len_new] = 0;

		q_text = len_new;
	}


	bool SEdit::CheckIn(POINT& pn)
	{
		if (m_f_read_only) { return false; }

		m_f_active = pn.x >= rc.left && pn.y >= rc.top && pn.x <= rc.right && pn.y <= rc.bottom;

		return m_f_active;
	}

	void GetKeysLangInput(EHotKeysLangInput& eKeys)
	{
		/////////////////////////////////// ���������� �������, �������� ������������� ��������� ����������
		HKEY hKey;
		if (RegOpenKeyExA(HKEY_CURRENT_USER, "Keyboard Layout\\Toggle", 0, KEY_READ, &hKey) == ERROR_SUCCESS)
		{
			BYTE Data[] = { 0x00, 0x00, 0x00 };
			DWORD cbData = sizeof(Data);
			RegQueryValueExA(hKey, "Language Hotkey", 0, NULL, Data, &cbData);
			RegCloseKey(hKey);  //int KEYBLAY = VK_MENU;//if(strcmp((char*)Data, "1")) KEYBLAY=VK_MENU; // Alt+Shift

			eKeys = EHKLI_ALT_SHIFT;

			if (strcmp((char*)Data, "2") == 0) {eKeys = EHKLI_CTRL_SHIFT;} //KEYBLAY = VK_CONTROL; // Ctrl+Shift
		}

	}

	LANGID GetPrimLangId()
	{
		DWORD hkl = (DWORD)GetKeyboardLayout(0);

		LANGID lang_id = hkl & 0xFFFF;

		return lang_id & 0x3FF;
	}

	char GetRusCharByKey(char c, bool fUp)
	{
		if (fUp)
		{
			if (c == 'Q') { return '�'; }
			if (c == 'W') { return '�'; }
			if (c == 'E') { return '�'; }
			if (c == 'R') { return '�'; }
			if (c == 'T') { return '�'; }
			if (c == 'Y') { return '�'; }
			if (c == 'U') { return '�'; }
			if (c == 'I') { return '�'; }
			if (c == 'O') { return '�'; }
			if (c == 'P') { return '�'; }
			if (c == '[') { return '�'; }
			if (c == ']') { return '�'; }
			if (c == 'A') { return '�'; }
			if (c == 'S') { return '�'; }
			if (c == 'D') { return '�'; }
			if (c == 'F') { return '�'; }
			if (c == 'G') { return '�'; }
			if (c == 'H') { return '�'; }
			if (c == 'J') { return '�'; }
			if (c == 'K') { return '�'; }
			if (c == 'L') { return '�'; }
			if (c == ';') { return '�'; }
			if (c == '\'') { return '�'; }
			if (c == 'Z') { return '�'; }
			if (c == 'X') { return '�'; }
			if (c == 'C') { return '�'; }
			if (c == 'V') { return '�'; }
			if (c == 'B') { return '�'; }
			if (c == 'N') { return '�'; }
			if (c == 'M') { return '�'; }
			if (c == ',') { return '�'; }
			if (c == '.') { return '�'; }
			if (c == '/') { return ','; }
			if (c == '`') { return '�'; }
			
		}
		else
		{
			if (c == 'Q') { return '�'; }
			if (c == 'W') { return '�'; }
			if (c == 'E') { return '�'; }
			if (c == 'R') { return '�'; }
			if (c == 'T') { return '�'; }
			if (c == 'Y') { return '�'; }
			if (c == 'U') { return '�'; }
			if (c == 'I') { return '�'; }
			if (c == 'O') { return '�'; }
			if (c == 'P') { return '�'; }
			if (c == '[') { return '�'; }
			if (c == ']') { return '�'; }
			if (c == 'A') { return '�'; }
			if (c == 'S') { return '�'; }
			if (c == 'D') { return '�'; }
			if (c == 'F') { return '�'; }
			if (c == 'G') { return '�'; }
			if (c == 'H') { return '�'; }
			if (c == 'J') { return '�'; }
			if (c == 'K') { return '�'; }
			if (c == 'L') { return '�'; }
			if (c == ';') { return '�'; }
			if (c == '\'') { return '�'; }
			if (c == 'Z') { return '�'; }
			if (c == 'X') { return '�'; }
			if (c == 'C') { return '�'; }
			if (c == 'V') { return '�'; }
			if (c == 'B') { return '�'; }
			if (c == 'N') { return '�'; }
			if (c == 'M') { return '�'; }
			if (c == ',') { return '�'; }
			if (c == '.') { return '�'; }
			if (c == '/') { return '.'; }
			if (c == '`') { return '�'; }
		}
	}

	
	/*bool SComboBox::Open(RECT& rc_new, int i_text_max_new )
	//
	{
		if (m_edit.Open(rc_new, i_text_max_new) == false) { return false; }
		
		int h_element = 22;
		int q_view_elements = 6;
		RECT rc_list = { rc_new.left,  rc_new.bottom,  rc_new.right, rc_new.bottom + q_view_elements*h_element };
		bool f_text_only = true;
		bool f_no_draw = true;
		
		if (m_list.Open(rc_list, h_element, 0, f_text_only, f_no_draw) == false) { return false; }

		return true;
	}

	void SComboBox::Close()
	{
		m_edit.Close();
		m_list.Close();
	}

	void SComboBox::ClearList()
	{
		m_list.list.clear();
	}

	void SComboBox::AddToList(char* sz_new)
	{
		m_list.Add(sz_new);
	}

	bool SComboBox::CheckIn(POINT& pn, bool& fNeedDrawBkGr)
	{
		fNeedDrawBkGr = false;

		bool  fIn = m_edit.CheckIn(pn);
		
		if (fIn) 
		{
			m_list.m_f_no_draw = ! m_list.m_f_no_draw;
		}
		else
		{
			if (m_list.m_f_no_draw==false)
			{
				bool fChState = false;
				
				SListBoxItem *pElement=0;

				fIn = m_list.Sel(pn, fChState, &pElement);

				if (fIn && pElement)
				{
					m_edit.SetText((char*)pElement->sz_text.c_str());

					m_list.m_f_no_draw = true;

					fNeedDrawBkGr = true;
				}
			}
		}

		return fIn;
	}

	void SComboBox::Draw(HDC hdc, SEdit::SDrawTextParam* p_param)
	{
		m_edit.Draw(hdc, p_param);
		m_list.Draw(hdc);
	}
	
	void SComboBox::SelectItem(int index)
	{
		int q = m_list.list.size();

		if (index < 0 || index >= q) { return; }

		char *p_text  = (char*) m_list.list[index].sz_text.c_str();

		m_edit.SetText(p_text);
	}

	bool SComboBox::InScrollOp(POINT& pn)
	{
		return m_list.InScrollOp(pn);
	}*/

	bool GetClientRectAbs(HWND hWnd, RECT& rcCleintAbs, SCWindowAttr* pAttr)
	{
		if (IsWindow(hWnd) == FALSE) { return false; }

		const int ci_fix_y_drw_wnd = -8;
		const int ci_fix_w = 1;
		const int ci_fix_h = 1;
		//const int ci_fix_y_drw_wnd = 21;

		RECT rc;
		RECT crc;

		if (GetWindowRect(hWnd, &rc) == FALSE) { return false; }

		if (GetClientRect(hWnd, &crc) == FALSE) { return false; }

		int wc = crc.right - crc.left;
		int hc = crc.bottom - crc.top;

		int iThick = ((rc.right - rc.left) - wc) / 2;
		int iCaption = ((rc.bottom - rc.top) - hc) - iThick;

		rcCleintAbs = rc; //memcpy(&rcCleintAbs ,   &rc,  sizeof(RECT));

		rcCleintAbs.left += iThick;
		rcCleintAbs.top += iCaption + iThick + ci_fix_y_drw_wnd;
		rcCleintAbs.right = rcCleintAbs.left + wc + ci_fix_w;
		rcCleintAbs.bottom = rcCleintAbs.top + hc + ci_fix_h;

		if (pAttr) { pAttr->iThick = iThick; pAttr->iCaption = iCaption; }

		return true;
	}
}//namespace win_e
