#ifndef _flags_h_
#define _flags_h_


class CFlags
{
	unsigned int m_flags;
	public:
	CFlags();
	void Clear();
	void SetFlag(int iPos, bool fNewVal);
	bool GetFlag(int iPos);
};

#endif