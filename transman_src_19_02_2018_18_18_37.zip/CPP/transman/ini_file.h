#ifndef _IniFile_h_
#define _IniFile_h_
#include "..\\transman_srv\\std_str.h"
#include <vector>

#include "..\\transman_srv\\std_str.h"

typedef void(*FN_INI_READ)(void *p_param, char *sz_param, char *sz_val);

class CIniFile
{
	bool m_fInit; //std_string m_sz_file;
	bool GetFromBuf(char *buf, long len, char *sz_param, char *sz_value, long l_max_value, FN_INI_READ fn_read = 0, void *p_param=0);
	
	struct SParamVal
	{
		std_string param;
		std_string val;
	};


	public:
	CIniFile(); //char *sz_file);
	~CIniFile();


	struct SGet
	{
		std::vector<SParamVal> list;
		void Add(char* sz_param, char *sz_val);

		bool Find(char* sz_param, SParamVal* *pItem=0);

		bool Save(char *sz_file);
	};

	
	bool Get(char *sz_file, char *sz_param, char *sz_value, long l_max_value, FN_INI_READ fn_read=0, void *p_param=0);
	
	bool Set(char *sz_file, char *sz_param, char *sz_value, long l_max_value);
	
};

#endif