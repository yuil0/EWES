#include <memory.h>
#include <time.h>
#include "mssql_agent.h" 
#include "mes_log.h"
#include "main.h" 
#include "..\\transman\\ini_file.h"
#include "..\\transman\\mssql.h"

const char* csz_file_mssql_agent = "C:\\transman\\mssql_agent.ini"; //time_t g_time_mili_sec;
const int ci_MSSQLAgent_sleep = 800;

CMSSQLAgent::CMSSQLAgent()
{
	m_fInit=false;
	
	memset(this, 0, sizeof(CMSSQLAgent));
	
	m_fInit=true;
}

CMSSQLAgent::~CMSSQLAgent()
{
	
}


DWORD WINAPI CFMSSQLThreadProc(LPVOID lpParameter)
{
	CMSSQLAgent *p_this = (CMSSQLAgent*)lpParameter;

	if (p_this == 0) { return 0; }

	while (1)
	{
		if (p_this->Exec()) { }

		Sleep(ci_MSSQLAgent_sleep);
	}

	return 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool CMSSQLAgent::Open()
{
	if (m_fInit == false) { return false; }

	if (LoadList() == false) { gMesLog.Mes("Error CMSSQLAgent::LoadList()"); return false; }

	DWORD dThreadId;

	HANDLE h = CreateThread(0, 0, CFMSSQLThreadProc, (LPVOID)this, 0, &dThreadId);

	return h != 0;
}

void CMSSQLAgent_FN_INI_READ(void *p_param, char *sz_param, char *sz_val)
{
	CMSSQLAgent* p_this = (CMSSQLAgent*)p_param;

	if (p_this == 0) { return; }

	p_this->ReadIni(sz_param, sz_val);
}

bool CMSSQLAgent::LoadList()
{
	m_list.clear();

	CIniFile ini;

	return ini.Get((char*)csz_file_mssql_agent, 0, 0, 0, CMSSQLAgent_FN_INI_READ, this);
}

void SMSSQLAgentRow::Clear()
{                       //time_prev_sec = 0;
	f_enabled=false;
	sz_query.clear();
}

void CMSSQLAgent::ReadIni(char *sz_param, char *sz_val)
{
	if (!stricmp(sz_param, "query")) { m_row.Clear();  m_row.sz_query = sz_val; }    //YUIL 2017-09-20 ������ ��� ����������
	else
	if (!stricmp(sz_param, "enabled")) { m_row.f_enabled = atol(sz_val); } //YUIL 2017-09-20 ����� ���������� ������ ����������� ������� sz_query
	else
	if (!stricmp(sz_param, "monday")) { m_row.f_monday = atol(sz_val); }
	else
	if (!stricmp(sz_param, "tuesday")) { m_row.f_tuesday = atol(sz_val); }
	else
	if (!stricmp(sz_param, "wednesday")) { m_row.f_wednesday = atol(sz_val); }
	else
	if (!stricmp(sz_param, "thursday")) { m_row.f_thursday = atol(sz_val); }
	else
	if (!stricmp(sz_param, "friday")) { m_row.f_friday = atol(sz_val); }
	else
	if (!stricmp(sz_param, "saturday")) { m_row.f_saturday = atol(sz_val); }
	else
	if (!stricmp(sz_param, "sunday")) { m_row.f_sunday = atol(sz_val); }
	else
	if (!stricmp(sz_param, "hour_from")) { m_row.hour_from = atol(sz_val); } //YUIL 2017-09-20 ��� ������  
	else
	if (!stricmp(sz_param, "hour_to")) { m_row.hour_to = atol(sz_val); }  //YUIL 2017-09-20 ��� ����������
	else
	if (!stricmp(sz_param, "pause_ms")) 
	{ 
		m_row.pause_ms = atol(sz_val); 

		m_list.push_back(m_row);
	}
	
}

void CMSSQLAgent_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesLog.Mes("CMSSQLAgent:: ������ MSSQL : %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
}

bool SMSSQLAgentRow::IsEnabled()
{
	if (f_enabled == false) {return false;}

	time_t time_mili_sec = time(0);

	struct tm* tm = localtime(&time_mili_sec); 

	if (tm->tm_wday == 0) { if (f_monday == false) { return false; } } else
	if (tm->tm_wday == 1) { if (f_tuesday == false) { return false; } } else
	if (tm->tm_wday == 2) { if (f_wednesday == false) { return false; } } else
	if (tm->tm_wday == 3) { if (f_thursday == false) { return false; } } else
	if (tm->tm_wday == 4) { if (f_friday == false) { return false; } } else
	if (tm->tm_wday == 5) { if (f_saturday == false) { return false; } } else
	if (tm->tm_wday == 6) { if (f_sunday == false) { return false; } }

	if (hour_from >= hour_to) { return false; }

	if (tm->tm_hour < hour_from) { return false; }
	if (tm->tm_hour > hour_to) { return false; }

	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool CMSSQLAgent::Exec()
{
	for (int i = 0; i < m_list.size(); i++)
	{
		SMSSQLAgentRow& row = m_list[i]; //g_time_mili_sec=time(0); //YUIL 2017-09-21 ��� ����� � ���� ���.int time_sec = g_time_mili_sec / 1000; //YUIL 2017-09-21 ��� ����� � ���.  //if (row.time_prev_sec == 0 || time_sec - row.time_prev_sec > row.pause_ms){row.time_prev_sec = time_sec;}

		if (row.IsEnabled())
		{
			FN_MSSQL_ADD fn_add = 0;    //gMesLog.Mes("CMSSQLAgent. Start SQL query : %s", row.sz_query.c_str());

			bool f_exec = MSSQL_Exec((char*)row.sz_query.c_str(), fn_add, CMSSQLAgent_FN_MSSQL_MES_ERR, this);
		}

		Sleep(row.pause_ms);
	}
	
	return true;
}



CMSSQLAgent gMSSQLAgent;