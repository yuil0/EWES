#include "load_xlsx.h"

#include <memory.h>
#include <stdio.h> 
#include <fcntl.h>
#include <io.h>
#include <sys/stat.h>
#include "xml_parser.h"
#include "str.h"
#include "file.h"


//<row r="1" spans="1:5" s="1" customFormat="1" x14ac:dyDescent="0.25"><c r="A1" s="1" t="s"><v>161</v></c><c r="B1" s="1" t="s"><v>162</v></c><c r="C1" s="1" t="s"><v>163</v></c><c r="D1" s="1" t="s"><v>164</v></c><c r="E1" s="1" t="s"><v>165</v></c></row>
//<row r = "2" spans = "1:5" x14ac:dyDescent = "0.25"><c r = "A2" t = "s"><v>0< / v>< / c><c r = "B2" t = "s"><v>1< / v>< / c><c r = "C2"><v>77< / v>< / c><c r = "D2" t = "s"><v>2< / v>< / c><c r = "E2" t = "s"><v>3< / v>< / c>< / row>
//<si><t>��� - 3 "�����������"< / t>< / si>
void SXLSX::ReadTag(int index, char *sz_text, int len_text)
{
	bool f_closed = len_text ? sz_text[len_text - 1] == '/' : false;

	if (m_eFile == ELXLSX_SHARED_STRINGS)
	{
		if (index == 0)
		{   //YUIL ������ ��� ��� ����
			if (!stricmp(sz_text, "t")) 
			{ m_f_shared_string = true; }
		}
	}
	else
	if (m_eFile == ELXLSX_SHEET1)
	{
		if (index == 0)
		{   //YUIL ������ ��� ��� ����
			if (!stricmp(sz_text, "row")) 
			{
				if  (m_i_var==0)
				{
					if (m_q_in_rows) { m_f_row = true;  } 
				
					m_row.list.clear(); 
				
					m_q_in_rows++; 

					m_q_in_cols = 0;
				}else
				if  (m_i_var==1)
				{
					m_f_row = true; 
				
					m_row.list.clear(); 
				
					m_q_in_cols = 1;
				}
			}
			else
			if (!stricmp(sz_text, "/row")) 
			{ 
				m_rows.push_back(m_row);

				m_row.list.clear();

				m_f_row = false;
			}
			else
			{
				if (m_f_row)
				{
					if (!stricmp(sz_text, "c")) 
					{ m_f_col = true; m_eCol = ELXLSXC_DIRECT; m_q_in_cols++; }
					else
					if (!stricmp(sz_text, "/c")) 
					{ m_f_col = false; }
				}

				if (m_f_col)
				{
					if (!stricmp(sz_text, "v")) 
					{ m_f_val = true; }
				}
			}
		}
		else //if (index == 2)
		{
			if (m_f_col)
			{
				char sz_param[MAX_PATH + 1];
				char sz_val[MAX_PATH + 1];

				XML_GetParamVal(sz_text, sz_param, sz_val, MAX_PATH);

				if (!stricmp(sz_param, "t")) 
				{ 
					if (!stricmp(sz_val, "s")) 
					{ m_eCol = ELXLSXC_SHARED_STRING; }
				}
				
			}

			if (f_closed)
			{
				if (m_f_row)
				{
					if (m_f_col) { SetRowField(""); }

					m_f_col = false;					
				}
			}
		}

	}
}

void SXLSX::ReadOutTag(char *sz_text, int len_text)
{
	const int ci_max = 255;
	
	if (m_eFile == ELXLSX_SHARED_STRINGS)
	{
		if (m_f_shared_string)
		{
			m_f_shared_string = false;

			char sz_trans[ci_max + 1];

			convert_from_UTF8(sz_text, sz_trans);

			m_shared_strings.push_back(sz_trans);
		}
	}
	else
	if (m_eFile == ELXLSX_SHEET1)
	{
		if (m_f_val)
		{
			m_f_val = false;

			if (m_q_in_cols > 1)
			{
				SetRowField(sz_text);
			}
		}
	}
}

void SXLSX::SetRowField(char *sz_text)
{
	char *p_in= sz_text;

	if (p_in)
	{
		if (m_eCol == ELXLSXC_SHARED_STRING)
		{
			int index_string = atoi(sz_text);

			p_in = (char *)m_shared_strings[index_string].c_str();
		}
	}

	if (m_q_in_cols >= m_i_col_start)
	{
		std_string cash= p_in;

		m_row.list.push_back(cash);
	}	
}

void SXLSX_FN_READ_TAG(void  *p_param, int index, char *sz_text, int len_text)
{
	if (p_param == 0) { return; }

	SXLSX  *p_this = (SXLSX  *)p_param;

	p_this->ReadTag(index, sz_text, len_text);
}

void CXLSX_in_tag_FN_READ(void  *p_param, char *sz_text, int len_text)
{
	const int ci_max = 512;

	char sz[ci_max];

	if (XML_DelUnusedChars(sz_text, sz, ci_max) == false) { return; }

	XML_ParseTag(sz, p_param, SXLSX_FN_READ_TAG);
}

void CXLSX_out_tag_FN_READ(void  *p_param, char *sz_text, int len_text)
{
	if (p_param == 0) { return; }
	
	const int ci_max = 512;

	char sz[ci_max];

	if (XML_DelUnusedChars(sz_text, sz, ci_max) == false) { return; }

	SXLSX  *p_this = (SXLSX  *)p_param;

	p_this->ReadOutTag(sz, strlen(sz));

}

void SXLSX::ClearFolder()
{
	::ClearFolder(m_sz_path_UNZIP, "*.*");
}

//////////////////////////////////////////////////////////////
bool SXLSX::Read(char *sz_path, char *sz_file_only, int i_col_start,  int i_var, char *sz_bat_file)
//
{
	memset(this, 0, sizeof(SXLSX)); //m_shared_strings.clear();m_rows.clear();

	m_i_col_start = i_col_start;

	m_i_var=i_var;

	sprintf_s(m_sz_path_UNZIP, MAX_PATH, "%s\\UNZIP", sz_path);

	ClearFolder();

	BOOL fSet= SetCurrentDirectoryA(sz_path);

	if (fSet == FALSE) { return false; }
	
	UINT uRes = WinExec(sz_bat_file, SW_SHOW); //

	Sleep(1000);

	if (uRes <= 31) { return false; }

	//1. sharedStrings.xml
	m_eFile = ELXLSX_SHARED_STRINGS;
	
	char sz_file[MAX_PATH + 1]; 

	char sz_full[MAX_PATH + 1]; 
	
	sprintf_s(sz_file, MAX_PATH, "%s\\sharedStrings.xml", m_sz_path_UNZIP);

	if (XML_Parse(sz_file, this, CXLSX_in_tag_FN_READ, CXLSX_out_tag_FN_READ) == false) { return false; }

	//2. sheet1.xml
	m_eFile = ELXLSX_SHEET1;

	int i_list=1;
	
	bool f_exists;

	sprintf_s(sz_full, MAX_PATH, "%s\\*.xml", m_sz_path_UNZIP);

	do
	{
		sprintf_s(sz_file, MAX_PATH, "sheet%d.xml", i_list);

	 f_exists = IsFileExists(sz_full, sz_file);	

		if (f_exists)
		{
			sprintf_s(sz_file, MAX_PATH, "%s\\sheet%d.xml", m_sz_path_UNZIP, i_list);
				
	  if (XML_Parse(sz_file, this, CXLSX_in_tag_FN_READ, CXLSX_out_tag_FN_READ) == false) { return false; }

			i_list++;
		}
	}while(f_exists);

	ClearFolder();

	return true;
}

/*bool CLoadXLSX::FindByDevice(const char *sz_dev, SATE3Row* *p_row)
{
	bool fFound = false;

	for (int i = 0; fFound == false && i < s_rows.size(); i++)
	{
		SATE3Row& rL= s_rows[i];

		if (rL.sz_device == sz_dev) { fFound = true; if (p_row) { *p_row = &rL; } }
	}

	return fFound;
}*/

void SXLSX::Add(const SXLSXRow& row)
{
	m_rows.push_back(row);
}

