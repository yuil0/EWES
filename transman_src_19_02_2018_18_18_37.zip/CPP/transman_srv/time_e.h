#ifndef _time_e_h_
#define _time_e_h_
#include <time.h>

namespace time_e
{
	bool GetCurLocalDateTime(struct tm& tmOut);

	struct SLocalTimeToTextParam
	{
		bool fDateOnly;
		time_t time_diff;
	};

	bool LocalTimeToText(char *sz_text, int i_max, char ch_replace=0, SLocalTimeToTextParam* pParam=0);

	//////////////////////////////////////////////////
	class CTimeOut
	//
	{
		time_t time_prev;
		time_t time_delta;
	public:
		CTimeOut(time_t time_delta_new);
		bool IsOver(time_t time);
	};
}

#endif