#include <memory.h>
#include "ATE3.h"
#include <stdio.h> //#include <odbcinst.h>
#include <fcntl.h>
#include <io.h>
#include <sys/stat.h>

#include "mes_log.h"

#include <compressapi.h>
#include "xml_parser.h"
#include "str.h"
#include "file.h"

#include "..\\transman\\mssql.h"
#include "..\\transman\\ini_file.h"

const int ci_ATE3_sleep = 800;


void SATE3Row_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	if (eState == EMSSQLS_START) { gMesLog.Mes("SATE3Row(). MS SQL : ��� �����"); }
	else
	{
		if (sz_text)
		{
			gMesLog.Mes("SATE3Row. MS SQL error: %s", sz_text);
		}
		else
		{
			gMesLog.Mes("SATE3Row. MS SQL error:");
		}
	}
}

void CATE3::SLoadParam::Clear()
{
	memset(this, 0, sizeof(CATE3::SLoadParam));

	m_shared_strings.clear();

	m_rows.clear();
}

bool CATE3::Open()
{
	m_fInit = false;

	LoadFromDB();

	if (CrThread() == false) { return false; } //if (FindDriver() == false) { return false; }

	m_fInit = true;

	return m_fInit;
}


void CATE3::Close()
{
	
}

DWORD WINAPI CATE3_ThreadProc(LPVOID lpParameter)
{
	CATE3 *p_this = (CATE3 *)lpParameter;

	if (p_this == 0) { return 0; }

	while (1)
	{
		p_this->Read();

		Sleep(ci_ATE3_sleep);
	}

	return 1;
}


bool CATE3::CrThread()
{
	HANDLE h=CreateThread(0, 0, CATE3_ThreadProc, (LPVOID)this, 0, 0);

	return  h != 0;
}

/*void CATE3_FN_MSSQL_EXCEPTION(EMSSQLExceptionPlace ePlace, LPCWSTR ErrorMessage)
{
	char sz_err[MAX_PATH + 1];

	memset(sz_err, 0, MAX_PATH);

	int iWritten = WideCharToMultiByte(CP_ACP, 0, ErrorMessage, lstrlen(ErrorMessage), sz_err, MAX_PATH, 0, 0); //CP_UTF8

	if (iWritten == 0) { return; }

	gMesLog.Mes("������  ������ ATP3.xlsx : %s", sz_err);
}

bool CATE3::ReadFile(char* *buf, int& len, char* *buf_u, int& len_u, double dRatio)
{
	bool fRes = false;

	int fi = open("C:\\transman\\from_ate_3\\ATP3.xlsx", O_RDONLY | O_BINARY);

	if (fi < 0) { gMesLog.Mes("������ �������� �����"); return false; }

	len = filelength(fi);

	if (len==0) { gMesLog.Mes("���� ����"); }
	else
	{ 
		*buf = new char[len];

		if (*buf==0) { gMesLog.Mes("������ �� ������"); }
		else
		{
			int iReaded = read(fi, *buf, len);

			if (iReaded!=len) { gMesLog.Mes("������ �������� ��������"); }
			else
			{
				len_u = len*dRatio;

				*buf_u = new char[len_u];

				if (*buf_u == 0) { gMesLog.Mes("������ ������ �� ������"); }
				else
				{
					fRes = true;
				}				
			}
		}
	}

	close(fi);

	return fRes;
}*/


//<row r="1" spans="1:5" s="1" customFormat="1" x14ac:dyDescent="0.25"><c r="A1" s="1" t="s"><v>161</v></c><c r="B1" s="1" t="s"><v>162</v></c><c r="C1" s="1" t="s"><v>163</v></c><c r="D1" s="1" t="s"><v>164</v></c><c r="E1" s="1" t="s"><v>165</v></c></row>
//<row r = "2" spans = "1:5" x14ac:dyDescent = "0.25"><c r = "A2" t = "s"><v>0< / v>< / c><c r = "B2" t = "s"><v>1< / v>< / c><c r = "C2"><v>77< / v>< / c><c r = "D2" t = "s"><v>2< / v>< / c><c r = "E2" t = "s"><v>3< / v>< / c>< / row>
//<si><t>��� - 3 "�����������"< / t>< / si>
void CATE3::SLoadParam::ReadTag(int index, char *sz_text, int len_text)
{
	if (m_eFile == EATE3F_SHARED_STRINGS)
	{
		if (index == 0)
		{   //YUIL ������ ��� ��� ����
			if (!stricmp(sz_text, "t")) 
			{ m_f_shared_string = true; }
		}
	}
	else
	if (m_eFile == EATE3F_SHEET1)
	{
		if (index == 0)
		{   //YUIL ������ ��� ��� ����
			if (!stricmp(sz_text, "row")) 
			{ 
				m_f_row = true; //if (m_q_in_rows) {  }
				
				m_eRowField = EATE3RF_AGENT; //������ �����

				m_q_in_rows++; 

				m_q_in_cols = 0;
			}
			else
			if (!stricmp(sz_text, "/row")) 
			{ 
				m_f_row = false; 

				m_rows.push_back(m_row);
			}
			else
			{
				if (m_f_row)
				{
					if (!stricmp(sz_text, "c")) { m_f_col = true; m_eCol = EATE3C_DIRECT; m_q_in_cols++; }
					else
					if (!stricmp(sz_text, "/c")) { m_f_col = false; }
				}

				if (m_f_col)
				{
					if (!stricmp(sz_text, "v")) 
					{ m_f_val = true; }
				}
			}
		}
		else
		{
			Check(sz_text);
		}
	}
}

void CATE3::SCellName::Set(char *sz_text)
{
	memset(this, 0, sizeof(CATE3::SCellName));

	if (sz_text == 0) { return; }
	
	int i_len_text = strlen(sz_text);
	
	if (i_len_text == 0) { return; }

	bool fNum = false;
	int iPosNum=0;

	for (int i=0; i<i_len_text; i++)
	{
		char c= sz_text[i];

		if (fNum == false)
		{
			if (c >= '0' && c <= '9')
			{
				char ch = sz_text[i]; sz_text[i]=0;
				
				strcpy_s(name, ci_cell_name_len, sz_text);

				sz_text[i] = ch;
				//
				fNum = true;
				iPosNum = i;
			}
		}
		else
		{
			if (!(c >= '0' && c <= '9')) 
			{ 
				char ch = sz_text[i]; sz_text[i] = 0;

				index = atoi(sz_text + iPosNum);

				sz_text[i] = ch;
				//
				break; 
			}
		}
	}

	if (index == 0) { index = atoi(sz_text + iPosNum); }
	
	i_name_len = strlen(name);
}

void CATE3::SCellName::operator=(SCellName& o)
{
	strcpy_s(name, ci_cell_name_len, o.name);

	index = o.index;
	
	i_name_len = strlen(name);
}

void CATE3::SLoadParam::Check(char *sz_text)
{
	char sz_param[MAX_PATH + 1];
	char sz_val[MAX_PATH + 1];

	XML_GetParamVal(sz_text, sz_param, sz_val, MAX_PATH);

	if (!stricmp("r", sz_param))
	{
		if (strlen(sz_val))
		{
			SCellName o(sz_val);

			if (stricmp(o.name,  "A") && o.i_name_len == 1 && m_cellName.i_name_len == 1)
			{
				int q_pass_cell = o.name[0] - m_cellName.name[0] - 1; //YUIL ����������: ������� ������ ��� ������.

				for (int i = 0; i < q_pass_cell; i++) 
				{ SetRowField(0); }  //������� ������ ��� ������.
			}

			m_cellName = o;
		}
	}
	else
	if (!stricmp(sz_param, "t"))
	{
		if (!stricmp(sz_val, "s"))
		{
			m_eCol = EATE3C_SHARED_STRING;
		}
	}

}

void CATE3::SLoadParam::ReadOutTag(char *sz_text, int len_text)
{
	const int ci_max = 255;

	/*EATE3File& m_eFile = m_load_param.m_eFile;
	bool& m_f_shared_string = m_load_param.m_f_shared_string;
	bool& m_f_val = m_load_param.m_f_val;
	int& m_q_in_cols = m_load_param.m_q_in_cols;*/
	
	if (m_eFile == EATE3F_SHARED_STRINGS)
	{
		if (m_f_shared_string)
		{
			m_f_shared_string = false;

			char sz_trans[ci_max + 1];

			convert_from_UTF8(sz_text, sz_trans);

			m_shared_strings.push_back(sz_trans);
		}
	}
	else
	if (m_eFile == EATE3F_SHEET1)
	{
		if (m_f_val)
		{
			m_f_val = false;

			SetRowField(sz_text); //if (m_q_in_cols > 1){}
		}
	}
}

void CATE3::SLoadParam::SetRowField(char *sz_text)
{
	char *p_in= sz_text;

	/*EATE3Col& m_eCol = m_load_param.m_eCol;
	EATE3RowField& m_eRowField = m_load_param.m_eRowField;
	SATE3Row& m_row = m_load_param.m_row;
	bool& m_f_row = m_load_param.m_f_row;*/

	if (m_eCol == EATE3C_SHARED_STRING && sz_text)
	{
		int index_string = atoi(sz_text);

		p_in = (char *)m_shared_strings[index_string].c_str();
	}

	if (m_eRowField == EATE3RF_AGENT)
	{
		m_row.agent_name = p_in;

		m_eRowField = EATE3RF_DEVICE;
	}else
	if (m_eRowField == EATE3RF_DEVICE)
	{
		m_row.sz_device = p_in;

		m_eRowField = EATE3RF_GARAGE_NUM;
	}
	else
	if (m_eRowField == EATE3RF_GARAGE_NUM)
	{
		m_row.sz_garage_num = p_in;

		m_eRowField = EATE3RF_MARK;
	}
	else
	if (m_eRowField == EATE3RF_MARK)
	{
		m_row.sz_mark = p_in;

		m_eRowField = EATE3RF_STATE_NUM;
	}
	else
	if (m_eRowField == EATE3RF_STATE_NUM)
	{
		m_row.sz_state_num = p_in;

		m_eRowField = EATE3RF_AGENT; //�� ����������
	}	
}

/*void CATE3::ReadTag(int index, char *sz_text, int len_text)
{
	m_load_param.ReadTag(index, sz_text, len_text);
}*/

void CATE3_FN_READ_TAG(void  *p_param, int index, char *sz_text, int len_text)
{
	if (p_param == 0) { return; }

	CATE3  *p_this = (CATE3  *)p_param;

	p_this->GetLoadParam().ReadTag(index, sz_text, len_text); //ReadTag(index, sz_text, len_text);
}

void CATE3_in_tag_FN_READ(void  *p_param, char *sz_text, int len_text)
{
	const int ci_max = 512;

	char sz[ci_max];

	if (XML_DelUnusedChars(sz_text, sz, ci_max) == false) 
	{ 
		gMesLog.Mes("CATE3_in_tag_FN_READ(). ������ ���."); 
	 return; 
	}

	XML_ParseTag(sz, p_param, CATE3_FN_READ_TAG);
}

void CATE3_out_tag_FN_READ(void  *p_param, char *sz_text, int len_text)
{
	if (p_param == 0) { return; }
	
	const int ci_max = 512;

	char sz[ci_max];

	if (XML_DelUnusedChars(sz_text, sz, ci_max) == false)
	{ 
		gMesLog.Mes("CATE3_in_tag_FN_READ(). ������ ���."); 
		return; 
	}

	CATE3  *p_this = (CATE3  *)p_param;

	p_this->GetLoadParam().ReadOutTag(sz, strlen(sz));

}

bool CATE3::CreateBatFile(char *sz_path, char *sz_file, char *sz_xlsx_file)
{
	char sz_full[MAX_PATH + 1]; sprintf_s(sz_full, MAX_PATH, "%s\\%s", sz_path, sz_file);

	//1.del
	unlink(sz_full);

	//2.cr
	FILE* fo = fopen(sz_full, "wb");
	if (fo == 0) { return false; }

	fprintf(fo, "set path=%cpath%c;C:\\Program Files\\7-Zip;\r\n\r\n", '%', '%');

	fprintf(fo, "7z.exe e %s -oUNZIP\r\n", sz_xlsx_file);
	fclose(fo);

	return true;
}

void CATE3::Read()
{
	const char * csz_path_ate_3 = "C:\\transman\\from_ate_3";
	const char * csz_path_ate_3_UNZIP = "C:\\transman\\from_ate_3\\UNZIP";
	const char * csz_path_ate_3_UNZIP_sharedStrings_xml = "C:\\transman\\from_ate_3\\UNZIP\\sharedStrings.xml";
	const char * csz_path_ate_3_UNZIP_sheet1_xml = "C:\\transman\\from_ate_3\\UNZIP\\sheet1.xml";
	char* sz_bat_file = "unzip_xlsx.bat";

	char sz_path_xlsx_file[ci_q_ATE_file][MAX_PATH+1]; 
	char sz_xlsx_file[ci_q_ATE_file][MAX_PATH + 1]; 
	
	CIniFile ini;

	if (ini.Get("c:\\transman\\transman.ini", "car_list", sz_xlsx_file[0], MAX_PATH)) {}
	else
	{ strcpy_s(sz_xlsx_file[0], MAX_PATH, "ATP3.xlsx"); }

	sprintf_s(sz_path_xlsx_file[0], MAX_PATH, "C:\\transman\\from_ate_3\\%s", sz_xlsx_file[0]);

	if (IsFileExists(sz_path_xlsx_file[0], sz_xlsx_file[0]) == false)
	{ return; }

	m_load_param.Clear();                                   //UINT uRes = WinExec("\"C:\\Program Files\\7-Zip\\7zG.exe\" e C:\\transman\\from_ate_3\\ATP3.xlsx -oUNZIP", SW_SHOW); //If the function succeeds, the return value is greater than 31.

	ClearFolder((char*)csz_path_ate_3_UNZIP, "*.*");

	BOOL fSet= SetCurrentDirectoryA(csz_path_ate_3);

	if (fSet == FALSE) { gMesLog.Mes("������ ��������� ������� �����"); return; }

	if (CreateBatFile((char*)csz_path_ate_3, sz_bat_file, sz_xlsx_file[0]) == false) { gMesLog.Mes("CATE3::Read(). �� ������ ���� '%s\\%s'.", csz_path_ate_3, sz_bat_file); }

	UINT uRes = WinExec(sz_bat_file, SW_SHOW); //UINT uRes = WinExec("\"C:\\Program Files\\7-Zip\\7zG.exe\" e C:\\transman\\from_ate_3\\ATP3.xlsx -oUNZIP", SW_SHOW); //If the function succeeds, the return value is greater than 31.

	Sleep(1000);

	if (uRes <= 31) { gMesLog.Mes("������ �������� ����������"); }

	EATE3File& m_eFile= m_load_param.m_eFile;

	//1. sharedStrings.xml
	m_eFile = EATE3F_SHARED_STRINGS;

	if (XML_Parse((char *)csz_path_ate_3_UNZIP_sharedStrings_xml, this, CATE3_in_tag_FN_READ, CATE3_out_tag_FN_READ) == false) { gMesLog.Mes("ATE3. Error parse sharedStrings_xml"); return; }

	//2. sheet1.xml
	m_eFile = EATE3F_SHEET1;

	if (XML_Parse((char *)csz_path_ate_3_UNZIP_sheet1_xml, this, CATE3_in_tag_FN_READ, CATE3_out_tag_FN_READ) == false) 
	{ gMesLog.Mes("ATE3. Error parse sheet1_xml"); return; }

	int q_file = 1;
	
	m_load_param.ReportToFile();

	m_load_param.SaveToDB();

	//CopyToArch((char*)csz_path_ate_3, (char**)sz_xlsx_file, (int)ci_q_ATE_file); //YUIL �������� � �����

	ClearFolder((char*)csz_path_ate_3_UNZIP, "*.*");

	unlink(sz_xlsx_file[0]);

	gMesLog.Mes("���� %s ��������. ������� : %d", sz_xlsx_file[0], m_load_param.m_rows.size());
}

bool CATE3::SLoadParam::FindByDevice(const char *sz_dev, SATE3Row* *p_row)
{
	bool fFound = false; //const char * csz_file = "C:\\transman\\from_ate_3\\FindByDevice.txt"; //unlink(csz_file); //FILE* fo = 0;  //fopen_s(&fo, csz_file, "wb");
	
	int i;
	int q = m_rows.size();

	for (i = 0; fFound == false && i < q; i++)
	{
		SATE3Row& rL= m_rows[i]; //if (fo) { fprintf_s(fo, "[%04d] rL.sz_device:'%s' sz_dev='%s'\r\n", i + 1, rL.sz_device.c_str(), sz_dev); }

		if (rL.sz_device == sz_dev) { fFound = true; if (p_row) { *p_row = &rL; } }
	}                         //fclose(fo);

	return fFound;
}

void CATE3::SLoadParam::ReportToFile()
{
	char* sz_file= "C:\\transman\\from_ate_3\\report_load_slsx.txt";

	unlink(sz_file);

	FILE *fo = 0; fopen_s(&fo, sz_file, "wb");

	if (fo == 0) { gMesLog.Mes("CATE3::ReportToFile(). ���� ������ ������ �� ������"); return;  }

	for (int i = 0; i < m_rows.size(); i++)
	{
		SATE3Row& o = m_rows[i];

		fprintf_s(fo, "%04d agent_name:'%s' device:'%s' garage_num:'%s' mark:'%s' state_num:'%s'\r\n", i+1, o.agent_name.c_str(), o.sz_device.c_str(), o.sz_garage_num.c_str(), o.sz_mark.c_str(), o.sz_state_num.c_str());
	}

	fclose(fo);
}

void CATE3::SLoadParam::SaveToDB()
{
	char* sz_file_sql_query_add = "C:\\transman\\from_ate_3\\sql_query.txt";

	unlink(sz_file_sql_query_add);

	//<q1
	char sz_cmd[MAX_PATH]; strcpy_s(sz_cmd, MAX_PATH, "DELETE FROM dbo.ate_3_book;;");
	
	bool fSave = MSSQL_Exec(sz_cmd, NULL, SATE3Row_FN_MSSQL_MES_ERR, this);
	//>q1

	for (int i = 1; i < m_rows.size(); i++)
	{
		SATE3Row& rL = m_rows[i];

		rL.SaveToDB(sz_file_sql_query_add);

		Sleep(1);
	}
}


void SATE3Row::SaveToDB(char* sz_file_sql_query_add)
{
	const int ci_len = 1024;
	
	char sz_cmd[ci_len]; strcpy_s(sz_cmd, ci_len, "EXEC dbo.P_add_ate_3_book");
	
	if (sz_device.size())
	{
		strcat_s(sz_cmd, ci_len, " @device_number=N'"); 
		strcat_s(sz_cmd, ci_len, sz_device.c_str()); 
		strcat_s(sz_cmd, ci_len, "'");
	}

	if (sz_garage_num.size())
	{
		strcat_s(sz_cmd, ci_len, ", @garage_num=N'"); 
		strcat_s(sz_cmd, ci_len, sz_garage_num.c_str()); 
		strcat_s(sz_cmd, ci_len, "'");
	}

	if (sz_mark.size())
	{
		strcat_s(sz_cmd, ci_len, ", @mark=N'"); 
		strcat_s(sz_cmd, ci_len, sz_mark.c_str());  
		strcat_s(sz_cmd, ci_len, "'");
	}

	if (sz_state_num.size())
	{
		strcat_s(sz_cmd, ci_len, ", @state_num=N'"); 
		strcat_s(sz_cmd, ci_len, sz_state_num.c_str()); 
		strcat_s(sz_cmd, ci_len, "'");
	}

	if (agent_name.size())
	{
		strcat_s(sz_cmd, ci_len, ", @agent_name=N'"); 
		strcat_s(sz_cmd, ci_len, agent_name.c_str()); 
		strcat_s(sz_cmd, ci_len, "'");
	}

	strcat_s(sz_cmd, ci_len, ";;");

	if (strstr(sz_cmd, ";;") == 0) 
	{ gMesLog.Mes("SATE3Row::SaveToDB(). ��� ����� ������ SQL �������");  return; }

	FILE *fo = 0; fopen_s(&fo, sz_file_sql_query_add, "ab");
	if (fo) { fprintf_s(fo, "%s\r\n", sz_cmd); fclose(fo); }

	bool fSave = MSSQL_Exec(sz_cmd, NULL, SATE3Row_FN_MSSQL_MES_ERR, this, "ms_con");
}

void CATE3_FN_MSSQL_ADD(void *p_param, FldsPtr fp)
{
	CATE3 * p_this = (CATE3 *)p_param;

	if (p_this == 0) { return; }

	SATE3Row row;
	
	_bstr_t bstr_agent_name(fp->Item["agent_name"]->Value);

	_bstr_t bstr_device_number(fp->Item["device_number"]->Value);

	_bstr_t bstr_garage_num(fp->Item["garage_num"]->Value);

	_bstr_t bstr_mark(fp->Item["mark"]->Value);

	_bstr_t bstr_state_num(fp->Item["state_num"]->Value);

	row.agent_name = (char*)bstr_agent_name;

	row.sz_device = (char*)bstr_device_number;

	row.sz_garage_num = (char*)bstr_garage_num;

	row.sz_mark = (char*)bstr_mark;

	row.sz_state_num = (char*)bstr_state_num;

	p_this->Add(row);
}

void CATE3::Add(const SATE3Row& row)
{
	m_load_param.m_rows.push_back(row);
}

void CATE3::LoadFromDB()
{
	std_string sz_cmd = "SELECT agent_name, device_number, garage_num, ISNULL(mark,'')mark, state_num FROM dbo.ate_3_book";
	
	m_load_param.Clear();

	bool fSave = MSSQL_Exec((char*)sz_cmd.c_str(), CATE3_FN_MSSQL_ADD, SATE3Row_FN_MSSQL_MES_ERR, this, "ms_con");

	if (fSave) 
	{ gMesLog.Mes("������� �� �� ���������: %d", m_load_param.m_rows.size()); }
	else 
	{ gMesLog.Mes("������ �� �� �� ���������d"); }
}

CATE3 gATE3;