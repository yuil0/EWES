#ifndef _FileCheckPoints_h_
#define _FileCheckPoints_h_

#include <windows.h>
#include "load_xlsx.h"
#include "..\\transman\\mssql.h"
#include "std_str.h"

typedef enum
{
	EFCP_BUS=0,
	EFCP_TRAM,
	EFCP_TROL,
	EFCP_QUANTITY,
}EFileCheckPoints;


typedef enum
{
	EFCPF_STOP_CODE=0, 
	EFCPF_NAME, 
	//
	EFCPF_QUANTITY,
}EFileCheckPointsField;

class CFileCheckPoints
{
	bool m_fInit; //bool m_found_drv[EED_QUANTITY];bool FindDriverFromBuf(char *buf, int len);bool FindDrvName(char *sz_in);

	SXLSX m_xlsx;

	EFileCheckPoints m_eFile;

	struct S_P_add_check_point_add_item
	{
		std_string route_short_name;
		std_string id_car_type;
	};

	struct S_P_add_check_point_add
	{
		int i_result;
		std_string car_type_name;
	 std::vector<S_P_add_check_point_add_item> not_list;

		void Mes(const char *route_short_name, const char *stop_code);
		bool IsNotFound() {return i_result==1 || i_result==2;}
		bool RouteIsReason(std_string& route_short_name_in,  char *sz_type_car);
		void Clear();
		void AddNotFound(const char *route_short_name_in, const char *sz_type_car_in);
		bool FindNotFound(const char *route_short_name_in, const char *sz_type_car_in);
	};
	
	S_P_add_check_point_add s_P_add_check_point_add;

	std_string m_sz_query;

	bool CrThread();

	void ReadedToFile();
	
	void SaveToDB(); //void LoadFromDB();	//bool CheckFileName(char *sz_name);

	void add_car_type(char* sz_type, int i_type_max); //char* get_sz_bat_file(std_string& sz_bat_file);

	bool CheckRoute(char *sz_in, std_string& route_short_name);

	void SaveToDB_op(std_string& route_short_name, std_string& stop_code, std_string& name, bool f_forward, int& i_order);

	void SaveToDB_in(std_string& route_short_name,  std_string& stop_code, std_string& name, bool f_forward, int i_order, char *sz_id_car_type=0);

	void set_id_car_type_del_query(std_string& sz_query);

	public:

	CFileCheckPoints() {}

	bool Open();

	void Close(); //bool FindDriver();

	void Read(EFileCheckPoints eFile);  //bool FindByDevice(const char *sz_dev, SATE3Row* *p_row);//std::vector<SATE3Row>  m_rows;

	void P_add_check_point_add(FldsPtr fp);

	void sql_err(char *sz_text);

	void WriteSQLQueryErr(char *sz_text);
};

extern CFileCheckPoints gFileCheckPoints;

#endif