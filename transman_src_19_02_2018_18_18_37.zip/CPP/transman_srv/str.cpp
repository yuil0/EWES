#include <memory.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

#include "str.h"


void convert_from_UTF8(char *sz_in, char *sz_out)
{
	if (sz_in == 0 || sz_out == 0) { return; }

	const  int c_max_pair = 2;
	const  int c_max_tri = 3;
	sz_out[0] = 0;
	int q_out = 0;
	for (int i = 0; sz_in[i]; i++)
	{
		bool  f_ch = false;

		if (sz_in[i + 2]) //YUIL ��  ���
		{
			unsigned char b[c_max_tri] = { sz_in[i] , sz_in[i + 1] , sz_in[i + 2] };

			unsigned uVal = b[2] + (((unsigned)b[1]) << 8) + (((unsigned)b[0]) << 16);

			if (uVal == 0xE28094)
			{
				sz_out[q_out] = '�';
				q_out++;
				i += 2;
				f_ch = true;
			}
			else
				if (uVal == 0xE28496)
				{
					sz_out[q_out] = '�';
					q_out++;
					i += 2;
					f_ch = true;
				}
		}

		if (f_ch == false && sz_in[i + 1]) //YUIL ��  ���
		{
			unsigned char b[c_max_pair] = { sz_in[i] , sz_in[i + 1] };

			unsigned uVal = b[1] + (((unsigned)b[0]) << 8);

			char c_out = UTF8_to(uVal);

			if (c_out)
			{
				sz_out[q_out] = c_out;
				q_out++;
				i++;
				f_ch = true;
			}
		}

		if (f_ch == false)
		{
			sz_out[q_out] = sz_in[i];
			q_out++;
		}
		sz_out[q_out] = 0;
	}
	//$D081..$D18F
}

char UTF8_to(unsigned uVal)
{
	if (uVal == 0xD090) { return '�'; }
	if (uVal == 0xD091) { return '�'; }
	if (uVal == 0xD092) { return '�'; }
	if (uVal == 0xD093) { return '�'; }
	if (uVal == 0xD094) { return '�'; }
	if (uVal == 0xD095) { return '�'; }
	if (uVal == 0xD096) { return '�'; }
	if (uVal == 0xD097) { return '�'; }
	if (uVal == 0xD098) { return '�'; }
	if (uVal == 0xD099) { return '�'; }
	if (uVal == 0xD09A) { return '�'; }
	if (uVal == 0xD09B) { return '�'; }
	if (uVal == 0xD09C) { return '�'; }
	if (uVal == 0xD09D) { return '�'; }
	if (uVal == 0xD09E) { return '�'; }
	if (uVal == 0xD09F) { return '�'; }
	if (uVal == 0xD0A0) { return '�'; }
	if (uVal == 0xD0A1) { return '�'; }
	if (uVal == 0xD0A2) { return '�'; }
	if (uVal == 0xD0A3) { return '�'; }
	if (uVal == 0xD0A4) { return '�'; }
	if (uVal == 0xD0A5) { return '�'; }
	if (uVal == 0xD0A6) { return '�'; }
	if (uVal == 0xD0A7) { return '�'; }
	if (uVal == 0xD0A8) { return '�'; }
	if (uVal == 0xD0A9) { return '�'; }
	if (uVal == 0xD0AA) { return '�'; }
	if (uVal == 0xD0AB) { return '�'; }
	if (uVal == 0xD0AC) { return '�'; }
	if (uVal == 0xD0AD) { return '�'; }
	if (uVal == 0xD0AE) { return '�'; }
	if (uVal == 0xD0AF) { return '�'; }
	if (uVal == 0xD0B0) { return '�'; }
	if (uVal == 0xD0B1) { return '�'; }
	if (uVal == 0xD0B2) { return '�'; }
	if (uVal == 0xD0B3) { return '�'; }
	if (uVal == 0xD0B4) { return '�'; }
	if (uVal == 0xD0B5) { return '�'; }
	if (uVal == 0xD0B6) { return '�'; }
	if (uVal == 0xD0B7) { return '�'; }
	if (uVal == 0xD0B8) { return '�'; }
	if (uVal == 0xD0B9) { return '�'; }
	if (uVal == 0xD0BA) { return '�'; }
	if (uVal == 0xD0BB) { return '�'; }
	if (uVal == 0xD0BC) { return '�'; }
	if (uVal == 0xD0BD) { return '�'; }
	if (uVal == 0xD0BE) { return '�'; }
	if (uVal == 0xD0BF) { return '�'; }
	if (uVal == 0xD180) { return '�'; }
	if (uVal == 0xD181) { return '�'; }
	if (uVal == 0xD182) { return '�'; }
	if (uVal == 0xD183) { return '�'; }
	if (uVal == 0xD184) { return '�'; }
	if (uVal == 0xD185) { return '�'; }
	if (uVal == 0xD186) { return '�'; }
	if (uVal == 0xD187) { return '�'; }
	if (uVal == 0xD188) { return '�'; }
	if (uVal == 0xD189) { return '�'; }
	if (uVal == 0xD18A) { return '�'; }
	if (uVal == 0xD18B) { return '�'; }
	if (uVal == 0xD18C) { return '�'; }
	if (uVal == 0xD18D) { return '�'; }
	if (uVal == 0xD18E) { return '�'; }
	if (uVal == 0xD18F) { return '�'; }
	if (uVal == 0xD001) { return '�'; }
	if (uVal == 0xD081) { return '�'; }
	if (uVal == 0xD191) { return '�'; }

	return 0;
}

void remove_double_chars(char *sz, int i_max)
{
	const int ci_max = 256;

	char sz_out[ci_max + 1] = { 0 };
	int q_out = 0;

	char *p = strstr(sz, "\"\"");
	while (p)
	{
		if (p[2] == 0) { break; }

		strcpy_s(p, i_max, p + 1);

		p = strstr(sz, "\"\"");
	}
	/*
	bool  f_ch_all = false;

	//1. ������  "" = > "
	char ch_prev=0;
	for (int i = 0; sz[i]; i++)
	{
	if ()
	{

	}
	*/
	/*
	if (sz[i]=='"')
	{
	if (ch_prev != sz[i])
	{
	sz_out[q_out] = sz[i];
	q_out++;
	sz_out[q_out] = 0;
	ch_prev = sz[i];
	}
	}else
	{
	sz_out[q_out] = sz[i];
	q_out++;
	sz_out[q_out] = 0;
	ch_prev = sz[i];
	}*/

	/*bool  f_ch = false;

	if (sz[i] == '"' && sz[i + 1] == '"')
	{
	sz_out[q_out] = '"';
	q_out++;
	i++;
	f_ch = true;
	f_ch_all = true;
	}

	if (f_ch == false)
	{
	sz_out[q_out] = sz[i];
	q_out++;
	}

	sz_out[q_out] = 0;
	*/


	//}strcpy_s(sz, sz_out);
}

void remove_first_last(char *sz, int i_max, char c_remove)
{
	const int ci_max = 256;

	char sz_out[ci_max + 1] = { 0 };

	if (strlen(sz) > ci_max) {return;}
	
	//<���� ���
	int i=0;

	for(; sz[i]==c_remove && sz[i]; i++) {}

	strcpy_s(sz_out, ci_max, sz + i); 
	
	strcpy_s(sz, i_max, sz_out);
	//>���� ���

	//<���� �����
	char *p_find=strchr(sz, c_remove);

	if (p_find) {*p_find=0;}
	//>���� �����
}

char* GetTranslit(char *sz_in, char *sz_out, int i_out_max) //i_out_max ��� ����� NULL terminator
{ //YUIL 2017-09-15 ������������������ ���� . ������ : 18� => 18l, 18� => 18p, 42�=> 42a	
	if (sz_in == 0) { return 0; }

	if (strlen(sz_in)== 0) { return 0; }
	
	int q= 0;
	
	sz_out[0] = 0;

	for (int i = 0; sz_in[i]; i++)
	{
		char c = sz_in[i];
		char c_new = c;
		if (c == '�') { c_new = 'l'; } else
		if (c == '�') { c_new = 'p'; } else
		if (c == '�') { c_new = 'a'; } else
		if (c == '�') { c_new = 'b'; } else
		
		if (c == '�') { c_new = 'L'; } else
		if (c == '�') { c_new = 'P'; } else
		if (c == '�') { c_new = 'A'; } else
		if (c == '�') { c_new = 'B'; } else
		{ }

		if (q >= i_out_max) { break; }
		sz_out[q] = c_new;
		q++;
		sz_out[q] = 0;
	}

	return sz_out;
}

void AddFormat(char *sz_buf, int i_buf_size, void *p_param, FN_OVER fn_over, char *szFormat, ...)
{
	va_list va;
	
	va_start(va, szFormat);

	int len_f = _vscprintf(szFormat, va);

	int i_len_buf = strlen(sz_buf);

	if (i_len_buf + len_f > i_buf_size) 
	{ 
		(fn_over)(p_param, sz_buf);

		sz_buf[0] = 0;
		
		i_len_buf = 0;
	}

	vsprintf(sz_buf + i_len_buf, szFormat, va); 
}

bool IsNumChar(char c)
{
	return c == '.' || (c >= '0' && c <= '9');
}

bool IsLetterChar(char c)
{
	return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
}

bool IsLetterRuChar(char c)
{
	return (c >= '�' && c <= '�') || (c >= '�' && c <= '�');
}

bool IsNum(char *sz_in, char ch_ignore)
{
	for (int i=0; sz_in[i]; i++)
	{
		char c=sz_in[i];
		if (ch_ignore)
		{
			if (ch_ignore==c) {continue;}
		}
		if (c!='.' && (c<'0' || c>'9')) { return false; }
	}	

	return true;
}

char* StrTruncByChar(char* sz_in, char cTrunc)
{
	char *p_found = strchr(sz_in, cTrunc);

	if (p_found) { *p_found = 0; }

	return sz_in;
}

char* ByteToHex(char* sz_buf, char byte, int i_max)
{
	sprintf_s(sz_buf, i_max, "%0X", byte);

	return sz_buf;
}

char* GetFileOnly(char* sz_file, char* sz_file_only, int i_file_only_max)
{
	int i_len= strlen(sz_file);

	int i_pos=-1;

	for (int i= i_len - 1; i_pos==-1 && i>=0; i--)
	{
		char c=sz_file[i];

		if (c=='\\' || c=='/') { i_pos = i; }
	}

	if (i_pos==-1) { strcpy_s(sz_file_only, i_file_only_max,  sz_file); }
	else
	{
		strcpy_s(sz_file_only, i_file_only_max,  sz_file + i_pos + 1);
	}

	return sz_file_only;
}

bool SStrList::Find(char *sz_find)
{
	bool fFound = false;

	int q = list.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		if (!stricmp(list[i].c_str(), sz_find)) { fFound = true; }
	}

	return fFound;
}

bool FindInStrList(std::vector<std_string>& list, char *sz_find, int* p_index)
{
	bool fFound = false;

	int q = list.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		if (!stricmp(list[i].c_str(), sz_find)) { fFound = true; if (p_index) { *p_index = i; } }
	}

	return fFound;
}

uchar GetHexByChar(char c)
{
	if (c=='0') { return 0; } 
	else
		if (c == '1') { return 1; }
		else
			if (c == '2') { return 2; }
			else
				if (c == '3') { return 3; }
				else
					if (c == '4') { return 4; }
					else
						if (c == '5') { return 5; }
						else
							if (c == '6') { return 6; }
							else
								if (c == '7') { return 7; }
								else
									if (c == '8') { return 8; }
									else
										if (c == '9') { return 9; }
										else
											if (c == 'A') { return 10; }
											else
												if (c == 'B') { return 11; }
												else
													if (c == 'C') { return 12; }
													else
														if (c == 'D') { return 13; }
														else
															if (c == 'E') { return 14; }
															else
																if (c == 'F') { return 15; }
}

void ReadHexStrByte(char *sz_val, uchar& part)
{
	//FF
	uchar hi= GetHexByChar(sz_val[0]);
	uchar lo = GetHexByChar(sz_val[1]);

	part = (hi << 4) + lo;
}

bool ReadHexStr(char *sz_val, ulong& color, uchar* p_part)
{
	int iLen = strlen(sz_val);

	if (iLen < 6) {return false;}
	
	enum{ B=0, G, R, QUANTITY };
	
	uchar part[QUANTITY];

	for (int i=0; i < QUANTITY; i++)
	{
		int iPos = 2 * i;

		int iPosNext = 2 * (i + 1);

		char cs = sz_val[iPosNext]; sz_val[iPosNext]=0;

		ReadHexStrByte(sz_val + iPos, part[i]);

		sz_val[iPosNext] = cs;
	}

	if (p_part)
	{ memcpy(p_part, part, 2 * QUANTITY); }

	color = ((part[B]) << 16) + ((part[G]) << 8) + (part[R]);

	return true;
}


void strcpy_y(char* dest, int i_dest_max, char *src)
{
	if (src == 0 || dest==0) { return; }

	int i_len_src = strlen(src);

	if (i_len_src > i_dest_max - 1) { i_len_src = i_dest_max - 1; }

	memcpy(dest, src, i_len_src); dest[i_len_src] = 0;
}


void set_str(char* sz, int i_max, char *sz_new)
{
	if (sz == 0 || sz_new == 0) { return; }

	int i_len_new = strlen(sz_new);

	if (i_len_new > i_max) { i_len_new = i_max; }

	memcpy(sz, sz_new, i_len_new); sz[i_len_new] = 0;
}

void add_str(char* sz, int i_max, char *sz_new)
{
	if (sz == 0 || sz_new == 0) { return; }

	int i_size = strlen(sz_new);
	
	int m = strlen(sz);

	if (m + i_size > i_max) 
	{ 
		i_size = i_max - m; 

		if (i_size <= 0) { return; }
	}	

	memcpy(sz + m, sz_new, i_size); m += i_size;
	
	sz[m] = 0;
}

char* NextSubStr(char* *p_pos, char cDevider, char* szSub)
{
	if (*p_pos == 0) { return 0; }
	if (**p_pos == 0) { return 0; }

	char *pStart = *p_pos;

	*p_pos = strchr(*p_pos, cDevider);
	
	if (*p_pos)
	{
		int size = (*p_pos) - pStart;

		memcpy(szSub, pStart, size); szSub[size] = 0;

		(*p_pos)++;
	}

	return szSub;
}