#ifndef _ATE3_h_
#define _ATE3_h_

#include <windows.h> //#pragma comment(lib, "Cabinet.lib")
#include "std_str.h"
#include <vector>


//#define SQL_NOUNICODEMAP
//#undef UNICODE

//���� ������ ����� ODBC
// ConnectionString = "Provider=MSDASQL.1;DSN = ATP3;DBQ=C:\transman\from_ate_3\ATP3.xlsx;" 
// ConnectionString = "Provider=MSDASQL.1;Data Source=ExcelVolumes"

//#pragma comment(lib, "odbccp32.lib")
const int ci_q_ATE_file=1;
const  int ci_cell_name_len = 2;

typedef enum
{
	EATE3F_SHARED_STRINGS = 0,
	EATE3F_SHEET1,
	//
	EATE3F_QUANTITY,
}EATE3File;

typedef enum
{
	EATE3RF_AGENT= 0,
	EATE3RF_DEVICE,
	EATE3RF_GARAGE_NUM,
	EATE3RF_MARK,
	EATE3RF_STATE_NUM,
	//
	EATE3RF_QUANTITY,
}EATE3RowField;

typedef enum
{
	EATE3C_NONE = 0,
	EATE3C_DIRECT,
	EATE3C_SHARED_STRING,
}EATE3Col;

struct SATE3Row
{
	std_string agent_name;
	std_string  sz_device;
	std_string  sz_garage_num;
	std_string sz_mark;
	std_string sz_state_num;

	void SaveToDB(char* sz_file_sql_query_add);
};

class CATE3
{
	bool m_fInit; //bool m_found_drv[EED_QUANTITY];bool FindDriverFromBuf(char *buf, int len);bool FindDrvName(char *sz_in);

	struct SCellName
	{
		char name[ci_cell_name_len+1];
		int index;
		int i_name_len;
		//
		SCellName() {}
		SCellName(char *sz_text) { Set(sz_text); }
		void Set(char *sz_text);
		void operator=(SCellName& o);
	};

	struct SLoadParam
	{
		EATE3File m_eFile;
		bool m_f_shared_string;
		EATE3Col m_eCol;
		bool m_f_col;   	
		EATE3RowField m_eRowField;
		bool m_f_row;
		bool m_f_val;
		SATE3Row m_row;
		int m_q_in_rows;
		int m_q_in_cols;
		//		
		SCellName m_cellName;
  //
		std::vector<std_string>  m_shared_strings;
		std::vector<SATE3Row>  m_rows;

		void ReadTag(int index, char *sz_text, int len_text);
		void Clear();
		void SetRowField(char *sz_text);
		void ReadOutTag(char *sz_text, int len_text);
		bool FindByDevice(const char *sz_dev, SATE3Row* *p_row);//std::vector<SATE3Row>  m_rows;
		void ReportToFile();
		void SaveToDB();		
		void Check(char *sz_text);
		//
		SLoadParam() {}
	};

	SLoadParam m_load_param;
	
	bool CrThread(); //bool ReadFile(char* *buf, int& len, char* *buf_u, int& len_u, double dRatio=10);
	
	
	void LoadFromDB();	
	bool CreateBatFile(char *sz_path, char *sz_file, char *sz_xlsx_file);
	
	public: 
	CATE3() {} //; ~CATE3();

	bool Open();
	void Close(); //bool FindDriver();

	SLoadParam& GetLoadParam() { return (SLoadParam&)m_load_param;}

	void Read(); //void ReadTag(int index, char *sz_text, int len_text);
	
	void Add(const SATE3Row& row);
};

bool ClearFolder(char *sz_path, char *sz_mask);

extern CATE3 gATE3;

#endif