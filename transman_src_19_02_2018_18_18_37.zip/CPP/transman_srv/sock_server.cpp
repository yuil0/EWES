#include "sock_server.h"

#undef UNICODE

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#include "main.h"
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>

#include "mes_log.h"
#include "FromPicas.h"

#include "..\\transman\\ini_file.h"

#pragma comment (lib, "Ws2_32.lib")// #pragma comment (lib, "Mswsock.lib")

#define DEFAULT_BUFLEN 1024
#define DEFAULT_PORT "50505" //const char *g_sock_addr = "77.95.94.9";

CSockServer::CSockServer() {}

CSockServer::~CSockServer() {}

bool CSockServer::Open()
{	
	memset(this, 0, sizeof(CSockServer));
	
	m_fInit = true;

	Listen();

	return m_fInit;
}

void CSockServer::Close() {}

DWORD WINAPI FnListen(LPVOID param);

void CSockServer::Listen()
{
	DWORD dwCreationFlags = 0;

	DWORD dThreadId = 0;

	m_i_done = 1;

	HANDLE h = CreateThread(0, 0, FnListen, (LPVOID)this, dwCreationFlags, &dThreadId);

	if (h == 0) { gMesLog.Mes("Error of creating thread"); }
}

////////////////////////////////////////////////////////////////////////////////////
DWORD WINAPI FnListen(LPVOID param)
{
	CSockServer *p_this = (CSockServer *)param;

	if (p_this==0) {  gMesLog.Mes("������. ������ ��������� � ������.");  return 1;}

	WSADATA wsaData;

	int iResult;

	SOCKET ListenSocket = INVALID_SOCKET;

	SOCKET ClientSocket = INVALID_SOCKET;

	struct addrinfo *result = NULL;

	struct addrinfo hints;

	int iSendResult;

	char recvbuf[DEFAULT_BUFLEN+1];  //YUIL +1 ��� ���� �����������
	
	char sz_mes[DEFAULT_BUFLEN+1];  //YUIL +1 ��� ���� �����������

	int recvbuflen = DEFAULT_BUFLEN;

	//<q1 Initialize Winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData); 

	if (iResult != 0) { gMesLog.Mes("WSAStartup() failed with error: %d\n", iResult); return 1; }
	//>q1

	//<q2  Resolve the server address and port
	ZeroMemory(&hints, sizeof(hints));

	hints.ai_family = AF_INET;

	hints.ai_socktype = SOCK_STREAM;

	hints.ai_protocol = IPPROTO_TCP;

	hints.ai_flags = AI_PASSIVE;
	
	iResult = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result);

	if (iResult != 0) { gMesLog.Mes("getaddrinfo() failed with error: %d\n", iResult); WSACleanup(); return 1; }
	//>q2
	
	//<q3 Create a SOCKET for connecting to server
	ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol); 

	if (ListenSocket == INVALID_SOCKET) { gMesLog.Mes("socket() failed with error: %ld\n", WSAGetLastError()); freeaddrinfo(result); WSACleanup(); return 1; }
	//>q3
	
	//<q4 Setup the TCP listening socket
	iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen); 

	if (iResult == SOCKET_ERROR) { gMesLog.Mes("bind() failed with error: %d\n", WSAGetLastError()); freeaddrinfo(result); closesocket(ListenSocket); WSACleanup(); return 1; }

	freeaddrinfo(result);
	//>q4

	CATE3Load cATE3Load(2* DEFAULT_BUFLEN);

	p_this->SetATE3Load(&cATE3Load);

	/*//<w1
	std::string sz_probe = "$2017-08-24,09:14:48,M166OH,47.273792,39.757253,124,26$";

	if (cATE3Load.Test((char*)sz_probe.c_str(), strlen(sz_probe.c_str())))
	{
		cATE3Load.Read((char*)sz_probe.c_str(), strlen(sz_probe.c_str())); //YUIL ���-3
	}
	//>w1*/


	gMesLog.Mes("socket server: start");

	const long cl_max_value = 128;
	
	char sz_val[cl_max_value + 1];
	
	time_t time_period_rep_sock_recv = 3600;

	time_t t_prev = 0;

	int i_cnt_recv_bytes = 0;

	//<ini	
	CIniFile cIniFile;
	if (cIniFile.Get("C:\\transman\\transman.ini", "time_period_rep_sock_recv", sz_val, cl_max_value)) { time_period_rep_sock_recv = (time_t)atoi(sz_val); }
	//>ini


	//<q5 cycle listen and accept
	while (p_this->GetDone())
	{
		iResult = listen(ListenSocket, 30);//SOMAXCONN

		if (iResult == SOCKET_ERROR) 
		{ gMesLog.Mes("listen() failed with error: %d\n", WSAGetLastError()); closesocket(ListenSocket); WSACleanup(); return 1; }

		
		struct sockaddr addr_client;
		int len_addr_client = sizeof(sockaddr);

		ClientSocket = accept(ListenSocket, &addr_client, &len_addr_client); // Accept a client socket

		if (ClientSocket == INVALID_SOCKET) 
		{ gMesLog.Mes("accept() failed with error: %d\n", WSAGetLastError()); closesocket(ListenSocket); WSACleanup(); return 1; }		
		else
		{

			memset(sz_mes,  0, DEFAULT_BUFLEN + 1);
			
			char *ch_data = addr_client.sa_data;			

			int ip[4] = { (int)ch_data[2], (int)ch_data[3], (int)ch_data[4], (int)ch_data[5]};  //bool fLocalAddr = ip[0] == 127 && ip[1] == 0 && ip[2] == 0 && ip[3] == 1;

			char sz_loc[4];

			for (int i=0; i<4; i++)
			{
				int uval = ip[i];// +(fLocalAddr ? 0 : 256);// (int)addr_client.sa_data[i];

				if (uval < 0) { uval += 256; }

				itoa(uval, sz_loc, 10);
				
				if (i > 0) { strcat_s(sz_mes, DEFAULT_BUFLEN, "."); }

				strcat_s(sz_mes, DEFAULT_BUFLEN, sz_loc);
			}
			gMesLog.Mes("accepted %s\n", sz_mes);
		}
		
		do  // Receive until the peer shuts down the connection
		{

			memset(recvbuf, 0, recvbuflen + 1); //YUIL +1 ��� ���� �����������

			iResult = recv(ClientSocket, recvbuf, recvbuflen, 0);
			
			AppendToFile("C:\\transman\\from_ate_3\\in.txt", iResult, recvbuf);

			if (iResult > 0) 
			{
				if (cATE3Load.Test(recvbuf, iResult))
				{
					cATE3Load.Read(recvbuf, iResult, DEFAULT_BUFLEN); //YUIL ���-3
				}

				//<q2
				time_t t = clock()/ CLOCKS_PER_SEC;

				i_cnt_recv_bytes += iResult;

				if (t - t_prev > time_period_rep_sock_recv)
				{
					gMesLog.Mes("Received %d bytes", i_cnt_recv_bytes);//time_period_rep_sock_recv, 

					i_cnt_recv_bytes = 0;

					t_prev = t;
				}				
				
				//>q2				
			}
			else 
			if (iResult == 0) { }				
			else 
			{ gMesLog.Mes("recv() failed with error: %d\n", WSAGetLastError()); /*closesocket(ClientSocket); WSACleanup(); return 1;*/ }

			Sleep(2);

		} while (iResult > 0);

		
		iResult = shutdown(ClientSocket, SD_SEND); // shutdown the connection since we're done

		if (iResult == SOCKET_ERROR) { gMesLog.Mes("shutdown() failed with error: %d\n", WSAGetLastError()); closesocket(ClientSocket); WSACleanup(); return 1; }

		Sleep(5);
	}

	
	//<q99 cleanup
	closesocket(ListenSocket); // No longer need server socket

	closesocket(ClientSocket);

	WSACleanup();
	//>q99

	gMesLog.Mes("Listen finsh");

	return 0;
}

