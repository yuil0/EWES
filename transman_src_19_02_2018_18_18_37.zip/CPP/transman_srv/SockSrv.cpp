#include "SockSrv.h"

#undef UNICODE

#define WIN32_LEAN_AND_MEAN

#include <windows.h>

#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#include "main.h"
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include <winsock2.h>
#include "mes_log.h"
#include "..\\transman\\ini_file.h"
#include "str.h"

#pragma comment (lib, "Ws2_32.lib")

CSockSrv::CSockSrv() {} //bool CSockSrv::Open(char* sz_port_new){return OpenOp(sz_port_new);}

bool CSockSrv::OpenOp(char* sz_port_new, void *p_param, FN_SOCK_SRV_ON_READ fn)
{
	//UINT_PTR i;SOCKET s;

	memset(this, 0, sizeof(CSockSrv));

	m_port = sz_port_new;

	time_period_rep_sock_recv = 3600;

	m_fInit = true;

	m_p_param = p_param;
	
	m_fn = fn;

	//InitializeCriticalSection(&m_cs_th_read);

	Read_time_period_rep_sock_recv_from_ini();

	Listen();

	//CrThRead();

	return m_fInit;
}

void CSockSrv::Close()
{
	//DeleteCriticalSection(&m_cs_th_read);
}

DWORD WINAPI CSockSrv_Listen(LPVOID param)
{
	CSockSrv* p_this = (CSockSrv*)param;

	if (p_this) { p_this->ListenOp(); }

	return 1;
}

void CSockSrv::Listen()
{
	DWORD dwCreationFlags = 0;

	DWORD dThreadId = 0;

	HANDLE h = CreateThread(0, 0, CSockSrv_Listen, (LPVOID)this, dwCreationFlags, &dThreadId);

	if (h == 0) { gMesLog.Mes("CSockSrv::Listen(). Error of creating thread. port: %s", m_port.c_str()); }
}

////////////////////////////////////////////
//
DWORD WINAPI CSockSrv_SClient_CrThRead(LPVOID param)
{
	CSockSrv::SClient* p_this = (CSockSrv::SClient*)param;

	if (p_this == 0) { return 0; }

	p_this->Read(); 

	return 1;
}

void CSockSrv::SClient::CrThRead()
{
	CreateThread(0, 0, CSockSrv_SClient_CrThRead, (LPVOID)this, 0, 0);
}

void CSockSrv::SClient::Read()
{
	/*const int ci_port_len = 10;

	char sz_port[ci_port_len + 1]; 
	
	strcpy_s(sz_port, ci_port_len, m_port.c_str());*/
	
	char* sz_port = (char*)m_port.c_str();

	gMesLog.Mes("CSockSrv::SClient::Read(). recv(). Start thread. port: %s IP:%s sock: %d.\n", sz_port, ip, s);

	char buf[ci_socksrv_buf_len];

	int iResult; //bool fData = false; 
	
	int i_CycleCount = 0; int i_MaxCycleCount = 300; //u_long uBytesToRead;

	u_long uNonBlockingMode=1;

	int i_res_ioctl = ioctlsocket(s, FIONBIO, &uNonBlockingMode);

	do
	{
		/*int i_res_ioctl = ioctlsocket(s, FIONREAD, &uBytesToRead);
		if (i_res_ioctl)
		{
			gMesLog.Mes("CSockSrv::SClient::Read(). FAIL  ioctlsocket(). port: %s IP:%s sock: %d. i_res_ioctl:%d\n", m_port.c_str(), ip, s, i_res_ioctl);
			break;
		}
		
		if (uBytesToRead <= 0) 
		{
			gMesLog.Mes("CSockSrv::SClient::Read(). ioctlsocket(). port: no  data. %s IP:%s sock: %d.\n", m_port.c_str(), ip, s);
			break;
		}*/

		fd_set read_s; // ���������

		timeval time_out; // �������

		FD_ZERO(&read_s); // �������� ���������

		FD_SET(s, &read_s); // ������� � ���� ��� �����

		time_out.tv_sec = 30; 
		
		time_out.tv_usec = 30000000;

		iResult = select(0, &read_s, NULL, NULL, &time_out);

		if (SOCKET_ERROR == iResult)
		{
			gMesLog.Mes("CSockSrv::SClient::Read(). Fail select(). port: %s IP:%s sock: %d. err: %d\n", sz_port, ip, s, WSAGetLastError()); break;
		}else
		if (0 == iResult)
		{
			gMesLog.Mes("CSockSrv::SClient::Read(). Fail select(). port: %s IP:%s sock: %d. timeout\n", sz_port, ip, s); break;
		}

		memset(buf, 0, ci_socksrv_buf_len);

		iResult = recv(s, buf, ci_socksrv_buf_len, 0);

		if (iResult == SOCKET_ERROR)
		{
			int i_err = WSAGetLastError();

			if (i_err == WSAEWOULDBLOCK)
			{ continue;}
		}else
	 if (iResult > 0)
		{ 
			int fo = open("C:\\transman\\SockSrv\\in.bin", O_CREAT | O_WRONLY | O_BINARY, S_IREAD | S_IWRITE);

			if (fo >= 0) { write(fo, buf, ci_socksrv_buf_len); close(fo); } //m_len_buf = iResult;

			if (m_fn)
			{
				(m_fn)(m_p_param, s, buf, ci_socksrv_buf_len);  //Use(); Answer(i_client_sock);
			}                                     

																																									
		}else
		if (iResult == 0)
		{
			gMesLog.Mes("CSockSrv::SClient::Read(). recv(). No data. port: %s. sock: %d\n", sz_port, s); break;
		}
		else
		{
			gMesLog.Mes("CSockSrv::SClient::Read(). recv() failed with error: %d. port: %s. sock: %d\n", WSAGetLastError(), sz_port, s); break;
		}

		//i_CycleCount++;

	} while (i_CycleCount < i_MaxCycleCount);  //iResult>0 && 

	gMesLog.Mes("CSockSrv::SClient::Read(). recv(). Finish thread. port: %s IP:%s sock: %d. %s\n", sz_port, ip, s, i_CycleCount == i_MaxCycleCount?"over count":"");

	shutdown_closesocket(s);
}

void CSockSrv::Read_time_period_rep_sock_recv_from_ini()
{	
	const long cl_max_value = 128;
	char sz_val[cl_max_value + 1];
	CIniFile cIniFile;
	if (cIniFile.Get("C:\\transman\\transman.ini", "time_period_rep_sock_recv", sz_val, cl_max_value)) { time_period_rep_sock_recv = (time_t)atoi(sz_val); }	
}

void CSockSrv::Notify_ip(struct sockaddr& addr_client,  int i_client_sock, SClient& s_client)
{
	char sz_buf[MAX_PATH+1];

	memset(sz_buf, 0, MAX_PATH + 1);

	char *ch_data = addr_client.sa_data;

	int ip[4] = { (int)ch_data[2], (int)ch_data[3], (int)ch_data[4], (int)ch_data[5] };  //bool fLocalAddr = ip[0] == 127 && ip[1] == 0 && ip[2] == 0 && ip[3] == 1;

	char sz_loc[4];

	for (int i = 0; i<4; i++)
	{
		int uval = ip[i];// +(fLocalAddr ? 0 : 256);// (int)addr_client.sa_data[i];

		if (uval < 0) { uval += 256; }

		itoa(uval, sz_loc, 10);

		if (i > 0) { strcat_s(sz_buf, MAX_PATH, "."); }

		strcat_s(sz_buf, MAX_PATH, sz_loc);
	}

	gMesLog.Mes("accepted %s. port: %s. sock=%d\n", sz_buf, m_port.c_str(), i_client_sock);

	strcpy_y(s_client.ip, ci_ip_len,  sz_buf);

	s_client.s = i_client_sock;

}

void CSockSrv::NotifyRecCount(int i_cnt_last)
{
	static 	time_t t_prev = 0;
	static 	int i_cnt_recv_bytes = 0;

	time_t t = clock() / CLOCKS_PER_SEC;

	i_cnt_recv_bytes += i_cnt_last;

	if (t - t_prev > time_period_rep_sock_recv)
	{
		gMesLog.Mes("Received %d bytes. port: %s", i_cnt_recv_bytes, m_port.c_str());//time_period_rep_sock_recv, 

		i_cnt_recv_bytes = 0;

		t_prev = t; 
	}
}

CSockSrv::SClient::SClient()
{
	memset(this, 0, sizeof(CSockSrv::SClient));
}

void shutdown_closesocket(SOCKET i_client_sock)
{
	shutdown(i_client_sock, SD_SEND); // shutdown the connection since we're done

	closesocket(i_client_sock);
}

////////////////////////////////////////////////////////////////////////////////////
void CSockSrv::ListenOp()
{
	WSADATA wsaData;

	int iResult;

	SOCKET ListenSocket = INVALID_SOCKET;

	SOCKET i_client_sock = INVALID_SOCKET;

	struct addrinfo *result = NULL;

	struct addrinfo hints;

	//<q1 Initialize Winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData); 

	if (iResult != 0) { gMesLog.Mes("CSockSrv::ListenOp(). WSAStartup() failed with error: %d\n", iResult); return; }
	//>q1

	//<q2  Resolve the server address and port
	ZeroMemory(&hints, sizeof(hints));

	hints.ai_family = AF_INET;

	hints.ai_socktype = SOCK_STREAM;

	hints.ai_protocol = IPPROTO_TCP;

	hints.ai_flags = AI_PASSIVE;
	
	iResult = getaddrinfo(NULL, (char*)m_port.c_str(), &hints, &result);

	if (iResult != 0) { gMesLog.Mes("CSockSrv::ListenOp(). getaddrinfo() failed with error: %d\n", iResult); WSACleanup(); return; }
	//>q2
	
	//<q3 Create a SOCKET for connecting to server
	ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol); 

	if (ListenSocket == INVALID_SOCKET) { gMesLog.Mes("CSockSrv::ListenOp(). socket() failed with error: %ld\n", WSAGetLastError()); freeaddrinfo(result); WSACleanup(); return; }
	//>q3
	
	//<q4 Setup the TCP listening socket
	iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen); 

	if (iResult == SOCKET_ERROR) { gMesLog.Mes("CSockSrv::ListenOp(). bind() failed with error: %d\n", WSAGetLastError()); freeaddrinfo(result); closesocket(ListenSocket); WSACleanup(); return; }

	freeaddrinfo(result);
	//>q4

	gMesLog.Mes("CSockSrv::ListenOp(). socket server start. port: %s", m_port.c_str());

	iResult = listen(ListenSocket, 30);//SOMAXCONN

	if (iResult == SOCKET_ERROR)
	{ gMesLog.Mes("CSockSrv::ListenOp(). listen() failed with error: %d\n", WSAGetLastError()); closesocket(ListenSocket); WSACleanup(); return; }

	while (1)
	{
		struct sockaddr addr_client;

		int len_addr_client = sizeof(sockaddr);

		i_client_sock = accept(ListenSocket, &addr_client, &len_addr_client); // Accept a client socket

		if (i_client_sock == INVALID_SOCKET) {gMesLog.Mes("CSockSrv::ListenOp(). accept() failed with error: %d\n", WSAGetLastError()); continue;}

		SClient s_client;

		Notify_ip(addr_client, i_client_sock, s_client);

		DWORD dwExitCode;

		if (GetExitCodeThread(m_hThRead, &dwExitCode))
		{
			gMesLog.Mes("CSockSrv::ListenOp(). ThRead %s active\n", dwExitCode == STILL_ACTIVE ? "" : "not");			
		}

		s_client.m_fn = m_fn;
		s_client.m_p_param = m_p_param;
		s_client.m_port = m_port;
		s_client.CrThRead(); //ReadSingle(s_client);shutdown_closesocket(s_client.s); //AddClient(s_client);
		
		Sleep(5);
	}
	
	closesocket(ListenSocket); 

	WSACleanup();

	gMesLog.Mes("CSockSrv::ListenOp(). Listen finsh");

	return;
}

