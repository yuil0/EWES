#include <memory.h>
#include <time.h>
#include <string.h>
#include <stdio.h>
#include <direct.h>
#include <windows.h>
#include <corecrt_io.h>
#include "file.h"


///////////////////////////////////////////////////////////////////////////////////////////////////
bool CopyToArch(char *sz_path, char* *sz_file,  int q_file) //YUIL �������� � �����
{
	//YUIL ������� ����� �� ������� �������
	time_t t_cur = time(0); //���������� ����� � ���� ����� ������, �������� ����� �������� 1 ������ 1970 �., ��� �������� "-1" � ������ ������.

	if (t_cur == -1) { return false; }

	struct tm* p_tm = localtime(&t_cur);

	//if (m_time_last_arch.tm_year == p_tm->tm_year && m_time_last_arch.tm_mon == p_tm->tm_mon && m_time_last_arch.tm_mday == p_tm->tm_mday) { return true; } //YUIL ��� ���� �������

	char sz_time[MAX_PATH + 1];

	sprintf_s(sz_time, MAX_PATH, "%04d_%02d_%02d__%02d_%02d_%02d", p_tm->tm_year + 1900, p_tm->tm_mon + 1, p_tm->tm_mday, p_tm->tm_hour, p_tm->tm_min, p_tm->tm_sec);

	char sz_dir[MAX_PATH + 1];

	if (Create_Directory(sz_path, "arch")==false) {return false;}

	sprintf_s(sz_dir, MAX_PATH,  "%s\\arch",sz_path);

	if (Create_Directory(sz_dir, sz_time)==false) {return false;}

	//YUIL ��������
	char sz_full_prev[MAX_PATH + 1];
	char sz_full_new[MAX_PATH + 1];
	
	//char sz_file_o[MAX_PATH + 1];

	for (int i = 0; i < q_file; i++)
	{
		char* p_file = sz_file[i];

		sprintf_s(sz_full_prev, MAX_PATH, "%s\\%s", sz_path, p_file);

		sprintf_s(sz_full_new, MAX_PATH, "%s\\%s", sz_dir, p_file);

		BOOL bFailIfExists = FALSE;

		BOOL fCopy = CopyFileA(sz_full_prev, sz_full_new, bFailIfExists);

		if (fCopy) { unlink(sz_full_prev); }
	}

	return true;
}

bool IsFileExists(const char  *csz_find_mask,  const char  *sz_file)
{
	_finddata_t fd;

	intptr_t hFile = _findfirst(csz_find_mask, &fd);

	if (hFile == -1) { return false; }

	bool fFound = false;

	do
	{
		if (fd.attrib != _A_SUBDIR)
		{
			if (!stricmp(fd.name, sz_file)) {fFound = true;}			
		}

	} while (!_findnext(hFile, &fd));


	_findclose(hFile); //

	return fFound;
}

bool IsDirExists(const char  *csz_find_mask,  const char  *szDir)
{
	_finddata_t fd;

	intptr_t hFile = _findfirst(csz_find_mask, &fd);

	if (hFile == -1) { return false; }

	bool fFound = false;

	do
	{
		if (fd.attrib == _A_SUBDIR)
		{
			if (!stricmp(fd.name, szDir)) {fFound = true;}			
		}

	} while (fFound == false && !_findnext(hFile, &fd));


	_findclose(hFile); //

	return fFound;
}

bool Create_Directory(const char * sz_path, const char * sz_dir, char *sz_out, int i_max_out)
{
	char sz_buf[MAX_PATH + 1];

	sprintf_s(sz_buf, MAX_PATH, "%s\\*", sz_path);

	if (IsDirExists(sz_buf, sz_dir)==false)
	{
 	sprintf_s(sz_buf, MAX_PATH, "%s\\%s", sz_path, sz_dir);

	 if (_mkdir(sz_buf) == -1) { return false; }
	}

	if (sz_out) { strcpy_s(sz_out, i_max_out, sz_buf); }

	return true;
}

bool ClearFolder(char *sz_path, char *sz_mask)
{
	if (strlen(sz_path) < 1 || strlen(sz_mask) < 1) { return false; }

	char sz_val[MAX_PATH + 1];

	sprintf_s(sz_val, MAX_PATH, "%s\\%s", sz_path, sz_mask);

	_finddata_t fd;

	intptr_t hFile = _findfirst(sz_val, &fd);

	if (hFile == -1) { return false; }

	do
	{
		if (fd.attrib != _A_SUBDIR)
		{
			sprintf_s(sz_val, MAX_PATH, "%s\\%s", sz_path, fd.name);

			int iRes = unlink(sz_val);
		}

	} while (!_findnext(hFile, &fd));


	_findclose(hFile); //
}