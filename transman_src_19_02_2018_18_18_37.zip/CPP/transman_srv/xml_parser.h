#ifndef _xml_parser_h_
#define _xml_parser_h_

typedef void(*FN_READ)(void  *p_param, char *sz_text, int len_text);

typedef void(*FN_READ_TAG)(void  *p_param, int index, char *sz_text, int len_text);

//class CXMLParser{ bool m_fInit;public: CXMLParser();~CXMLParser();};

bool XML_ParseFromBuf(char *buf, int len, void  *p_param, FN_READ fn_read_tag, FN_READ fn_read_betw_tag);

bool XML_Parse(char *sz_file, void  *p_param, FN_READ fn_read_tag, FN_READ fn_read_betw_tag);

bool XML_DelUnusedChars(char *sz_in, char *sz_out, int i_out_max);
bool XML_ParseTag(char *sz_in, void  *p_param, FN_READ_TAG fn_read_tag);
bool XML_GetParamVal(char *sz_in, char* sz_param, char* sz_val, int i_max);

#endif