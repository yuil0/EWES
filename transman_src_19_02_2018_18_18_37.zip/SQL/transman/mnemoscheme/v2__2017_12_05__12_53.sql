--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\v2__2017_12_05__12_53
DECLARE @dt_max   DATETIME; SET @dt_max='2017-12-04T23:59:59.997';
DECLARE @dt_start DATETIME; SET @dt_start= dbo.FN_get_date(@dt_max);
DECLARE @id_picas_route BIGiNt; SET @id_picas_route=64

SELECT * FROM dbo.mnemoscheme_events e WHERE dt_created>=@dt_start AND dt_created<=@dt_max AND e.id_picas_route = @id_picas_route -- AND id_ate_3=ISNULL(@id_ate_3, id_ate_3)
ORDER BY dt_created

