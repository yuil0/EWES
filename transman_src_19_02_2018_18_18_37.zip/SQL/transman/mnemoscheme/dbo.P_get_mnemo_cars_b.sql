ALTER PROC dbo.P_get_mnemo_cars_b(@id_picas_route BIGINT,  @dt_max DATETIME=NULL) AS
------------------------------------------------------------------------------------
-- D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\dbo.P_get_mnemo_cars_b

--DECLARE @id_picas_route BIGINT; SET @id_picas_route=64;

--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\v_2017_12_04
--<q1
--DECLARE @id_picas_route BIGINT; SET @id_picas_route=64 --DECLARE @id_ate_3 BIGINT; SET @id_ate_3=NULL --187
IF (@dt_max IS NULL) BEGIN SET @dt_max=GETDATE(); END
DECLARE @dt_start DATETIME; SET @dt_start= dbo.FN_get_date(@dt_max);

--DECLARE @e AS TABLE(id_mnemoscheme_event BIGINT, id_ate_3 BIGINT, f_forward BIT, i_order INT, id_check_point BIGINT, id_picas_stop BIGINT, dt_created DATETIME)

--INSERT @e (id_mnemoscheme_event,   id_ate_3,  f_forward, i_order, id_check_point, id_picas_stop, dt_created)
SELECT ROW_NUMBER() OVER(ORDER BY id_mnemoscheme_event)i_event, id_ate_3, f_forward, i_order, (SELECT s.stop_name FROM dbo.check_points x, dbo.picas_stops s WHERE x.id_check_point = e.id_check_point AND x.id_picas_stop=s.id_picas_stop)stop_name, DATEDIFF(minute, @dt_start, dt_created)time_minutes --id_mnemoscheme_event, --id_check_point, 
, (SELECT garage_num FROM dbo.ate_3_book k, dbo.ate_3 x WHERE x.id_ate_3 = e.id_ate_3 AND k.device_number = x.device_number)garage_num
--, ROW_NUMBER() OVER(PARTITION BY f_forward, i_order ORDER BY id_mnemoscheme_event)i_place_order
FROM dbo.mnemoscheme_events e WHERE dt_created>=@dt_start AND dt_created<=@dt_max AND e.id_picas_route = @id_picas_route
ORDER BY dt_created
/*
DECLARE @a AS TABLE(id_mnemoscheme_event BIGINT, id_ate_3 BIGINT, f_forward BIT, i_order INT, id_check_point BIGINT, id_picas_stop BIGINT, dt_created DATETIME, id_ate_3_prev BIGINT, d_time INT, i_order_prev INT)

INSERT @a(id_mnemoscheme_event,   id_ate_3,   f_forward,   i_order,   id_check_point,   id_picas_stop,   dt_created, id_ate_3_prev, d_time, i_order_prev)
SELECT  e.id_mnemoscheme_event, e.id_ate_3, e.f_forward, e.i_order, e.id_check_point, e.id_picas_stop, e.dt_created, prev_id_ate_3, d_time, ROW_NUMBER() OVER (PARTITION BY e.id_mnemoscheme_event ORDER BY d_time)
FROM
(SELECT  e.id_mnemoscheme_event, e.id_ate_3, e.f_forward, e.i_order, e.id_check_point, e.id_picas_stop, e.dt_created, prev.id_ate_3 prev_id_ate_3, DATEDIFF(minute, prev.dt_created, e.dt_created) d_time 
 FROM @e e LEFT JOIN @e prev ON (prev.f_forward = e.f_forward AND prev.i_order = e.i_order AND prev.id_ate_3!=e.id_ate_3 AND prev.dt_created < e.dt_created)
)e WHERE e.d_time IS NOT NULL
ORDER BY e.dt_created

DECLARE @b  AS TABLE (i INT, id_ate_3 BIGINT, f_forward  BIT, i_order INT, id_check_point BIGINT, id_picas_stop BIGINT, dt_created DATETIME, id_ate_3_prev BIGINT, d_time INT)

INSERT @b (i, id_ate_3, f_forward, i_order, dt_created, id_ate_3_prev, d_time,  id_check_point, id_picas_stop)
SELECT     i, id_ate_3, f_forward, i_order, dt_created, id_ate_3_prev, d_time,  id_check_point, id_picas_stop FROM
(SELECT ROW_NUMBER() OVER (ORDER BY dt_created) i, id_ate_3, f_forward, i_order, dt_created, id_ate_3_prev, d_time,  id_check_point, id_picas_stop FROM
 (SELECT id_ate_3, f_forward, i_order, dt_created, id_ate_3_prev, d_time,  id_check_point, id_picas_stop 
  FROM
  (SELECT id_ate_3, f_forward, i_order, dt_created, id_ate_3_prev, d_time --, i_order_ate_3 
   , ROW_NUMBER() OVER (PARTITION BY a.id_ate_3 ORDER BY dt_created DESC) i_order_ate_3
   ,  id_check_point, id_picas_stop
   FROM @a a WHERE i_order_prev=1 
  )a WHERE i_order_ate_3 = 1
 )a
)a
ORDER BY dt_created


SELECT i, id_ate_3, f_forward, i_order, dt_created, id_ate_3_prev, d_time,  id_check_point, id_picas_stop, i_prev, CASE WHEN b.i=1 OR b.i_prev <  b.i THEN 1 ELSE 0 END f_show_dist 
, (SELECT garage_num FROM dbo.ate_3_book k, dbo.ate_3 x WHERE x.id_ate_3 = b.id_ate_3 AND k.device_number = x.device_number)garage_num
FROM 
(SELECT i, id_ate_3, f_forward, i_order, dt_created, id_ate_3_prev, d_time,  id_check_point, id_picas_stop, (SELECT i FROM @b x WHERE x.id_ate_3 = b.id_ate_3_prev) i_prev FROM @b b
)b
ORDER BY dt_created
*/
-->q1

