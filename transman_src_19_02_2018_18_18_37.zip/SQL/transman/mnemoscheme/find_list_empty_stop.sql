--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\find_list_empty_stop
DECLARE @route_id NVARCHAR(32); SET  @route_id='rostov_bus_96' --DECLARE @id_picas_route BIGINT,  @dt DATETIME --SET @id_picas_route=65;
DECLARE @dt DATETIME; SET @dt = GETDATE() --'2017-12-06T10:00:00'--;

DECLARE @valid_dev_sec INT, @stop_radius FLOAT; SELECT valid_dev_sec, stop_radius FROM dbo.const
DECLARE @time TIME; SET @time = dbo.FN_get_time(@dt);
--DECLARE @time_hi TIME; SET @time = DATEADD(second, 10, @time);
--DECLARE @time_lo TIME; SET @time_lo = DATEADD(second, - @valid_dev_sec, @time);

--SELECT @time[@time]--, @time_hi[@time_hi], @time_lo[@time_lo]
SELECT id_picas_stop, stop_id, s.id_ate_3 FROM 
(SELECT id_picas_stop, stop_id, s.id_ate_3, ROW_NUMBER() OVER (PARTITION BY id_ate_3 ORDER BY dist) i_order_dist  FROM 
 (SELECT id_picas_stop, stop_id, s.id_ate_3, dbo.FN_get_dist(stop_x, stop_y, c.x, c.y) dist FROM 
  (SELECT id_picas_stop, stop_id,  arrival_time_o, departure_time_o
   , dbo.FN_get_near_car(s.route_id, stop_x, stop_y) id_ate_3, stop_x, stop_y FROM --, f_forward, i_order
   (SELECT s.id_picas_stop, st.stop_id --, st.arrival_time, st.departure_time
    ,DATEADD(minute, - 5, st.arrival_time) arrival_time_o
    ,DATEADD(minute,   5, st.departure_time) departure_time_o
    ,(SELECT COUNT(1) FROM dbo.ate_3 c WHERE dbo.FN_cross(c.x, c.y, s.x, s.y, @stop_radius)=1)q_cross
    ,r.route_id, s.x stop_x, s.y stop_y, cp.f_forward, cp.i_order
    FROM  dbo.picas_stop_times st, dbo.picas_stops s, dbo.picas_trips t, dbo.picas_routes r, dbo.check_points cp
    WHERE st.trip_id=t.trip_id AND t.route_id=r.route_id AND r.route_id = @route_id --id_picas_route=@id_picas_route
    AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
    AND st.stop_id=s.stop_id
    AND s.id_picas_stop = cp.id_picas_stop AND cp.id_picas_route = r.id_picas_route
   )s
   WHERE @time >= s.arrival_time_o AND @time <= s.departure_time_o AND q_cross=0
  )s, dbo.ate_3 c WHERE s.id_ate_3 = c.id_ate_3
 )s
)s
WHERE i_order_dist=1
ORDER BY s.id_ate_3