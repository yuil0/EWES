--D:\users\yuil\JOB\EWES\SQL\transman\check_points\list_cp
DECLARE @id_ate_3 BIGINT; SET @id_ate_3=1;
SELECT stop_name, id_picas_stop FROM dbo.picas_stops 
WHERE id_picas_stop IN (SELECT DISTINCT id_picas_stop FROM dbo.check_points cp, dbo.picas_routes r, dbo.ate_3 c WHERE cp.id_picas_route = r.id_picas_route AND r.route_id = c.route_id AND c.id_ate_3 = @id_ate_3) 
ORDER BY 1

/*
SELECT distinct device_number, id_ate_3 FROM dbo.check_points cp, dbo.picas_routes r, dbo.ate_3 c WHERE cp.id_picas_route = r.id_picas_route AND r.route_id = c.route_id
AND c.id_ate_3 IN (SELECT id_ate_3 FROM  dbo.form_mes_off)

SELECT DISTINCT stop_name, id_picas_stop FROM dbo.picas_stops 
WHERE id_picas_stop IN (SELECT DISTINCT id_picas_stop FROM dbo.check_points cp, dbo.picas_routes r, dbo.ate_3 c WHERE cp.id_picas_route = r.id_picas_route AND r.route_id = c.route_id AND c.device_number=N'K398TK') 
ORDER BY 1


SELECT DISTINCT stop_name FROM dbo.picas_stops
WHERE id_picas_stop IN(SELECT DISTINCT id_picas_stop FROM dbo.check_points cp, dbo.picas_routes r, dbo.ate_3 c WHERE cp.id_picas_route = r.id_picas_route AND r.route_id = c.route_id AND c.id_ate_3 = 34)
 ORDER BY 1


*/