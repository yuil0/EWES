CREATE PROC dbo.P_identity_insert_table(@sz_table NVARCHAR(128), @f_on BIT) AS
--D:\users\yuil\JOB\EWES\SQL\transman\dbo.P_identity_insert_table.sql

DECLARE @sz NVARCHAR(max);

SET @sz='SET IDENTITY_INSERT '+@sz_table+' '+CASE WHEN @f_on=1 THEN 'ON' ELSE 'OFF' END;

EXEC sp_executesql @sz;