--D:\users\yuil\JOB\EWES\SQL\transman\Restore\CREATE LOGIN transman_user
USE [master]
GO

/* For security reasons the login is created disabled and with a random password. */
/****** Object:  Login [transman_user]    Script Date: 20.11.2017 10:36:55 ******/
CREATE LOGIN [transman_user] WITH PASSWORD=N'Ig48/Vz5c6/b1zhWzZW1HXkMt/56EVxn8VEry/ssfBE=', DEFAULT_DATABASE=[transman], DEFAULT_LANGUAGE=[�������], CHECK_EXPIRATION=OFF, CHECK_POLICY=ON
GO

ALTER LOGIN [transman_user] DISABLE
GO


