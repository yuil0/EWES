CREATE PROC dbo.P_view_car_in_zone AS
--------- //YUIL 2017-10-11 : D:\users\yuil\JOB\EWES\SQL\transman\zone\dbo.P_view_car_in_zone

SELECT * FROM dbo.zones --order  by id_zone
SELECT * FROM dbo.ate_3