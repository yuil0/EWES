ALTER PROC dbo.P_car_zone(@id_ate_3 BIGINT, @id_zone BIGINT, @f_in BIT) AS
-------------------- //YUIL 2017-10-12 : D:\users\yuil\JOB\EWES\SQL\transman\zone\dbo.P_car_zone

DECLARE @id_car_zone BIGINT; SET @id_car_zone=(SELECT id_car_zone FROM dbo.car_zones WHERE id_ate_3 = @id_ate_3 AND id_zone = @id_zone)

IF (@f_in=1)
BEGIN
	IF (@id_car_zone IS NULL)
	BEGIN
		INSERT dbo.car_zones(dt_created, id_ate_3, id_zone, f_in, f_hide) SELECT GETDATE(), @id_ate_3, @id_zone, 1, 0
	END
	ELSE
	BEGIN
		UPDATE dbo.car_zones SET dt_updated=GETDATE(), f_in=1, f_hide=0 WHERE id_car_zone = @id_car_zone AND f_in=0
	END
END ELSE
BEGIN
	UPDATE dbo.car_zones SET dt_updated=GETDATE(), f_in=0, f_hide=0 WHERE id_car_zone = @id_car_zone AND f_in=1
END