ALTER FUNCTION dbo.FN_get_short_name(@route_id NVARCHAR(32), @route_short_name NVARCHAR(8))
RETURNS NVARCHAR(32)
AS --D:\users\yuil\JOB\EWES\SQL\transman\from_picas\dbo.FN_get_short_name
BEGIN
 DECLARE  @sz_out NVARCHAR(64)
 
 DECLARE  @sz_type NVARCHAR(64); SET @sz_type=(SELECT dbo.GetPartName(@route_id, 2))

 DECLARE  @sz_type_rus NVARCHAR(64); 
 
 SET @sz_type_rus = CASE @sz_type 
 WHEN 'rostov_bus' THEN N'���.'
 WHEN 'rostov_minibus' THEN N'����.'
 WHEN 'rostov_tram' THEN N'����.'
 WHEN 'rostov_trol' THEN N'����.'
 WHEN 'rostov_shuttle' THEN N'����� '
 ELSE 'N '
 END
 
 SET @sz_out = @sz_type_rus+' '+@route_short_name

 RETURN @sz_out;
END