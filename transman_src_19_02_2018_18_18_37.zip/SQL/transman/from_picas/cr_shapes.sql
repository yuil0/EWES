--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\cr_shapes.sql
/*
[shape_id][max_size:24]
[shape_pt_lat][max_size:8]
[shape_pt_lon][max_size:8]
[shape_pt_sequence][max_size:3]
[shape_dist_traveled][max_size:1]
*/
--1. from_picas\shapes.txt
--<q1
DROP TABLE dbo.picas_shapes
CREATE TABLE dbo.picas_shapes
(id_picas_shape BIGINT IDENTITY(1,1)
,shape_id NVARCHAR(32)     
,shape_pt_lat DECIMAL(10,6)
,shape_pt_lon DECIMAL(10,6)
,shape_pt_sequence INT
,shape_dist_traveled NVARCHAR(2)     
,id_shape_id BIGINT
,id_prev BIGINT
)
-->q1

ALTER TABLE dbo.picas_shapes ADD x FLOAT, y FLOAT


CREATE CLUSTERED INDEX I_id_picas_shape ON dbo.picas_shapes(id_picas_shape) 
CREATE INDEX I_id_shape_id ON dbo.picas_shapes(id_shape_id) INCLUDE(shape_pt_sequence)

CREATE INDEX I_shape_id ON dbo.picas_shapes(shape_id)


--<w1
SELECT id_picas_shape, shape_id ,shape_pt_lat , shape_pt_lon , shape_pt_sequence, id_shape_id, id_prev FROM dbo.picas_shapes WHERE dbo.GetPartName(shape_id, 3)='rostov_bus_1'
--order  by id_shape_id,  shape_pt_sequence

/*
SELECT stop_id, count(1) FROM dbo.picas_stops
group by stop_id
having count(1)>1
order  by stop_id --�����
*/
exec  sp_spaceused 'dbo.picas_shapes'; 


-->w1

DELETE FROM dbo.picas_shapes

--<q2
-- �������� id_shape_id BIGINT

ALTER TABLE dbo.picas_shapes ADD id_prev BIGINT

CREATE TABLE dbo.picas_shape_ids
(id_picas_shape_id BIGINT IDENTITY(1,1)
,shape_id NVARCHAR(32)     
)

CREATE CLUSTERED INDEX I_id_picas_shape_id ON dbo.picas_shape_ids(id_picas_shape_id) --CREATE INDEX I_shape_id ON dbo.picas_shapes(shape_id)

SELECT max(id_picas_shape_id) FROM dbo.picas_shape_ids
SELECT max(id_shape_id) FROM dbo.picas_shapes
-->q2

EXEC  dbo.P_fill_picas_shape_ids

SELECT SCOPE_IDENTITY()n

--<q3 YUIL 2017-08-22 ��� ������� ��� ������ � transman
DROP TABLE dbo.picas_shape_lines
CREATE TABLE dbo.picas_shape_lines
(id_picas_shape_lines BIGINT IDENTITY(1,1)
,shape_id NVARCHAR(32)     
,route_long_name NVARCHAR(128)
,from_lat DECIMAL(10,6)
,from_lon DECIMAL(10,6)
,from_sequence INT
,to_lat DECIMAL(10,6)
,to_lon DECIMAL(10,6)
,to_sequence INT
,direct BIT --YUIL ������ �����������
,id_picas_route BIGINT
,route_short_name NVARCHAR(32)
)

CREATE CLUSTERED INDEX I_id_picas_shape_lines ON dbo.picas_shape_lines(id_picas_shape_lines)
-->q3

select * FROM dbo.picas_shapes
select 'rostov_bus_1_a-b', SuBSTRing('rostov_bus_1_a-b', LEN('rostov_bus_1_a-b')-2, LEN('rostov_bus_1_a-b'))
select CHARINDEX('_',  'rostov_bus_1_a-b', 1)
select dbo.GetPartName('rostov_bus_1_a-b')


select shape_id, route_long_name , from_lat ,from_lon , from_sequence , to_lat , to_lon , to_sequence,direct,id_picas_route, route_short_name FROM dbo.picas_shape_lines --where route_short_name=N'���. 2'

-- select distinct shape_id, route_long_name FROM dbo.picas_shape_lines where route_long_name is null
-- SELECT * FROM dbo.picas_routes WHERE route_id LIKE '%rostov_minibus_96%'
-- SELECT distinct dbo.GetPartName(route_id) FROM dbo.picas_routes 


--SELECT route_id , route_id_cr FROM(SELECT route_id , 'rostov_minibus_'+CONVERT(NVARCHAR(10),route_short_name)route_id_cr FROM dbo.picas_routes)x WHERE route_id!=route_id_cr


