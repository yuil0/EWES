--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\strange_end_shape_id
select sz_end, q_end, 'SELECT * FROM dbo.picas_shapes WHERE SUBSTRING(shape_id, LEN(shape_id)-3, 4)='''+sz_end+'''' FROM
(select sz_end,  count(1)q_end FROM
 (select SUBSTRING(shape_id, LEN(shape_id)-3, 4)sz_end from dbo.picas_shapes )x --where SUBSTRING(shape_id, LEN(shape_id)-4, 4)
 GROUP BY sz_end
)x
ORDER BY 2 DESC