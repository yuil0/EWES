--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\picas_calendar
--<q1
DROP TABLE dbo.picas_calendar 
CREATE TABLE dbo.picas_calendar   --  197665,1,1,1,1,1,0,0,20170426,20180801
(id_calendar_row BIGINT IDENTITY(1,1)
, dt_created DATETIME --YUIL. ����/����� ��������  ������
, service_id BIGINT
, monday BIT
, tuesday BIT
, wednesday BIT
, thursday BIT
, friday BIT
, saturday BIT
, sunday BIT
, start_date DATETIME
, end_date DATETIME
)

CREATE CLUSTERED INDEX I_id_calendar_row ON dbo.picas_calendar(id_calendar_row) 

sp_spaceused 'dbo.picas_calendar'

SELECT * FROM dbo.picas_calendar --order  by id_calendar_row

--SELECT name, quantity, latitude_0, longitude_0, latitude_1, longitude_1, latitude_2, longitude_2, latitude_3, longitude_3 FROM dbo.picas_calendar

TRUNCATE TABLE dbo.picas_calendar 

INSERT dbo.picas_calendar(dt_created,  service_id, monday, tuesday, wednesday, thursday, friday, saturday, sunday, start_date, end_date)
            SELECT GETDATE(),           123,      1,       0,         0,        0,      0,        0,      0,        N'',      N''
				 

-->q1

