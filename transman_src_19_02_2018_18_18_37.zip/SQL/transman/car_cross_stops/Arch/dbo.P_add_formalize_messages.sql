CREATE PROC dbo.P_add_formalize_messages(@device_number NVARCHAR(16), @route_short_name NVARCHAR(8), @stop_id_from BIGINT, @stop_id_to BIGINT) 
AS --//YUIL 2017-09-20 : D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\dbo.P_add_formalize_messages
------------------------------------------------------------------------------------------------------------------------
DECLARE @id_formalize_message BIGINT; SET @id_formalize_message=ISNULL((SELECT MAX(id_formalize_message) FROM dbo.formalize_messages), 0)+1

SET IDENTITY_INSERT dbo.formalize_messages ON

DECLARE @time_cmd_minute_from INT;
DECLARE @time_cmd_minute_to INT;

INSERT dbo.formalize_messages(id_formalize_message, dt_created,  device_number,  route_short_name,   garage_num,   state_num,   stop_name_from,  time_cmd_minute_from,   stop_name_to,  time_cmd_minute_to, i_state)
SELECT                       @id_formalize_message,  GETDATE(), @device_number, @route_short_name, b.garage_num, b.state_num, s_from.stop_name, @time_cmd_minute_from, s_to.stop_name, @time_cmd_minute_to,       0
FROM dbo.ate_3_book b, dbo.picas_stops s_from, dbo.picas_stops s_to
WHERE b.device_number=@device_number AND s_from.stop_id=@stop_id_from AND s_to.stop_id=@stop_id_to

SET IDENTITY_INSERT dbo.formalize_messages OFF