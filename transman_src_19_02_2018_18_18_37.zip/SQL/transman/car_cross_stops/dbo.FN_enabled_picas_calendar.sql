ALTER FUNCTION dbo.FN_enabled_picas_calendar --YUIL ���� �� ���������� �� ������. ���� �������  ��� �� ���������.
( @dt DATETIME
, @service_id BIGINT
)
RETURNS BIT
AS --YUIL 2017-09-15 D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\dbo.FN_enabled_picas_calendar_dates
BEGIN
	DECLARE @date DATETIME; SET @date=dbo.FN_get_date(@dt); --//YUIL 2017-10-31. ������ ����

	DECLARE @f_enabled BIGINT; SET @f_enabled=1;

	--2. calendar week day 
	IF (@f_enabled=1)
	BEGIN
		DECLARE @dayWeek INT; SET @dayWeek=DATEPART(dw, @dt);
		
		SET @f_enabled=
		ISNULL((SELECT 
					CASE @dayWeek 
					 WHEN 1 THEN monday
					 WHEN 2 THEN tuesday
					 WHEN 3 THEN wednesday
					 WHEN 4 THEN thursday
					 WHEN 5 THEN friday 
					 WHEN 6 THEN saturday
					 WHEN 7 THEN sunday
					END
				FROM dbo.picas_calendar c WHERE service_id=@service_id AND @dt>=c.start_date AND @dt <=c.end_date), 0)		
	END

	--3. exception
	DECLARE @exception_type INT; SET @exception_type=(SELECT exception_type FROM dbo.picas_calendar_dates cd WHERE service_id=@service_id AND date = @date);

	IF (@exception_type IS NOT NULL)
	BEGIN
		SET @f_enabled= 
		CASE @exception_type 
			WHEN 1 THEN 1 --true
			WHEN 2 THEN 0 --false
		END
	END

	RETURN @f_enabled;
END

/*
FROM dbo.picas_calendar_dates cd WHERE service_id=@service_id AND date<=@dt

SELECT * FROM dbo.picas_calendar_dates WHERE service_id=197665 AND date<'2017-12-23T00:00:00.000' --0

SELECT dbo.FN_enabled_picas_calendar_dates('2017-12-23T00:00:00.000', 197665)
----
SELECT * FROM dbo.picas_calendar_dates cd WHERE exception_type=1 AND service_id=198057 order by date

SELECT dbo.FN_enabled_picas_calendar_dates('2017-12-31T00:00:00.000', 198057)
----
SELECT service_id, COUNT(DISTINCT exception_type) FROM dbo.picas_calendar_dates cd 
GROUP BY service_id
HAVING COUNT(DISTINCT exception_type)>1 --0
*/