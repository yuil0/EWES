CREATE FUNCTION dbo.FN_get_dist
( @x1 FLOAT, @y1 FLOAT --//YUIL 2017-09-20 point 1
, @x2 FLOAT, @y2 FLOAT --//YUIL 2017-09-20 point 2
)
RETURNS FLOAT
AS -- //YUIL 2017-09-20 : D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\dbo.FN_get_dist
BEGIN
	DECLARE  @dist FLOAT; SET @dist= SQRT(SQUARE(@x1 - @x2) + SQUARE(@y1 - @y2))

	RETURN @dist;
END