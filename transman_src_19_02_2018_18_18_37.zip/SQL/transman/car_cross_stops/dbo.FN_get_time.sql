CREATE FUNCTION dbo.FN_get_time(@dt DATETIME)
RETURNS TIME
AS -- //YUIL 2017-09-18 : D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\dbo.FN_get_time
BEGIN
	DECLARE  @time  TIME; SET  @time = TIMEFROMPARTS ( DATEPART(hh, @dt), DATEPART(minute, @dt), DATEPART(second, @dt), 0, 0)  

	RETURN @time;
END