--D:\users\yuil\JOB\EWES\SQL\transman\common\sel_by_page
/*
 
SELECT * FROM picas_shapes OFFSET 0 ROWS FETCH NEXT 3000 ROWS ONLY

SELECT TOP 3000 * FROM picas_shapes ORDER BY id_picas_shape ASC
SELECT TOP 3000 * FROM picas_shapes ORDER BY id_picas_shape DESC
*/
--
DECLARE @min_id_picas_shape BIGINT, @max_id_picas_shape  BIGINT

SELECT @min_id_picas_shape=MIN(id_picas_shape), @max_id_picas_shape=MAX(id_picas_shape) FROM picas_shapes --DECLARE @id_picas_shape BIGINT; SET @id_picas_shape=@min_id_picas_shape;DECLARE @step BIGint; SET  @step=3000;

DECLARE @i_page INT; SET @i_page=1;

WHILE(@min_id_picas_shape<=@max_id_picas_shape)
BEGIN
	SELECT @i_page[page], * FROM  picas_shapes WHERE id_picas_shape>=@min_id_picas_shape AND id_picas_shape<@min_id_picas_shape+3000

	SET @min_id_picas_shape = @min_id_picas_shape +3000;

	SET @i_page=@i_page+1
END

/*
--<w1
DECLARE @t AS TABLE (id_picas_shape BIGINT)

INSERT @t (id_picas_shape) SELECT id_picas_shape FROM picas_shapes ORDER BY id_picas_shape

WHILE EXISTS (SELECT 1 FROM @t)
BEGIN
	--DECLARE @part AS TABLE (id_picas_shape BIGINT) INSERT @part(id_picas_shape) SELECT TOP 3000 id_picas_shape FROM @t

	SELECT @i_page[page] ,* FROM picas_shapes WHERE id_picas_shape IN (SELECT id_picas_shape FROM @part)

	DELETE FROM @t WHERE id_picas_shape IN (SELECT id_picas_shape FROM @part)

	DELETE FROM @part

	SET @i_page=@i_page+1
END
-->w1
*/