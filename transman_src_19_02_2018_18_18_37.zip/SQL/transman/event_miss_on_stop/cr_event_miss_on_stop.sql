--<q1
-- DROP TABLE dbo.event_miss_on_stop
CREATE TABLE dbo.event_miss_on_stop
(
 id_event_miss_on_stop BIGINT
,dt_create DATETIME
,id_check_point BIGINT
,id_picas_route BIGINT
,shape_id NVARCHAR(32)
,arrival_time TIME
,departure_time TIME
)

-->q1

CREATE CLUSTERED INDEX I_id_event_miss_on_stop ON dbo.event_miss_on_stop (id_event_miss_on_stop)
--CREATE NONCLUSTERED INDEX I_id_event_miss_on_stop ON dbo.event_miss_on_stop (id_event_miss_on_stop)

--select* from dbo.picas_stops
--select* from dbo.picas_shapes
select* from dbo.picas_stop_times