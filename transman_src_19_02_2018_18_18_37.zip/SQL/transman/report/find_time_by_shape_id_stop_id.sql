--D:\users\yuil\JOB\EWES\SQL\transman\report\find_time_by_shape_id_stop_id
DECLARE @dt DATETIME; SET @dt='2017-09-21T00:00:00';

DECLARE @valid_dev_sec int; SET @valid_dev_sec = ISNULL((SELECT valid_dev_sec FROM dbo.const), 30) --YUIL 2017-10-06. ���������� ����������  � ��������

DECLARE @stop_id BIGINT; SET @stop_id=1828;
DECLARE @shape_id NVARCHAR(32); SET @shape_id='rostov_bus_96_a-b'
DECLARE @arrival_time TIME; SET @arrival_time='09:19:44.0000000'
DECLARE @departure_time TIME; SET @departure_time='09:19:59.0000000'

--������� :
SELECT arrival_time, departure_time FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
AND stop_id=@stop_id  AND shape_id=@shape_id 
ORDER BY arrival_time, departure_time


--��������� �� �����
SELECT TOP 1 1 FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
AND stop_id=@stop_id  AND shape_id=@shape_id 
AND (@arrival_time >= DATEADD(second, - @valid_dev_sec, arrival_time) AND @arrival_time <= DATEADD(second, @valid_dev_sec, arrival_time))
AND (@departure_time >= DATEADD(second, - @valid_dev_sec, departure_time) AND @departure_time <= DATEADD(second, @valid_dev_sec, departure_time))


--SELECT * FROM @tp  SELECT * FROM @t


--SELECT t.shape_id, t.stop_sequence, tp.stop_sequence  FROM @t t LEFT JOIN @tp tp ON (tp.shape_id=t.shape_id AND tp.stop_sequence < t.stop_sequence)
--ORDER BY t.shape_id, t.stop_sequence

/*
SELECT t.trip_id,  stop_id, stop_sequence,  id_trip, service_id, shape_id FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
AND stop_id=1818  AND route_id='rostov_bus_96'
*/