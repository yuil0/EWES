ALTER PROC dbo.P_enabled_shape_stop_times (@dt  DATETIME=NULL,  @shape_id NVARCHAR(32), @stop_id BIGINT) AS --//YUIL 2017-09-28 : D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_shape_stops
------------------

SELECT CONVERT(NVARCHAR(13),st.departure_time)departure_time, DATEDIFF(minute, 0, st.departure_time)departure_time_min
 FROM  dbo.picas_stop_times st, dbo.picas_trips t
 WHERE st.trip_id=t.trip_id AND t.shape_id=ISNULL(@shape_id, t.shape_id) AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1 AND st.stop_id=@stop_id
 order by st.departure_time
