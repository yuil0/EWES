--D:\users\yuil\JOB\EWES\SQL\transman\report\exec_dbo.P_report_1
--<q1
EXEC dbo.P_report_1 @i_mode=3; EXEC dbo.P_report_1 @dt='2017-09-21T23:59:59', @i_mode=0, @stop_id=NULL, @hour=7, @route_id='rostov_bus_96' --, @f_out=1; --SELECT * FROM dbo._rep_out; --, @route_id='rostov_bus_96'

EXEC dbo.P_report_1 @dt='2017-09-21T23:59:59', @i_mode=1, @stop_id=NULL, @hour=7, @route_id='rostov_bus_96' --, @f_out=1; --SELECT * FROM dbo._rep_out;  --, @route_id='rostov_bus_96'

EXEC dbo.P_report_1 @i_mode=3; EXEC dbo.P_report_1 @dt='2017-09-21T23:59:59', @i_mode=2, @hour=10, @route_id='rostov_bus_96'; 

--select * from dbo.picas_routes where route_id='rostov_bus_96'

EXEC dbo.P_report_1 @dt='2017-09-21T23:59:59', @i_mode=4, @hour=10, @route_id=NULL, @f_time_limit=0;EXEC dbo.P_report_1 @i_mode=3
EXEC dbo.P_report_1 @dt='2017-09-21T23:59:59', @i_mode=4, @hour=10, @route_id='rostov_bus_96', @f_time_limit=0;EXEC dbo.P_report_1 @i_mode=3

EXEC dbo.P_report_1 @dt='2017-09-21T23:59:59', @i_mode=5, @route_id='rostov_bus_96', @f_time_limit=0;EXEC dbo.P_report_1 @i_mode=3
EXEC dbo.P_report_1 @i_mode=3; EXEC dbo.P_report_1 @dt='2017-09-21T23:59:59', @i_mode=6, @route_id='rostov_bus_96', @stop_id=721, @f_time_limit=0;



-->q1

EXEC dbo.P_enabled_shapes @dt='2017-09-21T23:59:59', @route_id='rostov_bus_96'

USE transman

EXEC dbo.P_enabled_shape_stops @dt='2017-09-21T23:59:59', @shape_id='rostov_bus_96_a-b'

EXEC dbo.P_enabled_shape_stop_times @dt='2017-09-21T23:59:59', @shape_id='rostov_bus_96_a-b', @stop_id=1813
EXEC dbo.P_enabled_shape_stop_times @dt='2017-09-21T23:59:59', @shape_id='rostov_bus_96_a-b', @stop_id=1046

 
--<q2
DECLARE @dt DATETIME; SET @dt='2017-09-21T23:59:59'
DECLARE @hour INT; SET @hour=5;
WHILE @hour<=23
BEGIN
	EXEC dbo.P_report_1 @dt='2017-09-21T23:59:59', @i_mode=0, @stop_id=NULL, @hour=@hour, @route_id='rostov_bus_96'
	EXEC dbo.P_report_1 @dt=NULL, @i_mode=1, @stop_id=NULL, @hour=@hour, @route_id='rostov_bus_96'
	
	SET @hour=@hour+1;
END

-->q2

select * from sys.all_objects where name like '%sp_executesql%'
select * from sys.all_objects where name like '%delay%'