ALTER PROC dbo.P_enabled_shapes
(                               
  @dt  DATETIME=NULL
, @route_id NVARCHAR(32)=NULL
, @id_picas_route BIGINt=NULL
) 
AS --//YUIL 2017-09-28 : D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_enabled_shapes
------------------

SELECT DISTINCT t.shape_id
FROM  dbo.picas_stop_times st, dbo.picas_trips t , dbo.picas_routes r
WHERE st.trip_id=t.trip_id AND t.route_id=ISNULL(@route_id, t.route_id) AND r.id_picas_route=ISNULL(@id_picas_route, r.id_picas_route) AND dbo.FN_enabled_picas_calendar(ISNULL(@dt, GETDATE()), t.service_id)=1
AND t.route_id=r.route_id
