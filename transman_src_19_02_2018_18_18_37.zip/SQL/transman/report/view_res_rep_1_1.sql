--D:\users\yuil\JOB\EWES\SQL\transman\report\view_res_rep_1_1
SELECT * FROM  dbo.picas_trips t WHERE service_id IN (83112) 

SELECT                   dbo.FN_enabled_picas_calendar(GETDATE(), 83112) -- ==1
SELECT st.* FROM  dbo.picas_stop_times st, dbo.picas_trips t WHERE service_id IN (83112) AND st.trip_id=t.trip_id 

SELECT count(distinct  st.stop_id) FROM  dbo.picas_stop_times st, dbo.picas_trips t WHERE service_id IN (83112) AND st.trip_id=t.trip_id 
SELECT 109*225

SELECT st.trip_id, count(distinct stop_id) FROM  dbo.picas_stop_times st, dbo.picas_trips t WHERE service_id IN (83112) AND st.trip_id=t.trip_id 
GROUP BY st.trip_id
ORDER  BY 2 DESC

SELECT c_stop_id, count(1)c_c_stop_id FROM
(SELECT st.trip_id, count(distinct stop_id)c_stop_id FROM  dbo.picas_stop_times st, dbo.picas_trips t WHERE service_id IN (83112) AND st.trip_id=t.trip_id 
 GROUP BY st.trip_id
)t
GROUP BY c_stop_id
ORDER  BY 2 DESC
/*
c_stop_id	c_c_stop_id
51	98
60	90
25	11
35	9
36	6
16	6
45	3
20	2
-- //YUIL 2017-09-25 ������ ���������� ��������� ���  trip_id
*/


