ALTER  PROC dbo.P_report_4
( @i_mode TINYINT=0 /*YUIL 2017-10-03 0:���� �� ���������
					�������� 1: ������� �������  ����������
					�������� 2: ���� �� ������, �����					
                    */
, @dt DATETIME=NULL
, @stop_id BIGINT =NULL
, @id_file_stop_area BIGINT=NULL --area NVARCHAR(32)
, @id_file_stop_street BIGINT=NULL --street NVARCHAR(32)
) 
AS
------------------------------------------------------------------------------------------------------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_report_4

SET NOCOUNT ON;  --DECLARE @sz NVARCHAR(MAX);

IF (@i_mode=1)
BEGIN
	print N'Clearing';
	
	TRUNCATE TABLE dbo._rep_4_out

	RETURN; 
END

IF (@dt IS  NULL)  SET @dt=GETDATE();

--<q5  cr
IF (OBJECT_ID('dbo._rep_4_out')IS NULL) 
BEGIN
  --DROP TABLE dbo._rep_4_out
 CREATE TABLE dbo._rep_4_out(id_rep_out BIGINT IDENTITY(1,1), stop_name NVARCHAR(64), route_short_name NVARCHAR(8), area NVARCHAR(32), street NVARCHAR(32), lat FLOAT, lng FLOAT, stop_num NVARCHAR(6)); 
 CREATE CLUSTERED INDEX I_id_out ON dbo._rep_4_out(id_rep_out)
END
-->q5

IF (@i_mode=0)
BEGIN
	CREATE TABLE #route_stop(route_short_name NVARCHAR(8), stop_id BIGINT)

	CREATE CLUSTERED INDEX I_stop_id ON #route_stop (stop_id)

	INSERT #route_stop(route_short_name,   stop_id)
	SELECT DISTINCT  r.route_short_name, t.stop_id FROM
	(SELECT DISTINCT t.route_id, st.stop_id
	 FROM  dbo.picas_stop_times st, dbo.picas_trips t
	 WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1 AND st.stop_id=IsnULL(@stop_id, st.stop_id)
	)t, dbo.picas_routes r WHERE (t.route_id COLLATE Cyrillic_General_CI_AS)=(r.route_id COLLATE Cyrillic_General_CI_AS)

	--<q6  sel
	INSERT  dbo._rep_4_out(stop_name, area,street, lat, lng, stop_num, route_short_name)
	SELECT --fs.stop_id, fs.id_file_stop_area, fs.id_file_stop_street, fs.lat, fs.lng, fs.number, rs.route_id
	  (SELECT stop_name FROM dbo.picas_stops x WHERE x.stop_id=fs.stop_id)stop_name
	, (SELECT x.area FROM dbo.file_stop_areas x WHERE x.id_file_stop_area=fs.id_file_stop_area)area
	, (SELECT x.street FROM dbo.file_stop_streets x WHERE x.id_file_stop_street=fs.id_file_stop_street)street
	, fs.lat
	, fs.lng
	, fs.number stop_num
	, rs.route_short_name
	FROM (SELECT DISTINCT stop_id, id_file_stop_area, id_file_stop_street, lat,lng, number FROM dbo.file_stops) fs LEFT JOIN #route_stop rs ON (rs.stop_id=fs.stop_id)
	WHERE fs.stop_id=ISNULL(@stop_id, fs.stop_id) 
	AND fs.id_file_stop_area=ISNULL(@id_file_stop_area, fs.id_file_stop_area) 
	AND fs.id_file_stop_street=ISNULL(@id_file_stop_street, fs.id_file_stop_street) 

	ORDER BY fs.number, rs.route_short_name

	DROP TABLE #route_stop
END ELSE
IF (@i_mode=2)
BEGIN
	INSERT  dbo._rep_4_out(area, stop_name, street, lat, lng, stop_num)
	SELECT 
	  (SELECT x.area FROM dbo.file_stop_areas x WHERE x.id_file_stop_area=fs.id_file_stop_area)area
	, (SELECT stop_name FROM dbo.picas_stops x WHERE x.stop_id=fs.stop_id)stop_name	
	, (SELECT x.street FROM dbo.file_stop_streets x WHERE x.id_file_stop_street=fs.id_file_stop_street)street
	, fs.lat
	, fs.lng
	, fs.number stop_num
	FROM (SELECT DISTINCT stop_id, id_file_stop_area, id_file_stop_street, lat,lng, number FROM dbo.file_stops) fs 
	WHERE fs.id_file_stop_area=ISNULL(@id_file_stop_area, fs.id_file_stop_area) AND fs.id_file_stop_street=ISNULL(@id_file_stop_street, fs.id_file_stop_street) 

	ORDER BY fs.number

END 
-->q6

SELECT * FROM dbo._rep_4_out