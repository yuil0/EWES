--D:\users\yuil\JOB\EWES\SQL\transman\report\exec_dbo.P_report_4
EXEC dbo.P_report_4 @i_mode=1; EXEC dbo.P_report_4 @i_mode=0, @dt=NULL, @stop_id=2064, @id_file_stop_area=NULL, @id_file_stop_street=NULL --4.1

EXEC dbo.P_report_4 @i_mode=1; EXEC dbo.P_report_4 @i_mode=2, @dt=NULL, @stop_id=NULL, @id_file_stop_area=11, @id_file_stop_street=NULL --4.2

EXEC dbo.P_report_4 @i_mode=1; EXEC dbo.P_report_4 @i_mode=3, @dt=NULL, @stop_id=NULL, @id_file_stop_area=NULL, @id_file_stop_street=133 --4.3

EXEC dbo.P_report_4 @i_mode=1; EXEC dbo.P_report_4 @i_mode=2, @id_file_stop_street=6

EXEC dbo.P_report_4 @i_mode=2, @id_file_stop_street=54

SELECT id_file_stop_street, street FROM dbo.file_stop_streets ORDER BY id_file_stop_street