

DECLARE @dt  DATETIME; SET @dt='2017-09-21T23:59:59'
DECLARE @stop_id BIGINT; SET @stop_id=NULL --//YUIL 2017-09-22 @stop_id IS NULL : ��� ���� ���������
DECLARE @route_id NVARCHAR(32); SET @route_id='rostov_bus_96'
DECLARE @shape_id NVARCHAR(32); SET @shape_id='rostov_bus_96_a-b'
DECLARE @enabled_service AS TABLE(service_id BIGINT, f_enabled_picas_calendar BIT);

--<q1
INSERT @enabled_service (service_id,                         f_enabled_picas_calendar) 
SELECT                   service_id, dbo.FN_enabled_picas_calendar(@dt, t.service_id) FROM (SELECT DISTINCT service_id FROM dbo.picas_trips)t

DELETE FROM @enabled_service WHERE f_enabled_picas_calendar=0
-->q1                   --SELECT *FROM @enabled_service

DECLARE @t AS TABLE(stop_sequence INT, stop_id NVARCHAR(32), service_id BIGINT)

INSERT @t (stop_sequence, stop_id, service_id)
SELECT DISTINCT st.stop_sequence, st.stop_id, service_id 
FROM  dbo.picas_stop_times st, dbo.picas_trips t, dbo.picas_routes r 
WHERE st.trip_id=t.trip_id AND t.route_id=r.route_id AND st.stop_id=ISNULL(@stop_id, st.stop_id) AND t.route_id=ISNULL(@route_id, t.route_id)  AND t.shape_id=ISNULL(@shape_id, t.shape_id)

DELETE FROM  @t WHERE service_id NOT IN (SELECT service_id FROM @enabled_service)
	
SELECT * FROM  @t ORDER BY stop_sequence--, st.stop_sequence
