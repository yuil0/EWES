--D:\users\yuil\JOB\EWES\SQL\transman\car_stop\cr_car_last_stop.sql

--<q1
DROP TABLE dbo.user_binds
CREATE TABLE dbo.user_binds
( id_user_bind BIGINT IDENTITY(1,1)
, id_user_one BIGINT
, id_user BIGINT
)
-->q1
--ALTER TABLE dbo.users ADD f_out BIT

CREATE CLUSTERED INDEX I_id_user_bind ON dbo.user_binds(id_user_bind)
CREATE NONCLUSTERED INDEX I_id_user_one ON dbo.user_binds(id_user_one)
CREATE NONCLUSTERED INDEX I_id_user ON dbo.user_binds(id_user)

SELECT * FROM dbo.user_binds

DELETE FROM dbo.user_binds

INSERT dbo.user_binds(id_user_one, id_user)
SELECT 2, 4 UNION         
SELECT 2, 5

INSERT dbo.user_binds(id_user_one, id_user)
SELECT 3, 6 UNION         
SELECT 3, 7

-- ������ ������� ������ � ��������  �� : dbo.user_binds

/*
--<q2
DECLARE @id_user_prev BIGINT; SET @id_user_prev=ISNULL((SELECT MAX(id_user) FROM dbo.users),0);
DECLARE @f_our BIT; 

SET IDENTITY_INSERT dbo.users ON;
INSERT dbo.users(id_user, dt_created,  id_user_type,  user_name,  password)
SELECT @id_user_prev + 1,  GETDATE(), @id_user_type, @user_name, @password 
SET IDENTITY_INSERT dbo.users OFF;
-->q2*/