--D:\users\yuil\JOB\EWES\SQL\transman\user\crypt_MD5
select HASHBYTES ( 'SHA', '12345' )  

select HASHBYTES ( 'SHA', 0x827CCB0EEA8A706C4C34A16891F84E7B)