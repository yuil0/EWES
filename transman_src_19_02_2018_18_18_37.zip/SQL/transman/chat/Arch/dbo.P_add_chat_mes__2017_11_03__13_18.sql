ALTER PROC dbo.P_add_chat_mes
( @user_name_from NVARCHAR(32)
, @user_name_to NVARCHAR(32)=NULL
, @mes NVARCHAR(MAX)=NULL --���� NULL �� ��� ������ ���������
, @f_from_our BIT=0 --1 : ���
, @f_to_our BIT=0 --1 : ���
) AS --D:\users\yuil\JOB\EWES\SQL\transman\chat\dbo.P_add_chat_mes
------------------------------------
SET NOCOUNT ON;

DECLARE @id_user_from BIGINT, @id_user_to BIGINT;

/*IF (@mes IS NULL)
BEGIN
 print  '';
END ELSE
BEGIN*/
	--<q2
	--1. user
	EXEC dbo.P_add_user @user_name = @user_name_from, @f_our = @f_from_our, @id_user = @id_user_from OUTPUT;

	EXEC dbo.P_add_user @user_name = @user_name_to, @f_our = @f_to_our, @id_user = @id_user_to OUTPUT;

	--2. mes
	DECLARE @id_chat_mes_prev BIGINT; SET @id_chat_mes_prev=ISNULL((SELECT MAX(id_chat_mes) FROM dbo.chat_mes),0);

	SET IDENTITY_INSERT dbo.chat_mes ON;
	INSERT dbo.chat_mes(id_chat_mes, dt_created,  id_user_from,  id_user_to,  mes)
	SELECT    @id_chat_mes_prev + 1,  GETDATE(), @id_user_from, @id_user_to, @mes
	SET IDENTITY_INSERT dbo.chat_mes OFF;
	-->q2
--END
