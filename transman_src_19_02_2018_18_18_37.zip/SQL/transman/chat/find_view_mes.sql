--D:\users\yuil\JOB\EWES\SQL\transman\chat\find_view_mes
--<q1
DECLARE @id_user_1 BIGINT; SET @id_user_1=3;
DECLARE @id_user_2 BIGINT; SET @id_user_2=7;

SELECT CONVERT(NVARCHAR(40), dt_create, 120) dt_create, id_chat_mes_type, mes FROM dbo.chat_mes_head h, dbo.chat_mes m WHERE h.id_chat_mes_head=m.id_chat_mes_head AND h.id_user_from IN (@id_user_1, @id_user_2) AND h.id_user_to IN (@id_user_1, @id_user_2)
ORDER BY h.id_chat_mes_head
-->q1

EXEC dbo.P_view_mes @id_user_1=3, @id_user_2=7 --, @i_quantity=NULL

EXEC dbo.P_view_mes_one @id_user=8

SELECT user_name FROM dbo.users WHERE id_user_type=3 AND id_user in (SELECT id_user FROM dbo.user_binds WHERE id_user_one=8)

SELECT user_name FROM dbo.users WHERE id_user IN (SELECT id_user FROM dbo.user_binds WHERE id_user_one = 8)
--<q2
SELECT h.id_chat_mes_head, dt_create, id_chat_mes_type, mes 
, CASE WHEN mes like  '%.jpg' THEN 2 
       WHEN mes like  '%.mp4' THEN 3
  END valid_type
FROM dbo.chat_mes_head h, dbo.chat_mes m WHERE h.id_chat_mes_head=m.id_chat_mes_head AND mes like  '%http://%' AND id_chat_mes_type=1
ORDER BY h.id_chat_mes_head
-->q2

--<q4
UPDATE h SET id_chat_mes_type= 
  CASE WHEN mes like  '%.jpg' THEN 2 
       WHEN mes like  '%.mp4' THEN 3
  END
FROM dbo.chat_mes_head h, dbo.chat_mes m WHERE h.id_chat_mes_head=m.id_chat_mes_head AND mes like  '%http://%' AND id_chat_mes_type=1

-->q4

--<q3
������� dbo.chat_mes_head

������ �������� ��� id_chat_mes_type � ������� id_chat_mes_head IN(91, 94, 95, 96)

�� ���� dbo.chat_mes_types ��� 1 ��� �����.
-->q3