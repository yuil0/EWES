--D:\users\yuil\JOB\EWES\SQL\transman\missing_id
-- TRUNCATE TABLE dbo.picas_stop_times
--SELECT s.id_stop_time FROM dbo.picas_stop_times s

--SELECT s.id_stop_time FROM dbo.picas_stop_times s WHERE s.id_stop_time in(10901,  10901-1, 10871+1)

SELECT s.id_stop_time FROM dbo.picas_stop_times s LEFT JOIN dbo.picas_stop_times p  ON  (p.id_stop_time=s.id_stop_time-1)
WHERE s.id_stop_time>1  AND p.id_stop_time IS  NULL