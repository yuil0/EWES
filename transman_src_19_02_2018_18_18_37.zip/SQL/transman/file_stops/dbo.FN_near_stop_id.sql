ALTER  FUNCTION dbo.FN_near_stop_id(@stop_lat FLOAT, @stop_lon FLOAT)
RETURNS BIGINT
AS --D:\users\yuil\JOB\EWES\SQL\transman\file_stops\dbo.FN_near_stop_id
BEGIN
	DECLARE @stop_id BIGINT  ;

	DECLARE @delta FLOAT;  SET @delta=0.1

	SET @stop_id=
	(SELECT stop_id FROM
	 (SELECT stop_id, ROW_NUMBER() OVER (ORDER BY dist ASC)i_order FROM
	  (SELECT stop_id, dbo.FN_get_dist(stop_lat, stop_lon, @stop_lat, @stop_lon)dist FROM dbo.picas_stops WHERE ABS(stop_lat - @stop_lat)<@delta AND ABS(stop_lon - @stop_lon)<@delta) s
	 )s
	 WHERE i_order=1
	)

	RETURN @stop_id;
END
