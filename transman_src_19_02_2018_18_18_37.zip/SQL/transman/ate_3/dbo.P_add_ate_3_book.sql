ALTER PROC dbo.P_add_ate_3_book
( @device_number NVARCHAR(16)=NULL
, @garage_num NVARCHAR(8)=NULL
, @mark NVARCHAR(16)=NULL
, @state_num NVARCHAR(16)=NULL
, @agent_name NVARCHAR(64)=NULL
) 
AS 
--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\dbo.P_add_ate_3_book
---------------------------------------------------------
	DECLARE @id_ate_3_book BIGINT; SET @id_ate_3_book = ISNULL((SELECT MAX(id_ate_3_book) FROM dbo.ate_3_book),  0) + 1;

	SET IDENTITY_INSERT dbo.ate_3_book ON;

	INSERT dbo.ate_3_book(id_ate_3_book,  device_number,  garage_num,  mark,  state_num, dt_created,  agent_name) 
	SELECT               @id_ate_3_book, @device_number, @garage_num, @mark, @state_num, GETDATE(),  @agent_name

	SET IDENTITY_INSERT dbo.ate_3_book OFF;

	/*DECLARE @id_ate_3_book BIGINT; SET @id_ate_3_book = (SELECT id_ate_3_book FROM dbo.ate_3_book WHERE device_number = @device_number);

	IF (@id_ate_3_book IS NULL)
	BEGIN --YUIL ����� ��������

		SET @id_ate_3_book = ISNULL((SELECT MAX(id_ate_3_book) FROM dbo.ate_3_book), 0) + 1;

	END
	ELSE
	BEGIN
		UPDATE dbo.ate_3_book
		SET
		  garage_num =  @garage_num 
		, mark       =  @mark 
		, state_num  =  @state_num 
		, dt_update  = GETDATE()
		WHERE id_ate_3_book = @id_ate_3_book
	END*/

------------------
/*
EXEC dbo.P_add_ate_3_book    @device_number='?', @garage_num='?', @mark ='?', @state_num ='?'

SELECT * FROM dbo.ate_3_book
TRUNCATE TABLE  dbo.ate_3_book

EXEC dbo.P_add_ate_3_book @device_number=@device_number, @garage_num=@garage_num, @mark=@mark, @state_num=@state_num

*/