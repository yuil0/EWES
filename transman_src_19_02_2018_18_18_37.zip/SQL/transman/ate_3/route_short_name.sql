--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\route_short_name
SELECT route_short_name,  count(1) FROM  dbo.ate_3 
group by route_short_name