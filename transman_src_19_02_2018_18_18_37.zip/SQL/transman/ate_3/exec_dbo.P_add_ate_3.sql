--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\exec_dbo.P_add_ate_3
SELECT * FROM dbo.zones
EXEC dbo.P_add_ate_3 @device_number='M178OH', @latitude=47.259100, @longitude=39.685300, @x=4417740, @y=5984470, @route_en='96'

EXEC dbo.P_add_ate_3 @device_number=N'M178OH', @latitude=47.259, @longitude=39.685, @x=4417730, @y=5984470, @route_en=N'96'

--<q1	
DECLARE @dt DATETIME; SET @dt=GETDATE()
EXEC dbo.P_find_stop_by_car @dt=@dt, @device_number='M178OH', @route_id='96', @x=1, @y=1
-->q1	

--SELECT * FROM dbo.ate_3 WHERE device_number='M178OH'

latitude, longitude

-- EXEC dbo.P_add_ate_3 @device_number=@device_number, @latitude=@latitude, @longitude=@longitude, @x=@x, @y=@y, @route_en=@route_en