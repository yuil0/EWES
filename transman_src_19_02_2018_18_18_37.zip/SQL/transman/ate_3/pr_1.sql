DECLARE @id_picas_route BIGINT; SET @id_picas_route=65;

SELECT * FROM dbo.car_last_stops WHERE id_ate_3 = 8

SELECT cp.*,s.stop_id FROM dbo.check_points cp, dbo.picas_stops s WHERE cp.id_picas_stop = s.id_picas_stop AND s.stop_id IN (905,  862, 1870) AND cp.id_picas_route=@id_picas_route

SELECT MIN(i_order)min_i_order_f_forward_1 FROM dbo.check_points cp WHERE cp.id_picas_route=@id_picas_route AND f_forward=1
SELECT MAX(i_order)max_i_order_f_forward_0 FROM dbo.check_points cp WHERE cp.id_picas_route=@id_picas_route AND f_forward=0

--SELECT dbo.FN_is_one_direct_car_stop(4, 1870) [is_one_direct_car_stop]
SELECT dbo.FN_get_forward_by_check_point(@id_picas_route, 1870) 
SELECT dbo.FN_get_forward_by_check_point(@id_picas_route, 905) 



