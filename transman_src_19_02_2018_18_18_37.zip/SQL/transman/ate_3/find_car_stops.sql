--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\find_car_stops
--��� ��������� ������ ������� ��� ��������� 
DECLARE @stop_radius FLOAT; SELECT @stop_radius=stop_radius FROM dbo.const

SELECT c.device_number, c.x, c.y, s.stop_id FROM dbo.ate_3 c, dbo.picas_stops s WHERE dbo.FN_cross(c.x, c.y, s.x, s.y, @stop_radius)=1
ORDER BY c.device_number

--<q1
DECLARE @x FLOAT, @y FLOAT; SET @x=4418178.862325; SET @y=5988335.517836
DECLARE @stop_radius FLOAT; SELECT @stop_radius=stop_radius FROM dbo.const
SELECT s.stop_id FROM dbo.picas_stops s WHERE dbo.FN_cross(@x, @y, s.x, s.y, @stop_radius)=1
-->q1

--<q2 //YUIL 2017-10-13
DECLARE @stop_radius FLOAT; SELECT @stop_radius=stop_radius FROM dbo.const

DECLARE @stop AS TABLE(i_stop BIGINT IDENTITY(1,1), stop_id BIGINT)

INSERT @stop(stop_id) SELECT TOP 2 s.stop_id FROM dbo.picas_stops s WHERE dbo.FN_cross(@x, @y, s.x, s.y, @stop_radius)=1

DECLARE @stop_1 BIGINT; SET @stop_1=(SELECT stop_id FROM @stop WHERE i_stop=1)
DECLARE @stop_2 BIGINT; SET @stop_2=(SELECT stop_id FROM @stop WHERE i_stop=2)
-->q2
