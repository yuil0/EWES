CREATE PROC dbo.P_find_near_lag_lead_car_B(@dt DATETIME, @route_id NVARCHAR(32), @device_number NVARCHAR(16))  AS
------------------------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\dbo.dbo.P_find_near_lag_lead_car_B
-- ������ ��������� ����������, ������� �� ������� ������ �� �������� �����

DECLARE @time TIME; SET @time=dbo.FN_get_time(@dt);

DECLARE @stop_radius FLOAT, @valid_dev_sec INT; SELECT @stop_radius=stop_radius, @valid_dev_sec=valid_dev_sec FROM dbo.const

DECLARE @found_near_lag_lead_car AS TABLE (stop_id BIGINT, shape_id NVARCHAR(32), arrival_time TIME, departure_time TIME, device_number_lag NVARCHAR(16), device_number_lead NVARCHAR(16), f_lag BIT, f_lead BIT, i_order INT)

--INSERT @found_near_lag_lead_car (stop_id,   shape_id,   arrival_time,   departure_time, device_number_lag, device_number_lead,                             i_order, f_lag, f_lead)
SELECT                         t.stop_id, t.shape_id, t.arrival_time, t.departure_time--, device_number_lag, device_number_lead, ROW_NUMBER() OVER (ORDER BY t.dist) --, CASE WHEN @device_number = device_number_lag THEN 1 ELSE 0 END f_lag, CASE WHEN @device_number = device_number_lead THEN 1 ELSE 0 END f_lead
FROM
(SELECT s.stop_id, t.shape_id, st.arrival_time, st.departure_time, st.stop_sequence
 , dbo.FN_cross(c.x, c.y, s.x, s.y, @stop_radius) dist 
 FROM dbo.picas_stop_times st, dbo.picas_trips t, dbo.picas_stops s, dbo.ate_3 c
 WHERE s.stop_id=st.stop_id AND @time>=DATEADD(second, - @valid_dev_sec, st.arrival_time) AND @time<=DATEADD(second, @valid_dev_sec, st.departure_time) AND st.trip_id=t.trip_id AND t.route_id=@route_id
 AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
 AND dbo.FN_cross(c.x, c.y, s.x, s.y, @stop_radius)=0 --���� ���� ������ �� �� ���������
)t
ORDER BY t.stop_id, t.shape_id, t.arrival_time

--SELECT * FROM @found_near_lag_lead_car
