--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\find_lag_lead
DECLARE @id_picas_route BIGINT; SET @id_picas_route=65;

DECLARE @dt DATETIME; SET @dt = GETDATE();
DECLARE @date DATETIME; SET @date = dbo.FN_get_date(@dt);

DECLARE @time TIME; SET @time=dbo.FN_get_time(@dt);

DECLARE @stop_radius FLOAT, @valid_dev_sec INT; SELECT @stop_radius=stop_radius, @valid_dev_sec=valid_dev_sec FROM dbo.const -- --, CASE WHEN c.stop_id IN (cls.stop_id_1, cls.stop_id_2) THEN 1 ELSE 0 END

DECLARE @max_time_dist_minutes INT; SET @max_time_dist_minutes=5;
DECLARE @max_d_time INT; SET @max_d_time=60;

SELECT @dt[@dt], @time[@time]

SELECT c.id_picas_stop, c.stop_id, c.arrival_time, c.departure_time, c.id_ate_3, c.device_number, c.dist, c.stop_id_1 --, c.stop_id_2, c.stop_id_1_prev, c.stop_id_2_prev
, c.dt_car_last_stop 
,f_forward_stop, i_order_stop, f_forward_car, i_order_car, id_lag_lead
, CASE WHEN id_lag_lead=1 
   THEN CASE WHEN d_time<@max_d_time THEN d_time ELSE -1 END
   ELSE 
    CASE WHEN time_order>=0 AND d_time<@max_d_time THEN time_order - d_time ELSE -1 END
  END dist_minutes --, DATEDIFF(minute, c.arrival_time, @time)  
  ,time_order , d_time
FROM 
(SELECT c.id_picas_stop, c.stop_id, c.arrival_time, c.departure_time, c.id_ate_3, c.device_number, c.dist, cls.stop_id_1, cls.stop_id_2, cls.stop_id_1_prev, cls.stop_id_2_prev
, ISNULL(cls.dt_update, cls.dt_created)dt_car_last_stop --��������� ����� ����������� ���������. ��� ����.
 , ROW_NUMBER() OVER (PARTITION BY c.stop_id, cp_stop.f_forward ORDER BY dist) i_order_stop_dist
 ,cp_stop.f_forward f_forward_stop, cp_stop.i_order i_order_stop
 ,cp_car.f_forward f_forward_car, cp_car.i_order i_order_car
 ,CASE WHEN c.stop_id = cls.stop_id_1 THEN 1
   ELSE
   CASE WHEN cp_car.i_order > cp_stop.i_order THEN 1 
	 ELSE 2 
   END
  END AS id_lag_lead
  ,  dbo.FN_get_time_order_by_mnemoscheme_event_minutes(@id_picas_route, cp_car.f_forward, cp_car.i_order) time_order
  ,  DATEDIFF(minute, (SELECT ISNULL(dt_update, dt_created) FROM dbo.car_last_stops x, dbo.picas_routes r WHERE r.route_id=x.route_id AND r.id_picas_route=@id_picas_route AND x.id_ate_3=c.id_ate_3), @dt) d_time
  --,  DATEDIFF(minute, dbo.FN_get_last_date_by_mnemoscheme_event(@id_picas_route, c.id_ate_3, cp_car.f_forward, cp_car.id_check_point), @dt) d_time --,dbo.FN_get_time_dist_minutes_by_mnemoscheme_events(cp_stop.id_check_point, cp_car.id_check_point) >  @max_time_dist_minutes
 FROM 
 (SELECT DISTINCT s.id_picas_stop, s.stop_id, st.arrival_time, st.departure_time, c.id_ate_3, dbo.FN_get_dist(c.x, c.y, s.x, s.y) dist, c.device_number FROM 
  dbo.picas_stop_times st, dbo.picas_trips t, dbo.picas_stops s, dbo.ate_3 c, dbo.picas_routes r, dbo.car_type ct 
  WHERE s.stop_id=st.stop_id AND @time>=DATEADD(second, - @valid_dev_sec, st.arrival_time) AND @time<=DATEADD(second, @valid_dev_sec, st.departure_time) AND st.trip_id=t.trip_id AND t.route_id=r.route_id
  AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
  AND dbo.FN_cross(c.x, c.y, s.x, s.y, @stop_radius)=0 --���� ���� ������ �� �� ��������� 
  AND r.id_picas_route = @id_picas_route
  AND r.route_id = 'rostov_'+ct.name_short_en+'_'+c.route_en AND ISNULL(c.route_en,'')!='' AND c.id_car_type = ct.id_car_type 
  AND s.id_picas_stop IN (SELECT id_picas_stop FROM dbo.check_points cp WHERE cp.id_picas_route = @id_picas_route GROUP BY id_picas_stop HAVING count(1)=1) --������ ��������� ����� �������� --SELECT DISTINCT id_picas_stop FROM dbo.check_points cp WHERE cp.id_picas_route = @id_picas_route) 
 )c
 LEFT JOIN (SELECT stop_id, f_forward, i_order, id_check_point FROM dbo.check_points cp, dbo.picas_stops s WHERE cp.id_picas_stop = s.id_picas_stop AND cp.id_picas_route=@id_picas_route)cp_stop ON (cp_stop.stop_id = c.stop_id)
, dbo.car_last_stops cls
 LEFT JOIN (SELECT stop_id, f_forward, i_order, id_check_point FROM dbo.check_points cp, dbo.picas_stops s WHERE cp.id_picas_stop = s.id_picas_stop AND cp.id_picas_route=@id_picas_route)cp_car ON (cp_car.stop_id = cls.stop_id_1)

 WHERE cls.id_ate_3 = c.id_ate_3 AND ISNULL(cls.dt_update, cls.dt_created)>=@date 
 AND cp_stop.f_forward = cp_car.f_forward --dbo.FN_get_forward_by_check_point(@id_picas_route, c.stop_id) = dbo.FN_get_forward_by_check_point(@id_picas_route, cls.stop_id_1)   
 AND (cp_stop.i_order = cp_car.i_order OR cp_stop.i_order - cp_car.i_order=1)
)c 
--WHERE i_order_stop_dist=1
ORDER BY c.id_picas_stop, c.arrival_time, c.id_ate_3