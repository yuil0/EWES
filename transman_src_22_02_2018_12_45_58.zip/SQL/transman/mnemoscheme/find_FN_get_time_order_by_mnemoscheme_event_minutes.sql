--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\find_FN_get_time_order_by_mnemoscheme_event_minutes
	DECLARE @id_picas_route BIGINT, @f_forward BIT, @i_order INT

	SET @id_picas_route=65; 
	SET @f_forward=1;
	SET @i_order=0;

	DECLARE @i_minutes INT, @i_order_next INT, @f_forward_next BIT

	DECLARE @i_order_max INT; SET @i_order_max  = (SELECT MAX(i_order) FROM dbo.check_points WHERE id_picas_route=@id_picas_route AND f_forward=@f_forward)

	IF (@i_order=@i_order_max)
	BEGIN
		SET @i_order_next=0;
		SET @f_forward_next= CASE WHEN @f_forward=1 THEN 0 ELSE 1 END;
	END ELSE
	BEGIN
		SET @i_order_next=@i_order+1;
		SET @f_forward_next= @f_forward;
	END

	DECLARE @t AS TABLE (id_mnemoscheme_event BIGINT, id_ate_3 BIGINT, dt DATETIME,  i_order_car INT);

	INSERT @t(id_mnemoscheme_event, id_ate_3, dt, i_order_car)
	SELECT    id_mnemoscheme_event, id_ate_3, dt, ROW_NUMBER() OVER (PARTITION BY id_ate_3 ORDER BY i_order) i_order_car
	FROM dbo.mnemoscheme_events WHERE id_picas_route=@id_picas_route AND f_forward = @f_forward AND i_order IN (@i_order, @i_order_next)
	ORDER BY id_ate_3, i_order

	SELECT * FROM @t
	
	DECLARE @a AS TABLE (id_ate_3 BIGINT, dt_from DATETIME, dt_to DATETIME);

	INSERT @a (id_ate_3, dt_from, dt_to)
	SELECT t.id_ate_3, t_from.dt, t_to.dt
	FROM (SELECT DISTINCT id_ate_3 FROM @t)t 
	LEFT JOIN @t t_from ON (t_from.id_ate_3 = t.id_ate_3 AND t_from.i_order_car=1)
	LEFT JOIN @t t_to ON (t_to.id_ate_3 = t.id_ate_3 AND t_to.i_order_car=2)

	DELETE FROM @a WHERE dt_from >= dt_to
	
	DELETE FROM @a WHERE dbo.FN_get_date(dt_from)!=dbo.FN_get_date(dt_to);

	DELETE FROM @a WHERE DATEDIFF(hour, dt_from, dt_to)>1

	SELECT *, DATEDIFF(minute, dt_from, dt_to)delta FROM @a

	DECLARE @q INT; SET @q=ISNULL((SELECT COUNT(1) FROM @a),0)

	IF (@q=0) BEGIN print 'FN_get_time_order_by_mnemoscheme_event_minutes. @q=0'; RETURN; END --DECLARE @b AS TABLE (minutes INT); INSERT @b(minutes) SELECT DATEDIFF(minute, dt_from, dt_to) FROM @a --����� ��������  �������

	SET @i_minutes= ISNULL((SELECT SUM(DATEDIFF(minute, dt_from, dt_to))/@q FROM @a), 0)

	SELECT @i_minutes[@i_minutes]