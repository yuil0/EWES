ALTER PROC dbo.P_add_mnemoscheme_event
(
@device_number NVARCHAR(16)=NULL
) 
AS
--------------------------------------------------------
-- D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\dbo.P_add_mnemoscheme_event

--RETURN
--1. ��������� ��������� car � ������� ��������� ������������ ��� ����������� �����.
DECLARE @stop_radius FLOAT; SELECT @stop_radius=stop_radius FROM dbo.const

DECLARE @dt DATETIME; SET @dt=GETDATE(); --DECLARE @id_ate_3 BIGINT; SET @id_ate_3=(SELECT id_ate_3 FROM dbo.mnemoscheme_events WHERE )

DECLARE @dt_data_max DATETIME; SET @dt_data_max=(SELECT MAX(dt_created) FROM dbo.mnemoscheme_events);

IF (DATEDIFF(second, @dt_data_max, @dt)<5) BEGIN  print 'To fast.Exit without add'; RETURN; END

DECLARE @found_cross AS TABLE(dt DATETIME, id_picas_route BIGINT, id_ate_3 BIGINT, id_check_point BIGINT, f_forward BIT, i_order INT)

INSERT @found_cross (dt,    id_picas_route,   id_ate_3,    id_check_point,    f_forward ,   i_order)
SELECT             c.dt, cp.id_picas_route, c.id_ate_3, cp.id_check_point, cp.f_forward, cp.i_order
 FROM dbo.ate_3 c, dbo.check_points cp, dbo.picas_routes r
 WHERE cp.id_picas_route = r.id_picas_route AND r.route_id=c.route_id AND dbo.FN_cross(c.x, c.y, cp.x, cp.y, @stop_radius)=1
 AND c.device_number = ISNULL(@device_number, c.device_number) --//YUIL 2017-02-05

INSERT dbo.mnemoscheme_events(id_picas_route, id_ate_3, f_forward, id_check_point,  dt, i_order, dt_created)
SELECT                        id_picas_route, id_ate_3, f_forward, id_check_point,  dt, i_order,        @dt FROM @found_cross e 
WHERE 
NOT EXISTS
( SELECT TOP 1 1 FROM dbo.mnemoscheme_events t 
  WHERE t.dt = e.dt AND t.id_check_point = e.id_check_point AND t.id_ate_3 = e.id_ate_3 AND t.id_picas_route = e.id_picas_route) -- AND t.f_forward = e.f_forward AND t.i_order = e.i_order )
