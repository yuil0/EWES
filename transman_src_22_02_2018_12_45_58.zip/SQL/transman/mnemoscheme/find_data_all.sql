--D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\find_data_all

DECLARE @id_picas_route BIGINT; SET @id_picas_route=64;
DECLARE @f_no_stat_dt_prev BIT; SET @f_no_stat_dt_prev=0;

SELECT id_ate_3, i_order, id_check_point, f_forward, max_dt FROM
(SELECT id_ate_3, i_order, id_check_point, f_forward, dt, (SELECT MAX(dt) FROM dbo.mnemoscheme_events x WHERE x.id_picas_route = @id_picas_route AND x.id_ate_3 = e.id_ate_3)max_dt  
 FROM dbo.mnemoscheme_events e
 WHERE 
 id_picas_route = @id_picas_route 
)e WHERE e.dt = e.max_dt
--AND dt = (SELECT MAX(dt) FROM dbo.mnemoscheme_events x WHERE x.id_picas_route = @id_picas_route AND x.id_ate_3 = e.id_ate_3)
ORDER BY max_dt --f_forward