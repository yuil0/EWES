ALTER FUNCTION dbo.FN_get_last_date_by_mnemoscheme_event(@id_picas_route BIGINT, @id_ate_3 BIGINT, @f_forward BIT, @id_check_point BIGINT)
RETURNS DATETIME
AS --D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\dbo.FN_get_last_date_by_mnemoscheme_event
BEGIN
	DECLARE @dt DATETIME

	/*DECLARE @id_picas_route BIGINT, @id_ate_3 BIGINT, @f_forward BIT, @id_check_point BIGINT
	SET @id_picas_route=65
	SET @id_ate_3=38
	SET @f_forward=0*/


	SET @dt=(SELECT MAX(dt) FROM dbo.mnemoscheme_events WHERE id_picas_route=@id_picas_route AND id_ate_3=@id_ate_3 AND f_forward=@f_forward AND id_check_point=@id_check_point)
	

	RETURN @dt;
END

-- CREATE INDEX I_dt ON dbo.mnemoscheme_events(dt)