CREATE FUNCTION dbo.FN_get_car_forward_by_mnemoscheme_events(@id_ate_3 BIGINT, @dt DATETIME, @route_id NVARCHAR(32))
RETURNS BIT
AS -- D:\users\yuil\JOB\EWES\SQL\transman\mnemoscheme\dbo.FN_get_car_forward_by_mnemoscheme_events
BEGIN
	DECLARE @f_forward BIT;

	SET @f_forward = 
	(SELECT CASE WHEN sum_0 > sum_1 THEN 1 ELSE 0 END FROM 
	 (SELECT   --SUM(CASE WHEN f_forward=0 THEN 1 ELSE 0 END)sum_0, SUM(CASE WHEN f_forward=1 THEN 1 ELSE 0 END)sum_1 
	  FROM
	  (SELECT f_forward, i_order, ROW_NUMBER() OVER(ORDER BY id_mnemoscheme_event DESC) i_order_event 
	   FROM dbo.mnemoscheme_events e, dbo.picas_stop_times st, dbo.picas_stops s, dbo.picas_trips t, dbo.check_points cp
	   WHERE e.id_ate_3 = @id_ate_3 AND st.trip_id = t.trip_id AND t.route_id=@route_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
		AND st.stop_id=s.stop_id
		AND s.id_picas_stop = cp.id_picas_stop AND cp.id_check_point = e.id_check_point
	  )e WHERE i_order_event IN (1,2,3)
	 )e
	)

	RETURN @f_forward
END