--select * from dbo.mnemoscheme_events WHERE id_ate_3=20

DECLARE @t AS TABLE (dt DATETIME, id_check_point BIGINT, f_forward BIT, id_ate_3 BIGINT, id_picas_route BIGINT, i_order INT)

INSERT @t(dt, id_check_point, f_forward, id_ate_3, id_picas_route, i_order)
select    dt, id_check_point, f_forward, id_ate_3, id_picas_route, i_order FROM dbo.mnemoscheme_events 
GROUP BY dt, id_check_point, f_forward, id_ate_3, id_picas_route, i_order
HAVING count(1)>1

DELETE FROM e FROM dbo.mnemoscheme_events e WHERe EXistS(SELECT 1 FROM @t t WHERE t.dt=e.dt AND t.id_check_point=e.id_check_point AND t.f_forward=e.f_forward AND t.id_ate_3=e.id_ate_3 AND t.id_picas_route=e.id_picas_route AND t.i_order=e.i_order)

INSERT  dbo.mnemoscheme_events(dt, dt_created, id_check_point, f_forward, id_ate_3, id_picas_route, i_order)
                       SELECT  dt,         dt, id_check_point, f_forward, id_ate_3, id_picas_route, i_order FROM @t