CREATE PROC dbo.P_clear_mes AS
------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\chat\dbo.P_clear_mes

DECLARE @dt  DATETIME; SET @dt =GETDATE();
DECLARE @max_days_back INT; SET @max_days_back=30;

--<q1
DELETE FROM m FROM  dbo.chat_mes_head h, dbo.chat_mes m WHERE h.id_chat_mes_head=m.id_chat_mes_head AND DATEDIFF(dd, h.dt_create, @dt) > @max_days_back; --//YUIL 2017-02-13
DELETE FROM h FROM  dbo.chat_mes_head h WHERE DATEDIFF(dd, h.dt_create, @dt) > @max_days_back; --//YUIL 2017-02-13
-->q1