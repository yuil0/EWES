--D:\users\yuil\JOB\EWES\SQL\transman\chat\exec_dbo.P_add_chat_mes

EXEC dbo.P_add_chat_mes @id_user_from BIGINT, @id_user_to BIGINT, @id_chat_mes_state BIGINT, @id_chat_mes_type BIGINT, @mes=N''

--@id_chat_mes_type=4