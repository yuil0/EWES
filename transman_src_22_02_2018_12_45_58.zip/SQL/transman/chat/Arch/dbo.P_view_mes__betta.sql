ALTER PROC dbo.P_view_mes (@id_user_1 BIGINT=NULL, @id_user_2 BIGINT=NULL, @i_quantity INT=NULL) AS
------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\chat\dbo.P_view_mes

IF  (@i_quantity IS NULL)
BEGIN
	SET @i_quantity=(SELECT COUNT(1) FROM dbo.chat_mes)
END

DECLARE @user_list AS TABLE(id_user BIGINT);

INSERT @user_list (id_user) SELECT @id_user_1 WHERE @id_user_1 IS NOT NULL
INSERT @user_list (id_user) SELECT @id_user_2 WHERE @id_user_2 IS NOT NULL

DECLARE @q_user INT; SET @q_user= ISNULL((SELECT COUNT(1) FROM @user_list),0);

IF (@q_user=0) RETURN;

SELECT TOP (@i_quantity) REPLACE(CONVERT(NVARCHAR(40), dt_create, 113),':000', '') dt_create
, (SELECT user_name FROM dbo.users u WHERE u.id_user = h.id_user_from) user_from
, (SELECT user_name FROM dbo.users u WHERE u.id_user = h.id_user_to) user_to
, id_chat_mes_type
, mes 
FROM dbo.chat_mes_head h, dbo.chat_mes m WHERE h.id_chat_mes_head=m.id_chat_mes_head 
AND 
(   @q_user=1 AND (h.id_user_from IN (SELECT id_user FROM @user_list) OR h.id_user_to IN (SELECT id_user FROM @user_list))
 OR @q_user=2 AND (h.id_user_from IN (SELECT id_user FROM @user_list) AND h.id_user_to IN (SELECT id_user FROM @user_list))
)
--AND h.id_chat_mes_head=94
ORDER BY h.id_chat_mes_head DESC

