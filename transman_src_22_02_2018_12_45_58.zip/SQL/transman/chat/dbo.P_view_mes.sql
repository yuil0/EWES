ALTER PROC dbo.P_view_mes (@id_user_1 BIGINT=NULL, @id_user_2 BIGINT=NULL, @i_quantity INT=NULL) AS
------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\chat\dbo.P_view_mes

IF  (@i_quantity IS NULL)
BEGIN
	SET @i_quantity=(SELECT COUNT(1) FROM dbo.chat_mes)
END

SELECT TOP (@i_quantity) REPLACE(CONVERT(NVARCHAR(40), dt_create, 113),':000', '') dt_create
, (SELECT user_name FROM dbo.users u WHERE u.id_user = h.id_user_from) user_from
, (SELECT user_name FROM dbo.users u WHERE u.id_user = h.id_user_to) user_to
, id_chat_mes_type
, mes 
FROM dbo.chat_mes_head h, dbo.chat_mes m WHERE h.id_chat_mes_head=m.id_chat_mes_head 
AND 
(   (h.id_user_from IN (@id_user_1, @id_user_2) AND h.id_user_to IN (@id_user_1, @id_user_2))
)
--AND h.id_chat_mes_head=94
ORDER BY h.id_chat_mes_head DESC

