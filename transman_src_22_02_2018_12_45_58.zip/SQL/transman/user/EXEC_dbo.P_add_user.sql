--D:\users\yuil\JOB\EWES\SQL\transman\user\EXEC_dbo.P_add_user

EXEC dbo.P_add_user @user_name=N'�������', @password=N'12345', @id_user_type=1, @id_user BIGINT OUTPUT

EXEC dbo.P_add_user @user_name=N'����', @password=N'12345', @id_user_type=2

EXEC dbo.P_add_user @user_name=N'���', @password=N'12345', @id_user_type=2

EXEC dbo.P_add_user @user_name=N'����_�', @password=N'12345', @id_user_type=3

EXEC dbo.P_add_user @user_name=N'����_�', @password=N'12345', @id_user_type=3

EXEC dbo.P_add_user @user_name=N'����_�', @password=N'12345', @id_user_type=3

EXEC dbo.P_add_user @user_name=N'����_�', @password=N'12345', @id_user_type=3

/*
SELECT * FROM dbo.user_types
SELECT * FROM dbo.users
SELECT * FROM dbo.chat_mes_states
SELECT * FROM dbo.chat_mes
SELECT * FROM dbo.chat_mes_head
SELECT * FROM dbo.user_binds
*/