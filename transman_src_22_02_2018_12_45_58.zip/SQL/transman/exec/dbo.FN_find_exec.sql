CREATE FUNCTION dbo.FN_find_exec(@sz_text NVARCHAR(128)) 
RETURNS BIT
AS --//YUIL 2017-09-27 : D:\users\yuil\JOB\EWES\SQL\transman\exec\dbo.FN_find_exec
BEGIN
	DECLARE  @f_found BIT; 
	
	SET @f_found=ISNULL((SELECT 1 FROM sys.dm_exec_requests r CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) t WHERE r.session_id!=@@SPID AND CHARINDEX(@sz_text, t.text)!=0), 0)

	RETURN @f_found;
END