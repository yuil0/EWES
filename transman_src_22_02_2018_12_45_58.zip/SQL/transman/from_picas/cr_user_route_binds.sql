--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\cr_user_route_binds.sql

--<q1
DROP TABLE dbo.user_route_binds
CREATE TABLE dbo.user_route_binds
(id_user_route_bind BIGINT IDENTITY(1,1)
, id_user BIGINT
, id_picas_route BIGINT
)
-->q1
CREATE CLUSTERED INDEX I_id_user_route_bind ON dbo.user_route_binds(id_user_route_bind)
