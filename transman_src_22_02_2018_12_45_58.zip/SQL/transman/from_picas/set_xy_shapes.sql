--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\set_xy_shapes
SELECT * FROM dbo.picas_shapes WHERE x IS NULL OR y IS NULL

--<q1
DECLARE @id_picas_shape BIGINT; SET @id_picas_shape=(SELECT MIN(id_picas_shape) FROM dbo.picas_shapes WHERE x IS NULL OR y IS NULL)

WHILE  @id_picas_shape IS NOT NULL
BEGIN
	DECLARE @shape_pt_lat FLOAT, @shape_pt_lon FLOAT, @x FLOAT, @y FLOAT

	SELECT @shape_pt_lat=shape_pt_lat, @shape_pt_lon=shape_pt_lon FROM dbo.picas_shapes WHERE (x IS NULL OR y IS NULL) AND id_picas_shape=@id_picas_shape

	EXEC dbo.P_latitude_longitude_to_xy @lat=@shape_pt_lat, @lng=@shape_pt_lon, @x=@x OUTPUT, @y=@y OUTPUT;

	UPDATE dbo.picas_shapes SET x=@x, y=@y WHERE id_picas_shape=@id_picas_shape

	SET @id_picas_shape=(SELECT MIN(id_picas_shape) FROM dbo.picas_shapes WHERE x IS NULL OR y IS NULL)
END
-->q1