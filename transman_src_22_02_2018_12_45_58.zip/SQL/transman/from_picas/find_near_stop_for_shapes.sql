--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\find_near_stop_for_shapes

DECLARE @dt DATETIME; SET @dt='2017-10-13T09:00:00'; --DECLARE @device_number NVARCHAR(16);
DECLARE @time TIME; SET @time=dbo.FN_get_time(@dt);
DECLARE @x FLOAT; SET @x=4417855.033926
DECLARE @y FLOAT; SET @y=5986346.578824
DECLARE @route_id NVARCHAR(32); SET @route_id='rostov_bus_94';

DECLARE @stop_radius FLOAT; SELECT @stop_radius=stop_radius FROM dbo.const

SELECT * FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND t.route_id=@route_id AND @time>=st.arrival_time AND @time<=st.departure_time
AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1