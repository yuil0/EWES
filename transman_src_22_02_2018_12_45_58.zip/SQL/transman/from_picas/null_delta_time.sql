--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\null_delta_time.sql

SELECT * FROM dbo.picas_stop_times WHERE departure_time<arrival_time --0

SELECT DATEDIFF(second,  arrival_time,   departure_time)d_second FROM dbo.picas_stop_times 

SELECT d_second, count(1)q_second FROM 
(SELECT DATEDIFF(second,  arrival_time,   departure_time)d_second FROM dbo.picas_stop_times)x
GROUP BY  d_second

SELECT f_second, count(1)q_f_second FROM 
(SELECT CASE WHEN DATEDIFF(second,  arrival_time,   departure_time)=0 THEN 0 ELSE 1 END f_second FROM dbo.picas_stop_times)x
GROUP BY  f_second
/*
f_second	q_f_second
0			758972
1			 26553
*/

SELECT stop_sequence, count(1) FROM dbo.picas_stop_times 
GROUP BY  stop_sequence
ORDER BY  stop_sequence

SELECT * FROM dbo.picas_stop_times WHERE stop_sequence=1