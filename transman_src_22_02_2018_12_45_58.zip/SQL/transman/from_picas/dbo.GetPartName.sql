ALTER FUNCTION dbo.GetPartName(@sz_in NVARCHAR(32), @q_max INT)
RETURNS  --D:\users\yuil\JOB\EWES\SQL\transman\from_picas\dbo.GetPartName
NVARCHAR(32)
AS
BEGIN
  DECLARE  @sz_out NVARCHAR(32); SET @sz_out=''
  DECLARE  @index INT; SET @index=1
  DECLARE  @q INT; SET @q=0;

  SET @index=CHARINDEX('_',  @sz_in, @index);

  WHILE (@index>0)
  BEGIN

	SET @q=@q+1;

	IF (@q = @q_max)
	BEGIN
		SET @sz_out=SUBSTRING(@sz_in, 1,  @index-1);
	END

    SET @index=CHARINDEX('_',  @sz_in, @index+1);
  END

  RETURN @sz_out
END