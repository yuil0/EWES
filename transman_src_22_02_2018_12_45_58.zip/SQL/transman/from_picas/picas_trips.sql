--D:\users\yuil\JOB\EWES\SQL\transman\from_picas\picas_trips
--<q1

DROP TABLE dbo.picas_trips

CREATE TABLE dbo.picas_trips   --  rostov_bus_1, 197665, 1, "���. �����������",,, rostov_bus_1_a-b,
(id_trip BIGINT IDENTITY(1,1)
, dt_created DATETIME --YUIL. ����/����� ��������  ������
, route_id NVARCHAR(32)
, service_id BIGINT
, trip_id BIGINT
, trip_headsign NVARCHAR(64)
, direction_id NVARCHAR(10)
, block_id NVARCHAR(10)
, shape_id NVARCHAR(32)     
, wheelchair_accessible NVARCHAR(1)
)

CREATE CLUSTERED INDEX I_id_trip ON dbo.picas_trips(id_trip) 
CREATE NONCLUSTERED INDEX I_trip_id ON dbo.picas_trips(trip_id) 
CREATE NONCLUSTERED INDEX I_service_id ON dbo.picas_trips(service_id) 

sp_spaceused 'dbo.picas_trips'

SELECT * FROM dbo.picas_trips --order  by id_trip

--SELECT name, quantity, latitude_0, longitude_0, latitude_1, longitude_1, latitude_2, longitude_2, latitude_3, longitude_3 FROM dbo.picas_trips

TRUNCATE TABLE dbo.picas_trips 

INSERT dbo.picas_trips(dt_created,  route_id, service_id, trip_id, trip_headsign, direction_id, block_id, shape_id, wheelchair_accessible)
                SELECT GETDATE(),        N'',        123,     132,           N'',          N'',      N'',      N'',                     1
				 

-->q1

