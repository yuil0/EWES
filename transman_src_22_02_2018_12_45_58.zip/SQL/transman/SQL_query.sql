-- D:\users\yuil\JOB\EWES\SQL\transman\SQL_query
select * from dbo.car_type

SELECT * FROM dbo.users

SELECT * FROM dbo.user_binds

DELETE FROM dbo.user_binds Where id_user=9

INSERT dbo.user_binds(id_user_one, id_user) SELECT id_user, @id_user FROM dbo.users WHERE user_name=N'NAME'

SELECT * FROM dbo.user_route_binds

SELECT * FROM dbo.picas_routes

SELECT * FROM dbo.car_type

SELECT r.id_picas_route id, dbo.FN_get_short_name(route_id, route_short_name)name FROM dbo.picas_routes r, dbo.user_route_binds urb WHERE r.id_picas_route = urb.id_picas_route AND id_user=(SELECT id_user FROM dbo.users WHERE user_name=N'NAME')

SELECT id_picas_route id, dbo.FN_get_short_name(route_id, route_short_name)name FROM dbo.picas_routes WHERE id_picas_route NOT IN (SELECT id_picas_route FROM dbo.user_route_binds)

DELETE FROM dbo.user_route_binds WHERE id_picas_route=@id_picas_route

INSERT dbo.user_route_binds (id_user, id_picas_route) SELECT id_user, @id_picas_route FROM dbo.users WHERE user_name=N'NAME'

select * FROM dbo.ate_3 

SELECT 'rostov_'+ct.name_short_en+'_'+N'79' FROM dbo.car_type ct WHERE 4=ct.id_car_type

select * from dbo.picas_agents

UPDATE c SET c.route_id=(SELECT 'rostov_'+ct.name_short_en+'_'+c.route_en FROM dbo.car_type ct WHERE c.id_car_type=ct.id_car_type)
FROM dbo.ate_3 c

route_id

UPDATE c SET c.id_picas_route=(SELECT id_picas_route FROM dbo.picas_routes r WHERE r.route_id=c.route_id)
FROM dbo.ate_3 c