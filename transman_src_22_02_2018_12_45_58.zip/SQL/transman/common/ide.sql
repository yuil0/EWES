--D:\users\yuil\JOB\EWES\SQL\transman\common\ide
SELECT device_number FROM dbo.ate_3

SELECT TOP 10 id_formalize_message, dt_created, device_number, route_short_name, garage_num, state_num, stop_name_from, time_cmd_minute_from, stop_name_to, time_cmd_minute_to, i_state FROM dbo.formalize_messages WHERE i_state=0
SELECT dt, device_number, latitude, longitude, azimut, speed, dt_created, dt_update, ISNULL(route_short_name,N'?')route_short_name, x, y, ISNULL((SELECT id_picas_route FROM dbo.picas_routes r WHERE r.route_id=c.route_id),0)id_picas_route, ISNULL((SELECT TOP 1 1 FROM dbo.formalize_messages m WHERE m.id_ate_3 = c.id_ate_3), 0) f_formalize_messages FROM dbo.ate_3 c

SELECT device_number FROM dbo.ate_3

SELECT DISTINCT stop_name FROM dbo.picas_stops WHERE id_picas_stop IN (SELECT DISTINCT id_picas_stop FROM dbo.check_points) ORDER BY 1

SELECT DISTINCT id_picas_stop, stop_name FROM dbo.picas_stops WHERE id_picas_stop IN (SELECT DISTINCT id_picas_stop FROM dbo.check_points) ORDER BY 1
SELECT id_picas_stop, stop_name FROM dbo.picas_stops WHERE id_picas_stop IN (SELECT DISTINCT id_picas_stop FROM dbo.check_points) ORDER BY 1