--D:\users\yuil\JOB\EWES\SQL\transman\audio\cr_audio.sql

--<q1 wav_file ��������� �� ��������� �������� transman* (transman_co)
DROP TABLE dbo.audio_out
CREATE TABLE dbo.audio_out
( id_audio_out BIGINT IDENTITY(1,1)
, dt_created DATETIME
, device_number NVARCHAR(16) ----//
, wav_file VARBINARY(300) -- 44 + 256 = size_header + len_data
)
CREATE CLUSTERED INDEX I_id_audio_out ON dbo.audio_out(id_audio_out)

CREATE INDEX I_device_number ON dbo.audio_out(device_number)

SELECT *, LEN(wav_file) FROM dbo.audio_out

-->q1

--<q4
DECLARE @wav_file VARBINARY(300); SET @wav_file=0x00;
SET @wav_file = @wav_file + 0xFF; print '1. '+CONVERT(NVARCHAR(10), LEN(@wav_file));
SET @wav_file = @wav_file + 0xFF; print '2. '+CONVERT(NVARCHAR(10), LEN(@wav_file));

SELECT @wav_file[@wav_file]
-->q4

--<q3
TRUNCATE TABLE dbo.audio_out
---
DECLARE @device_number NVARCHAR(16); SET @device_number='M169OH'
DECLARE @wav_file VARBINARY(300); SET @wav_file=0x00;
DECLARE @i INT; SET @i=0;
WHILE @i < 300-1
BEGIN
 SET @wav_file = @wav_file + 0xFF;

 SET @i = @i + 1
END
SELECT @wav_file[@wav_file], LEN(@wav_file)[len_wav_file]
---------
DECLARE @id_audio_out_prev BIGINT; SET @id_audio_out_prev=ISNULL((SELECT MAX(id_audio_out) FROM dbo.audio_out), 0);

SET IDENTITY_INSERT dbo.audio_out ON
INSERT dbo.audio_out(id_audio_out, dt_created,  device_number,  wav_file)
SELECT     @id_audio_out_prev + 1,  GETDATE(), @device_number, @wav_file
SET IDENTITY_INSERT dbo.audio_out OFF

-->q3

--<q2 wav_file �������� � �������� �������� transman* (transman_co)
DROP TABLE dbo.audio_in
CREATE TABLE dbo.audio_in
( id_audio_in BIGINT IDENTITY(1,1)
, dt_created DATETIME
, device_number NVARCHAR(16) ----//
, wav_file VARBINARY(300) -- 44 + 256 = size_header + len_data
)
CREATE CLUSTERED INDEX I_id_audio_in ON dbo.audio_in(id_audio_in)

CREATE INDEX I_device_number ON dbo.audio_in(device_number)

SELECT * FROM dbo.audio_in
-->q2
