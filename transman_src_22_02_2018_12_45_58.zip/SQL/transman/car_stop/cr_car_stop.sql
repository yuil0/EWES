--D:\users\yuil\JOB\EWES\SQL\transman\car_stop\cr_car_last_stop.sql

--<q1
DROP TABLE dbo.car_last_stops
CREATE TABLE dbo.car_last_stops
( id_car_last_stop BIGINT IDENTITY(1,1)
, dt_created DATETIME
, dt_update DATETIME
, id_ate_3 BIGINT
, route_id NVARCHAR(32)
, stop_id_1 BIGINT, stop_id_2 BIGINT
, stop_id_1_prev BIGINT
, stop_id_2_prev BIGINT
, car_x FLOAT
, car_y FLOAT
)
-->q1

--DROP INDEX I_device_number_route_id  ON dbo.car_last_stops

CREATE CLUSTERED INDEX I_id_car_last_stop ON dbo.car_last_stops(id_car_last_stop)
CREATE INDEX I_id_ate_3 ON dbo.car_last_stops(id_ate_3)

--TRUNCATE TABLE dbo.car_last_stops
SELECT * FROM dbo.car_last_stops WHERE stop_id_1_prev IS NOT NULL --ANd stop_id_1 NOT IN (SELECT s.stop_id FROM )