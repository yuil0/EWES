--D:\users\yuil\JOB\EWES\SQL\transman\report\find_shape_by_stop_id_route_id
DECLARE @dt DATETIME; SET @dt='2017-09-21T00:00:00';

DECLARE @stop_id_p BIGINT; SET @stop_id_p=1818;
DECLARE @stop_id BIGINT; SET @stop_id=1861;

--SELECT dbo.FN_enabled_picas_calendar(@dt, 83112)

DECLARE @tp AS TABLE (stop_sequence INT, shape_id NVARCHAR(32))
DECLARE @t AS TABLE (stop_sequence INT, shape_id NVARCHAR(32))

INSERT @tp(stop_sequence, shape_id)
SELECT DISTincT stop_sequence, shape_id FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
AND stop_id=@stop_id_p AND route_id='rostov_bus_96'

INSERT @t(stop_sequence, shape_id)
SELECT DISTincT stop_sequence, shape_id FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
AND stop_id=@stop_id  AND route_id='rostov_bus_96'

SELECT * FROM @tp
SELECT * FROM @t


SELECT t.shape_id, t.stop_sequence, tp.stop_sequence  FROM @t t LEFT JOIN @tp tp ON (tp.shape_id=t.shape_id AND tp.stop_sequence < t.stop_sequence)
ORDER BY t.shape_id, t.stop_sequence

/*
SELECT t.trip_id,  stop_id, stop_sequence,  id_trip, service_id, shape_id FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
AND stop_id=1818  AND route_id='rostov_bus_96'
*/