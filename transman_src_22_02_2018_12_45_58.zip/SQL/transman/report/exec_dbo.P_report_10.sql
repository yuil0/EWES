--D:\users\yuil\JOB\EWES\SQL\transman\report\exec_dbo.P_report_10

EXEC dbo.P_report_10 @i_mode=1; EXEC dbo.P_report_10 @i_mode=0, @dt='2017-09-21T23:59:59'
