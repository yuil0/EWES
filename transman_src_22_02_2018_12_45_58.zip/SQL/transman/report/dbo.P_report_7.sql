ALTER PROC dbo.P_report_7
( @i_mode TINYINT=0 /*YUIL 2017-10-03 0:���� 
					�������� 1: ������� �������  ����������					
                    */
, @dt  DATETIME=NULL
, @f_night BIT=1 --//YUIL 2017-10-04 ������ ������ ������ ����� � 0 �� 5  ����� �� ������������
, @delta_time_stop_min INT=5  --minute
, @f_night_del_in_park BIT=1 --if @f_night==1 ������ �� ������� ������ ���������� � �����
) 
AS
------------------------------------------------------------------------------------------------------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_report_7

SET NOCOUNT ON;  --DECLARE @sz NVARCHAR(MAX);

IF (@i_mode=1) BEGIN print N'Clearing'; TRUNCATE TABLE dbo._rep_7_out; RETURN; END

IF (@dt IS  NULL)  SET @dt=GETDATE();

--<q5  cr
IF (OBJECT_ID('dbo._rep_7_out')IS NULL) 
BEGIN
  --DROP TABLE dbo._rep_7_out
 CREATE TABLE dbo._rep_7_out(id_rep_out BIGINT IDENTITY(1,1), device_number NVARCHAR(16), route_short_name NVARCHAR(8), agency_name NVARCHAR(64), lat FLOAT, lng FLOAT, min_time TIME, max_time TIME, delta_time_min INT, in_zone_agency_name NVARCHAR(64)); 
 CREATE CLUSTERED INDEX I_id_out ON dbo._rep_7_out(id_rep_out)
END
-->q5

DECLARE @dt_only DATETIME; SET @dt_only = dbo.FN_get_date(@dt) 

/*
SELECT * FROM dbo.car_chrono WHERE lat IS NULL OR lng IS NULL ORDER  BY id_car_chrono

SELECT count(1) FROM dbo.car_chrono WHERE lat IS NULL OR lng IS NULL;
EXEC sp_spaceused 'dbo.car_chrono';

SELECT * FROM dbo.picas_agents 
SELECT * FROM dbo.picas_trips
SELECT * FROM dbo.picas_routes
*/

DECLARE @car_time AS TABLE  (id_car_time BIGINT IDENTITY(1,1), device_number NVARCHAR(16), i_order INT, route_id NVARCHAR(32), agency_name NVARCHAR(64), lat FLOAT, lng FLOAT, time TIME, x FLOAT, y FLOAT, id_zone BIGINT)

INSERT @car_time(device_number, i_order,   route_id,        agency_name, lat, lng, time, x, y, id_zone)
SELECT           device_number, i_order, t.route_id, a.name agency_name, lat, lng, time, x, y, id_zone FROM
(SELECT device_number, CASE  WHEN ISNULL(route_en,'')!='' THEN 'rostov_'+ct.name_short_en+'_'+c.route_en ELSE '' END route_id, dbo.FN_get_time(c.dt_created)time, DATEPART(hour, c.dt_created) hour, c.lat, c.lng
 , ROW_NUMBER() OVER (PARTITION BY device_number ORDER BY c.dt_created) i_order
 , x, y, c.id_zone
 FROM dbo.car_chrono c, dbo.car_type ct
 WHERE c.id_car_type=ct.id_car_type AND dbo.FN_get_date(c.dt_created) = @dt_only AND c.dt_created<=@dt AND c.lat IS NOT NULL AND c.lng IS NOT NULL --ISNULL(route_en,'')!='' AND 
)t, dbo.picas_agents a, dbo.picas_routes r
WHERE (@f_night IS NULL OR (t.hour>=0 AND t.hour<5)) AND t.route_id=r.route_id AND r.agency_id=a.id
ORDER BY device_number

--SELECT '@car_time', * FROM @car_time

INSERT dbo._rep_7_out(device_number,              route_short_name,              agency_name, lat, lng, min_time, max_time, delta_time_min, in_zone_agency_name)
SELECT                device_number, ISNULL(r.route_short_name,''), ISNULL(r.agency_name,''), lat, lng, min_time, max_time, delta_time_min,   ISNULL(z.name,'')
FROM
(SELECT device_number, route_id, lat, lng, id_zone, min_time, max_time, DATEDIFF(minute, min_time, max_time)delta_time_min FROM 
 (SELECT device_number, route_id, lat, lng, id_zone, MIN(time)min_time, MAX(time)max_time FROM @car_time
  GROUP BY device_number, route_id, lat, lng, id_zone
  HAVING count(1)>1
 )t
)t LEFT JOIN (SELECT route_id, route_short_name, a.name agency_name FROM dbo.picas_agents a, dbo.picas_routes r WHERE r.agency_id=a.id)r ON (t.route_id=r.route_id)
LEFT JOIN dbo.zones z ON (z.id_zone = t.id_zone)
WHERE t.delta_time_min > @delta_time_stop_min
AND (@f_night!=1 OR (@f_night_del_in_park!=1 OR ISNULL(t.id_zone,0)=0))
ORDER BY device_number, t.route_id, min_time


SELECT device_number, route_short_name, agency_name, lat, lng, CONVERT(NVARCHAR(8), min_time)min_time, CONVERT(NVARCHAR(8), max_time)max_time, delta_time_min, in_zone_agency_name FROM dbo._rep_7_out