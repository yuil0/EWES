--D:\users\yuil\JOB\EWES\SQL\transman\report\find_enabled_shapes
DECLARE @dt  DATETIME; SET @dt='2017-09-21T23:59:59'
DECLARE @stop_id BIGINT; SET @stop_id=NULL --//YUIL 2017-09-22 @stop_id IS NULL : ��� ���� ���������
DECLARE @route_id NVARCHAR(32); SET @route_id='rostov_bus_96'

DECLARE @enabled_service AS TABLE(service_id BIGINT, f_enabled_picas_calendar BIT);

--<q1
INSERT @enabled_service (service_id,                         f_enabled_picas_calendar) 
SELECT                   service_id, dbo.FN_enabled_picas_calendar(@dt, t.service_id) FROM (SELECT DISTINCT service_id FROM dbo.picas_trips)t

DELETE FROM @enabled_service WHERE f_enabled_picas_calendar=0
-->q1                   

--SELECT *FROM @enabled_service

DECLARE @t AS TABLE(shape_id NVARCHAR(32), service_id BIGINT)

INSERT @t(shape_id, service_id)
SELECT DISTINCT t.shape_id, t.service_id
FROM  dbo.picas_stop_times st, dbo.picas_trips t
WHERE st.trip_id=t.trip_id AND t.route_id=ISNULL(@route_id, t.route_id)

DELETE FROM @t WHERE service_id NOT IN (SELECT service_id FROM @enabled_service)
SELECT * FROM @t

