ALTER PROC dbo.P_enabled_shape_stops 
(@dt  DATETIME=NULL
,@shape_id NVARCHAR(32)=NULL
,@route_id NVARCHAR(32)=NULL
,@id_picas_route BIGINT=NULL
,@i_mode INT =0
) AS --//YUIL 2017-09-28 : D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_shape_stops
------------------
SET NOCOUNT ON

IF (@dt IS NULL) SET @dt=GETDATE();

IF (@i_mode=0)
BEGIN
	SELECT t.stop_id, t.stop_sequence, s.stop_name + ' ('+CONVERT(NVARCHAR(10), s.stop_lat)+', '+CONVERT(NVARCHAR(10), s.stop_lon)+')' stop_name, s.x, s.y FROM
	(SELECT DISTINCT st.stop_sequence, st.stop_id --t.shape_id, 
		FROM  dbo.picas_stop_times st, dbo.picas_trips t, dbo.picas_routes r 
		WHERE st.trip_id=t.trip_id AND t.route_id=r.route_id AND t.shape_id=ISNULL(@shape_id, t.shape_id) AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
		AND r.id_picas_route = ISNULL(@id_picas_route, r.id_picas_route)
		AND r.route_id= ISNULL(@route_id, r.route_id)	  
	)t, dbo.picas_stops s WHERE t.stop_id=s.stop_id
	order by stop_sequence
END ELSE
IF (@i_mode IN(1,2,3,4))
BEGIN
	DECLARE @t AS TABLE(shape_id NVARCHAR(32), stop_id  BIGINT, stop_sequence INT, stop_name NVARCHAR(64), x FLOAT, y FLOAT, f_first BIT, f_last BIT)

	INSERT @t(shape_id,   stop_id,   stop_sequence,   stop_name,   x,   y, f_first, f_last)
	SELECT  t.shape_id, t.stop_id, t.stop_sequence, t.stop_name, t.x, t.y, CASE WHEN i_order=1 THEN 1 ELSE 0 END f_first, CASE WHEN i_order_back=1 THEN 1 ELSE 0 END f_last
	FROM
	(SELECT t.shape_id, t.stop_id, t.stop_sequence, s.stop_name + ' ('+CONVERT(NVARCHAR(10), s.stop_lat)+', '+CONVERT(NVARCHAR(10), s.stop_lon)+')' stop_name, s.x, s.y 
	 , ROW_NUMBER() OVER (PARTITION BY t.shape_id ORDER BY t.stop_sequence) i_order
	 , ROW_NUMBER() OVER (PARTITION BY t.shape_id ORDER BY t.stop_sequence DESC) i_order_back
	 FROM
	 (SELECT DISTINCT t.shape_id, st.stop_sequence, st.stop_id --t.shape_id, 
 	  FROM  dbo.picas_stop_times st, dbo.picas_trips t, dbo.picas_routes r 
	  WHERE st.trip_id=t.trip_id AND t.route_id=r.route_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
	  AND r.id_picas_route = ISNULL(@id_picas_route, r.id_picas_route)
	  AND r.route_id= ISNULL(@route_id, r.route_id)	  
	 )t, dbo.picas_stops s WHERE t.stop_id=s.stop_id
	)t
	order by t.shape_id, stop_sequence

	IF @i_mode=1
	BEGIN
		SELECT * FROM @t
	END ELSE
	IF @i_mode=2
	BEGIN
		SELECT * FROM @t WHERE f_first=1 OR f_last=1
	END ELSE
	IF @i_mode IN(3,4)
	BEGIN
		DECLARE @ta AS TABLE(id_ta BIGINT IDENTITY(1,1), shape_id NVARCHAR(32), stop_id  BIGINT, stop_sequence INT, stop_name NVARCHAR(64), x FLOAT, y FLOAT, f_first BIT, f_last BIT, q_co_first INT, q_co_last INT, q_next INT, q_prev INT)
		DECLARE @tb AS TABLE(id_tb BIGINT IDENTITY(1,1), shape_id NVARCHAR(32), stop_id  BIGINT, stop_sequence INT, stop_name NVARCHAR(64), x FLOAT, y FLOAT, f_first BIT, f_last BIT, q_co_first INT, q_co_last INT, q_next INT, q_prev INT, co_first_names NVARCHAR(MAX), co_last_names NVARCHAR(MAX), next_names NVARCHAR(MAX), prev_names NVARCHAR(MAX))

		INSERT @ta(shape_id, stop_id, stop_sequence, stop_name, x, y, f_first, f_last, q_co_first, q_co_last, q_next, q_prev)
		SELECT     shape_id, stop_id, stop_sequence, stop_name, x, y, f_first, f_last
		, (SELECT COUNT(1) FROM @t x WHERE x.f_first=1 AND t.f_first=1 AND x.stop_id=t.stop_id AND x.shape_id!=t.shape_id) q_co_first
		, (SELECT COUNT(1) FROM @t x WHERE x.f_last=1 AND t.f_last=1 AND x.stop_id=t.stop_id AND x.shape_id!=t.shape_id) q_co_last
		, (SELECT COUNT(1) FROM @t x WHERE x.f_first=1 AND t.f_last=1 AND x.stop_id=t.stop_id AND x.shape_id!=t.shape_id) q_next
		, (SELECT COUNT(1) FROM @t x WHERE x.f_last=1 AND t.f_first=1 AND x.stop_id=t.stop_id AND x.shape_id!=t.shape_id) q_prev
		FROM @t t WHERE f_first=1 OR f_last=1
		ORDER BY shape_id ASC, f_first DESC

		DECLARE @id_ta BIGINT; SET @id_ta=(SELECT MIN(id_ta) FROM @ta)

		WHILE (@id_ta IS NOT NULL)
		BEGIN
			DECLARE @q_co_first INT, @q_co_last INT, @q_next INT, @q_prev INT, @stop_id BIGINT, @shape_id_L NVARCHAR(32); SELECT @q_co_first=q_co_first, @q_co_last=q_co_last, @q_next=q_next, @q_prev=q_prev, @stop_id=stop_id, @shape_id_L=shape_id FROM @ta WHERE id_ta=@id_ta;
			
			DECLARE @co_first_names NVARCHAR(MAX); SET @co_first_names=''
			DECLARE @co_last_names NVARCHAR(MAX); SET @co_last_names=''
			DECLARE @next_names NVARCHAR(MAX); SET @next_names=''
			DECLARE @prev_names NVARCHAR(MAX); SET @prev_names=''

			IF (@q_co_first>0) BEGIN SELECT @co_first_names=@co_first_names+CASE WHEN @co_first_names='' THEN '' ELSE ',' END+shape_id FROM @t x WHERE x.f_first=1 AND x.stop_id=@stop_id AND x.shape_id!=@shape_id_L; END
			IF (@q_co_last>0) BEGIN SELECT @co_last_names=@co_last_names+CASE WHEN @co_last_names='' THEN '' ELSE ',' END+shape_id FROM @t x WHERE x.f_last=1 AND x.stop_id=@stop_id AND x.shape_id!=@shape_id_L; END
			IF (@q_next>0) BEGIN SELECT @next_names=@next_names+CASE WHEN @next_names='' THEN '' ELSE ',' END+shape_id FROM @t x WHERE x.f_first=1 AND x.stop_id=@stop_id AND x.shape_id!=@shape_id_L; END
			IF (@q_prev>0) BEGIN SELECT @prev_names=@prev_names+CASE WHEN @prev_names='' THEN '' ELSE ',' END+shape_id FROM @t x WHERE x.f_last=1 AND x.stop_id=@stop_id AND x.shape_id!=@shape_id_L; END
			

			INSERT @tb(shape_id, stop_id, stop_sequence, stop_name, x, y, f_first, f_last, q_co_first, q_co_last, q_next, q_prev,  co_first_names,  co_last_names,  next_names,  prev_names)
		    SELECT     shape_id, stop_id, stop_sequence, stop_name, x, y, f_first, f_last, q_co_first, q_co_last, q_next, q_prev, @co_first_names, @co_last_names, @next_names, @prev_names FROM @ta WHERE id_ta=@id_ta

			SET @id_ta=(SELECT MIN(id_ta) FROM @ta WHERE id_ta>@id_ta)
		END

		IF @i_mode=3
		BEGIN
			SELECT * FROM @tb t WHERE t.shape_id=ISNULL(@shape_id, t.shape_id)
		END ELSE
		IF @i_mode=4
		BEGIN
			DECLARE @tc AS TABLE(id_tc BIGINT IDENTITY(1,1), shape_id NVARCHAR(32), co_first_names NVARCHAR(MAX), co_last_names NVARCHAR(MAX), next_names NVARCHAR(MAX), prev_names NVARCHAR(MAX))

			INSERT @tc (shape_id, co_first_names, co_last_names, next_names, prev_names)
			SELECT shape_id
			, ISNULL((SELECT co_first_names FROM @tb x WHERE x.shape_id=t.shape_id AND x.co_first_names!=''),'')
			, ISNULL((SELECT co_last_names FROM @tb x WHERE x.shape_id=t.shape_id AND x.co_last_names!=''),'')
			, ISNULL((SELECT next_names FROM @tb x WHERE x.shape_id=t.shape_id AND x.next_names!=''),'')
			, ISNULL((SELECT prev_names FROM @tb x WHERE x.shape_id=t.shape_id AND x.prev_names!=''),'')
			FROM 
			(SELECT DISTINCT shape_id FROM @tb t WHERE t.shape_id=ISNULL(@shape_id, t.shape_id))t

			SELECT * FROM @tc
		END

	END
END