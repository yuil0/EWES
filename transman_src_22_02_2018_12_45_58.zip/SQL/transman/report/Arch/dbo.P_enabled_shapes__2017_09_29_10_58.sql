ALTER PROC dbo.P_enabled_shapes
(                               
  @dt  DATETIME=NULL
, @route_id NVARCHAR(32)=NULL
) 
AS --//YUIL 2017-09-28 : D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_enabled_shapes
------------------

SELECT DISTINCT t.shape_id
FROM  dbo.picas_stop_times st, dbo.picas_trips t 
WHERE st.trip_id=t.trip_id AND t.route_id=ISNULL(@route_id, t.route_id) AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1


/*
CREATE TABLE #enabled_service(service_id BIGINT, f_enabled_picas_calendar BIT); 

INSERT #enabled_service (service_id,                         f_enabled_picas_calendar)  
SELECT                   service_id, dbo.FN_enabled_picas_calendar(@dt, t.service_id) FROM (SELECT DISTINCT service_id FROM dbo.picas_trips)t 

DELETE FROM #enabled_service WHERE f_enabled_picas_calendar=0 

CREATE TABLE #t (shape_id NVARCHAR(32), service_id BIGINT) 

INSERT #t(shape_id, service_id) 
SELECT DISTINCT t.shape_id, t.service_id 
FROM  dbo.picas_stop_times st, dbo.picas_trips t 
WHERE st.trip_id=t.trip_id AND t.route_id=ISNULL(@route_id, t.route_id) 

DELETE FROM #t WHERE service_id NOT IN (SELECT service_id FROM #enabled_service) 

IF (OBJECT_ID('dbo._enabled_shapes') IS NULL) 
BEGIN 
	CREATE TABLE dbo._enabled_shapes(id_enabled_shapes BIGINT IDENTITY(1,1), shape_id NVARCHAR(32)) 
	CREATE CLUSTERED INDEX I_id_enabled_shapes ON dbo._enabled_shapes(id_enabled_shapes) 
END 

TRUNCATE TABLE dbo._enabled_shapes; 

INSERT dbo._enabled_shapes(shape_id) SELECT shape_id FROM #t

SELECT shape_id FROM dbo._enabled_shapes
*/
/*
DECLARE @sz NVARCHAR(MAX);
SET @sz=
'DECLARE @enabled_service AS TABLE(service_id BIGINT, f_enabled_picas_calendar BIT); '+

'INSERT @enabled_service (service_id,                         f_enabled_picas_calendar)  '+
'SELECT                   service_id, dbo.FN_enabled_picas_calendar(@dt, t.service_id) FROM (SELECT DISTINCT service_id FROM dbo.picas_trips)t '+

'DELETE FROM @enabled_service WHERE f_enabled_picas_calendar=0 '+

'DECLARE @t AS TABLE(shape_id NVARCHAR(32), service_id BIGINT) '+

'INSERT @t(shape_id, service_id) '+
'SELECT DISTINCT t.shape_id, t.service_id '+
'FROM  dbo.picas_stop_times st, dbo.picas_trips t '+
'WHERE st.trip_id=t.trip_id AND t.route_id=ISNULL(@route_id, t.route_id) '+

'DELETE FROM @t WHERE service_id NOT IN (SELECT service_id FROM @enabled_service) '+

'IF (OBJECT_ID(''dbo._enabled_shapes'') IS NULL) '+
'BEGIN '+
	'CREATE TABLE dbo._enabled_shapes(id_enabled_shapes BIGINT IDENTITY(1,1), shape_id NVARCHAR(32)) '+
	'CREATE CLUSTERED INDEX I_id_enabled_shapes ON dbo._enabled_shapes(id_enabled_shapes) '+
'END '+

'TRUNCATE TABLE dbo._enabled_shapes; '+

'INSERT dbo._enabled_shapes(shape_id) SELECT shape_id FROM @t '+

'SELECT shape_id FROM dbo._enabled_shapes;;'

IF CHARINDEX(';;',  @sz)=0 BEGIN RAISERROR('Not full query', 18, 1); RETURN; END

EXEC sp_executesql @sz, N'@dt DATETIME, @route_id NVARCHAR(32)',  @dt, @route_id;
*/
--DROP TABLE dbo._enabled_shapes