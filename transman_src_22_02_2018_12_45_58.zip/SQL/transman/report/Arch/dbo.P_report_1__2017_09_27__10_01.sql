ALTER PROC dbo.P_report_1
( 
  @user_name NVARCHAR(32)='user'
, @dt  DATETIME=NULL
, @i_mode TINYINT=0 --//YUIL 2017-09-21 0:�� �����, 1:�� �����. C�������� ����-���� ������� ������ �������� @i_mode IN(0,1). �������� 2 ��� ��������������� ������ ���-����, ������ ����� ������ � ���������� 0 � 1 ��� �������  ���� @arrival_hour IN(5..23)
, @stop_id BIGINT=NULL --//YUIL 2017-09-22 @stop_id IS NULL : ��� ���� ���������
, @arrival_hour INT=NULL --//YUIL 2017-09-22 . ����� ��� ��������� ����-����, ����� ������� ��������� ����������� 
, @route_id NVARCHAR(32)=NULL
, @f_out BIT=NULL
) 
AS
------------------------------------------------------------------------------------------------------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_report_1
--1. ����� �� ������������ � ������������ �������

SET NOCOUNT ON

IF (@dt IS  NULL)  SET @dt=GETDATE();

DECLARE @table NVARCHAR(128); SET  @table='dbo._rep_out_'+@user_name
DECLARE @sz NVARCHAR(MAX);

SET  @sz=
'IF (OBJECT_ID('''+@table+''')IS NOT NULL) '+
'BEGIN DROP TABLE '+@table+'; END '+
'CREATE TABLE '+@table+'(id_rep_out BIGINT IDENTITY(1,1), stop_id BIGINT, stop_name NVARCHAR(64), arrival_hour INT, hour_arrival INT, min_arrival INT, sec_arrival INT, hour_departure INT, min_departure INT, sec_departure INT, route_short_name NVARCHAR(8), garage_num NVARCHAR(8), quantity_car INT, service_id BIGINT); '+
'CREATE CLUSTERED INDEX I_id_out ON '+@table+'(id_rep_out);; ';

IF CHARINDEX(';;',@sz)=0 BEGIN RAISERROR('Error 1',18,1); RETURN; END

EXEC sp_executesql @sz;

CREATE TABLE #out (stop_id BIGINT, arrival_hour INT, arrival_time TIME, departure_time TIME, route_short_name NVARCHAR(8), garage_num NVARCHAR(8), quantity_car INT, f_enabled_picas_calendar  BIT, service_id BIGINT); --DECLARE @out_b AS TABLE (stop_id BIGINT, stop_name NVARCHAR(64), arrival_hour INT, hour_arrival INT, min_arrival INT, sec_arrival INT, hour_departure INT, min_departure INT, sec_departure INT, route_short_name NVARCHAR(8), garage_num NVARCHAR(8), quantity_car INT); --, service_id BIGINT

--<q2 fill
IF @i_mode IN (0)
BEGIN
	DECLARE @enabled_service AS TABLE(service_id BIGINT, f_enabled_picas_calendar BIT);

	--<q1
	INSERT @enabled_service (service_id,                         f_enabled_picas_calendar) 
	SELECT                   service_id, dbo.FN_enabled_picas_calendar(@dt, t.service_id) FROM (SELECT DISTINCT service_id FROM dbo.picas_trips)t

	DELETE FROM @enabled_service WHERE f_enabled_picas_calendar=0
	-->q1

	INSERT #out (stop_id,   arrival_hour,    arrival_time,   departure_time,   route_short_name,       garage_num,      quantity_car,                                                       f_enabled_picas_calendar,   service_id)
	SELECT       t.stop_id, t.arrival_hour,  t.arrival_time, t.departure_time, t.route_short_name, '' AS garage_num, 1 AS quantity_car, ISNULL((SELECT 1 FROM @enabled_service es WHERE es.service_id=t.service_id),0), t.service_id FROM
	(SELECT DISTiNCT t.stop_id, t.arrival_hour, t.arrival_time, t.departure_time, t.route_short_name, t.service_id FROM
	 (SELECT st.stop_id, DATEPART(hour, st.arrival_time)arrival_hour, st.arrival_time, st.departure_time, r.route_short_name, DATEPART(hour, st.arrival_time) hour_arrival_time, DATEPART(hour, st.departure_time) hour_departure_time,  t.service_id	   
	   FROM  dbo.picas_stop_times st, dbo.picas_trips t, dbo.picas_routes r 
	  WHERE st.trip_id=t.trip_id AND t.route_id=r.route_id AND st.stop_id=ISNULL(@stop_id, st.stop_id) AND t.route_id=ISNULL(@route_id, t.route_id)
	 )t
	 WHERE NOT(hour_arrival_time>=0 AND hour_departure_time<5) AND t.arrival_hour=ISNULL(@arrival_hour, t.arrival_hour)
	)t
	ORDER  BY stop_id, t.arrival_time

	DELETE  FROM  #out  WHERE f_enabled_picas_calendar=0
END

IF @i_mode IN (1)
BEGIN
	DECLARE @dt_only DATETIME; SET @dt_only = dbo.FN_get_date(@dt) 

	DECLARE @time TIME; SET  @time = dbo.FN_get_time(@dt) --DECLARE @f_direct BIT; SET @f_direct=0; --YUIL 2017-09-18 ����������� : 1 : �����, 0 : �������

	--<q6 --����� �  ����� ������ � ��������� �������� �������� �  ��������� � �������� �������� ���������� �� ���������
	IF (OBJECT_ID('dbo.#car_stop') IS NOT NULL) BEGIN DROP TABLE dbo.#car_stop; END;
	CREATE TABLE dbo.#car_stop (id_car_stop BIGINT IDENTITY(1,1), stop_id  BIGINT, dt_created DATETIME, time TIME, hour INT, device_number NVARCHAR(16), route_id NVARCHAR(32), i_type TINYINT) --YUIL 2017-09-22: i_type: 0:start 1:fin
	CREATE CLUSTERED INDEX I_id_car_stop ON dbo.#car_stop (id_car_stop)
	CREATE INDEX I_device_number_stop_id_route_id ON dbo.#car_stop (device_number, stop_id, route_id)	INCLUDE(i_type)

	INSERT dbo.#car_stop (stop_id, dt_created, time,                 hour, device_number, route_id,                                         i_type)
	SELECT                stop_id, dt_created, time, DATEPART(hour, time), device_number, route_id, (CASE WHEN f_prev_no_stop=1 THEN 0 ELSE 1 END) 
	FROM
	(SELECT          ps.stop_id, c.dt_created, dbo.FN_get_time(c.dt_created) time, device_number, 'rostov_'+ct.name_short_en+'_'+c.route_en route_id
	 , ISNULL((SELECT 1 FROM dbo.car_chrono o WHERE o.id_car_chrono=c.id_car_chrono-1  AND NOT EXISTS(SELECT 1 FROM dbo.car_chrono_stop p WHERE p.id_car_chrono=o.id_car_chrono)), 0) f_prev_no_stop
	 , ISNULL((SELECT 1 FROM dbo.car_chrono o WHERE o.id_car_chrono=c.id_car_chrono+1  AND NOT EXISTS(SELECT 1 FROM dbo.car_chrono_stop p WHERE p.id_car_chrono=o.id_car_chrono)), 0) f_next_no_stop
	 FROM dbo.car_chrono c, dbo.car_chrono_stop cs, dbo.car_type ct, dbo.picas_stops ps
	 WHERE ISNULL(route_en,'')!='' AND cs.id_car_chrono=c.id_car_chrono AND c.id_car_type=ct.id_car_type AND cs.id_stop=ps.id_picas_stop AND ps.stop_id=ISNULL(@stop_id, ps.stop_id) 
	 AND dbo.FN_get_date(c.dt_created) = @dt_only
	 AND c.dt_created<=@dt
	)t WHERE (f_prev_no_stop=1 OR  f_next_no_stop=1) AND t.route_id=ISNULL(@route_id, t.route_id)
	ORDER BY stop_id, dt_created

	IF (@arrival_hour IS NOT NULL) 
	BEGIN 
		DELETE FROM dbo.#car_stop WHERE hour<@arrival_hour OR hour>@arrival_hour; 
	END
	-->q6

	--<q3
	IF (OBJECT_ID('dbo.#car_stop_b') IS NOT NULL) BEGIN DROP TABLE dbo.#car_stop_b; END;
	CREATE TABLE dbo.#car_stop_b (id_car_stop BIGINT, stop_id  BIGINT, dt_created DATETIME, time TIME, hour INT, device_number NVARCHAR(16), route_id NVARCHAR(32), i_type TINYINT, id_car_stop_start BIGINT)
	CREATE CLUSTERED INDEX I_id_car_stop ON dbo.#car_stop_b (id_car_stop)

	INSERT dbo.#car_stop_b (id_car_stop, stop_id, dt_created, time, hour, device_number, route_id, i_type, id_car_stop_start)
	SELECT                  id_car_stop, stop_id, dt_created, time, hour, device_number, route_id, i_type
	, (SELECT id_car_stop FROM dbo.#car_stop p WHERE p.i_type=0 AND p.device_number=t.device_number AND p.stop_id=t.stop_id AND p.route_id=t.route_id AND t.i_type=1 AND p.id_car_stop=(SELECT MAX(id_car_stop) FROM dbo.#car_stop p WHERE p.i_type=0 AND p.device_number=t.device_number AND p.stop_id=t.stop_id AND p.route_id=t.route_id AND p.id_car_stop < t.id_car_stop))
	FROM dbo.#car_stop t
	ORDER BY stop_id, dt_created
	-->q3
	
	--<q2 ������� ����
	INSERT #out(stop_id,            arrival_hour, arrival_time, departure_time, route_short_name, garage_num, quantity_car)
	SELECT     ta.stop_id, DATEPART(hour, ta.time),      ta.time,        td.time
	, (SELECT route_short_name FROM dbo.picas_routes r WHERE (r.route_id COLLATE SQL_Latin1_General_CP1_CI_AS)=(ta.route_id COLLATE SQL_Latin1_General_CP1_CI_AS)) route_short_name
	, (SELECT garage_num FROM dbo.ate_3_book b WHERE (b.device_number COLLATE SQL_Latin1_General_CP1_CI_AS)=(ta.device_number COLLATE SQL_Latin1_General_CP1_CI_AS))  garage_num
	, 1
	FROM dbo.#car_stop ta, dbo.#car_stop_b td WHERE ta.i_type=0 AND td.i_type=1 AND ta.id_car_stop=td.id_car_stop_start
	ORDER BY stop_id, ta.time
	-->q2

	
END
-->q2

ALTER TABLE #out DROP  COLUMN f_enabled_picas_calendar 

SET  @sz=
'INSERT '+@table+' (stop_id,                                                                     stop_name, arrival_hour, hour_arrival, min_arrival, sec_arrival, hour_departure, min_departure, sec_departure, route_short_name, garage_num, quantity_car, service_id) '+
'SELECT             stop_id, (SELECT stop_name  FROM dbo.picas_stops s WHERE s.stop_id=o.stop_id)stop_name, arrival_hour '+
', DATEPART(hour, arrival_time)hour_arrival '+
', DATEPART(minute, arrival_time)min_arrival '+
', DATEPART(second, arrival_time)sec_arrival '+
', DATEPART(hour, departure_time)hour_departure '+
', DATEPART(minute, departure_time)min_departure '+
', DATEPART(second, departure_time)sec_departure '+
', route_short_name, garage_num, quantity_car, service_id FROM #out o;;';

IF CHARINDEX(';;',@sz)=0 BEGIN RAISERROR('Error 2',18,2); RETURN; END
EXEC sp_executesql @sz;

--<q3
IF (@f_out=1)
BEGIN
	SET @sz='SELECT * FROM '+@table+';;';
	IF CHARINDEX(';;',@sz)=0 BEGIN RAISERROR('Error 3',18,3); RETURN; END
	EXEC sp_executesql @sz;

	print '@table: '+@table;
END
-->q3