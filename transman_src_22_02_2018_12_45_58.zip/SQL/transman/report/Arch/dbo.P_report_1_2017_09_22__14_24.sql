ALTER PROC dbo.P_report_1
( @dt  DATETIME=NULL
, @i_mode TINYINT=0 --//YUIL 2017-09-21 0:�� �����, 1:�� �����, 2:��������� ����-����
, @stop_id BIGINT=NULL --//YUIL 2017-09-22 @stop_id IS NULL : ��� ���� ���������
) 
AS
------------------------------------------------------------------------------------------------------------------------
--D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_report_1
--1. ����� �� ������������ � ������������ �������

IF (@dt IS  NULL)  SET @dt=GETDATE();

DECLARE @plane AS TABLE(id_plane BIGINT IDENTITY(1,1), stop_id BIGINT, arrival_time TIME, departure_time TIME, route_short_name NVARCHAR(8), garage_num NVARCHAR(8), quantity_car INT, f_enabled_picas_calendar  BIT);

DECLARE @fact AS TABLE(id_fact BIGINT IDENTITY(1,1), stop_id BIGINT, arrival_time TIME, departure_time TIME, route_short_name NVARCHAR(8), garage_num NVARCHAR(8), quantity_car INT);

--<q2 fill
IF @i_mode IN (0,2)
BEGIN
	DECLARE @enabled_service AS TABLE(service_id BIGINT, f_enabled_picas_calendar BIT);

	--<q1
	INSERT @enabled_service (service_id,                         f_enabled_picas_calendar) 
	SELECT                   service_id, dbo.FN_enabled_picas_calendar(@dt, t.service_id) FROM (SELECT DISTINCT service_id FROM dbo.picas_trips)t

	DELETE FROM @enabled_service WHERE f_enabled_picas_calendar=0
	-->q1

	INSERT @plane (stop_id,    arrival_time,   departure_time,   route_short_name,       garage_num,      quantity_car,                                                       f_enabled_picas_calendar)
	SELECT       t.stop_id,  t.arrival_time, t.departure_time, t.route_short_name, '' AS garage_num, 0 AS quantity_car, ISNULL((SELECT 1 FROM @enabled_service es WHERE es.service_id=t.service_id),0) FROM
	(SELECT DISTiNCT t.stop_id, t.arrival_time, t.departure_time, t.route_short_name, t.service_id FROM
	 (SELECT st.stop_id, st.arrival_time, st.departure_time, r.route_short_name, DATEPART(hour, st.arrival_time) hour_arrival_time, DATEPART(hour, st.departure_time) hour_departure_time,  t.service_id	   
	   FROM  dbo.picas_stop_times st, dbo.picas_trips t, dbo.picas_routes r 
	  WHERE st.trip_id=t.trip_id AND t.route_id=r.route_id AND st.stop_id=ISNULL(@stop_id, st.stop_id) 
	 )t
	 WHERE NOT(hour_arrival_time>=0 AND hour_departure_time<5)
	)t
	ORDER  BY stop_id, t.arrival_time

	DELETE  FROM  @plane  WHERE f_enabled_picas_calendar=1
END

IF @i_mode IN (1,2)
BEGIN
	DECLARE @dt_only DATETIME; SET @dt_only = dbo.FN_get_date(@dt) 

	DECLARE @time TIME; SET  @time = dbo.FN_get_time(@dt) --DECLARE @f_direct BIT; SET @f_direct=0; --YUIL 2017-09-18 ����������� : 1 : �����, 0 : �������

	--<q6 --����� �  ����� ������ � ��������� �������� �������� �  ��������� � �������� �������� ���������� �� ���������
	DECLARE @car_stop AS TABLE(id_car_stop BIGINT IDENTITY(1,1), stop_id  BIGINT, dt_created DATETIME, time TIME, hour INT, device_number NVARCHAR(16), route_id NVARCHAR(32), i_type TINYINT) --YUIL 2017-09-22: i_type: 0:start 1:fin

	INSERT @car_stop (stop_id, dt_created, time,                 hour, device_number, route_id,                                         i_type)
	SELECT            stop_id, dt_created, time, DATEPART(hour, time), device_number, route_id, (CASE WHEN f_prev_no_stop=1 THEN 0 ELSE 1 END) 
	FROM
	(SELECT          ps.stop_id, c.dt_created, dbo.FN_get_time(c.dt_created) time, device_number, 'rostov_'+ct.name_short_en+'_'+c.route_en route_id
	 , ISNULL((SELECT 1 FROM dbo.car_chrono o WHERE o.id_car_chrono=c.id_car_chrono-1  AND NOT EXISTS(SELECT 1 FROM dbo.car_chrono_stop p WHERE p.id_car_chrono=o.id_car_chrono)), 0) f_prev_no_stop
	 , ISNULL((SELECT 1 FROM dbo.car_chrono o WHERE o.id_car_chrono=c.id_car_chrono+1  AND NOT EXISTS(SELECT 1 FROM dbo.car_chrono_stop p WHERE p.id_car_chrono=o.id_car_chrono)), 0) f_next_no_stop
	 FROM dbo.car_chrono c, dbo.car_chrono_stop cs, dbo.car_type ct, dbo.picas_stops ps
	 WHERE ISNULL(route_en,'')!='' AND cs.id_car_chrono=c.id_car_chrono AND c.id_car_type=ct.id_car_type AND cs.id_stop=ps.id_picas_stop AND ps.stop_id=ISNULL(@stop_id, ps.stop_id) 
	 AND dbo.FN_get_date(c.dt_created) = @dt_only
	 AND c.dt_created<=@dt
	)t WHERE (f_prev_no_stop=1 OR  f_next_no_stop=1)
	ORDER BY stop_id, dt_created

	DELETE FROM  @car_stop WHERE (hour>=0 AND hour<5)
	-->q6

	--<q3
	DECLARE @car_stop_b AS TABLE(id_car_stop BIGINT, stop_id  BIGINT, dt_created DATETIME, time TIME, hour INT, device_number NVARCHAR(16), route_id NVARCHAR(32), i_type TINYINT, id_car_stop_start BIGINT)
	
	INSERT @car_stop_b (id_car_stop, stop_id, dt_created, time, hour, device_number, route_id, i_type, id_car_stop_start)
	SELECT              id_car_stop, stop_id, dt_created, time, hour, device_number, route_id, i_type
	, (SELECT id_car_stop FROM @car_stop p WHERE p.i_type=0 AND p.device_number=t.device_number AND p.stop_id=t.stop_id AND p.route_id=t.route_id AND t.i_type=1 AND p.id_car_stop=(SELECT MAX(id_car_stop) FROM @car_stop p WHERE p.i_type=0 AND p.device_number=t.device_number AND p.stop_id=t.stop_id AND p.route_id=t.route_id AND p.id_car_stop < t.id_car_stop))
	FROM @car_stop t
	-->q3
	
	--<q2 ������� ����
	INSERT @fact (stop_id, arrival_time, departure_time, route_short_name, garage_num, quantity_car)
	SELECT     ta.stop_id,      ta.time,        td.time
	, (SELECT route_short_name FROM dbo.picas_routes r WHERE r.route_id=ta.route_id) route_short_name
	, (SELECT garage_num FROM dbo.ate_3_book b WHERE b.device_number=ta.device_number)  garage_num
	, 1
	FROM @car_stop ta, @car_stop_b td WHERE ta.i_type=0 AND td.i_type=1 AND ta.id_car_stop=td.id_car_stop_start
	ORDER BY stop_id, ta.time
	-->q2

	
END
-->q2

IF @i_mode=0
BEGIN
	SELECT stop_id, arrival_time,   departure_time,   route_short_name,       garage_num,      quantity_car FROM  @plane
END

IF @i_mode=1
BEGIN
	SELECT stop_id, arrival_time,   departure_time,   route_short_name,       garage_num,      quantity_car FROM  @fact
END
