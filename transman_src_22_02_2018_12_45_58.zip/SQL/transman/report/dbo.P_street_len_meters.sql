ALTER PROC dbo.P_street_len_meters
( @dt DATETIME=NULL
, @id_file_stop_street BIGINT
) AS
------------------------------------- //YUIL 2017-10-04 : D:\users\yuil\JOB\EWES\SQL\transman\report\dbo.P_street_len_meters
DECLARE @min_len FLOAT; SET @min_len=0;

DECLARE @min_shape_id NVARCHAR(32); 

DECLARE @max_len FLOAT; SET @max_len=0;

DECLARE @max_shape_id NVARCHAR(32); 


IF (@dt IS  NULL)  SET @dt=GETDATE();

DECLARE @stops AS TABLE(id_stop BIGINT IDENTITY(1,1), shape_id NVARCHAR(32), stop_sequence INT, stop_id BIGINT, x FLOAT, y FLOAT,  stop_name NVARCHAR(64), i_order INT)

INSERT @stops (shape_id, stop_sequence, stop_id, x, y, stop_name, i_order)
SELECT shape_id, stop_sequence, t.stop_id, s.x, s.y, s.stop_name, ROW_NUMBER() OVER (PARTITION BY shape_id ORDER BY stop_sequence)i_order FROM
(SELECT t.shape_id, stop_id, stop_sequence FROM
	(SELECT DISTINCT st.stop_id, st.stop_sequence, t.shape_id, t.service_id FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id)t 
	WHERE dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1 
	AND t.stop_id IN (SELECT stop_id FROM dbo.file_stops WHERE id_file_stop_street=@id_file_stop_street)
)t, dbo.picas_stops s WHERE t.stop_id=s.stop_id
ORDER BY shape_id, stop_sequence



DECLARE @shapes AS TABLE(id_shape BIGINT IDENTITY(1,1), shape_id NVARCHAR(32)); INSERT @shapes(shape_id) SELECT DISTINCT shape_id FROM @stops

DECLARE @id_shape BIGINT; SET @id_shape=(SELECT MIN(id_shape) FROM @shapes)

-- SELECT * FROM @shapes WHERE id_shape = @id_shape

-- SELECT * FROM @stops WHERE shape_id='rostov_minibus_30_a-b'--(SELECT shape_id FROM @shapes WHERE id_shape = @id_shape)

WHILE (@id_shape IS NOT NULL)
BEGIN
	DECLARE @shape_id NVARCHAR(32); SELECT @shape_id=shape_id FROM @shapes WHERE id_shape = @id_shape
	
	DECLARE @len FLOAT; SET @len=0;

	SELECT @len = @len + dbo.FN_get_dist (p.x, p.y, s.x, s.y) FROM @stops s, @stops p WHERE s.id_stop>1 AND p.id_stop = s.id_stop - 1 AND s.shape_id = @shape_id AND p.shape_id = @shape_id

	IF (@id_shape=1)
	BEGIN
		SET @max_len = @len; SET @max_shape_id=@shape_id;
		SET @min_len = @len; SET @min_shape_id=@shape_id;
	END ELSE
	BEGIN
		IF (@len > @max_len) BEGIN SET @max_len = @len; SET @max_shape_id=@shape_id; END
		IF (@len < @min_len) BEGIN SET @min_len = @len; SET @min_shape_id=@shape_id; END
	END
		
	SET @id_shape=(SELECT MIN(id_shape) FROM @shapes WHERE id_shape > @id_shape)
END



SELECT @min_len min_len, @min_shape_id min_shape_id, @max_len max_len, @max_shape_id max_shape_id;


