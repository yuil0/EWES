--D:\users\yuil\JOB\EWES\SQL\transman\report\exec_dbo.P_report_7
--SELECT * FROM dbo.car_chrono  WHERE id_zone IS NOT NULL

EXEC dbo.P_report_7 @i_mode=1; EXEC dbo.P_report_7 @i_mode=0, @dt='2017-10-24T23:59:59', @f_night=NULL,  @delta_time_stop_min=-1, @f_night_del_in_park=0

EXEC dbo.P_report_7 @i_mode=1; EXEC dbo.P_report_7 @i_mode=0, @dt='2017-10-24T23:59:59', @f_night=1


EXEC dbo.P_report_7 @i_mode=1; EXEC dbo.P_report_7 @i_mode=0, @dt='2017-11-21T23:59:59', @f_night=NULL,  @delta_time_stop_min=-1, @f_night_del_in_park=0

EXEC dbo.P_report_7 @i_mode=1; EXEC dbo.P_report_7 @i_mode=0, @f_night=NULL, @dt='2017-11-21T23:59:59.997'