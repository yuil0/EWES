---- D:\users\yuil\JOB\EWES\SQL\transman\car_cross_stops\test_dbo.P_view_stop_times
EXEC dbo.P_view_stop_times @dt='2017-09-19T16:02:00', @i_mode=1

--UPDATE dbo.const SET f_add_formalize_messages=1


TRUNCATE TABLE dbo.formalize_messages

EXEC dbo.P_view_stop_times @dt='2017-09-19T16:02:00', @i_mode=3

SELECT *FROM dbo.formalize_messages

UPDATE dbo.formalize_messages SET i_state=0 WHERE id_formalize_message=1

SELECT MAX(m.dt_created) FROM dbo.formalize_messages m WHERE m.device_number='M270OH' AND m.dt_created<='2017-09-19T16:00:00'