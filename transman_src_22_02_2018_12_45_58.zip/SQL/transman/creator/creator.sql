--D:\users\yuil\JOB\EWES\SQL\transman\creator\creator
DROP TABLE dbo.creator
CREATE TABLE dbo.creator
(id_creator BIGINT IDENTITY(1,1)
, dt_create DATETIME --
, name NVARCHAR(16)
)


CREATE CLUSTERED INDEX I_id_creator ON dbo.creator(id_creator) 

INSERT dbo.creator (dt_create, name) SELECT GETDATE(), N'WEB server'

SELECT * FROM dbo.creator