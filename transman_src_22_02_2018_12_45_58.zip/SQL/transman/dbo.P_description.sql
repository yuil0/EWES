﻿ALTER PROC dbo.P_description(@sz_table NVARCHAR(64))
AS --D:\users\yuil\JOB\EWES\SQL\transman\dbo.P_description

	SELECT ROW_NUMBER() OVER(ORDER BY c.column_id)[№], c.name[Имя поля],  UPPER(t.name)
	+CASE WHEN t.name IN ('text', 'varchar', 'char', 'nvarchar', 'nchar') THEN '('+CONVERT(NVARCHAR(10),c.max_length)+')' ELSE '' END [Тип]
	,CASE 
	  WHEN c.column_id=1 THEN N'Идентификатор записи' 
	  WHEN c.name='dt_created' THEN N'Дата создания' 
	  WHEN c.name='id_state' THEN N'Состояние' 
	  WHEN c.name='id_org' THEN N'Организация' 
	  WHEN c.name='name' THEN N'Имя' 
	  WHEN c.name='mobile_number' THEN N'Номер мобильного телефона' 
	  WHEN c.name='capacity' THEN N'Емкость' 	  
	  WHEN c.name='id_route_type' THEN N'Тип маршрута' 	  	  
	  WHEN c.name='id_route' THEN N'Маршрут'
	  WHEN c.name='id_driver_vehicle' THEN N'Водитель'	  
	  WHEN c.name='addr' THEN N'Адрес'	  
	  WHEN c.name='id_point' THEN N'Остановка'	  
	  WHEN c.name='id_route_point_prev' THEN N'Предшествующая остановка'	  
	  WHEN c.name='dt_offer_from' THEN N'Время отбытия предоставленное'	  
	  WHEN c.name='dt_offer_to' THEN N'Время прибытия предоставленное'	  
	  WHEN c.name='id_org_offer' THEN N'Организация предоставитель'	  
	  WHEN c.name='id_vehicle' THEN N'Транспортное средство'	  
	  WHEN c.name='id_point_from' THEN N'Остановка отбытия'	  
	  WHEN c.name='id_point_to' THEN N'Остановка прибытия'	  
	  
	  
	  ELSE '' 
	 END [Смысл поля]
	FROM sys.columns c LEFT JOIN sys.types t ON (t.system_type_id=c.system_type_id AND t.system_type_id=t.user_type_id)
	WHERE OBJECT_ID=OBJECT_ID(@sz_table)
