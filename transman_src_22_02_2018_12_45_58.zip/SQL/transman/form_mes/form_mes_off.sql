--D:\users\yuil\JOB\EWES\SQL\transman\form_mes\form_mes_off

--//YUIL 2017-09-20  ��������������� ���������
--<q1
DROP TABLE dbo.form_mes_off
CREATE TABLE dbo.form_mes_off
( id_form_mes_off BIGINT IDENTITY(1,1)
, id_ate_3 BIGINT
, dt_created DATETIME
, id_picas_route BIGINT
, id_picas_stop_from BIGINT
, time_cmd_minute_from INT
, id_picas_stop_to BIGINT
, time_cmd_minute_to INT
)
-->q1

CREATE CLUSTERED INDEX I_id_form_mes_off ON dbo.form_mes_off(id_form_mes_off)
CREATE INDEX I_id_ate_3 ON dbo.form_mes_off(id_ate_3)

--TRUNCATE TABLE dbo.form_mes_off
SELECT * FROM dbo.form_mes_off

SELECT c.device_number, s.stop_name stop_name_from FROM dbo.form_mes_off fmo, dbo.ate_3 c, dbo.picas_stops s WHERE fmo.id_ate_3=c.id_ate_3 AND fmo.id_picas_stop_from=s.id_picas_stop

--<q3
DECLARE @device_number NVARCHAR(16);
SELECT c.device_number
,(SELECT s.stop_name FROM dbo.picas_stops s WHERE fmo.id_picas_stop_from = s.id_picas_stop) stop_name_from 
,(SELECT s.stop_name FROM dbo.picas_stops s WHERE fmo.id_picas_stop_to = s.id_picas_stop) stop_name_to 
,fmo.time_cmd_minute_from
,fmo.time_cmd_minute_to
FROM dbo.form_mes_off fmo, dbo.ate_3 c WHERE fmo.id_ate_3=c.id_ate_3 
AND c.device_number = @device_number

-->q3
