CREATE PROC dbo.P_add_form_mes_ack ( @device_number NVARCHAR(16)) 
AS -- D:\users\yuil\JOB\EWES\SQL\transman\form_mes\dbo.P_add_form_mes_ack
----------------------------------------------------
DECLARE @dt DATETIME; SET @dt = GETDATE() --'2017-12-06T10:00:00'--;

--<q0
IF EXISTS
(SELECT 1 FROM dbo.form_mes_ack 
 WHERE 
  device_number = @device_number 
  AND DATEDIFF(second, dt_created, @dt)<5 
)
BEGIN print 'Repeat fast. No save.'; RETURN; END
-->q0

--<q1
DECLARE @id_form_mes_ack BIGINT; SET @id_form_mes_ack = ISNULL((SELECT MAX(id_form_mes_ack) FROM dbo.form_mes_ack), 0) + 1;

SET IDENTITY_INSERT dbo.form_mes_ack ON

INSERT dbo.form_mes_ack(id_form_mes_ack,  device_number,  dt_created)
SELECT                 @id_form_mes_ack, @device_number,         @dt

SET IDENTITY_INSERT dbo.form_mes_ack OFF
-->q1