CREATE PROC dbo.P_view_stops_by_shape( @dt DATETIME, @shape_id NVARCHAR(32)) AS
------------------------------
-- D:\users\yuil\JOB\EWES\SQL\transman\ate_3\dbo.P_view_stops_by_shape
SELECT t.stop_sequence, s.x, s.y, s.stop_name
FROM
(SELECT DISTINCT st.stop_id, st.stop_sequence FROM dbo.picas_stop_times st, dbo.picas_trips t WHERE st.trip_id=t.trip_id AND t.shape_id=@shape_id AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1)t
, dbo.picas_stops s WHERE t.stop_id = s.stop_id