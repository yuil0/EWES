--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\cr_table
--<q1
DROP TABLE dbo.ate_3
CREATE TABLE dbo.ate_3
(id_ate_3 BIGINT IDENTITY(1,1) --, dt DATETIME --, year INT  , month INT  , day INT , hour INT  , minute INT  , second INT 
, device_number NVARCHAR(16)
, latitude DECIMAL(10,6)
, longitude DECIMAL(10,6)
, azimut INT  --//YUIL. ���� �� ����������� �� �����.
, speed INT --//YUIL . �������� / ���
, dt_created DATETIME --YUIL. ����/����� ��������  ������
, dt_update DATETIME --YUIL. ����/����� ��������  ������
, route_id NVARCHAR(32) --YUIL 2017-09-15 dbo.picas_routes
, id_picas_route BIGINT
, dist_lag FLOAT
, minutes_lag  INT
)
-->q1

--ALTER TABLE dbo.ate_3 ADD dist_lag FLOAT, minutes_lag  INT

SELECT * from sys.columns WHERE OBJECT_ID=OBJECT_ID('dbo.ate_3')

(SELECT 'rostov_'+ct.name_short_en+'_'+@route_en FROM dbo.car_type ct WHERE @id_car_type=ct.id_car_type) AS route_id

CREATE CLUSTERED INDEX I_id_ate_3 ON dbo.ate_3(id_ate_3) 
CREATE  INDEX I_device_number ON dbo.ate_3(device_number) 


sp_spaceused 'dbo.ate_3'

SELECT MAX(dt_created)MAX_dt_created, MAX(dt_update)MAX_dt_update  FROM dbo.ate_3 --order  by id_ate_3

SELECT * FROM dbo.ate_3 ORDER BY dt_update desc --WHERE route_en IS NOT NULL

SELECT route_short_name, count(1)c FROM dbo.ate_3 GROUP BY route_short_name ORDER BY 2 DESC

--UPDATE dbo.ate_3 SET id_car_type=2

--TRUNCATE TABLE dbo.ate_3 --order  by id_ate_3

--<q2 INSERT

-- INSERT dbo.ate_3(year, month, day, hour, minute, second, device_number, latitude, longitude, azimut, speed) SELECT ...
INSERT dbo.ate_3(dt, device_number, latitude, longitude, azimut, speed) SELECT ...
-->q2

SELECT OBJECT_ID('dbo.ate_3')

--<q3
EXEC dbo.P_add_ate_3 @dt ='2017-08-24T09:14:48', @device_number = 'M266OH', @latitude = 47.273792, @longitude = 39.757253, @azimut = 124,  @speed = 26 

-->q3

--<q4
DECLARE @dt  DATETIME; SET @dt='2017-08-24T14:29:09.000'

DECLARE @fl FLOAT; SET @fl=CONVERT(float, @dt)

DECLARE @dtr  DATETIME; SET @dtr=CONVERT(DATETIME, @fl)


SELECT @dt[@dt], @fl[@fl],  @dtr[@dtr]

-->q4

--<q5 ��� ���������� � ������
ALTER TABLE dbo.ate_3 ADD x FLOAT, y FLOAT --���� �  _srv
-->q5