CREATE FUNCTION dbo.FN_sign_direct_by_check_point(@id_picas_route BIGINT, @stop_id_from BIGINT, @stop_id_to BIGINT) 
RETURNS INT
AS --D:\users\yuil\JOB\EWES\SQL\transman\ate_3\dbo.FN_sign_direct_by_check_point
BEGIN 
	DECLARE @i_sign_direct INT; 

	IF (@stop_id_from = @stop_id_to) BEGIN SET @i_sign_direct=0; END
	ELSE
	BEGIN
		DECLARE @f_forward_from BIT, @i_order_from INT;
	
		DECLARE @f_forward_to BIT, @i_order_to INT;

		SELECT @f_forward_from = f_forward, @i_order_from = i_order FROM dbo.check_points cp, dbo.picas_stops s WHERE cp.id_picas_stop = s.id_picas_stop AND s.stop_id = @stop_id_from AND cp.id_picas_route=@id_picas_route
	
		SELECT @f_forward_to = f_forward, @i_order_to = i_order FROM dbo.check_points cp, dbo.picas_stops s WHERE cp.id_picas_stop = s.id_picas_stop AND s.stop_id = @stop_id_to AND cp.id_picas_route=@id_picas_route

		IF (@f_forward_from = @f_forward_to)
		BEGIN
			IF (@i_order_from = @i_order_to) SET @i_sign_direct=0; 
			ELSE
			BEGIN
				SET @i_sign_direct = CASE WHEN @i_order_to > @i_order_from THEN 1 ELSE -1 END;
			END
		END ELSE
		BEGIN
			--DECLARE @f_forward_from_next BIT, @i_order_from_next INT;

			DECLARE @i_order_from_max INT; SET @i_order_from_max=(SELECT MAX(i_order) FROM dbo.check_points WHERE id_picas_route = @id_picas_route AND f_forward = @f_forward_from)
			
			DECLARE @i_order_to_max INT; SET @i_order_to_max=(SELECT MAX(i_order) FROM dbo.check_points WHERE id_picas_route = @id_picas_route AND f_forward = @f_forward_to)

			DECLARE @i_len_from_dir1 INT; SET @i_len_from_dir1 = (@i_order_from_max - @i_order_from) + @i_order_to;
			
			DECLARE @i_len_from_dir0 INT; SET @i_len_from_dir0 = @i_order_from + (@i_order_to_max - @i_order_to);

			SET @i_sign_direct = CASE WHEN @i_len_from_dir1 < @i_len_from_dir0 THEN 1 ELSE -1 END;
		END
	END

	RETURN @i_sign_direct;
END