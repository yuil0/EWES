ALTER PROC dbo.P_add_car_lag_lead(@dt DATETIME, @route_id NVARCHAR(32), @device_number NVARCHAR(16)) AS
-------------------- 
-- //YUIL 2017-10-17 : D:\users\yuil\JOB\EWES\SQL\transman\ate_3\dbo.P_add_car_lag_lead

DECLARE @found_near_lag_lead_car AS TABLE (stop_id BIGINT, shape_id NVARCHAR(32), arrival_time TIME, departure_time TIME, device_number_lag NVARCHAR(16), device_number_lead NVARCHAR(16), f_lag BIT, f_lead BIT, i_order INT)

INSERT @found_near_lag_lead_car EXEC dbo.P_find_near_lag_lead_car @dt = @dt, @route_id = @route_id, @device_number = @device_number

DELETE FROM dbo.car_lag_lead WHERE device_number=@device_number

DECLARE @time TIME; SET @time = dbo.FN_get_time(@dt);

INSERT dbo.car_lag_lead(dt_created,  device_number, stop_id, shape_id, arrival_time, departure_time, f_lag, f_lead, diff_minutes)
SELECT                         @dt, @device_number, stop_id, shape_id, arrival_time, departure_time, f_lag, f_lead, diff_minutes
FROM
(SELECT stop_id, shape_id, arrival_time,  departure_time

,f_lag --CASE WHEN @time < arrival_time THEN 1 ELSE 0 END f_lag

,f_lead --CASE WHEN @time > departure_time THEN 1 ELSE 0 END f_lead

,CASE WHEN @time < arrival_time THEN DATEDIFF(minute, arrival_time, @time)
  ELSE
   CASE WHEN @time > departure_time THEN DATEDIFF(minute, departure_time, @time)
   END
 END diff_minutes
FROM @found_near_lag_lead_car
)x

--- EXEC dbo.P_add_car_lag_lead @device_number = @device_number