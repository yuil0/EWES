--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\view_stop_id_by_route_id
DECLARE @dt DATETIME; SET @dt='2017-09-21T09:04:00'; --DECLARE @device_number NVARCHAR(16);
DECLARE @time TIME; SET @time=dbo.FN_get_time(@dt);
DECLARE @route_id NVARCHAR(32); SET @route_id='rostov_bus_96';

DECLARE @stop_radius FLOAT, @valid_dev_sec INT; SELECT @stop_radius=stop_radius, @valid_dev_sec=valid_dev_sec FROM dbo.const

SELECT t.shape_id, t.stop_sequence, t.stop_id, s.stop_name FROM 
(SELECT DISTincT t.shape_id, st.stop_sequence, st.stop_id FROM
dbo.picas_stop_times st, dbo.picas_trips t
WHERE st.trip_id=t.trip_id AND t.route_id=@route_id
AND dbo.FN_enabled_picas_calendar(@dt, t.service_id)=1
)t, dbo.picas_stops s 
WHERE t.stop_id=s.stop_id
ORDER BY t.shape_id, t.stop_sequence