CREATE FUNCTION dbo.FN_get_forward_by_check_point(@id_picas_route BIGINT, @stop_id BIGINT) 
RETURNS BIT
AS --D:\users\yuil\JOB\EWES\SQL\transman\ate_3\dbo.FN_get_forward_by_check_point
BEGIN 
	DECLARE @f_forward BIT;
	
	SELECT @f_forward = f_forward FROM dbo.check_points cp, dbo.picas_stops s WHERE cp.id_picas_stop = s.id_picas_stop AND s.stop_id = @stop_id AND cp.id_picas_route=@id_picas_route	
	
	RETURN @f_forward;
END