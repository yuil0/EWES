ALTER PROC dbo.P_add_ate_3
( @year int=NULL
, @month int=NULL
, @day int=NULL
, @hour int=NULL
, @minute int=NULL
, @second int=NULL
, @device_number NVARCHAR(16)
, @latitude DECIMAL(10,6)
, @longitude DECIMAL(10,6)
, @azimut INT=NULL
, @speed INT=NULL
, @x FLOAT
, @y FLOAT
, @route_short_name NVARCHAR(32)=NULL
, @route_en NVARCHAR(8)=NULL --//YUIL 2017-09-15 ������������������ ���� ��  �������� �������� ����� ��������. ������ : 18� => 18l, 18� => 18p, 42�=> 42a
, @id_zone BIGINT --//YUIL 2017-10-23
, @id_agent BIGINT=NULL --//YUIL 2017-12-18
, @id_src BIGINT=NULL --//YUIL 2017-01-26
, @id_car_type BIGINT=2  --//YUIL 2018-01-30 //YUIL 2017-09-15 ���-3  ������  ��������
) 
AS 
--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\dbo.P_add_ate_3
---------------------------------------------------------
	SET NOCOUNT ON; 

	DECLARE @id_ate_3 BIGINT; SET @id_ate_3 = (SELECT id_ate_3 FROM dbo.ate_3 WHERE device_number = @device_number);

	DECLARE @dt_cr DATETIME; SET @dt_cr=GETDATE();

	--<q3 //YUIL 2017-10-17       --DECLARE @valid_dev_sec INT; SET @valid_dev_sec=(SELECT valid_dev_sec FROM [dbo].[const])
	--DECLARE @dt DATETIME; SET @dt=@dt_cr; --(SELECT MAX(ISNULL(dt_update, dt_created)) dt FROM dbo.ate_3) --IF (DATEDIFF(second, @dt, @dt_cr) < 2) BEGin RETURN; END --
	-->q3

	--DECLARE @f_datetime_from_data BIT; SELECT @f_datetime_from_data=f_datetime_from_data FROM dbo.const; --//YUIL 2017-10-31 ����� ���� �� ����� ������

	/*BEGIN TRY 
		SET @dt=DATETIMEFROMPARTS(@year, @month, @day, @hour, @minute, @second, 0);
	END TRY 
	BEGIN CATCH
		INSERT dbo.err_add_ate_3 (dt_created,  device_number,  year,  month,  day,  hour,  minute,  second) 
		                    SELECT    @dt_cr, @device_number, @year, @month, @day, @hour, @minute, @second
		SET @dt=NULL;
	END CATCH*/

	DECLARE @route_id NVARCHAR(32); SET @route_id=(SELECT 'rostov_'+ct.name_short_en+'_'+@route_en FROM dbo.car_type ct WHERE @id_car_type=ct.id_car_type); --//YUIL 2017-10-13
	
	DECLARE @id_picas_route BIGINT; SET @id_picas_route=(SELECT id_picas_route FROM dbo.picas_routes WHERE route_id = @route_id) --//YUIL 2017-02-21

	IF (@id_agent IS NULL)
	BEGIN
		SET @id_agent=(SELECT id_agent FROM dbo.picas_routes r, dbo.picas_agents a WHERE r.agency_id = a.id AND r.route_id = @route_id) --YUIL 2017-12-27
	END

	--EXEC dbo.P_add_car_lag_lead @dt = @dt_cr, @route_id = @route_id, @device_number = @device_number --//YUIL 2017-10-17 //������ �������� ������ ����� ����� ���� ������ ��� ����� ��������

	IF (@id_ate_3 IS NULL)
	BEGIN --YUIL ����� ��������

		SET @id_ate_3 = ISNULL((SELECT MAX(id_ate_3) FROM dbo.ate_3), 0) + 1;

		SET IDENTITY_INSERT dbo.ate_3 ON;

		INSERT dbo.ate_3(id_ate_3,  device_number,  latitude,  longitude,  azimut,  speed, dt_created,  x,  y,  route_en,  id_car_type,  route_id,  route_short_name,  id_zone,  id_agent,  id_src,  id_picas_route) 
		SELECT          @id_ate_3, @device_number, @latitude, @longitude, @azimut, @speed,     @dt_cr, @x, @y, @route_en, @id_car_type, @route_id, @route_short_name, @id_zone, @id_agent, @id_src, @id_picas_route --YUIL 2017-09-13 + @route_short_name

		SET IDENTITY_INSERT dbo.ate_3 OFF;
	END
	ELSE
	BEGIN
		UPDATE c 
		SET
		  latitude      = @latitude
		, longitude     = @longitude
		, azimut        = @azimut
		, speed         = @speed
		, dt_update     = @dt_cr
		, delta_update_sec = DATEDIFF(second, ISNULL(c.dt_update, c.dt_created), @dt_cr) --//YUIL 2017-02-06
		, x_prev = x  --//YUIL 2017-10-13
		, y_prev = y
		, x = @x
		, y = @y
		, route_en    = @route_en --//YUIL 2017-10-09
		, id_car_type = @id_car_type  -- //YUIL 2017-10-09
		, route_id    = @route_id --//YUIL 2017-10-13
		, route_short_name = @route_short_name
		, id_zone = @id_zone
		, id_agent = @id_agent
		,  id_src  = @id_src --//YUIL 2017-01-26
		, id_picas_route = @id_picas_route --//YUIL 2017-02-21
		FROM  dbo.ate_3 c
		WHERE id_ate_3 = @id_ate_3
	END
	
	--YUIL 2018-02-05 ������� A1. ��������. �� ����� .EXEC dbo.P_find_stop_by_car @dt=@dt_cr, @id_ate_3=@id_ate_3, @route_id=@route_id, @x=@x, @y=@y --//YUIL 2017-11-30

	--//YUIL 2017-10-31 �������� ����� � @dt ����� �������� : --SET @dt = CASE WHEN @f_datetime_from_data=1 THEN @dt ELSE @dt_cr END;

	--//YUIL 2017-09-15 
	EXEC dbo.P_add_car_chrono 
	  @dt = @dt_cr
	, @device_number=@device_number
	, @azimut=@azimut
	, @speed=@speed
	, @x=@x
	, @y=@y
	, @id_car_type = @id_car_type --//YUIL 2017-09-15 ���-3  ������  ��������
	, @route_en=@route_en
	, @lat=@latitude, @lng=@longitude --//YUIL 2017-10-04
	, @id_zone = @id_zone

	EXEC dbo.P_add_mnemoscheme_event @device_number = @device_number --//YUIL 2017-02-05, 2017-11-27

	--EXEC dbo.P_add_formalize_messages @route_id = @route_id --//YUIL 2017-12-07
------------------
/*
CREATE TABLE dbo.err_add_ate_3
( id_err_add_ate_3 BIGINT IDENTITY(1,1), dt_created DATETIME, device_number NVARCHAR(16), year int
, month int
, day int
, hour int
, minute int
, second int)

CREATE CLUSTERED INDEX I_id_err_add_ate_3 ON dbo.err_add_ate_3 (id_err_add_ate_3)
---

*/
