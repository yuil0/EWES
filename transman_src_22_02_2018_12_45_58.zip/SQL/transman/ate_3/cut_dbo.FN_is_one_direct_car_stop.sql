--D:\users\yuil\JOB\EWES\SQL\transman\ate_3\cut_dbo.FN_is_one_direct_car_stop
DECLARE @id_ate_3 BIGINT, @stop_id BIGINT
SET @id_ate_3=4;
SET @stop_id = 1870

DECLARE @f_one_direct BIT; SET @f_one_direct=0;

DECLARE @stop_id_1 BIGINT, @stop_id_2 BIGINT, @stop_id_1_prev BIGINT, @stop_id_2_prev BIGINT, @id_picas_route BIGINT, @route_id NVARCHAR(32);

SELECT @stop_id_1 = stop_id_1, @stop_id_2=stop_id_2, @stop_id_1_prev=stop_id_1_prev, @stop_id_2_prev=stop_id_2_prev, @route_id = route_id FROM dbo.car_last_stops WHERE id_ate_3 = @id_ate_3

SET @id_picas_route = (SELECT id_picas_route FROM dbo.picas_routes WHERE route_id = @route_id);

IF ((@stop_id_1_prev IS NOT NULL OR @stop_id_2_prev IS NOT NULL) AND @id_picas_route IS NOT NULL)
BEGIN
	IF (@stop_id_1_prev IS NOT NULL AND @stop_id_2_prev IS NULL AND @stop_id_1 IS NOT NULL AND @stop_id_2 IS NULL)
	BEGIN
		/* //YUIL 2017-12-01 
		*/
		--SELECT '*'

		DECLARE @i_sign_inside INT; SET @i_sign_inside= dbo.FN_sign_direct_by_check_point(@id_picas_route, @stop_id_1_prev, @stop_id_1);

		DECLARE @i_sign_alien INT; SET @i_sign_alien= dbo.FN_sign_direct_by_check_point(@id_picas_route, @stop_id_1_prev, @stop_id);

		SELECT @i_sign_inside [@i_sign_inside], @i_sign_alien [@i_sign_alien]
		IF (@i_sign_inside!=0 AND @i_sign_alien!=0)
		BEGIN
			SET @f_one_direct =  CASE WHEN @i_sign_inside = @i_sign_alien THEN 1 ELSE 0 END;
		END
	END
END


SELECT @f_one_direct [@f_one_direct]