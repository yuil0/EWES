#ifndef _u_color_h_
#define _u_color_h_

#ifndef ulong
typedef unsigned long ulong;
typedef unsigned char uchar;
#endif

typedef  enum
{
	ECP_BLUE=0,
	ECP_GREEN,
	ECP_RED,
}EColorPart;

extern ulong g_color;

void blue_plus_handler(int iNotify, void* p_param);
void blue_minus_handler(int iNotify, void* p_param);

void green_plus_handler(int iNotify, void* p_param);
void green_minus_handler(int iNotify, void* p_param);

void red_plus_handler(int iNotify, void* p_param);
void red_minus_handler(int iNotify, void* p_param);

void chColorWnd();
void getStep(ulong& step);
/*
class UColor
{
	bool m_fInit;

	public:
	
	static 

	UColor();
	~UColor();
	bool Init();
	void Destroy();
	
	static 
	
};
*/



#endif