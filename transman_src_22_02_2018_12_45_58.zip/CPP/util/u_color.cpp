#include <memory.h>
#include "u_color.h"
#include "main.h"

const int ci_step_color=16;

ulong g_color=0;

/*
UColor::UColor() {}

UColor::~UColor() {}

bool UColor::Init()
{
	m_fInit=false;
	
	memset(this, 0, sizeof(UColor));
	
	m_fInit=true;

	return m_fInit;
}

void UColor::Destroy()
{
	
}
*/

void getBGR(uchar& B, uchar& G, uchar& R)
{
	B = (g_color >> 16) & 0xFF;
	G = (g_color >> 8) & 0xFF;
	R = g_color & 0xFF;
}

void setByBGR(uchar B, uchar G, uchar R)
{
	g_color = (B << 16) + (G << 8) + R;
}

void out()
{
	char sz[MAX_PATH + 1]; sprintf(sz, "%06X", g_color);

	g_WinCtrl.SendMes(12, WM_SETTEXT, (WPARAM)0, (LPARAM)sz);
}

void getStep(ulong& step)
{
	char sz[MAX_PATH + 1];

	g_WinCtrl.SendMes(1, WM_GETTEXT, (WPARAM)MAX_PATH, (LPARAM)sz);

	sscanf(sz, "%d", &step);
}

void plusOp(uchar& x, ulong step)
{
	if (x + step > 0xFF) { return; }

	x += step;
}

void minusOp(uchar& x, ulong step)
{
	if (((int)x - (int)step) < 0) { return; }

	x -= step;
}

void handler(EColorPart ePart, bool fPlus)
{
	ulong step = 16;

	getStep(step);

	uchar B, G, R;

	getBGR(B, G, R);

	if (ePart == ECP_BLUE)  { if (fPlus) { plusOp(B, step); } else { minusOp(B, step); } }
	else
	if (ePart == ECP_GREEN) { if (fPlus) { plusOp(G, step); } else { minusOp(G, step); } }
	else
	if (ePart == ECP_RED)   { if (fPlus) { plusOp(R, step); } else { minusOp(R, step); } }

	setByBGR(B, G, R);

	out();

	chColorWnd();
}

void blue_plus_handler(int iNotify, void* p_param)
{
	handler(ECP_BLUE, true);
	/*
	uchar B, G, R;

	getBGR(B, G, R);

	plusOp(B);

	setByBGR(B, G, R);

	out(); */
}

void blue_minus_handler(int iNotify, void* p_param)
{
	handler(ECP_BLUE, false);
	/*
	uchar B, G, R;

	getBGR(B, G, R);

	minusOp(B);

	setByBGR(B, G, R);

	out(); */
}

void green_plus_handler(int iNotify, void* p_param) { handler(ECP_GREEN, true); }
void green_minus_handler(int iNotify, void* p_param) { handler(ECP_GREEN, false); }

void red_plus_handler(int iNotify, void* p_param) { handler(ECP_RED, true); }
void red_minus_handler(int iNotify, void* p_param) { handler(ECP_RED, false); }

void chColorWnd()
{
	SCtrl* p_ctrl;
	if (g_WinCtrl.Find(13, &p_ctrl) == false) { return; }

	HWND hwnd = p_ctrl->hwnd;

	HDC hdc = GetDC(hwnd);
	
	HBRUSH hBrush = CreateSolidBrush(g_color);

	SelectObject(hdc, hBrush);

	RECT rc;

	if (GetClientRect(hwnd, &rc) == false) { return; }

	Rectangle(hdc, 0, 0,  rc.right, rc.bottom);

	DeleteObject(hBrush);

	ReleaseDC(hwnd, hdc);

	UpdateWindow(hwnd);
}