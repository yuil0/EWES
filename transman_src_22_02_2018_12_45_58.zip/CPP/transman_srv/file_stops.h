#ifndef _file_stops_h_
#define _file_stops_h_

#include <windows.h>
#include "std_str.h"
#include <vector>
#include "load_xlsx.h"
#include "std_str.h"

typedef enum
{
	EFSF_NUMBER=0, 
	EFSF_NAME, 
	EFSF_LNG, 
	EFSF_LAT,
	EFSF_AREA, 
	EFSF_STREET,
	//
	EFSF_QUANTITY,
}EFileStopsField;

class CFileStops
{
	bool m_fInit; //bool m_found_drv[EED_QUANTITY];bool FindDriverFromBuf(char *buf, int len);bool FindDrvName(char *sz_in);

	SXLSX m_xlsx;

	bool CrThread();
	
	void SaveToDB();

	void LoadFromDB();	

	void SaveToDB_op(std_string& sz_query);
	
	void SaveToDB_op_area(std_string& sz_query_area);

	void SaveToDB_op_street(std_string& sz_query_street);

	bool AddQueryRowIn(std_string& sz_query, SXLSXRow& row, std_string& sz_query_area, std_string& sz_query_street);

	public:

	CFileStops() {}

	bool Open();

	void Close(); //bool FindDriver();

	void Read();  //bool FindByDevice(const char *sz_dev, SATE3Row* *p_row);//std::vector<SATE3Row>  m_rows;
};

extern CFileStops gFileStops;

#endif