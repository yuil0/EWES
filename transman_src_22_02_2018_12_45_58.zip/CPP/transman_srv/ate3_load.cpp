#include <memory.h>
#include <corecrt_math.h>
#include <time.h>
#include "ate3_load.h"
#include "..\\transman\\math_e.h"
#include "mes_log.h"
#include "..\\transman\\ini_file.h"
#include "time_e.h"
#include "file_bind_car_route.h"
#include "..\\transman\\MSSQL.h"

#include "ATE3.h"
#include "FromPicas.h"
#include "str.h"
#include "zones.h"

const char *csz_file_query_save_ate_3 = "C:\\transman\\ate_3_QuerySave.txt";

const int ci_ATE3Load_time_ms_pause=800; //YUIL 2017-11-13

CRITICAL_SECTION cs_CATE3Load_SaveToDB;

void CATE3Load_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesLog.Mes("CATE3Load:: ������ MSSQL : %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
}

CATE3Load::CATE3Load(int i_buf_len_new)
{
	memset(this, 0, sizeof(CATE3Load));

	if (i_buf_len_new < 0) { return; } //m_i_buf_len = i_buf_len_new; //m_buf = new char[m_i_buf_len+1]; //YUIL +1 null terminator // //memset(m_buf, 0, sizeof(m_i_buf_len + 1));
	
	m_fInit=true; //// //double x=-1, y=-1; math_e::LatitudeLongitudeToXY_s("47", "51", x, y);

	ReadIni();

	unlink(csz_file_query_save_ate_3);
}

CATE3Load::~CATE3Load()
{
	
}


void CATE3Load::ReadIni()
{
	CIniFile ini;
	char sz_value[MAX_PATH + 1];

	if (ini.Get("C:\\transman\\transman.ini", "ate_3_sleep_after_save", sz_value, MAX_PATH))
	{
		m_sleep_after_save = atoi(sz_value);
	}

	if (ini.Get("C:\\transman\\transman.ini", "srv_from_ate_3_save_sql_query", sz_value, MAX_PATH))
	{
		m_fSaveSQLQuery = atoi(sz_value);
	}

}

bool CATE3Load::FindEndRow(char *sz_in, int i_pos, int i_len_in)
{
	bool fFound = false;

	for (int i = i_pos; fFound == false && i < i_len_in; i++)
	{
		if (sz_in[i] == '$') { fFound = true; }
	}

	return fFound;
}

bool IsNum(char c) //YUIL isdigit('2')�� ���� true
{
	const char c_min = 48;

	const char c_max = 57;

	return c >= c_min && c <= c_max;
}

void OutCharsTofile() 
{
	FILE *fo = 0;

	fopen_s(&fo, "chars.txt", "wb");

	if (fo)
	{
		for (int i=0,  k=0; i<256; i++,  k++)
		{
			fprintf_s(fo, "[%3d]:%c ", i,i);

			if (k == 7) { fprintf(fo, "%c%c", 13, 10); k = -1; }
		}

		fclose(fo);
	}
}

bool CATE3Load::Test(char *sz_in, int i_len_in)
{
	if (m_fInit == false) { return false; } //if (m_buf[0]) { return true; } //YUIL �� ������  ����������  �� �������

	bool fFound = false;

	for (int i = 0; fFound == false && i < i_len_in; i++)
	{
		if (sz_in[i] == '$') 
		{ 
			if (IsNum(sz_in[i + 1]) && IsNum(sz_in[i + 2]) && IsNum(sz_in[i + 3]) && IsNum(sz_in[i + 4])) 
			{ fFound = true; }
		}		
	}

	return fFound;
}

bool CATE3Load::Read(char *sz_in, int i_len_in, int i_max)
{
	if (m_fInit == false) { return  false; }

	if (i_len_in == 0) { return true; }           //Exec("TRUNCATE TABLE dbo.ate_3"); //YUIL ������ ������� � ��

	//<q2 //YUIL 2017-11-13 ������ �� ������� ������
	static time_t t_prev=0;

	time_t t = clock();

	if (t_prev && t - t_prev < ci_ATE3Load_time_ms_pause) {return false;}

	t_prev = t;
	//>q2

	/*YUIL 2017-08-24 . ������.������ : $2017 - 08 - 24, 09:14 : 48, M166OH, 47.273792, 39.757253, 124, 26$
	���-3 ������� ������ � �������:
	$����,�����,� �������,������, �������,�����������,��������$
	$2017-07-28,13:21:15,M230OH,47.23895,39.613431,215,0$
	*/
	bool f_open=false;

	char *p_in = sz_in; //YUIL  ���������� ������ �� sz_in

	/*if (m_buf[0])
	{
		int i_len_m_buf = strlen(m_buf);

		if (i_len_m_buf + i_len_in > m_i_buf_len)
		{
			i_len_in = m_i_buf_len - i_len_m_buf; //YUIL �������  � ������������, ��� ������ ���.
		}

		memcpy(m_buf + i_len_m_buf, sz_in, i_len_in);  //YUIL ������ m_buf, ����� ����� � ��� ���� ������ �����.

		i_len_m_buf += i_len_in;

		p_in = m_buf; //YUIL  ���������� ������ �� m_buf

		i_len_in = i_len_m_buf; //YUIL �������� ������
	}*/
	
	EATE3LoadField eField;
	SATE3RowStr row;

	int i_pos_field;
	int i_pos_divider;

	for (int i=0; i<i_len_in; i++)
	{
		bool f_divider = p_in[i] == '$';

		if (f_open == false)
		{
			if (f_divider)
			{
				f_open = true;

				i_pos_field = i+1;

				eField = EATE3LF_DATE;
				
				i_pos_divider = i;

				row.Clear();

				bool fFoundEnd = FindEndRow(p_in , i_pos_divider + 1, i_len_in);

				if (fFoundEnd == false)
				{
					int q = i_len_in - (i_pos_divider + 1);

					/*if (q <= m_i_buf_len)
					{
						memcpy(m_buf, p_in + i_pos_divider, q); m_buf[q] = 0; //YUIL. ��� �����,�.�.  ������ �� ���.
					}
					else
					{
						m_buf[0] = 0; //YUIL. ��� ���. ������ ������. ����� �������� � ��� ����.
					}*/

					break; //YUIL � ������ ���������. ���� �� �����.
				}
				/*else
				{
					m_buf[0]=0; //YUIL. ��� �� �����,�.�.  ���� ��� ������.
				}*/

			}
		}
		else
		{
			if (f_divider)
			{
				f_open = false;
			}

		}

		if (f_open && f_divider==false)
		{
			if (p_in[i] == ',' || p_in[i + 1] == '$' || i + 1 == i_len_in)
			{
				int i_size = i - i_pos_field;
				
				int i_shift= 0;
				
				if (p_in[i] != ',' && (p_in[i + 1] == '$' || i + 1 == i_len_in)) { i_size++; i_shift = 1; }

				if (i_size)
				{
					char ch_save = p_in[i + i_shift]; 
					
					p_in[i + i_shift] = 0;

					ReadOpStr(eField, p_in + i_pos_field, row, i_size);
					
					p_in[i + i_shift] = ch_save;
				}

				i_pos_field = i + 1;
			}
		}
		
	}

	return true;
}

void SATE3RowStr::SetRoute(const char *sz_type)
{
	SATE3Row* pATE3Row;

	if (gATE3.GetLoadParam().FindByDevice(device_number.c_str(), &pATE3Row) == false) { return; }

	SFileBindCarRouteRow* pFileBindCarRouteRow; //if (gFileBindCarRoute.FindByGarageNum(pATE3Row->sz_garage_num.c_str(), &pFileBindCarRouteRow) == false) { return; }

	if (gFileBindCarRoute.FindByGarageNumAndType(pATE3Row->sz_garage_num.c_str(), (char*)sz_type, &pFileBindCarRouteRow) == false) { return; }

	route = pFileBindCarRouteRow->route;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void CATE3Load::ReadOpStr(EATE3LoadField& eField, char *sz_in, SATE3RowStr& row, int i_max) //YUIL. sz_in  is null-terminated string.
{
	if (eField == EATE3LF_DATE)
	{
		//CorrectDate(sz_in, &row.date);
	}
	else
	if (eField == EATE3LF_TIME)
	{
		//std_string sz_out = CorrectTime(sz_in, i_max, &row.time);

		//strcpy_s(sz_in, i_max, sz_out.c_str());
	}
	else
	if (eField == EATE3LF_DEVICE_NUMBER)
	{
		row.device_number = sz_in;
	}
	else
	if (eField == EATE3LF_LATITUDE)
	{
		row.latitude = sz_in;
	}
	else
	if (eField == EATE3LF_LONGITUDE)
	{
		row.longitude = sz_in;
	}
	else
	if (eField == EATE3LF_AZIMUT)
	{
		row.azimut = sz_in;
	}
	else
		if (eField == EATE3LF_SPEED)
		{
			row.speed = sz_in;

			row.CalcXY();

			row.SetRoute(); //YUIL 2017-09-13

			char* sz_id_agent = "15\0";

			SaveToDB(row, sz_id_agent); //YUIL ��� ���� ������ ����� ����� ������ � ��.                  //Save(row);				
		}
		else {}

		int i = (int)eField;

		i++;

		eField = (EATE3LoadField)i;
}

void SATE3RowStr::Clear() { memset(this, 0, sizeof(SATE3RowStr)); }

void SATE3RowStr::CalcXY()
{
	double lat = atof((char*)latitude.c_str());

	double lng = atof((char*)longitude.c_str());

	if (fabs(lat) > 99 || fabs(lng) > 99) { eErr = ESATE3RSE_LAT_LNG_OVER;  return; } //gMesLog.Mes("CATE3Load. Not save to DB ATE-3 device '%s'. Over values lat=%f lng=%f", device_number, lat, lng); return;

	math_e::LatitudeLongitudeToXY(lat, lng, x, y);

}

void CATE3Load::SaveToDB(SATE3RowStr& row, char* sz_id_agent)
{                                                                                          //EnterCriticalSection(&cs_CATE3L�oad_SaveToDB);
	if (row.device_number == "") { return; } //YUIL � ������ ������ ���������� �� �����
	
	if (row.eErr!= ESATE3RSE_NONE) { return; } //YUIL 2017-09-19

	const int ci_ate_3_load_buf_len = 1024;

	//CMSSQL cMSSQL;

	//bool f_open = cMSSQL.Open();

	//bool fNoRows = true;
		
	/*double x, y;

	double lat = atof((char*)row.latitude.c_str());

	double lng = atof((char*)row.longitude.c_str());

	if (lat > 100 || lng > 100) { gMesLog.Mes("CATE3Load. Not save to DB ATE-3 device '%s'. Over values lat=%f lng=%f", row.device_number, lat, lng); return; } //YUIL ����� ������

	math_e::LatitudeLongitudeToXY(lat, lng, x, y);*/

	char sz_val[MAX_PATH + 1]; 

	SZone s_zone;

	char sz_query[ci_ate_3_load_buf_len + 1]; 
	
	strcpy_s(sz_query, ci_ate_3_load_buf_len, "EXEC dbo.P_add_ate_3 @id_src=2, @device_number = N'"); 
	
	strcat_s(sz_query, ci_ate_3_load_buf_len, row.device_number.c_str());

	strcat_s(sz_query, ci_ate_3_load_buf_len, "', @latitude = ");

	strcat_s(sz_query, ci_ate_3_load_buf_len, row.latitude.c_str()); 
	
	strcat_s(sz_query, ci_ate_3_load_buf_len, ", @longitude = "); 
	
	strcat_s(sz_query, ci_ate_3_load_buf_len, row.longitude.c_str()); 
	
	strcat_s(sz_query, ci_ate_3_load_buf_len, ", @azimut = ");  
	
	strcat_s(sz_query, ci_ate_3_load_buf_len, row.azimut.c_str());

	strcat_s(sz_query, ci_ate_3_load_buf_len, ", @speed = "); 
	
	strcat_s(sz_query, ci_ate_3_load_buf_len, row.speed.c_str());

	sprintf_s(sz_val, MAX_PATH, ", @x = %f, @y = %f", row.x, row.y); 
	
	strcat_s(sz_query, ci_ate_3_load_buf_len, sz_val);

	if (row.route.size())
	{
		strcat_s(sz_query, ci_ate_3_load_buf_len, ", @route_short_name = N'"); 
		
		strcat_s(sz_query, ci_ate_3_load_buf_len, row.route.c_str()); 
		
		strcat_s(sz_query, ci_ate_3_load_buf_len, "'");

		strcat_s(sz_query, ci_ate_3_load_buf_len, ", @route_en = N'"); 
		
		strcat_s(sz_query, ci_ate_3_load_buf_len, GetTranslit((char*)row.route.c_str(), sz_val, MAX_PATH)); 
		
		strcat_s(sz_query, ci_ate_3_load_buf_len, "'"); //YUIL 2017-09-15 ������������������ ���� ��  �������� �������� ����� ��������. ������ : 18� => 18l, 18� => 18p, 42�=> 42a	
	}

	strcat_s(sz_query, ci_ate_3_load_buf_len, ", @id_zone = ");

	if (gZones.FindXY(row.x, row.y, s_zone))
	{
		strcat_s(sz_query, ci_ate_3_load_buf_len, s_zone.id_zone.c_str());
	}
	else
	{
		strcat_s(sz_query, ci_ate_3_load_buf_len, "0");
	}

	if (sz_id_agent)
	{
		if (strlen(sz_id_agent))
		{
			strcat_s(sz_query, ci_ate_3_load_buf_len, ", @id_agent="); 
			
			strcat_s(sz_query, ci_ate_3_load_buf_len, sz_id_agent);
		}
	}

	strcat_s(sz_query, ci_ate_3_load_buf_len, ";;");

	if (strstr(sz_query, ";;") == 0)
	{
		gMesLog.Mes("CSockSrvWialon::SaveToDB. ������. � ������ SQL ������� ��� ����������");
		return;
	}

	/* std_string sz_query = "SET IDENTITY_INSERT dbo.ate_3 ON;";

	sz_query.append("DECLARE @id_ate_3 BIGINT; SET @id_ate_3 = ISNULL((SELECT MAX(id_ate_3) FROM dbo.ate_3), 0) + 1;");

	sz_query.append("INSERT dbo.ate_3(id_ate_3, dt, device_number, latitude, longitude, azimut, speed) SELECT @id_ate_3, '" + row.date + "T" + row.time + "', '" + row.device_number + "', " + row.latitude + ", " + row.longitude + ", " + row.azimut + ", " + row.speed + ";");

	sz_query.append("SET IDENTITY_INSERT dbo.ate_3 OFF;");  */

	/*if (m_fSaveSQLQuery)
	{
		static time_t time_prev = 0;
		time_t time = clock();
		if (time_prev == 0 || (time - time_prev) > 3600000)
		{
			time_prev = time;
			unlink(csz_file_query_save_ate_3);
		}
	}*/

	bool fExec = MSSQL_Exec((char*)sz_query, NULL, CATE3Load_FN_MSSQL_MES_ERR, this);  //cMSSQL.Execute((char*)p_query, fNoRows, CATE3Load_FN_MSSQL_EXCEPTION); Sleep(50);  //cMSSQL.Close(); //LeaveCriticalSection(&cs_CATE3Load_SaveToDB);

	if (fExec == false)
	{
		FILE *fo = 0; fopen_s(&fo, csz_file_query_save_ate_3, "ab");
		if (fo) { fprintf_s(fo, "%s\r\n", sz_query); fclose(fo); }
	}

	Sleep(m_sleep_after_save);
}

/*
@year = ";

itoa(row.date.year, sz_val, 10); sz_query.append(sz_val);

sz_query.append(", @month = ");

itoa(row.date.month, sz_val, 10); sz_query.append(sz_val);

sz_query.append(", @day = ");

itoa(row.date.day, sz_val, 10); sz_query.append(sz_val);

sz_query.append(", @hour = ");

itoa(row.time.hour, sz_val, 10); sz_query.append(sz_val);

sz_query.append(", @minute = ");

itoa(row.time.minute, sz_val, 10); sz_query.append(sz_val);

sz_query.append(", @second = ");

itoa(row.time.second, sz_val, 10); sz_query.append(sz_val);

sz_query.append(", 
	*/


void cs_CATE3Load_SaveToDB_init() { InitializeCriticalSection(&cs_CATE3Load_SaveToDB); }
void cs_CATE3Load_SaveToDB_del() { DeleteCriticalSection(&cs_CATE3Load_SaveToDB); }


