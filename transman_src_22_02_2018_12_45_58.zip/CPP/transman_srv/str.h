#ifndef _str_0_h_
#define _str_0_h_

#include "..\\transman_srv\\std_str.h"
#include <vector>

#ifndef ulong
typedef unsigned long ulong;
#endif

#ifndef uchar
typedef unsigned char uchar;
#endif

void convert_from_UTF8(char *sz_in, char *sz_out);

char UTF8_to(unsigned uVal);

void remove_double_chars(char *sz, int i_max);

void remove_first_last(char *sz, int i_max, char c_remove='"');

char* GetTranslit(char *sz_in, char *sz_out,  int i_out_max); //YUIL 2017-09-15

typedef void(*FN_OVER)(void *p_param, char *sz_buf);

void AddFormat(char *sz_buf, int i_buf_size, void *p_param, FN_OVER fn_over, char *szFormat, ...);

bool IsNumChar(char c);

bool IsLetterChar(char c);

bool IsLetterRuChar(char c);

bool IsNum(char *sz_in, char ch_ignore=0);

char* StrTruncByChar(char* sz_in, char cTrunc);

char* ByteToHex(char* sz_buf, char byte, int i_max);

char* GetFileOnly(char* sz_file, char* sz_file_only, int i_file_only_max);

struct SStrList
{
	std::vector<std_string> list;
	bool Find(char *sz_find);
};

bool FindInStrList(std::vector<std_string>& list, char *sz_find, int* p_index=0);

template<class Type>
struct SFind
{
	bool Find(std::vector<Type>& list, Type lFind)
	{
		std::vector<Type>::iterator it_begin = list.begin();
		std::vector<Type>::iterator it_end = list.end();

		std::vector<Type>::iterator it = find(it_begin, it_end, lFind);

		return it != it_end;
	}

	/*bool  FillUnique(std::vector<Type>& list, std::vector<Type>& uniq_list)
	{
		uniq_list.clear();

		int q = list.size();

		for (int i = 0; i < q; i++)
		{
			bool fFound = Find(uniq_list, list[i]);

			if (fFound==false)
			{
				uniq_list.push_back(list[i]);
			}
		}
	}*/
};

void ReadHexStrByte(char *sz_val, uchar& part);

bool ReadHexStr(char *sz_val, ulong& color, uchar* p_part=0);

void strcpy_y(char* dest, int i_dest_max, char *src);

void set_str(char* sz, int i_max, char *sz_new);
void add_str(char* sz, int i_max, char *sz_new);
void add_str(char* sz, int i_max, const char *sz_new);

char* NextSubStr(char* *p_pos, char cDevider, char* szSub);

#endif