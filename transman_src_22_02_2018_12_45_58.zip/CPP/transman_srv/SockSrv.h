#ifndef _SockSrv_h_
#define _SockSrv_h_

#include "std_str.h"
#include <time.h>
#include <vector>
#include <basetsd.h>

const int ci_socksrv_buf_len = 1024;
const int ci_socksrv_client_max= 40;
const int ci_ip_len = 11;


typedef void(*FN_SOCK_SRV_ON_READ)(void *p_param, int i_client_sock, char *buf, int len); //void Read(char *buf, int len, int i_client_sock);

#ifndef SOCKET
typedef UINT_PTR SOCKET;
#endif

#ifndef HANDLE
typedef void* HANDLE;
#endif

class CSockSrv
{
public:
	struct SClient
	{
		SOCKET s;
		time_t time_prev;
		char ip[ci_ip_len+1];
		//
		FN_SOCK_SRV_ON_READ m_fn;
		void *m_p_param;    //int m_len_buf;
		//
		std_string m_port;
		//
		SClient();
		void CrThRead();
		void Read();
	};
private:
	bool m_fInit;
	std_string m_port;
	time_t time_period_rep_sock_recv;

	FN_SOCK_SRV_ON_READ m_fn;
	void *m_p_param;
	HANDLE m_hThRead;

	void Read_time_period_rep_sock_recv_from_ini();
	void Notify_ip(struct sockaddr& addr_client, int i_client_sock, SClient& s_client);
	void NotifyRecCount(int i_cnt_last);	
	char m_buf[ci_socksrv_buf_len];  //YUIL +1 ��� ���� ����������� //t_char_list m_buf; //std_string m_buf;
	int m_len_buf;
	public:
	
	//
	CSockSrv(); //virtual bool Open(char* sz_port_new);
	bool OpenOp(char* sz_port_new, void *p_param, FN_SOCK_SRV_ON_READ fn);
	void Close();

	void Listen();
	char* GetBuf() { return (char*)m_buf; } //t_char_list& GetBuf() { return (t_char_list&)m_buf; }
	void ListenOp(); //void ClearBuf() { m_buf.clear(); } //void AppendBuf(char *sz_in, int len_in); 	//void AddClient(SClient& s_client);	void ReadClients();
	int GetBufLen() { return m_len_buf; } //	void DelClient(int index);
};

void shutdown_closesocket(SOCKET i_client_sock);

#endif