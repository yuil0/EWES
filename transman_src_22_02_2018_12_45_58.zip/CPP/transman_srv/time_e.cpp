#include <memory.h>
#include <string.h>
#include <stdio.h>
#include "time_e.h"

namespace time_e
{
	bool GetCurLocalDateTime(struct tm& tmOut)
	{		
		time_t t = time(0);

		struct tm *tm = localtime(&t);

		if (t == 0) { return false; }

		tm->tm_year += 1900;

		tm->tm_mon += 1;

		memcpy(&tmOut, tm, sizeof(struct tm));

		return true;
	}


	bool LocalTimeToText(char *sz_text, int i_max, char ch_replace, SLocalTimeToTextParam* pParam)
	{
		bool fDateOnly = false;

		time_t time_val = time(0);

		if (pParam)
		{
			fDateOnly = pParam->fDateOnly;

			time_val += pParam->time_diff;
		}

		if (time_val < 0) { return false; }

		struct tm* tm = localtime(&time_val);

		int i_len = strlen(sz_text);
		
		tm->tm_year += 1900;
		tm->tm_mon += 1;
		if (fDateOnly)
		{
			sprintf_s(sz_text + i_len, i_max, "%04d-%02d-%02dT23:59:59.997", tm->tm_year, tm->tm_mon, tm->tm_mday);
		} 
		else
		{
			sprintf_s(sz_text + i_len, i_max, "%04d-%02d-%02dT%02d:%02d:%02d", tm->tm_year, tm->tm_mon, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec); 
		}

		if (ch_replace)
		{
			char *p = (char *)(sz_text + i_len);
			for (int i = 0; p[i]; i++)
			{
				if (p[i] == '-' || p[i] == ':') { p[i] = ch_replace; }
			}
		}

		return true;
	}

	////////////////////////////////////////////////////////
	CTimeOut::CTimeOut(time_t time_delta_new)
	//
	{
		memset(this, 0, sizeof(CTimeOut));

		time_delta = time_delta_new;
	}

	bool CTimeOut::IsOver(time_t time)
	{
		bool fOver = false;

		if (time_prev)
		{
			if (time - time_prev > time_delta)
			{
				fOver = true;

				time_prev = time;
			}
		}
		else
		{ time_prev = time; }

		return fOver;
	}

}

