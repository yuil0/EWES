#include <memory.h>
#include <windows.h>
#include "zones.h"
#include "mes_log.h"
#include "..\\transman\\mssql.h"
#include "..\\transman\\math_e.h"

const int ci_max_quantity_zone_point=4;

void CZones_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesLog.Mes("CZones:: ������ MSSQL : %s", eState == EMSSQLS_START ? "��� �����" : sz_text);
}

CZones::CZones()
{
	m_fInit=false;
	
	memset(this, 0, sizeof(CZones));
	
	m_fInit=true;
}

CZones::~CZones()
{
	
}

bool CZones::Open()
{
	memset(this, 0, sizeof(CZones));
	
	m_fInit=true;

	CrThread();

	return m_fInit;
}

void CZones::Close()
{

}

DWORD WINAPI CZones_ThreadProc(LPVOID lpParameter)
{
	CZones *p_this = (CZones *)lpParameter;

	if (p_this == 0) { return 0; }

	while (1)
	{
		p_this->ReadFromDB();

		Sleep(800);
	}

	return 1;
}


bool CZones::CrThread()
{
	HANDLE h=CreateThread(0, 0, CZones_ThreadProc, (LPVOID)this, 0, 0);

	return  h != 0;
}

void CZones_FN_MSSQL_ADD(void *p_param, FldsPtr fp)
{
	CZones* p_this=(CZones*)p_param;

	if (p_this)  {p_this->Add(fp);}
}

void CZones::Add(FldsPtr fp)
{
	SZone o;
	
	_bstr_t bstr_id_zone(fp->Item["id_zone"]->Value);

	o.id_zone=(char*)bstr_id_zone;
	
	o.quantity = fp->Item["quantity"]->Value.intVal;

	o.x_0 = fp->Item["x_0"]->Value.dblVal;	
	o.y_0 = fp->Item["y_0"]->Value.dblVal;

	o.x_1 = fp->Item["x_1"]->Value.dblVal;	
	o.y_1 = fp->Item["y_1"]->Value.dblVal;

	o.x_2 = fp->Item["x_2"]->Value.dblVal;	
	o.y_2 = fp->Item["y_2"]->Value.dblVal;

	o.x_3 = fp->Item["x_3"]->Value.dblVal;	
	o.y_3 = fp->Item["y_3"]->Value.dblVal;

	m_list.push_back(o);
}

void CZones::ReadFromDB()
{
	m_list.clear();

	bool f_exec = MSSQL_Exec("SELECT id_zone, quantity, x_0, y_0, x_1, y_1, x_2, y_2, x_3, y_3 FROM dbo.zones", CZones_FN_MSSQL_ADD, CZones_FN_MSSQL_MES_ERR, this);
}

bool CZones::FindXY(double x, double y, SZone& s_zone)
{
	bool fFound=false;

	SPoint<double> pn={x, y};

	for (int i=0; fFound==false && i<m_list.size(); i++)
	{
		SZone& o=m_list[i];
		
		SPoint<double> pPoly[ci_max_quantity_zone_point]; 

		pPoly[0].x = o.x_0; pPoly[0].y = o.y_0;
		pPoly[1].x = o.x_1; pPoly[1].y = o.y_1;
		pPoly[2].x = o.x_2; pPoly[2].y = o.y_2;
		pPoly[3].x = o.x_3; pPoly[3].y = o.y_3;
		
		fFound = math_e::InPoly(pn, pPoly, o.quantity);

		if (fFound) {s_zone=o;}
	}

	return fFound;
}

CZones gZones;