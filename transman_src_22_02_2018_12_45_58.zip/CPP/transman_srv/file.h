#ifndef _file_0_h_
#define _file_0_h_

bool CopyToArch(char *sz_path, char* *sz_file, int q_file); //YUIL �������� � �����

bool IsFileExists(const char  *csz_find_mask, const char  *sz_file);

bool IsDirExists(const char *csz_find_mask,  const char  *szDir);

bool ClearFolder(char *sz_path, char *sz_mask);

bool Create_Directory(const char * sz_path, const char * sz_dir, char *sz_buf=0, int i_max_out = MAX_PATH);

#endif