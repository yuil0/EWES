#ifndef _sock_server_h_
#define _sock_server_h_

#include "ate3_load.h"

/*typedef enum
{
	ESSD_ATE_3=0,
	ESSD_CHAT,
	//
	ESSD_QUANTITY,
}ESockServerDevider;*/

class CSockServer
{
	bool m_fInit; //void Connect();// char *sz_server_name);

	long m_i_done; //

	CATE3Load* m_pATE3Load;
	
	public:
	CSockServer();
	~CSockServer();

	bool Open();
	void Close();

	void Listen();

	long GetDone() { return m_i_done; } //void ReadBuf(char *buf, int len_buf);
	CATE3Load* GetATE3Load() { return m_pATE3Load; }
	void SetATE3Load(CATE3Load*  p_new) { m_pATE3Load= p_new; }
};


//int ServerOpen();

#endif