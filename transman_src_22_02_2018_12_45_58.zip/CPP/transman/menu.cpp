#include "menu.h"
#include <memory.h>


CMenu::CMenu()
{
	memset(this, 0, sizeof(CMenu));
	
	m_fInit=true;
}

bool CMenu::Open()
{
	HMENU m_menu = CreatePopupMenu();

	if (m_menu == 0) { return false; }

	/*BOOL fAdd = InsertMenuItem(m_menu, _In_ UINT            uItem,
		_In_ BOOL            fByPosition,
		_In_ LPCMENUITEMINFO lpmii
	);*/

	return true;
}

void CMenu::Close()
{
	DestroyMenu(m_menu);
}
