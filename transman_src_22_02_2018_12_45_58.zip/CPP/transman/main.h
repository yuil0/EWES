#ifndef _main_h_
#define _main_h_

#include <windows.h>
#include "window.h"
#include "ms_inet.h"
//#include "wnd_hook.h"
#include "map_timer.h"
#include "draw_wnd.h"
#include "ControlPanelWnd.h"
#include "mes_wnd.h"
#include "win_e.h"

typedef enum
{
	ELS_MAP=0,
	ELS_BOOK_MARKS,
	ELS_VIDEO_WALL,
	//
	ELS_QUANTITY,
}ELogicalScreen;

extern HINSTANCE g_hInstance;

extern HWND g_hWndMap;

extern CWindow gWndMain;

extern CMSInet gWndMap; //extern CWndHook gWndHook;

extern wchar_t g_wz_map_addr[MAX_PATH + 1];

extern CMapTimer gMapTimer;

extern CDrawWnd gDrawWnd;

extern CControlPanelWnd gControlPanelWnd;

extern int g_i_user_interface;

extern bool g_f_bitmap_interface;

extern bool g_f_log_draw_objects;

extern const char* csz_log_draw_objects;

extern win_e::SMonitors gMonitors;

void InitSec();

void ShowLeftScr(int cmd_show);

void ShowRightScr(int cmd_show);

void Destroy(HWND hwnd = 0);

void ChLogicalScreen();

void DestroyExit();

#endif