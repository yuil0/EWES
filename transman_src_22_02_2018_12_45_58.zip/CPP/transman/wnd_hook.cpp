#include <memory.h>
#include "wnd_hook.h"

#include "main.h"

#include "transman_wnd_hook.h"

//#import "transman_wnd_hook.dll" //C:\\transman\\transman_wnd_hook.dll"

CWndHook::CWndHook()
{
	m_fInit=false;
	
	memset(this, 0, sizeof(CWndHook));
	
	m_fInit=true;
}

CWndHook::~CWndHook()
{
	
}

/*
void WM__LBUTTONDOWN()
{
	MessageBox(0, L"WM_LBUTTONDOWN", g_sz_app, 0);
}

void WM__CLOSE()
{
	SendMessage(gWndMand.GetHWND(), WM_CLOSE, 0, 0);
}


LRESULT CALLBACK GetMsgProc(int code, WPARAM wParam, LPARAM lParam)
{
	if (code < 0) { return CallNextHookEx(0, code, wParam, lParam); }
	
	MSG *pMsg = (MSG *)lParam;

	if (pMsg->hwnd == g_hWndMap)
	{
		switch(pMsg->message)
		{
		case WM_LBUTTONDOWN: WM__LBUTTONDOWN(); break;
		case WM_CLOSE: WM__CLOSE(); break;
		}

	}

	return CallNextHookEx(0, code, wParam, lParam);
} */

bool CWndHook::Open()
{
	bool fRes = false;

	DWORD dwThreadId = 0;

	HWND hWndReceiver = gWndMand.GetHWND();
	
	HWND hWndTarget = g_hWndMap;

	DLL_WND_HOOK_SetHWND(hWndReceiver, hWndTarget);

	HMODULE hModDLL=GetModuleHandle(L"transman_wnd_hook.dll");

	m_hHook = SetWindowsHookEx(WH_MOUSE_LL, DLL_HOOK_Func, hModDLL, NULL); //WH_GETMESSAGE

	if (m_hHook == 0)
	{
		wchar_t wszText[MAX_PATH + 1];
		long lErr = GetLastError();

		wsprintf(wszText, L"������ ��������� ������������� ��������� : %d", lErr);

		if (lErr == ERROR_HOOK_NEEDS_HMOD)
		{
			lstrcat(wszText, L" : Cannot set nonlocal hook without a module handle");
		}				

		MessageBox(gWndMand.GetHWND(), wszText, g_sz_app, MB_OK | MB_ICONERROR);
	}

	return fRes;
}

bool CWndHook::Close()
{
	if (m_hHook == 0) { return true; }

	bool fRes = UnhookWindowsHookEx(m_hHook);

	return fRes;
}
