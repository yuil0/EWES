#include "fill_ctrl.h"
#include "..\\transman_srv\\str.h"

#include "MesWnd.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////
SFillCtrl::SFillCtrl(CWinCtrl* p_ctrls)
//
{
	memset(this, 0, sizeof(SFillCtrl));

	if (p_ctrls == 0) { return; }

	m_p_ctrls = p_ctrls;

	m_fInit = true;
}

SNameId::SNameId() { memset(this, 0, sizeof(SNameId)); }

void SFillCtrl_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesWnd.Mes("SFillCtrl. ������ MS SQL : %s", sz_text);
}

void SFillCtrl_fill_from_db_add(void *p_param, FldsPtr fp)
{
	SFillCtrl *p_this = (SFillCtrl *)p_param;

	if (p_this) { p_this->fill_from_db_add(fp); }
}

void SFillCtrl::fill_from_db_add(FldsPtr fp)
{
	if (m_fInit == false) { return; }

	bool f_name = m_name_fields.name.size() != 0;
	bool f_id = m_name_fields.id.size() != 0;

	if (f_name)
	{
		_bstr_t bstr(fp->Item[(char*)m_name_fields.name.c_str()]->Value);

		for (int i = 0; i < m_box_names.size(); i++)
		{ m_p_ctrls->SendMes((char*)m_box_names[i].c_str(), m_eTypeBox == ETB_COMBOBOX ? CB_ADDSTRING : LB_ADDSTRING, (WPARAM)0, (LPARAM)((char*)bstr)); }


		if (m_p_list)
		{
			SNameId o;
			o.name = (char*)bstr;

			if (f_id)
			{
				_bstr_t bstr_id(fp->Item[(char*)m_name_fields.id.c_str()]->Value);
				o.id = (char*)bstr_id;
			}

			m_p_list->push_back(o);
		}
	}

	m_i_read_rows++;
}

void SFillCtrl::fill_from_db(ETypeBox eTypeBox, std::vector<std_string>& box_names, char *sz_query, SNameId& name_fields, std::vector<SNameId>* p_list, int index_to_set)
{
	if (m_fInit == false) { return; }

	m_box_names = box_names; //m_sz_box_name = sz_box_name;

	m_eTypeBox = eTypeBox;

	m_p_list = p_list;

	m_name_fields = name_fields;

	m_p_list = p_list;

	if (m_p_list) { m_p_list->clear(); }

	for (int i = 0; i < m_box_names.size(); i++)
	{
		m_p_ctrls->SendMes((char*)m_box_names[i].c_str(), m_eTypeBox == ETB_COMBOBOX ? CB_RESETCONTENT : LB_RESETCONTENT, (WPARAM)0, (LPARAM)0);
	}	

	m_i_read_rows=0;

	bool f_exec = MSSQL_Exec(sz_query, SFillCtrl_fill_from_db_add, SFillCtrl_FN_MSSQL_MES_ERR, this);

	if (f_exec)
	{
		if (index_to_set >= 0)
		{
			for (int i = 0; i < m_box_names.size(); i++)
			{
				m_p_ctrls->SendMes((char*)m_box_names[i].c_str(), m_eTypeBox == ETB_COMBOBOX ? CB_SETCURSEL : LB_SETCURSEL, (WPARAM)index_to_set, (LPARAM)0);
			}
		}
	}
	else
	{
		for (int i = 0; i < m_box_names.size(); i++)
		{
			gMesWnd.Mes("SFillCtrl::fill_from_db(). ������ ���������� �������� : %s", (char*)m_box_names[i].c_str());			
		}
	}
}


bool FindInListByName(std::vector<SNameId>& list, char *sz_name, int* p_index)
{
	bool fFound = false;

	int q = list.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SNameId o = list[i];

		if (!stricmp(o.name.c_str(), sz_name)) { fFound = true; if (p_index) { *p_index = i; } }
	}

	return fFound;
}

bool FindInListById(std::vector<SNameId>& list, char *sz_id, int* p_index)
{
	bool fFound = false;

	int q = list.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		SNameId o = list[i];

		if (!stricmp(o.id.c_str(), sz_id)) { fFound = true; if (p_index) { *p_index = i; } }
	}

	return fFound;
}

void SFillCtrl::SetPosByName(ETypeBox eTypeBox, char *sz_box_name, std::vector<SNameId>& list, char *sz_name)
{
	int indexL;

	if (FindInListByName(list, sz_name, &indexL))
	{
		m_p_ctrls->SendMes(sz_box_name, eTypeBox == ETB_COMBOBOX ? CB_SETCURSEL : LB_SETCURSEL, (WPARAM)indexL, (LPARAM)0);
	}
}

void SFillCtrl::SetPosById(ETypeBox eTypeBox, char *sz_box_name, std::vector<SNameId>& list, char *sz_id)
{
	int indexL;

	if (FindInListById(list, sz_id, &indexL))
	{
		m_p_ctrls->SendMes(sz_box_name, eTypeBox == ETB_COMBOBOX ? CB_SETCURSEL : LB_SETCURSEL, (WPARAM)indexL, (LPARAM)0);
	}

}

void SFillCtrl_fill_edit_from_db_add(void *p_param, FldsPtr fp)
{
	SFillCtrl *p_this = (SFillCtrl *)p_param;

	if (p_this) { p_this->fill_edit_from_db_add(fp); }
}

void SFillCtrl::AddRowNames(FldsPtr fp)
{
	std::vector<std_string> row;

	for (long i = 0; i < fp->Count; i++)
	{
		/*_variant_t v_index;
		v_index.vt = VT_INT;
		v_index.intVal = i;*/
		_bstr_t bstr_name(fp->GetItem(i)->Name);

		row.push_back((char*)bstr_name);
	}

	m_rows.push_back(row);
}

void SFillCtrl::AddRow(FldsPtr fp)
{
	std::vector<std_string> row;

	for (long i = 0; i < fp->Count; i++)
	{
		/*_variant_t v_index;
		v_index.vt = VT_INT;
		v_index.intVal = i;*/
		_bstr_t bstr_val(fp->GetItem(i)->Value); //Item[i]

		row.push_back((char*)bstr_val);
	}

	m_rows.push_back(row);
}

void SFillCtrl::fill_edit_from_db_add(FldsPtr fp)
{
	if (m_fInit == false) { return; }

	if (m_rows.size()==0) { AddRowNames(fp); }
	
	AddRow(fp);	
}

bool SFillCtrl::fill_edit_from_db(char* sz_edit, char* sz_query)
{
	bool fRes = false;

	m_rows.clear();
	m_sz_edit = sz_edit;

	bool f_exec = MSSQL_Exec(sz_query, SFillCtrl_fill_edit_from_db_add, SFillCtrl_FN_MSSQL_MES_ERR, this);
	if (f_exec)
	{
		if (m_rows.size())
		{
			CalcColChars();

			SetTextEdit();
			
			SCtrl* p_ctrl;
			if (m_p_ctrls->Find((char*)m_sz_edit.c_str(), &p_ctrl))
			{
				UpdateWindow(p_ctrl->hwnd);
			}

			fRes = true;
		}
	}
	return fRes;
}

void SFillCtrl::CalcColChars()
{
	m_col_chars.clear();

	for (int r = 0; r < m_rows.size(); r++)
	{
		std::vector<std_string>& row = m_rows[r];

		for (int c = 0; c < row.size(); c++)
		{
			int i_item_size = row[c].size();

			int q_cols = m_col_chars.size();

			if (c >= q_cols)
			{
				m_col_chars.push_back(i_item_size);
			}
			else
			{
				int i_item_size_L = m_col_chars[c];

				if (i_item_size_L < i_item_size) { m_col_chars[c] = i_item_size; }
			}
		}
	}
}

void SFillCtrl::SetTextEdit()
{
	std_string sz_text;
	for (int r = 0; r < m_rows.size(); r++)
	{
		std::vector<std_string>& row = m_rows[r];

		for (int c = 0; c < row.size(); c++)
		{
			AddTextItem(sz_text, row[c].c_str(), row[c].size(), m_col_chars[c]);
		}
		sz_text.append("\r\n");
	}
	m_p_ctrls->SendMes((char*)m_sz_edit.c_str(), WM_SETTEXT, (WPARAM)0, (LPARAM)sz_text.c_str());
}

void SFillCtrl::AddTextItem(std_string& sz_text, const char *sz_item, int i_size_item, int i_size_item_max)
{
	int i_delta = i_size_item_max - i_size_item;
	if (i_delta)
	{
		for (int i = 0; i < i_delta; i++) { sz_text.append(" "); }
	}

	FILE *fo = fopen("C:\\transman\\SFillCtrl_AddTextItem.txt", "wb");
	if (fo) { fprintf(fo, "%s", sz_text.c_str()); fclose(fo); }

	sz_text.append(sz_item);
	sz_text.append("|"); //devider
}