#include <memory.h>
#include <time.h>
#include "keyb.h"

const int ci_time_delta = 150;  //YUIL milicec

CKeyb::CKeyb() {} /*m_fInit=false;m_fInit=true;*/

void CKeyb::Clear() { memset(this, 0, sizeof(CKeyb)); }

void CKeyb::Read()
{
	BYTE baKey[ci_max_key];

	//BOOL fGetKey = GetKeyboardState(baKey);
	for (int i = 0; i < ci_max_key; i++)
	{
		baKey[i]= GetKeyState(i);
	}
	
	ClearEventDown();

	if (m_fKeybReaded)
	{

		//��� ������ ������� ���������
		for (int i = 0; i < ci_max_key; i++)
		{
			if (m_baKey[i] != baKey[i] && baKey[i])                    // 
			{                                              //if (i == VK_LBUTTON) { int k = 0;k++;}
				int time_cur = clock(); //YUIL milisec

				int& time_prev = m_delta_time[i];

				if (time_prev == 0 || time_cur - time_prev > ci_time_delta)
				{
					SetEventDown(i); //if (baKey[i]) {  } //YUIL ��������� �������

					time_prev = time_cur;
				}				
			}
		}
	}
	else
	{
		m_fKeybReaded=true;
	}

	memcpy(m_baKey, baKey, ci_max_key * sizeof(BYTE));
}

void CKeyb::ClearEventDown()
{
	memset(m_eventDown, 0, ci_max_part_event*sizeof(unsigned int));
}

void CKeyb::GetEventDownPart(int iKey, int& i_part, int& iPosInPart)
{
	int iSizePart = sizeof(unsigned int) * ci_bits_in_byte;

	i_part = iKey / iSizePart;

	iPosInPart = iKey - i_part * iSizePart;
	
}

void CKeyb::SetEventDown(int iKey)
{
	int i_part;
	
	int iPosInPart;

	GetEventDownPart(iKey, i_part, iPosInPart);
	
	m_eventDown[i_part] |= 1 << iPosInPart;
}

bool CKeyb::GetEventDown(int iKey)
{
	int i_part;

	int iPosInPart;

	GetEventDownPart(iKey, i_part, iPosInPart);

	bool f_true = m_eventDown[i_part] & (1 << iPosInPart);

	return  f_true;
}

bool CKeyb::GetEventDown_2(int *iKey)
{
	int i_part[ci_pair_key];

	int iPosInPart[ci_pair_key];
	
	for (int i = 0; i < ci_pair_key; i++)
	{
		GetEventDownPart(iKey[i], i_part[i], iPosInPart[i]);

		if (m_eventDown[i_part[i]] & (1 << iPosInPart[i]) == false) { return false; }
	}	

	return true;
}