#ifndef _draw_data_h_
#define _draw_data_h_

#include  <vector>
#include  <string.h>
#include "point.h"
#include "DrawObjectBase.h"
#include "..\\transman_srv\\std_str.h"
#include "MSSQL.h"

const long cl_info_color_back = 0xFFFFFF;

const long cl_info_color = 0xFF0000;

const long cl_panel_border_color = 0x555555;

const long cl_panel_color = 0xEFEFEF; //0xE0E0E0

const long cl_max_zone_points = 4;

/*
const long cl_panel_y = 80;

const long cl_panel_h = 80;

const long cl_panel_no_expand_w = 40;

const long cl_panel_expand_w = 200;

const long cl_panel_ident = 11;
*/

typedef enum
{
	EPB_PEN_CENTER = 0,

	EPB_PEN_SEL,

	EPB_PEN_ROUTE_POINT,
	
	EPB_PEN_ROUTE_LINE,

	EPB_BRUSH_ROUTE_POINT,

	EPB_PEN_STOP,

	EPB_BRUSH_STOP,  //EPB_PEN_PANEL_BORDER,EPB_BRUSH_PANEL,

	EPB_PEN_CHECK_POINT,

	EPB_BRUSH_CHECK_POINT,

	EPB_PEN_CAR,

	EPB_PEN_CAR_LIGHT,

	EPB_BRUSH_CAR,

	EPB_BRUSH_CAR_LIGHT,

	EPB_PEN_ZONE,

	EPB_BRUSH_ZONE,

	EPB_PEN_ZONE_NEW,

	EPB_BRUSH_ZONE_NEW,

	EPB_PEN_ANSWER_USER,
	
	EPB_BRUSH_ANSWER_USER,

	EPB_PEN_TROL,

	EPB_BRUSH_TROL,

	EPB_PEN_BUS,

	EPB_BRUSH_BUS,

	EPB_PEN_TRAM,

	EPB_BRUSH_TRAM,

	EPB_PEN_MINIBUS,

	EPB_BRUSH_MINIBUS,

	EPB_PEN_LIM_MOB,

	EPB_BRUSH_LIM_MOB,

	EPB_QUNATITY,
}EPenBrush;

/*
struct SPointInt
{
	SPointInt();
	int y;
	int x;

	SPointInt(int xNew, int yNew) { Set(xNew, yNew); }

	void Set(int xNew, int yNew) { x = xNew; y = yNew; }

	void SetByLatLng(const Leaflet::LatLng& latlng, double zoom);
};*/

struct SRoute
{
	long id_picas_route;
	std_string route_id;
	std_string agency_id;
	std_string route_short_name;
	std_string route_long_name;
	std_string route_type;
	bool f_check_points; //YUIL 2017-12-07
	int id_agent; //YUIL 2017-01-31
};

struct SStop
{
	SStop() {}
	std_string id_picas_stop;
	std_string stop_id;
	std_string stop_name;
	Leaflet::LatLng latlng;
	bool f_check_point; //YUIL 2017-01-22

	//calc
	SPointInt point;
};

struct SShapeLine
{
	std_string route_long_name;
	Leaflet::LatLng from;
	long from_sequence;
	Leaflet::LatLng to;
	long to_sequence;
	bool direct; 
	std_string route_short_name;

	//calc
	SPointInt from_point;
	SPointInt to_point;

	void Clear();
};

struct SHideRect
{
	SPointInt point;
	SPointInt size;
	SHideRect() {} //int x, int y, int w, int h) { point.Set(x, y);  size.Set(w, h); }
	void Set(int x, int y, int w, int h) { point.Set(x, y);  size.Set(w, h); }
};

/*
struct SControlPanel
{
	bool f_expand;
	SPointInt point;
	SPointInt size;
	void Draw(HDC hdc, HGDIOBJ *pen_brush);
	void SetByExpand(RECT& rcWnd);
	bool In(const SPointInt& point_new,  RECT& rcWnd);
};
*/

/*struct SPointInterest
{
	std_string name;
	Leaflet::LatLng latlng;

	//calc
	SPointInt point;
};*/

struct SZone
{
	std_string name;
	int quantity; 
	Leaflet::LatLng latlng_list[cl_max_zone_points]; //std::vector<SPointInterest> point_list;
	SPointInt point_list[cl_max_zone_points]; //std::vector<SPointInterest> point_list;

	void Draw(HDC hdc, const SPointInt& origin, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list);

	bool AddPoint(int x, int y, double zoom);
	void Clear(); 
	void Save();
	bool FindPoint(int x, int y);
};

void DrawPoint(HDC hdc, int x, int y);
void DrawLine(HDC hdc, int x, int y, int xPrev, int yPrev);

///////////////////////////
struct SDrawData
{
	std::vector<SRoute> m_routes;
	std::vector<SStop> m_stops;
	std::vector<SShapeLine> m_shape_lines;

	std::vector<SHideRect> m_hide_rects;

	std::vector<SZone> m_zones; //YUIL ���� (��������,...)
	
	SZone m_zone_new; //YUIL ����������� ����
	
	bool m_f_sel_mes;
	bool m_f_shape_lines;

	//long m_flag_no_draw_zones;

	//SControlPanel m_control_panel;

	long m_index_sel_route; //YUIL ��������:  0 :�������  ��� , ���� ������ ���� �� ������� ������� ����� �������� ������
	long m_index_sel_stop;
	long m_index_sel_zone;

	void LoadRoutes();
	void LoadStops();
	void LoadShapeLines();
	void LoadZones();
	
	void Load(RECT& rcWnd);

	void CalcStops(double zoom);
	void CalcShapeLines(double zoom);
	void CalcZones(double zoom);

	void Calc(double zoom);

	void DrawStops(HDC hdc, const SPointInt& origin, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list, int& index_sel_stop, HGDIOBJ* pen_brush); // HPEN hpenSel);
	void DrawShapeLines(HDC hdc, const SPointInt& origin, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list, HGDIOBJ PenPoint, HGDIOBJ PenLine);// char *sel_text);  //void AddHideRect(const SHideRect& sRect);
	void DrawZones(HDC hdc, const SPointInt& origin, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list);


	static bool IsHide(int x, int y, const SPointInt& sizeWnd); //void AddHideRects(); //void Fill();void FindPrev(int index);  // long id_prev, SShape* *p_prev); // void FindNext(SShape& sShape, int indexShape);bool SelectZoneDel();
	
	bool FindZone(char *sz_name, SZone* *p_zone=0);
	void LoadStops_ADD(FldsPtr fp);
	void LoadShapeLines_ADD(FldsPtr fp);
	void LoadRoutes_ADD(FldsPtr fp);
	void LoadZones_ADD(FldsPtr fp);
	void ReadIni();

	void StopsReportToFile(char *sz_file_name);
};

#endif