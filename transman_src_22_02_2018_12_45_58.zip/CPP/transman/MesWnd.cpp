#include <memory.h>
#include <windows.h>
#include <commctrl.h>
#include <Windowsx.h>
#include "main.h"
#include "MesWnd.h"
#include "..\\transman_srv\\time_e.h" 

//const int ci_mes_wnd_ident_edit =0; //const int ci_mes_wnd_id_list =1;//const int ci_mes_wnd_id_but_clear =2;

HWND gMW_MainWnd; //long g_mes_wnd_list_hwnd;//long g_mes_wnd_but_clear;

CMesWnd::CMesWnd() {}

CMesWnd::~CMesWnd() {}

void CMesWnd::WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam)
{		
	POINT pn;

	pn.x= GET_X_LPARAM(lParam);
	pn.y= GET_Y_LPARAM(lParam);

	if (m_lb.Sel(pn)) {}
}


void CMesWnd::WM__MOUSEMOVE(WPARAM wParam, LPARAM lParam)
{
	POINT pn;

	pn.x = GET_X_LPARAM(lParam);
	pn.y = GET_Y_LPARAM(lParam);
	bool fLeft = wParam & MK_LBUTTON;

	if (fLeft)
	{
		m_lb.ScrollOp(pn); //lb_formMes.ScrollOp(pn);

		CallPaint();
	}
}

void CMesWnd::WM__MOUSEWHEEL(WPARAM wParam, LPARAM lParam)
{
	int v = (wParam >> 16) & 0xFFFF; 
	
	if (v >= 5000) { v = -1; } //65000

	POINT pn = { GET_X_LPARAM(lParam) - m_rc.left, GET_Y_LPARAM(lParam) - m_rc.top };	

	if (m_lb.InMouseWheel(pn, v))
	{
		CallPaint();
	}

	/*if (m_lb.In(pn))
	{
		if (v > 0) 
		{ 
			m_lb.DecIndexView(); 
		}
		else
		{
			m_lb.IncIndexView();
		}
		
		if (v)
		{  }
	}*/
}

///////////////////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK WindowProc_MesWnd(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	/*CMesWnd *p_this = (CMesWnd*)GetWindowLong(hwnd, GWL_USERDATA); //&gMesWnd;// 

	if (p_this == 0) { return DefWindowProc(hwnd, uMsg, wParam, lParam);}

	if (p_this->IsInit()==false) { return DefWindowProc(hwnd, uMsg, wParam, lParam);}*/

	switch (uMsg)
	{
	/*case WM_CLOSE: WMClose(hwnd, wParam, lParam); break;
	case WM_DESTROY: WMDestroy(wParam, lParam); break;
	case WM_SIZE: WMSize(wParam, lParam); break;*/
	case WM_LBUTTONDOWN: gMesWnd.WM__LBUTTONDOWN(wParam, lParam); break;
	case WM_COMMAND: gMesWnd.WM__COMMAND(wParam, lParam); break;
	case WM_MOUSEMOVE: gMesWnd.WM__MOUSEMOVE(wParam, lParam); break;
	case WM_MOUSEWHEEL: gMesWnd.WM__MOUSEWHEEL(wParam, lParam); break;		
	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 1;
}

bool CMesWnd::Create(HINSTANCE hInstance, wchar_t *wsz_app) //, HWND draw_hwnd_new)
{
	m_fInit = false;

	memset(this, 0, sizeof(CMesWnd));

	m_ident = 10;

	m_but_size=22;

	//<q1 YUIL ��������� ����
	SWindowCreateParam wcp;

	wcp.hInstance = hInstance;

	wcp.wsz_name = wsz_app;

	wcp.wndProc = WindowProc_MesWnd;

	wcp.fVisible = true;

	wcp.dwStyleEx = WS_EX_TOPMOST | WS_EX_TOOLWINDOW;

	wcp.dwStyle = WS_POPUP | WS_BORDER; // DLGFRAME;//wcp.hWndParent = draw_hwnd;

	if (g_i_user_interface==0) 
	{
	 SetFirst(wcp);
	}else
	if (g_i_user_interface==1) 
	{
		SetForI2(wcp);
	}

	if (wnd.Create(wcp) == false) { return false; }

	GetClientRect(wnd.GetHWND(), &m_rc_client);

	CrControls(hInstance);

	gMW_MainWnd = wnd.GetHWND();

	CallPaint();

	BOOL f_up = UpdateWindow(gMW_MainWnd);

	//>q1

	m_fInit = true;

	return true;
}

void CMesWnd::SetFirst(SWindowCreateParam& wcp)
{
	//1. ���������� ���������� ���� �����
	RECT rcMap;

	BOOL  fGet = GetWindowRect(g_hWndMap, &rcMap);

	if (fGet == FALSE) { return; }

	m_rc = rcMap;

	int i_ident = 1;

	m_rc.top = m_rc.bottom + i_ident;

	m_rc.bottom = m_rc.top + cl_mes_wnd_h;

	wcp.w = m_rc.right - m_rc.left;

	wcp.h = cl_mes_wnd_h;

	wcp.x = m_rc.left;

	wcp.y = m_rc.top - cl_mes_wnd_h;

	//2. �������� ����  �����
	SSizeDelta delta;

	delta.h =  - (cl_mes_wnd_h);

	CWindow::ReizeWnd(g_hWndMap, delta);

	//2. �������� ���� ���������
	CWindow::ReizeWnd(gDrawWnd.GetHWND(), delta);
}

void CMesWnd::SetForI2(SWindowCreateParam& wcp)
{
	win_e::SMonitors& sm = gMonitors;

	int index_scr = sm.i_monitor < 0 ? 1 : sm.i_monitor;

	wcp.x = sm.rc[index_scr].left;

	wcp.y = sm.rc[index_scr].bottom - cl_mes_wnd_h;

	wcp.w = sm.rc[index_scr].right - sm.rc[index_scr].left;

	wcp.h = cl_mes_wnd_h;

	m_rc.left = wcp.x;
	m_rc.top = wcp.y;
	m_rc.right = wcp.x + wcp.w;
	m_rc.bottom = wcp.y + wcp.h;

}

void CMesWnd::SetWnd_I2()
{
	SWindowCreateParam wcp;

	SetForI2(wcp);

	MoveWindow(wnd.GetHWND(), m_rc.left, m_rc.top, m_rc.right - m_rc.left, m_rc.bottom - m_rc.top, TRUE);

	GetClientRect(wnd.GetHWND(), &m_rc_client);

	Set_rc_childs();

	CallPaint(); //SendMessage(wnd.GetHWND(), WM_PAINT, 0, 0);
}

void CMesWnd::OnChMap()
{
	//1. ������ ���� ���������� 
	RECT rcMap;

	if (GetWindowRect(g_hWndMap, &rcMap) == FALSE) { return; }

	m_rc = rcMap;
	
	int i_ident = 1;

	m_rc.top = m_rc.bottom + i_ident;

	m_rc.bottom = m_rc.top + cl_mes_wnd_h;

	SetWindowPos(wnd.GetHWND(), HWND_TOP, m_rc.left, m_rc.top, m_rc.right - m_rc.left, m_rc.bottom - m_rc.top, SWP_SHOWWINDOW);

	Set_rc_childs();

	/*int x = ci_mes_wnd_ident_edit;
	int y = ci_mes_wnd_ident_edit;
	int w= m_rc_client.right - m_rc_client.left - 2*ci_mes_wnd_ident_edit - m_but_size;
	int h= m_rc_client.bottom - m_rc_client.top - 2*ci_mes_wnd_ident_edit;
	
	RECT& rc = m_lb.rc;
	rc.left = x;
	rc.top = y;
	rc.right = x + w - m_but_size;
	rc.bottom = y + h;*/ //SetWindowPos(, HWND_TOP, x, y, w - m_but_size, h, SWP_SHOWWINDOW);

	SetWindowPos(m_hwnd[EC_BUT_CLEAR], HWND_TOP, m_rc_client.right - m_ident - m_but_size, m_rc_client.top + m_ident, m_but_size, m_but_size, SWP_SHOWWINDOW);
}

void CMesWnd::Set_rc_childs()
{
	m_border.rc = m_rc_client;

	RECT rc_lb = { m_rc_client.left + m_ident, m_rc_client.top + m_ident, m_rc_client.right - m_ident - m_but_size, m_rc_client.bottom - m_ident };

	m_lb.rc = rc_lb;
}

void CMesWnd::Destroy()
{
	m_border.Close();

	m_lb.Close();

	DestroyWindow(wnd.GetHWND());
}

void CMesWnd::CallPaint()
{
	HWND hwnd = wnd.GetHWND();

	if (!hwnd) { return; }

	HDC hdc = GetDC(hwnd);

	Paint(hdc);

	ReleaseDC(hwnd, hdc);
}

void CMesWnd::Paint(HDC hdc)
{                                                                                                 //HWND hwnd = wnd.GetHWND();	//HWND hwnd = wnd.GetHWND(); //HDC hdc = GetDC(hwnd);
	Rectangle(hdc, m_rc.left, m_rc.top, m_rc.right, m_rc.bottom);  // crc.right, crc.bottom);
	
	m_border.Draw(hdc);

	HGDIOBJ* p_gdi_obj = g_sGDI_objects.h;

	m_lb.Draw(hdc, ci_height_font_edit, (HFONT)p_gdi_obj[EGDIO_FONT_EDIT]);  //ReleaseDC(hwnd, hdc);
}

int CMesWnd::GetH()
{
	RECT crc;

	BOOL  fGetRect = CWindow::GetClientRectAbs(g_hWndMap, crc); //draw_hwnd, GetWindowRect(draw_hwnd,  &rc);

	return crc.bottom - crc.top;
}

/*void CMesWnd::calc_edit_XYWH(int& x, int& y, int& w, int& h)
{
	RECT crc;

	GetClientRect(wnd.GetHWND(), &crc);

	x= ci_mes_wnd_ident_edit;
	y= ci_mes_wnd_ident_edit;
	w= crc.right - 2*ci_mes_wnd_ident_edit;
	h= crc.bottom - 2*ci_mes_wnd_ident_edit;
}*/

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void CMesWnd::CrControls(HINSTANCE hInstance)
//
{
	DWORD dwStyle = WS_CHILD | WS_BORDER | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL; // | ES_MULTILINE | ES_LEFT | ES_READONLY | ES_NOHIDESEL;
	
	/*int x = m_rc.left + m_ident;
	int	y = m_rc.top + m_ident;
	int	w= m_rc.bottomm_ident
	int	h; //calc_edit_XYWH(x, y, w, h);	*/
	
	m_border.Open(m_rc_client, m_ident);

	RECT rc_lb = { m_rc_client.left + m_ident, m_rc_client.top + m_ident, m_rc_client.right - m_ident - m_but_size, m_rc_client.bottom - m_ident };
	int h_element_new = 22;
	m_lb.Open(rc_lb, h_element_new); //m_hwnd[EC_LIST] = CreateWindowA("listbox", "", dwStyle, x, y, w - m_but_size, h, wnd.GetHWND(), (HMENU)EC_LIST, g_hInstance, 0); //InterlockedExchange(&g_mes_wnd_list_hwnd, (long)hwnd); BOOL f_up = UpdateWindow(m_hwnd[EC_LIST]);
	m_lb.m_f_text_only = true;
	m_lb.m_f_back_order = true;
	//but clear
	m_hwnd[EC_BUT_CLEAR] = CreateWindowA("button", "X", WS_CHILD | WS_VISIBLE, m_rc_client.right - m_ident - m_but_size, m_rc_client.top + m_ident, m_but_size, m_but_size, wnd.GetHWND(), (HMENU)EC_BUT_CLEAR, g_hInstance, 0); //InterlockedExchange(&g_mes_wnd_but_clear, (long)hwnd);
	
	BOOL f_up = UpdateWindow(m_hwnd[EC_BUT_CLEAR]);	

	//-probe
	/*char sz[MAX_PATH + 1];

	for (int i = 0; i < 10; i++)
	{
		sprintf(sz, "%d", i);

		m_lb.Add(sz);
	}*/
}

void CMesWnd::WM__COMMAND(WPARAM wParam, LPARAM lParam)
{                                         //DWORD idThread =GetCurrentThreadId();
	int notify= HIWORD(wParam);
	int id = LOWORD(wParam);
	HWND hwndChild = (HWND)lParam; 

	if (id== EC_BUT_CLEAR)
	{ 
		ListClear();
	}
}

void CMesWnd::ListClear()
{/*
	RECT crc;

	if (GetClientRect(gMW_MainWnd, &crc) == FALSE) { return; } //if (GetClientRect((HWND)g_mes_wnd_list_hwnd, &crc) == FALSE) { return; }

	crc.right-= m_but_size;

	DestroyWindow(m_hwnd[EC_LIST]);

	DWORD dwStyle = WS_CHILD | WS_BORDER | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL; //HWND hParent = wnd.GetHWND();

	m_hwnd[EC_LIST] = CreateWindowA("listbox", "", dwStyle, crc.left, crc.top, crc.right - crc.left, crc.bottom - crc.top, gMW_MainWnd, (HMENU)EC_LIST, g_hInstance, 0);

	if (m_hwnd[EC_LIST] == 0)
	{
		char sz_buf[MAX_PATH + 1];
		sprintf(sz_buf, "GetLastError=%d", GetLastError());
		MessageBoxA(0, sz_buf,"err",0);
		return;
	} */                                                        //InterlockedExchange(&g_mes_wnd_list_hwnd, (long)hwnd);

	m_lb.list.clear(); //SendMessage(m_hwnd[EC_LIST], LB_RESETCONTENT, 0, 0); //int q= SendMessage(m_hwnd[EC_LIST], LB_GETCOUNT, 0, 0); //Mes("Mes after del = %d", q);//UpdateWindow(m_hwnd[EC_LIST]); UpdateWindow(wnd.GetHWND());

	CallPaint();
}

/*void CMesWnd::CallPaint()
{
	HWND hwnd = wnd.GetHWND();

	if (!hwnd) { return; }

	HDC hdc = GetDC(hwnd);

	Paint(hdc);

	ReleaseDC(hwnd, hdc);
}*/

void CMesWnd::Mes(char *szFormat, ...)
{                 
	va_list va;

	va_start(va, szFormat);  //int len = _vscprintf(szFormat, va);

	char buf [MAX_PATH + 1];//len + strlen(g_szmapp)+ ci_time_len +2 if (buf == 0) { return; }

	memset(buf, 0, MAX_PATH + 1);

	time_e::LocalTimeToText(buf, MAX_PATH);

	strcat(buf,  " ");

	int i_len_buf = strlen(buf);

	vsprintf(buf + i_len_buf, szFormat, va); //HWND hwnd = m_hwnd[EC_LIST]; //SendMessageA(hwnd, LB_ADDSTRING, 0, (LPARAM)buf); int q_item = SendMessageA(hwnd, LB_GETCOUNT, 0, (LPARAM)buf); SendMessageA(hwnd, LB_SETCARETINDEX, (WPARAM)q_item-1, (LPARAM)FALSE);

	m_lb.Add(buf);

	CallPaint();

	Log(buf);
}

void CMesWnd::Log(char *sz_new)
{
	static bool fStart = false;
	const char *csz_log_file = "c:\\transman\\log.txt";

	if (fStart == false)
	{
		unlink(csz_log_file);
		fStart = true;
	}

	FILE *fo = fopen(csz_log_file, "ab");
	if (fo)
	{
		fprintf(fo,"%s\r\n", sz_new);
		fclose(fo);
	}
}

void CMesWnd::MesB(char *szFormat, ...)
{                 
	va_list va;

	va_start(va, szFormat);  //int len = _vscprintf(szFormat, va);

	char buf [MAX_PATH + 1];//len + strlen(g_szmapp)+ ci_time_len +2 if (buf == 0) { return; }

	memset(buf, 0, MAX_PATH + 1);

	vsprintf(buf, szFormat, va); //HWND hwnd = m_hwnd[EC_LIST]; SendMessageA(hwnd, LB_ADDSTRING, 0, (LPARAM)buf); int q_item = SendMessageA(hwnd, LB_GETCOUNT, 0, (LPARAM)buf); SendMessageA(hwnd, LB_SETCARETINDEX, (WPARAM)q_item-1, (LPARAM)FALSE);

	m_lb.Add(buf);

	CallPaint();
}

CMesWnd gMesWnd;