#include <memory.h>
#include "main.h"
#include "Map.h"

#include "BookMarks.h"
#include "login_wnd.h"
#include "MesWnd.h"
#include <commctrl.h>
#include "..\\transman_srv\\time_e.h"
#include "win_e.h"
#include "FormMes.h"  


void CMap_FN_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesWnd.Mes("CMap_MSSQL_MES_ERR(). ������ MS SQL: %s", sz_text);
	
}

void CMap_fill_combo_car_agent_add(void *p_param, FldsPtr fp)
{
	CMap* p_this = (CMap*)p_param;

	if (p_this) { p_this->fill_combo_car_agent_add(fp); }
}

void CMap::fill_combo_car_agent_add(FldsPtr fp)
{
	_bstr_t bstr_name(fp->Item["name"]->Value);
	VARIANT v_id_agent = fp->Item["id_agent"]->Value;	

	static bool fStart = false;
	
	if (fStart == false)
	{
		m_ctrls.AddToList("combo_car_agent", "���"); //m_ctrls.SendMes("combo_car_agent", CB_ADDSTRING, 0, (WPARAM)"���");
		m_ctrls.AddToList("combo_car_agent", "���������"); //m_ctrls.SendMes("combo_car_agent", CB_ADDSTRING, 0, (WPARAM)"");
	}

	fStart = true;

	m_ctrls.AddToList("combo_car_agent", (char*)bstr_name);
	m_id_agent_list.push_back(v_id_agent.decVal.Lo32);
}

void CMap::fill_combo_car_agent()
{                                            //char sz_val[MAX_PATH + 1]; std_string sz_query = "select name from dbo.picas_agents where id_agent IN (select DISTINCT id_Agent from dbo.ate_3)";
	SCtrl *pCtrl;

	m_ctrls.ClearList("combo_car_agent", &pCtrl); //SendMes("combo_car_agent", CB_RESETCONTENT, 0, 0);

	m_id_agent_list.clear();
	
	const int ci_max = 1024;

	char sz_query[ci_max + 1]; 
	
	set_str(sz_query, ci_max, "select id_agent, name from dbo.picas_agents");

	EUserType eUserType = gLoginWnd.GetUserType();

	if (eUserType == EUT_DISP)
	{
		add_str(sz_query, ci_max, " WHERE id IN (SELECT agency_id FROM dbo.picas_routes r, dbo.user_route_binds urb WHERE r.id_picas_route=urb.id_picas_route AND urb.id_user=");
		
		add_str(sz_query, ci_max, (char*)gLoginWnd.GetIdUser().c_str());

		add_str(sz_query, ci_max, ")");
	}

	bool fExec = MSSQL_Exec(sz_query, CMap_fill_combo_car_agent_add, CMap_FN_MSSQL_MES_ERR, this); //(char*)sz_query.c_str()
	if (fExec)
	{
		m_ctrls.SelByIndex("combo_car_agent", 0); // m_ctrls.SendMes("combo_car_agent", CB_SETCURSEL, 0, 0);
	}
}

////////////////////////////////
// read mes
//����� ��������� ������ ���������

void CMap_ShowMes_add(void *p_param, FldsPtr fp)
{
	CMap* p_this = (CMap*)p_param;

	if (p_this) { p_this->ShowMes_add(fp); }
}

void CMap::ShowMes_add(FldsPtr fp)
{
	_bstr_t bstr_dt_create(fp->Item["dt_create"]->Value);
	_bstr_t bstr_user_from(fp->Item["user_from"]->Value);
	_bstr_t bstr_user_to(fp->Item["user_to"]->Value);
	_bstr_t bstr_mes(fp->Item["mes"]->Value);
	VARIANT v_id_chat_mes_type = fp->Item["id_chat_mes_type"]->Value; //VARIANT v_id_chat_mes_head = fp->Item["id_chat_mes_head"]->Value;
	_bstr_t bstr_garage_num(fp->Item["garage_num"]->Value);
	
	SCtrl* p_ctrl;
	if (m_ctrls.Find("list_mes", &p_ctrl))
	{
		if (p_ctrl->p_obj)
		{
			win_e::SListBox* p_list = (win_e::SListBox*)p_ctrl->p_obj;

			if (p_list)
			{
				win_e::SListBoxItem sItem;   //"���� � �����#�����������#����������#��������#�����#"
				sItem.sz_text = (char*)bstr_dt_create;
				sItem.sz_text.append("#");
				sItem.sz_text.append((char*)bstr_user_from);
				sItem.sz_text.append("#");
				sItem.sz_text.append((char*)bstr_user_to);
				sItem.sz_text.append("#");
				sItem.sz_text.append((char*)bstr_garage_num);
				sItem.sz_text.append("#");
				sItem.sz_text.append((char*)bstr_mes);
				sItem.sz_text.append("#");

				p_list->Add(sItem);
			}
		}
	}


	/*char sz_val[MAX_PATH + 1];

	sprintf(sz_val, "%s | ", (char*)bstr_dt_create);

	m_ctrls.AddToList("list_mes", sz_val);*/
}

void CMap::ReadMes()
{                                     //char sz_val[MAX_PATH + 1];
	if (m_f_readMes == false) { return; }

	SCtrl *pCtrl;

	m_ctrls.ClearList("list_mes",  &pCtrl);

	char sz_query[MAX_PATH + 1] = {0};

	set_str(sz_query, MAX_PATH, "EXEC ");

	add_str(sz_query, MAX_PATH, gLoginWnd.GetUserType() == EUT_DISP_HI ? "dbo.P_view_mes_by_type_all" : "dbo.P_view_mes_by_type");

	add_str(sz_query, MAX_PATH, " @id_user=");
	
	add_str(sz_query, MAX_PATH, (char*)gLoginWnd.GetIdUser().c_str()); 
	
	add_str(sz_query, MAX_PATH, ", @id_user_type_to=4"); //��� : ��������

	bool f_exec = MSSQL_Exec(sz_query, CMap_ShowMes_add, CMap_FN_MSSQL_MES_ERR, this); //if (f_exec){}//gMesWnd.Mes("��������� � �������� ���");

	if (f_exec)
	{
		//LPARAM lParam = pCtrl->x + ((pCtrl->y)<<16);
		//The low - order word specifies the x - coordinate of the cursor.The coordinate is relative to the upper - left corner of the client area.
		//The high - order word specifies the y - coordinate of the cursor.The coordinate is relative to the upper - left corner of the client area.

		//PostMessageA(m_ctrls.m_param.hwndParent, WM_LBUTTONDOWN, 0, lParam); // CallPaint();//SendDlgItemMessage(m_ctrls.m_param.hwndParent, pCtrl->id, LB_ADDSTRING, 0, 0); // CallPaint();
		CallPaint();
	}
}
