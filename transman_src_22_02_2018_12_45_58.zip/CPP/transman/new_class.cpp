#include <memory.h>
#include "new.h"

CNew::CNew()
{
	memset(this, 0, sizeof(CNew));
	
	m_fInit=true;
}

CNew::~CNew()
{
	
}
