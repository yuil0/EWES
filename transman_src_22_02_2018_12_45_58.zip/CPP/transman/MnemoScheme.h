#ifndef _MnemoScheme_h_
#define _MnemoScheme_h_

#include <windows.h>
#include "..\\util\\winctrl.h"
#include "MSSQL.h"
#include "draw_data.h"

typedef enum
{
	EMSGDIO_PEN_WHITE,
	EMSGDIO_PEN_GROUND,
	EMSGDIO_BRUSH_GROUND,
	EMSGDIO_PEN_BLACK,
	EMSGDIO_PEN_SEL_FRAME,
	EMSGDIO_BRUSH_SEL_FRAME,
	EMSGDIO_BRUSH_STOP_BORD,
	EMSGDIO_BRUSH_STOP_IN,
	EMSGDIO_FONT_STOP,
	EMSGDIO_FONT,
	EMSGDIO_FONT_MINI,
	EMSGDIO_BRUSH_PATH_AB_UP,
	EMSGDIO_BRUSH_PATH_BA_DOWN,
	EMSGDIO_BRUSH_SEL_ROUTE_IN,
	EMSGDIO_BRUSH_CONTROL_POINT_BORD,
	EMSGDIO_BRUSH_WHITE,
	EMSGDIO_BITMAP_BUS,
	EMSGDIO_STOP_A,
	EMSGDIO_STOP_B,
	//
	EMSGDIO_QUANTITY,
}EMnemoSchemeGDIObject;

typedef enum
{
	EMSMI_SHOW_RECT=0,
	//
	EMSMI_QUANTITY,
}EMnemoSchemeMenuItem;

struct SMnemoSchemeParam
{
	long color_path_AB_up; //61BA2F
	long color_path_BA_down; // = BGR = 93 159 254 HEX = 5D9FFE
	long color_stop_bord; // = BGR = 189 111 10 HEX = BD6F0A
	long color_stop_in; // ��������� ����� = BGR = 106 249 252 HEX = 6AF9FC
	long color_check_point_bord;  //�� ���� ���� = BGR = 239 222 196  HEX = EFDEC4
	long color_sel_route_in; //��������� ������� ������ = BGR = 232 227 228 HEX = E8E3E4

	int stop_size; // ��������� ������ ������� = 929 - 677 = 252
	int stop_bord_thick;  //��������� ������ ������� = 677 - 697 = 20
	int check_point_size; // �� ������� = 877 - 749 = 128
	int check_point_thick; // �� ������� ������� = 769 - 749 = 20
	//�� ������� = �� �������

	int path_thick; // ������� ���� = 765 - 863 = 98
	//
	int iFontStop_h;
	int iFont_h;
	int iFontMini_h;
	//
	int rad_stop;
	int rad_car;
	int rad_car_in;
	void Init();
};

struct SMnemoCheckPointRow
{
	std_string name;
	int i_order;
};

struct SMnemoCheckPointRows
{
	std::vector<SMnemoCheckPointRow> list;

	void add(FldsPtr fp);

	int GetMaxOrder(SMnemoCheckPointRow* *p_check_point=0);
};

struct SMnemoPlace
{
	bool f_forward;
	int i_order;
};

struct SMnemoPlaceCount : SMnemoPlace
{
	int q;
};

struct SMnemoCar
{	
	int i_event;
	bool f_forward;
	int i_order; 
	int id_ate_3;
	std_string stop_name;
	int time_minutes;
	std_string garage_num;	

	//-------------------
	bool f_next;

	typedef enum
	{
		EA_ONE_ORDER=0,
		EA_EASY_NEAR,
	}EAlg;

	struct SNext
	{
		int index;
		int d_minutes;
		EAlg eAlg;
	};
	
	SNext s_next; //int index_prev;int d_minutes;
	//-----------------------------------
	POINT pn;
	POINT pn_next;
	bool GetDrawTrianLeft();	//bool OrderOnStop();
};

struct SMnemoCarLast
{
	int index_last;
	int i_event;
	int id_ate_3;
	int i_place_order; //����� ��� �� ���� �����
	int q_place; //���� �� ���� �����
};

struct SMnemoCars
{
	std::vector<SMnemoCar> list;
	std::vector<SMnemoCarLast> list_last;	
	std::vector<SMnemoPlaceCount> place_count;

	void Clear() { list.clear(); list_last.clear(); }

	void add(FldsPtr fp);

	bool FindLast(int id_ate_3, SMnemoCarLast* *p_car);
	void AddLast(int index_last_new, int i_event_new, int id_ate_3_new);
	void SortLast();
	bool FindLastByGarageNum(char *garage_num, int& index_last); 
	void AddPlaceCount(SMnemoCarLast& oLast, SMnemoCar& o);
	bool FindPlaceCount(bool f_forward, int i_order, int& index);
	void set_q_place();
};

struct SDrawPoint
{
	POINT pn;

	int i_order; //void Set(POINT& pn_new, int i_order_new) { pn = pn_new; i_order = i_order_new; }
};

struct SDrawPointAdder
{
	bool fForward;
	std::vector<SDrawPoint>* p_list;
	int i_order;

	SDrawPointAdder(bool fForward_new, std::vector<SDrawPoint>* p_list_new, int i_order_max);
	void add(int x, int y);
};

///////////////////////////////////////////////////////////////////////
class CMnemoScheme
//
{	
	typedef enum
	{
		ECPV_PLACE = 0,
		ECPV_LEGEND,
	}ECheckPointNameView;

	bool m_fInit;
	SMnemoCheckPointRows m_list_check_point_AB;
	SMnemoCheckPointRows m_list_check_point_BA;
	SMnemoCars m_mnemoCars;
	void fill_combo_route();
	POINT m_wnd_size;
	CWinCtrl m_ctrls;
	SRoute m_route;
	int err_id_picas_route;
	HGDIOBJ m_gdi_obj[EMSGDIO_QUANTITY]; //HMENU  m_menu;
	int m_q_menu_item;
	HWND m_hwnd;
	int m_i_menu_item_view_rect;
	bool m_fShowRect;
	SMnemoSchemeParam m_param;

	struct SPaint
	{
		RECT rc;
		int w, h;
		void Init(POINT& m_wnd_size, int i_ctrls_StatMaxY);
	};

	struct SPath
	{
		RECT rc;
		int hr;
		RECT irc;
		RECT �enter_rc; //center  line
		int radi;
		int ihr;
		int i_�enter_rad;
		int i_�enter_rad_axe_prj; //�������� �� ���
		void Init(int w, int h);
		void DrawPath(HDC hdc, HGDIOBJ* gdi_obj);
	};

	SPaint m_paint;
	SPath m_path;
	POINT m_bitmap_stop_size;

	ECheckPointNameView m_eCheckPointNameView;

	void LoadIni();
	void cr_m_gdi_obj();
	void del_m_gdi_obj();
	void PaintOp(HDC hdc, int w, int h, int i_mode=0); //void CrContextMenu(); //void TrackContextMenu(POINT& pn);
	void DrawGround(HDC hdc, int w, int h);
	void FloodPath(HDC hdc); //void SetFont(HDC hdc, char *fontName, long nFontSize, bool  fBold, HFONT& hFont);
	void CrFonts(HDC hdc);
	void EnumFonts(HDC hdc);
	void DrawStop(HDC hdc, bool f_A); // , char *sz_text);
	void DrawStopOp(POINT c, HDC hdc, bool f_A); //, char *sz_text);
	void FloodPathDown(HDC hdc);
	void DrawSelRouteIn(HDC hdc);
	void Text_Out(HDC hdc, POINT& c, char *sz_text, HFONT hfont, int font_h);
	
	struct SDrawLabelBitmap
	{
		HBITMAP h;
		POINT size;
	};

	void DrawLabel(HDC hdc, POINT pn, POINT shift, HBRUSH hbrushBackGround, HPEN hpenEraser, HFONT hfont, int h_font, SDrawLabelBitmap* p_bitmap, std::vector<std_string>& text_list); // char *szFormat, ...);
	void CalcShift_Text_Out(char *sz_text, int font_h, POINT& shift, int* piLenText=0);
	void Text_OutB(HDC hdc, POINT c, char *sz_text, HFONT hfont, int iLenText);
	void fill_by_sel_combo_route();

	void DrawCheckPoint(HDC hdc, POINT& pn);
	
	void AddToDrawPointList(bool fForward, std::vector<SDrawPoint>& list, int x, int y, int& i_order);
	bool GetDrawPointsCheckPoints(bool fForward, std::vector<SDrawPoint>& list);
	bool FindInDrawPoints(std::vector<SDrawPoint>& list, int i_order, SDrawPoint* *pDrawPoint=0);

	void combo_route_SELCHANGE();
	void DrawCheckPoints(HDC hdc, bool fForward, std::vector<SMnemoCheckPointRow>& list_check_point);
	void fill_by_sel_combo_route_BA();
	void DrawCars(HDC hdc);
	void DrawCar(HDC hdc, POINT& pn, bool fLeft=true);
	void PlaceCars();
	bool LoadCheckPointEventsFromDB();
	void GetDrawPointStop(bool f_A, POINT& pn);
	bool CalcPoints();
	bool CalcPoint(SMnemoCar& o);
	bool GetNextPlace(SMnemoCar& o, SMnemoPlace& next_place); //POINT GetPointShift(SMnemoCar& o);
	bool CalcPointOp(SMnemoPlace& place, POINT& pn, POINT& pn_next);
	void DrawCheckPointFrames(HDC hdc);
	void DrawCheckPointFrame(HDC hdc, POINT& pn, char* sz_text);
	void DrawCheckPointFramesOp(HDC hdc, SMnemoCheckPointRows& list_check_point, bool f_forward);
	void DrawCarFrames(HDC hdc);
	void DrawCarFrame(HDC hdc, POINT& pn, std::vector<std_string>& text_list, bool fSel, POINT& shift, EMnemoSchemeGDIObject eFont= EMSGDIO_FONT);
	void FindNearNextCar(int indexLast, SMnemoCarLast& oLast, SMnemoCar& o); // SMnemoCar& s_car);
	void ReportAboutCalcPrevToFile();
	void fill_combo_car();
	void DrawCarA(HDC hdc, int index);
	void DrawCarFrameA(HDC hdc, int i, bool fSel);
	void DrawLegend(HDC hdc, int w);
	void FillMnemoPlaceNext(SMnemoPlace& place, SMnemoPlace& next);
	void Calc_Point(SMnemoPlace& place, POINT& pn);
	void CalcDrawPoint(POINT& pn, POINT& pn_next, int i_place_order, int q_place, POINT& pn_calc);
	void CalcShiftDraw(POINT& pn, POINT& pn_next, POINT& shift);
	void CalcDrawPoint_AB(POINT& pn, POINT& pn_next, int i_place_order, int q_place, POINT& pn_calc);
	void CheckCalcedPoint(POINT& pn);
	int GetMaxOrder(bool f_forward, SMnemoCheckPointRow* *p_check_point=0);
	char* GetCheckPointName(bool f_forward, SMnemoCheckPointRow& o, char* sz_name); //std_string&
	void DrawCheckPointList(HDC hdc, int start_x, int start_y, int step_y, int w); //void GetMaxOrderName(bool f_forward, std_string& sz_name);
	void DrawCheckPointListOp(bool f_forward, HDC hdc, int start_x, int start_y, int step_yhfont, int& index, int w);
	public:
	CMnemoScheme();
	~CMnemoScheme();
	bool Open(HINSTANCE hInstance, HWND hwndParent, int w, int h);
	void Close();
	void CrControls(HINSTANCE hInstance, HWND hwndParent);
	void Show(bool fShow);
	void OnCmd(int id, int notify);
	void Paint(HDC hdc, int i_mode=0); //i_mode: 1:ground_only
	void WM__RBUTTONDOWN(POINT& pn);
	void CallPaint();
	CWinCtrl& GetCtrls() { return (CWinCtrl&)m_ctrls; }
};


#endif