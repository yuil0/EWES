#include <memory.h>
#include <windows.h>
#include "ini_file.h"
#include <fcntl.h>
#include <io.h>
#include <sys/stat.h>

CIniFile::CIniFile() //char *sz_file)
{
	m_fInit=false;
	
	memset(this, 0, sizeof(CIniFile));

	//m_sz_file= sz_file;
	
	m_fInit=true;
}

CIniFile::~CIniFile()
{
	
}

bool CIniFile::Get(char *sz_file, char *sz_param, char *sz_value, long l_max_value, FN_INI_READ fn_read, void *p_param)
{
	int fi = open(sz_file, O_RDONLY|O_BINARY);
	if (fi < 0) { return false; }
	long len = filelength(fi);

	bool f_res = false;
	if (len)
	{
		char *buf = new char[len + 1];
		if (buf)
		{
			memset(buf, 0, len + 1);
			long i_readed = read(fi, buf, len);
			if (i_readed == len)
			{				
				f_res = GetFromBuf(buf, len,  sz_param, sz_value, l_max_value, fn_read, p_param);
			}
			delete buf;
		}
	}

	close(fi);
	return f_res;
}

bool CIniFile::GetFromBuf(char *buf, long len, char *sz_param, char *sz_value, long l_max_value, FN_INI_READ fn_read, void *p_param)
{
	const long cl_max_devider = 4;
	char sz_devider[cl_max_devider] = { 13,10,':',0 };
	
	bool f_found_param=false;

	long l_pos = 0;
	long l_pos_param;
	bool f_param = true;
	bool f_found = false;
	
	bool f_colon = false;
	
	bool fComment = false;

	for (long i = 0; (sz_param==0 || f_found == false) && i < len; i++)
	{

		bool f_devider = strchr(sz_devider, buf[i]);
		
		if (buf[i] == 13 || buf[i] == 10) 
		{
			f_colon = false; if (fComment) { fComment = false; l_pos = i + 1; }
		}
		else
		if (buf[i] == ':') 
		{ 
			if (f_colon == false) { f_colon = true; }
			else
			{
				f_devider = false;
			}
		}

		if (fComment == false)
		{
			if (i == 0)
			{
				if (buf[i] == '/' && buf[i + 1] == '/') 
				{ fComment = true; i += 2;  continue; }
			}
			/*else
			{
				if (i + 2 < len)
				{
					if (buf[i + 1] == '/' && buf[i + 2] == '/') 
					{ fComment = true; }
				}
			}*/
		}
		else 
		{ continue; }

		bool fLast = i + 1 == len; // || fComment ? true : false;

		if (f_devider || fLast)
		{
			long l_size = i-l_pos;

			bool f_last = f_devider == false && fLast;

			if (f_last) { l_size++; }

			/*if (l_size < 0) 
			{
				int k = 0;
				k++;
			}else*/
			if (l_size>0)
			{
				char ch_save;

				if (f_last == false) { ch_save = buf[i]; buf[i] = 0; }
				
				char *p = buf + l_pos;

				if (f_param) 
				{
					if (sz_param) 
					{ 						
						if (!stricmp(p, sz_param)) 
						{ f_found_param = true; } 
					}
					else
					{ 
						f_found_param = true; 
						l_pos_param = l_pos;
					}

					f_param = false;
				}
				else
				{
					if (f_found_param) 
					{ 
						if (sz_value)
						{
							if (l_size > l_max_value) { l_size = l_max_value; }

							memcpy(sz_value, buf + l_pos, l_size); sz_value[l_size] = 0;
							
						}

						if (fn_read)
						{
							char ch_save_param = buf[l_pos - 1]; buf[l_pos - 1]=0;

							char *p_data= buf + l_pos_param;

							(fn_read)(p_param, p_data, buf + l_pos);

							buf[l_pos - 1] = ch_save_param;
						}	

						f_found = true;
					}
					f_param = true;
				}

				if (f_last == false) { buf[i] = ch_save; }
			}
			l_pos = i + 1;
		}
	}

	return f_found;
}

void CIniFile_FN_INI_READ(void *p_param, char *sz_param, char *sz_val)
{
	CIniFile::SGet *p_this= (CIniFile::SGet *)p_param;

	p_this->Add(sz_param, sz_val);
}

void CIniFile::SGet::Add(char* sz_param, char *sz_val)
{
	SParamVal o;

	bool fFound=Find(sz_param);

	if (fFound) {return;}

	o.param=sz_param;
	o.val=sz_val;

	list.push_back(o);
}

bool CIniFile::SGet::Find(char* sz_param, SParamVal* *pItem)
{
	bool fFound=false;

	for (int i=0; fFound==false && i<list.size(); i++)
	{
		SParamVal& o=list[i];

		if (!stricmp(sz_param, o.param.c_str())) {fFound=true; if (pItem) {*pItem=&o;} }
	}

	return fFound;
}

bool CIniFile::SGet::Save(char *sz_file)
{
	char sz_copy_file[MAX_PATH + 1]; 
	
	strcpy(sz_copy_file, sz_file); 
	
	strcat(sz_copy_file, ".copy");

	FILE *fo = 0;
	
	fopen_s(&fo, sz_copy_file, "wb");

	if (fo==0) {return false;}	

	for (int i=0; i<list.size(); i++)
	{
		SParamVal& o=list[i];

		fprintf(fo, "%s:%s\r\n",  o.param.c_str(), o.val.c_str());
	}
	
	fclose(fo);

	CopyFileA(sz_copy_file, (const char*)sz_file, FALSE);

	unlink(sz_copy_file);

	return true;
}

bool CIniFile::Set(char *sz_file, char *sz_param, char *sz_value, long l_max_value)
{
	SGet s_get;

	s_get.list.clear();

	Get(sz_file, 0, 0, l_max_value, CIniFile_FN_INI_READ, &s_get);

	SParamVal *pItem;

	bool fFound = s_get.Find(sz_param, &pItem);

	if (fFound)
	{
		pItem->val=sz_value;
	}
	else
	{
		s_get.Add(sz_param, sz_value);
	}

	bool fSave= s_get.Save(sz_file);

	return fSave;
}