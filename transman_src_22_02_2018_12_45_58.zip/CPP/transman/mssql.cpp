#include <memory.h>
#include <windows.h>
#include "MSSQL.h"
#include "ini_file.h"

bool MSSQL_Exec(char *sz_cmd, FN_MSSQL_ADD fn_add, FN_MSSQL_MES_ERR fn_mes_err, void *p_param, char * sz_con_name, int *p_i_rec_aff, bool f_query_in_err, FN_MSSQL_END fn_end, FN_MSSQL_CON_STR fn_con_str) //, int* p_err)
{
	HRESULT hr;

	ConPtr con;

	bool fRes = false;		
	
	EMSSQLState eState = EMSSQLS_START;

	try
	{                                //AddTextToFile("MSSQL_Exec(). 1.\r\n");		
		//open
		hr = CoInitialize(0); //AddTextToFile("MSSQL_Exec(). 3.");

		hr = con.CreateInstance(__uuidof(ADODB::Connection));  //AddTextToFile("MSSQL_Exec(). 5.");

		const long cl_max_value = 128;
		static char sz_con[cl_max_value + 1] = {0};

		if (sz_con[0] == 0)
		{
			CIniFile cIniFile;

			if (cIniFile.Get("C:\\transman\\transman.ini", sz_con_name, sz_con, cl_max_value) == false) { return false; }

			if (fn_con_str) { (fn_con_str)(p_param, sz_con); }
		}		

		wchar_t* sz_user = 0;

		wchar_t* sz_pwd = 0;

		con->ConnectionTimeout = 5; //AddTextToFile("MSSQL_Exec(). 9.");

		if (con->Open(sz_con, sz_user, sz_pwd, NULL) != S_OK) { return false; } //AddTextToFile("MSSQL_Exec(). 11.");

		eState = EMSSQLS_CON;

		con->CommandTimeout = 0; //AddTextToFile("MSSQL_Exec(). 13.");

		//exec
		const int adCmdText = 1; const int adExecuteNoRecords = 0x80; //_bstr_t bstr(sz_cmd);

		long Options = adCmdText; 
		
		if (fn_add==0) { Options |= adExecuteNoRecords; }

		VARIANT recAff;

		recAff.vt = VT_INT;

		RecPtr rec = con->Execute(sz_cmd, &recAff, Options); //AddTextToFile("MSSQL_Exec(). 17.");

		eState = EMSSQLS_EXEC;

		if (p_i_rec_aff) { *p_i_rec_aff = recAff.intVal; }

		if (fn_add)
		{                                                    //AddTextToFile("MSSQL_Exec(). 19.");
			while (rec->EndOfFile == VARIANT_FALSE)
			{                                                      //AddTextToFile("MSSQL_Exec(). 21.");

				(fn_add)(p_param, rec->Fields); //AddTextToFile("MSSQL_Exec(). 23.");

				rec->MoveNext(); //AddTextToFile("MSSQL_Exec(). 25.");
			}			//AddTextToFile("MSSQL_Exec(). 27.");

			if (fn_end) { (fn_end)(p_param); } //AddTextToFile("MSSQL_Exec(). 29.");
		} //AddTextToFile("MSSQL_Exec(). 31.");

		eState = EMSSQLS_READ;

		//close
		hr = con->Close(); //AddTextToFile("MSSQL_Exec(). 33.");

		fRes = true;
	}
	catch (_com_error &e)
	{
		OnException(e, fn_mes_err, p_param, eState);
	}

	return fRes;
}

void OnException(_com_error &e, FN_MSSQL_MES_ERR fn_mes_err, void *p_param, EMSSQLState eState) //char *sz_cmd, 
{
 if (fn_mes_err == 0) { return; }

	char sz_val[MAX_PATH + 1];

	memset(sz_val, 0, MAX_PATH + 1);

	int i_res = WideCharToMultiByte(CP_ACP, WC_COMPOSITECHECK, e.ErrorMessage(), lstrlen(e.ErrorMessage()), sz_val, MAX_PATH + 1, NULL, NULL);

	int err = GetLastError();

	if (i_res)
	{
		(fn_mes_err)(p_param, sz_val, eState);
	}
}

_variant_t get_bstr(_variant_t& v)
{
	return v.vt == VT_EMPTY || v.vt==VT_NULL ? (_variant_t)"" : v;
}

_variant_t get_int(_variant_t& v)
{
	return v.vt == VT_EMPTY || v.vt == VT_NULL ? (_variant_t)0 : v;
}