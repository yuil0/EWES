#ifndef _new_thread_h_
#define _new_thread_h_

#include <windows.h>
#include <string>
#include <vector>

class C_new_thread
{
	bool m_fInit;

	//std::vector<S_new_thread_Row> m_list;

	//SMSSQLAgentRow m_row;
	
public:
	C_new_thread();
	~C_new_thread();
	bool Open();
	void Close() {}
	
	bool Exec();	
};

extern C_new_thread g_new_thread;

#endif