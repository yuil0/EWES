#ifndef _keyb_h_
#define _keyb_h_
#include  <windows.h>

const int ci_bits_in_byte= 8;
const int ci_max_key = 256;
const int ci_max_part_event = 8;
const int ci_pair_key= 2;

class CKeyb
{                                //bool m_fInit;
	bool m_fKeybReaded;
	BYTE m_baKey[ci_max_key];
	
	int m_delta_time[ci_max_key];
	
	unsigned int m_eventDown[ci_max_part_event];
	
	void ClearEventDown();
	void SetEventDown(int iKey);
	void GetEventDownPart(int iKey, int& i_part, int& iPosInPart);
	public:
	CKeyb();
	void Clear();
	void Read();
	bool GetEventDown(int iKey);
	bool GetEventDown_2(int *iKey);
};

#endif