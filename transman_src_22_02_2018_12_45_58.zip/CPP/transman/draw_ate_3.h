#ifndef _draw_ate_3_h_
#define _draw_ate_3_h_

#include <vector>
#include "..\\transman_srv\\std_str.h"
#include <time.h>
#include "DrawObjectBase.h"
#include "MSSQL.h"
#include "CarLagLead.h"
#include "..\\util\\winctrl.h"

const int ci_route_name_len = 16;
const int ci_agent_name_len = 64;
const int ci_user_name_len = 32;
const int ci_sip_name_len = 5;
const int ci_garage_num_len = 16;

extern int g_count_ch_route; //YUIL 2017-02-02 //������� ����� ���������

struct SDeviceATE_3;

extern std::vector<SDeviceATE_3> gVisibleCars;

typedef enum
{
	ECT_TROL = 0,
	ECT_BUS,
	ECT_TRAM,
	ECT_MINIBUS,
	ECT_SHUTTLE,
	ECT_LIM_MOB,
	//
	ECT_QUANTITY,
}ECarType;

extern const char* csz_car_type[ECT_QUANTITY];

struct SCarLagLead
{
	std_string stop_name;
	std_string shape_id;
	std_string arrival_time;
	std_string departure_time;
};


struct CDrawATE_3_Draw_param
{
	ECarLagLeadView m_CarLagLeadView; ////YUIL 2017-10-25.bool f_car_lag_lead;
	HGDIOBJ *p_pen_brush;
	bool* p_drawCarTypes;
};

struct SMnemoSchema //YUIL 2017-10-25 . ���������� �� ������� ��������.
{

};

struct SShapePoint
{
	int sequence;
	int x, y;
};

struct SLoadVisibleShapePoints
{
	double zoom;
	//
	SLoadVisibleShapePoints(double zoom_new)
	{
		zoom = zoom_new;
 }
	void add(FldsPtr fp);
};

typedef enum
{
	ELLS_NORMAL=0,
	ELLS_LAG,
	ELLS_LEAD,
}ELagLeadState; ////YUIL 2017-02-07

struct SDeviceATE_3 : SDrawObjectBase
{                           //long id_ate_3;
	double dt;              //std_string device_number;
	Leaflet::LatLng latlng;
	int azimut;				//YUIL. ���� �� ����������� �� �����.
	int speed;				//YUIL . �������� / ���
	double dt_created;		//YUIL.���� / ����� ��������  ������
	double dt_update;		//YUIL.���� / ����� ��������  ������
	char route[ci_route_name_len+1];      //YUIL 2017-09-13  ������� ��� �������� //bool f_formalize_messages; //YUIL 2017-12-07 ������� � ����.�����
	std_string sz_full_name;
	int id_agent;
	char agent_name[ci_agent_name_len + 1];
	int id_car_type;
	ELagLeadState eLagLeadState; //YUIL 2017-02-07

	double x, y;

	long id_picas_route; //long m_lDraw; //YUIL 2017-02-01 ���� �����������
	char user_name[ci_user_name_len + 1]; //YUIL 2017-02-02
	char sip_name[ci_sip_name_len + 1]; //YUIL 2017-02-02

	char garage_num[ci_garage_num_len + 1]; //YUIL 2017-02-21
	int minutes_lag; //YUIL 2017-02-22
	//

	bool fSel;  //YUIL 2017-02-02  ������
	//
	void  Clear();
	virtual char *GetDrawName(); //void Draw(int hdc, int i_draw_radius, char *sz_title_name, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list);

	//std::vector<SCarLagLead> m_lag; //YUIL 2017-10-17 ������ ��� ��� �������	//std::vector<SCarLagLead> m_lead; //YUIL 2017-10-17 ������ ��� ��� ��������� //void AddLagLead(FldsPtr fp, bool fLag);	
	void SelectGDI_Objs(int hdc, CDrawATE_3_Draw_param& param);
	void Draw(bool fFillVisible, int hdc, int i_draw_radius, char *sz_title_name, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list, const SPointInt& origin, CDrawATE_3_Draw_param& param);
	char* GetStrLead(char* sz_buf, int i_max_buf);
};

//typedef std::vector<SDeviceATE_3> TypeDeviceATE_3List;

class CDrawATE_3
{
	bool m_fInit;
	bool m_fLoad;
	std::vector<SDeviceATE_3> m_dev_list;
	
	time_t m_time_prev;
	void LoadOp(); //void DrawOp(HDC hdc); void FillLagLead();
	long m_l_copy_proc;
	SMnemoSchema m_mnemo_schema;
	bool m_f_draw;
	std::vector<long> m_list_enable_routes;
	int m_count_id_picas_route_not_null;
	int m_id_agent;
	bool m_fSElectSQLCondAllDate;
	int m_car_draw_radius;
	//
	void LoadIni();

	public:
	CDrawATE_3();
	~CDrawATE_3();
	bool Open();
	void Close(); //	void Load();  void LoadTh();
	void Draw(HDC hdc, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list, const SPointInt& origin, CDrawATE_3_Draw_param& param, double zoom);
	void Calc(double zoom, const SPointInt& origin);
	bool FindNear(double x, double y, SDeviceATE_3& sDev);
	void SetDraw(bool f_draw_new) { m_f_draw = f_draw_new;}
	bool OpDraw() 
	{
		m_f_draw = m_f_draw ? false : true; 
	 return m_f_draw; 
	}
	void list_enable_routes_clear() { m_list_enable_routes.clear(); }
	void list_enable_routes_add(int id_picas_route_new) { m_list_enable_routes.push_back(id_picas_route_new); }
	std::vector<long>& get_list_enable_routes() { return m_list_enable_routes; }
	bool FillCombo(CWinCtrl* p_ctrls, char *sz_combo);
	bool Find(char *name, int& index);

	void Set_id_agent(int id_agent_new) {m_id_agent = id_agent_new;}
	void LoadOp_ADD(FldsPtr fp);
	bool NextVisible(int& i, SDeviceATE_3& o);
	bool NextVisiblePtr(int& i, SDeviceATE_3* *p);
	void UnSelAll();
};

void LoadVisibleShapePoints(char* shape_id_postfix, double zoom);
void DrawRouteSelCar(HDC  hdc, const SPointInt& origin, int i_draw_radius, CDrawATE_3_Draw_param& param);
#endif