#include <memory.h>
#include "window.h"
#include "main.h"           //const wchar_t *cWndClassName = L"transman_wnd_class";
#include <TlHelp32.h>
#include "..\\transman_srv\\str.h"

#pragma comment(lib, "Kernel32.lib")

#ifndef GWL_USERDATA
#define GWL_USERDATA        (-21)
#endif

#ifndef GWL_WNDPROC
#define GWL_WNDPROC         (-4)
#endif


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
SWindowCreateParam::SWindowCreateParam() { memset(this, 0, sizeof(SWindowCreateParam)); }

void SWindowCreateParam::Calc_xy()
{
	if (fCalc_xy == false) { return; }

	x = (GetSystemMetrics(SM_CXSCREEN) - w) / 2;

	y = (GetSystemMetrics(SM_CYSCREEN) - h) / 2;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CWindow::CWindow() { memset(this, 0, sizeof(CWindow)); } /*m_fInit=false;m_hInstance=hInstance;m_fInit=true;*///CWindow::~CWindow(){}


void CWindow::Destroy()
{
	DestroyWindow(m_hwnd);
}

/*
void CWindow::WMClose(WPARAM wParam, LPARAM lParam)
{
	Destroy();	
}

void CWindow::WMDestroy(WPARAM wParam, LPARAM lParam)
{
	ExitProcess(1);
}

void CWindow::WMSize(WPARAM wParam, LPARAM lParam)
{
	int new_width = lParam & 0xFFFF; //The low - order word of lParam specifies the new width of the client area.	
	int new_height= (lParam>>2) & 0xFFFF; //The high - order word of lParam specifies the new height of the client area.
	
	//Paint();
}

void CWindow::WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam)
{
	
}

LRESULT CALLBACK WindowProc(
  HWND   hwnd,
  UINT   uMsg,
  WPARAM wParam,
  LPARAM lParam )
{
	CWindow *p_wnd= (CWindow*)GetWindowLong(hwnd, GWL_USERDATA);
	
	bool fMapWnd = uMsg & (1 << 16);
	switch (uMsg)
	{
	case WM_CLOSE: if (p_wnd) { p_wnd->WMClose(wParam, lParam); } break;
	case WM_DESTROY: if (p_wnd) { p_wnd->WMDestroy(wParam, lParam); } break;
	case WM_SIZE: if (p_wnd) { p_wnd->WMSize(wParam, lParam); } break;
	case WM_LBUTTONDOWN: if (p_wnd) { p_wnd->WM__LBUTTONDOWN(wParam, lParam); } break;
	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 1;
} */

bool CWindow::RegClass(const SWindowCreateParam& sParam)
{
	WNDCLASS wc;
	wc.style=CS_HREDRAW|CS_VREDRAW;   	
	wc.lpfnWndProc = m_sParam.wndProc;
	wc.cbClsExtra=0;
	wc.cbWndExtra=0;
	wc.hInstance= g_hInstance; //m_sParam.hInstance; 
	wc.hIcon = (HICON)LoadImage(g_hInstance, L"transman.ico", IMAGE_ICON, 128, 128, LR_LOADFROMFILE); //m_sParam.hInstance
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = sParam.hbrush ? sParam.hbrush : (HBRUSH) GetStockObject(WHITE_BRUSH);//wc.lpszMenuName;
	wc.lpszMenuName = L"MainMenu";

	if (lstrlen(sParam.wzClassName) == 0) 
	{ wc.lpszClassName = L"CWindow"; }
	else
	{ wc.lpszClassName = sParam.wzClassName; }

	bool f_res= RegisterClass(&wc);

	return f_res;
}

bool CWindow::Create(const SWindowCreateParam& sParam) //HINSTANCE hInstance, wchar_t* wsz_name, TYPE_FUNC p_Destroy, HWND hWndParent, HMENU hMenu,  bool fVisible)
{
	m_sParam = sParam;

	SWindowCreateParam& prm = m_sParam;

	RegClass(sParam);

	if (prm.dwStyle == 0) 
	{ prm.dwStyle = WS_POPUP | WS_SYSMENU | WS_CAPTION | WS_DLGFRAME | WS_MAXIMIZEBOX | WS_MINIMIZEBOX | WS_SIZEBOX; }

	prm.Calc_xy();

	wchar_t wzClassName[64];
	
	if (lstrlen(sParam.wzClassName) == 0)
	{ lstrcpy(wzClassName, L"CWindow"); }
	else
	{ lstrcpy(wzClassName, sParam.wzClassName); }

	m_hwnd = CreateWindowEx(prm.dwStyleEx, wzClassName, prm.wsz_name, prm.dwStyle, prm.x, prm.y, prm.w, prm.h, prm.hWndParent, prm.hMenu, g_hInstance, 0); //transman_wnd_class // prm.hInstance

	if (m_hwnd)
	{
		if (prm.wndProc) { SetWindowLong(m_hwnd, GWL_WNDPROC, (LONG)prm.wndProc); }

		SetWindowLong(m_hwnd, GWL_USERDATA, (LONG)(prm.p_param ? prm.p_param : this)); //HICON hIcon = (HICON)LoadImage(prm.hInstance, L"transman.ico", IMAGE_ICON, 128, 128, LR_LOADFROMFILE); //SendMessage(m_hwnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);                  //DeleteObject(hIcon);  //LoadIcon(_In_opt_ HINSTANCE hInstance,_In_     LPCTSTR   lpIconName);//Paint();

		UpdateWindow(m_hwnd);

		ShowWindow(m_hwnd, prm.fVisible ? SW_SHOW : SW_HIDE);		
	}
	else
	{
		char sz[MAX_PATH+1]; 

		sprintf_s(sz, MAX_PATH, "GetLastError:%d",GetLastError());		
	}

	return m_hwnd != 0;
}

void CWindow::SetIconWnd(HWND hwnd)
{
	HICON hIcon = (HICON)LoadImage(g_hInstance, L"transman.ico", IMAGE_ICON, 128, 128, LR_LOADFROMFILE);

	SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon); //DeleteObject(hIcon); //LoadIcon(_In_opt_ HINSTANCE hInstance,_In_     LPCTSTR   lpIconName);
}

void CWindow::SetWindowSize(HWND hwnd, int widthWinCtrl, int heightWinCtrl)
{                                 //RECT rc; GetWindowRect(hwnd, &rc);
	BOOL bRepaint = TRUE;

	int xm= GetSystemMetrics(SM_CXSCREEN);
	int ym = GetSystemMetrics(SM_CYSCREEN);

	int x = (xm - widthWinCtrl) / 2;;
	int y = (ym - heightWinCtrl) / 2;

	MoveWindow(hwnd, x, y, widthWinCtrl, heightWinCtrl, bRepaint);
}


/*
void CWindow::Paint()
{
	RECT cr;
	if (GetClientRect(m_hwnd, &cr) == false) { return; }
	HDC hdc = GetDC(m_hwnd);

	HDC hMem = CreateCompatibleDC(hdc);
	HBITMAP memBM = CreateCompatibleBitmap(hdc, cr.right+2, cr.bottom + 2);
	SelectObject(hMem, memBM);

	Rectangle(hMem, 0, 0, cr.right+2, cr.bottom+2);

	BitBlt(hdc, -1, -1, cr.right, cr.bottom, hMem, 0, 0, SRCCOPY);

	DeleteObject(memBM);
	DeleteObject(hMem);
	ReleaseDC(m_hwnd, hdc);
} */

bool CWindow::TerminateProcessByHWND(HWND hWnd)
{
	if (IsWindow(hWnd) == FALSE) { return false; }

	DWORD dProcessId;

	DWORD dThreadId = GetWindowThreadProcessId(hWnd, &dProcessId);

	BOOL  bInheritHandle = TRUE;

	HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, bInheritHandle, dProcessId);

	BOOL fTerm = TerminateProcess(hProcess, 1);

	return fTerm;
}


bool CWindow::GetClientRectAbs(HWND hWnd, RECT& rcCleintAbs, SCWindowAttr* pAttr)
{
	if (IsWindow(hWnd) == FALSE) { return false; }

	const int ci_fix_y_drw_wnd = -8;
	const int ci_fix_w = 1;
	const int ci_fix_h = 1;
	//const int ci_fix_y_drw_wnd = 21;

	RECT rc;
	RECT crc;

	if (GetWindowRect(hWnd, &rc) == FALSE) { return false; }

	if (GetClientRect(hWnd, &crc) == FALSE) { return false; }

	int wc = crc.right - crc.left;
	int hc = crc.bottom - crc.top;

	int iThick = ((rc.right - rc.left) - wc) / 2;
	int iCaption = ((rc.bottom - rc.top) - hc) - iThick;

	rcCleintAbs = rc; //memcpy(&rcCleintAbs ,   &rc,  sizeof(RECT));

	rcCleintAbs.left += iThick;
	rcCleintAbs.top += iCaption + iThick + ci_fix_y_drw_wnd;
	rcCleintAbs.right = rcCleintAbs.left + wc + ci_fix_w;
	rcCleintAbs.bottom = rcCleintAbs.top + hc + ci_fix_h;

	if (pAttr) {pAttr->iThick=iThick; pAttr->iCaption=iCaption; }

	return true;
}

BOOL CALLBACK MinimizeAllWndFunc(HWND hWnd, LPARAM  lParam)
{
	if (IsWindow(hWnd)==FALSE)  { return TRUE; }
	
	if (IsWindowVisible(hWnd) == FALSE) { return TRUE; } //if (IsIconic(hWnd) == TRUE) { return TRUE; }

	char szClassName[MAX_PATH + 1];
	bool f_hide = false;

	if (GetClassNameA(hWnd, szClassName, MAX_PATH))
	{
		if (!strcmp(szClassName,  "Ghost")) { f_hide = true; }
		if (!strcmp(szClassName, "Internet Explorer_Hidden")) { f_hide = true; }
		if (!strcmp(szClassName, "Alternate Owner")) { f_hide = true; }		
	}

	if  (f_hide)  
	{ //ShowWindow(hWnd, SW_HIDE); 
		BOOL bRepaint = TRUE;
		MoveWindow(hWnd, 0, -100, 5, 5, FALSE);
	}
	else
	{ ShowWindow(hWnd, SW_SHOWMINIMIZED); }
	

	return TRUE;
}

void MinimizeAllWnd()
{
	EnumWindows(MinimizeAllWndFunc, (LPARAM)0);
}

SSizeDelta::SSizeDelta() { memset(this, 0, sizeof(SSizeDelta)); }

///////////////////////////////////////////////////////////////////////////////////////////////
void CWindow::ReizeWnd(HWND hwnd, const SSizeDelta& delta) //, int dx, int dy, int dw, int dh)
{
	RECT rc;

	GetWindowRect(hwnd, &rc);

	BOOL bRepaint = TRUE;

	int w = rc.right - rc.left;

	int h = rc.bottom - rc.top;

	int x_new = rc.left + delta.x;

	int y_new = rc.top + delta.y;

	int w_new = w + delta.w;

	int h_new = h + delta.h;

	MoveWindow(hwnd, x_new, y_new, w_new, h_new, bRepaint);

}

/*
void CWindow::SizeForBackWnd(HWND hwnd, int iStep, int iQuantityStep, int iSleep)
{
	for (int i=0; i<iQuantityStep; i++)
	{
		ReizeWnd(hwnd, 0, iStep);
		
		Sleep(iSleep);
	}	

	for (int i = 0; i<iQuantityStep; i++)
	{
		ReizeWnd(hwnd, 0, - iStep);

		Sleep(iSleep);
	}
} */


///////////////////////////////////////////////////////////////////////////////////////////////
void CWindow::MouseOp(HWND hwnd)
{
	RECT rc;
	
	int step_x=5;

	GetWindowRect(hwnd, &rc);

	POINT sh = { 8, 6 };
	POINT point = { rc.right - sh.x, rc.bottom - sh.y };
	
	SetCursorPos(point.x, point.y); mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_ABSOLUTE, point.x, point.y, 0, 0);

	Sleep(100);
	
	SetCursorPos(point.x + step_x, point.y); mouse_event(MOUSEEVENTF_MOVE, step_x, 0, 0, 0);

	Sleep(100);

	SetCursorPos(point.x - step_x, point.y); mouse_event(MOUSEEVENTF_MOVE, - step_x, 0, 0, 0);

	Sleep(100);
	
	mouse_event(MOUSEEVENTF_LEFTUP | MOUSEEVENTF_ABSOLUTE, point.x + step_x, point.y, 0, 0);

	SetCursorPos(rc.left + (rc.right - rc.left)/2, rc.top + (rc.bottom - rc.top)/2);
}

///////////////////////////////////////////////////////////////////////////////////////////////
void CWindow::ClickLButton(HWND hwnd)
{
	RECT rc;
	
	int step_x=5;

	GetWindowRect(hwnd, &rc);

	POINT point = { (rc.right + rc.left)/2, (rc.bottom + rc.top)/2 };
	
	SetCursorPos(point.x, point.y); mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_ABSOLUTE, point.x, point.y, 0, 0);

	Sleep(100);	
	
	mouse_event(MOUSEEVENTF_LEFTUP | MOUSEEVENTF_ABSOLUTE, point.x + step_x, point.y, 0, 0);
}

///////////////////////////////////////////////////////////////////////////////////////////////
bool CWindow::ClickKey(HWND hwnd, int  vk)
{
	RECT rc;
	
	int step_x=5;

	BOOL f_get = GetWindowRect(hwnd, &rc);

	if (f_get==FALSE) {return false;}

	POINT point = { (rc.right + rc.left)/2, (rc.bottom + rc.top)/2 };
	
	BYTE bScan=1;

	DWORD dwFlags = 0; //KEYEVENTF_KEYUP;

	keybd_event(vk, bScan, dwFlags, 0);

	return true;
}

void CWindow::Show(bool f_show)
{
	ShowWindow(m_hwnd, f_show ? SW_SHOW : SW_HIDE);
}

void CWindow::ChShow()
{
	BOOL fShow = IsWindowVisible(m_hwnd);

	ShowWindow(m_hwnd, fShow ? SW_HIDE : SW_SHOW);
}

void WindowChShow(HWND hwnd)
{
	BOOL fShow = IsWindowVisible(hwnd);

	ShowWindow(hwnd, fShow ? SW_HIDE : SW_SHOW);
}

void AddChildWndToFile(HWND hwndChild,  char *sz_file)
{
	FILE *fo=fopen(sz_file, "ab");

	if (fo)
	{
		char sz_val[MAX_PATH+1];
			
		HWND hwndParent = GetParent(hwndChild);

		fprintf(fo, "hwndParent:0x%X", hwndParent);

		int i_readed = GetWindowTextA(hwndParent, sz_val, MAX_PATH); fprintf(fo, " text:'%s'", sz_val);

		i_readed = GetClassNameA(hwndParent, sz_val, MAX_PATH); fprintf(fo, " class:'%s'", sz_val);

		fprintf(fo, " hwndChild:0x%X", hwndChild);

		i_readed = GetWindowTextA(hwndChild, sz_val, MAX_PATH); fprintf(fo, " text:'%s'", sz_val);

		i_readed = GetClassNameA(hwndChild, sz_val, MAX_PATH); fprintf(fo, " class:'%s'", sz_val);
			
		fprintf(fo, "\r\n");

		fclose(fo);
	}
}

BOOL CALLBACK WindowsToFile_EnumFunc(HWND hwndChild, LPARAM lParam)
{

	AddChildWndToFile(hwndChild,  (char*)lParam);

	return  TRUE;
}

void WindowsToFile(HWND hwndParent, char *sz_file,  bool f_del_file) //YUIL 2017-11-14
{
	if (f_del_file) { unlink(sz_file); }

 EnumChildWindows(hwndParent, WindowsToFile_EnumFunc,  (LPARAM)sz_file);
}


HWND find_window(char *sz_part_text, char *sz_class)
{
	HWND hwndFound=0;

	int i_len = sz_part_text ? strlen(sz_part_text) : 0;
					
	do
	{
		HWND hwnd=FindWindowA(sz_class,0);

		if (i_len)
		{
			char sz_name[MAX_PATH+1];

			if (GetWindowTextA(hwnd, sz_name, MAX_PATH))
			{
				if (strstr(sz_name, sz_part_text)) 
				{ 
					hwndFound = hwnd; 
				}
			}
		}
		else
		{ 
			hwndFound = hwnd; 
		}

	}while(hwndFound==0);					
	
	return hwndFound;
}

void TerminateProcessByClass(char *sz_class, HWND hwndIgnore)
{
	HWND hwnd = 0;

	do
	{
		hwnd = FindWindowA(sz_class, 0);

		if (hwnd && hwnd != hwndIgnore)
		{
			CWindow::TerminateProcessByHWND(hwnd);
		}

	} while (hwnd);

}

bool SHWNDList::Find(HWND hwnd)
{
	bool fFound = false;

	int q = list.size();

	for (int i = 0; fFound == false && i < q; i++)
	{
		if (list[i] == hwnd) { fFound = true; }
	}

	return fFound;
}

void CloseDestroyWindowByClass(char *sz_class, HWND hwndIgnore)
{
	HWND hwnd = 0; //SHWNDList s_list;
	HWND hwndPrev= 0; //int q_repeat = 0;

	do
	{
		hwnd = FindWindowA(sz_class, 0); //if (s_list.Find(hwnd)) { break; } s_list.list.push_back(hwnd);

		if (hwnd != hwndIgnore)
		{
			CloseWindow(hwnd); DestroyWindow(hwnd);
		}

		if (hwndPrev == hwnd) { break; }

		hwndPrev = hwnd;

	} while (hwnd);
}

/*
HWND find_child_window(HWND hwndParent, char *sz_part_text, char *sz_class)
{
	HWND hwndFound=0;
					
	do
	{
		HWND hwnd=FindWindowExA(hwndParent, 0, sz_class,0);

		char sz_name[MAX_PATH+1];

		if (GetWindowTextA(hwnd, sz_name, MAX_PATH))
		{
			if (strstr(sz_name, sz_part_text)) 
			{ 
				hwndFound = hwnd; 
		 }
		}

	}while(hwndFound==0);					
	
	return hwndFound;
}*/

BOOL CALLBACK find_child_window_ENUMPROC(HWND hwnd, LPARAM lParam)
{
	S_find_child_window_param* p_param= (S_find_child_window_param*)lParam;

	if (p_param==0) {return FALSE;}

	char sz_val[MAX_PATH+1];

	int i_len = GetClassNameA(hwnd, sz_val, MAX_PATH);

	if (i_len==0) {return FALSE;}

	if (!stricmp(sz_val, p_param->sz_class.c_str()))
	{
		if (GetWindowTextA(hwnd, sz_val, MAX_PATH))
		{
			if (strstr(sz_val, p_param->sz_part_text.c_str())) 
			{ 
				p_param->hwnd = hwnd; 

				p_param->hwndParent = GetParent(hwnd);

				return FALSE;
			}
		}
	}

	return TRUE;
}

HWND find_child_window(S_find_child_window_param& s_param)
{
	s_param.hwnd=0;
					
	EnumWindows(find_child_window_ENUMPROC, (LPARAM)&s_param);
	
	return s_param.hwnd;
}

BOOL CALLBACK FindThread_WNDENUMPROC(HWND hwnd, LPARAM lparam)
{
	AddChildWndToFile(hwnd, "C:\\transman\\explore\\wnds.txt");

	return true;
}

bool FindThread()
{
	HANDLE hShapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);

	if (hShapshot==INVALID_HANDLE_VALUE) {return false;}

	THREADENTRY32 te;
	te.dwSize = sizeof(THREADENTRY32);

	if (!Thread32First(hShapshot, &te)) {CloseHandle(hShapshot); return false;}

	do
 {
		
		EnumThreadWindows(te.th32ThreadID, FindThread_WNDENUMPROC, 0);
	}while(Thread32Next(hShapshot, &te));

	CloseHandle(hShapshot);

	return true;
}

/*
HWND GetMainWindowByProcess(HWND hwnd, char *sz_file,  bool f_del_file) //YUIL 2017-11-14
{
	DWORD dwProcessId;
	DWORD ThreadId = GetWindowThreadProcessId(hwnd, &dwProcessId);

	//if (f_del_file) { unlink(sz_file); }

 //EnumChildWindows(hwnd, ChildWindowsToFile_EnumFunc,  (LPARAM)sz_file);
}*/
