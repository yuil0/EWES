#ifndef _draw_wnd_h_
#define _draw_wnd_h_

#include <windows.h> 
#include <vector>
#include "MapAddr.h"
#include "leaflet.h"
#include "draw_data.h"
#include "draw_ate_3.h"
#include "CarLagLead.h"
#include "..\\transman_srv\\std_str.h"

const int c_draw_radius = 4; ///const int c_q_draw_object= 1;
const int ci_max_point_tool = 2;
const int cl_max_value = 256;
extern HWND g_hwndDraw;

typedef enum
{
	ETDO_CENTER=0,

	ETDO_STOP,	
	
	ETDO_ROUTE_POINT,

	ETDO_ZONE,
	
	ETDO_CAR,
	
	ETDO_ZONE_NEW,
}ETypeDrawObject;

/*
struct SDrawObject
{
	ETypeDrawObject eType;
	
	long id;

	std_string id_in;

	std_string name;

	std_string name_long;

	Leaflet::LatLng latlng;

	SPointInt point;
};*/

typedef enum
{
	EDWT_NONE = 0,

	EDWT_LINE_MEASURE,

	EDWT_LINE_MEASURE_MOUSE,
	
	EDWT_ZONE_POINT_NEW,
}EDrawWndTool;

typedef enum
{
	ETSF_ID_PICAS_STOP=0, 
	ETSF_STOP_ID,
	ETSF_STOP_NAME,
	ETSF_STOP_LAT,
	ETSF_STOP_LON,

	ETSF_QUANTITY,
}ETableStopField;


struct SSelectedObject
{                 //ETypeDrawObject type;//void* p;
	SPointInt point;

	std::vector<std_string> str_list; // std_string text;

	void  Clear() { str_list.clear(); }
};

/*typedef enum 
{
	ECLLV_ALL=0, //���
	ECLLV_LAG,  //��������� 
	ECLLV_LEAD, //�����������
	ECLLV_NORM, //� �����
}ECarLagLeadView;*/

///////////////////////////
class CDrawWnd
{                                             	//const int ci_len_wns_class; //const wchar_t cwsz_wnd_class[ci_len_wns_class+1];//  wc.lpszClassName = L"transman_wnd_class";	//bool m_fInit;
	HWND m_hwnd; //HINSTANCE m_hInstance; //std::vector<SDrawObject> m_object_list; //SDrawObject m_a_object[c_q_draw_object];  //SDrawObject m_drawObject;

	EDrawWndTool m_tool;

	int i_toolState; //EDWT_LINE_MEASURE : 0:��� ����� 1:�����  ����� 2:��� �����
	
	SPointInt m_pointTool[ci_max_point_tool];

	SPointInt m_center; //YUIL 
	
	SPointInt m_centerLeaflet; //YUIL from Leaflet

	SPointInt m_clientMouse;

	SPointInt m_viewOrigin;   //SPointInt m_centerFromLeaflet;

	CDrawATE_3 m_DrawATE_3;

	double m_zoom;

	bool m_fDrawObject; 
	
	SSelectedObject m_sel_object;

	SDrawData m_data;

	SPointInt m_size;

	int m_draw_wnd_x_shift;

	bool m_f_find_near_car;

	int m_map_object_shift_y;
	
	int m_index_sel_stop; //2 + value== valid_index, 1== <request to check>, 0== <not select> //RECT m_rc;

	bool m_drawCarTypes[ECT_QUANTITY];

	//
	void DelToolPoint(int index_point);

	void AddTextToolOp(wchar_t * wsz_text, const SPointInt& pointLast);

	void DrawTextToolOp(HDC hdc, const SPointInt& pointLast);

	void ReportChSizeToFile(char *sz_file); 
	
	bool IsMouseOnObject();

	void DrawObjectInfo(HDC hdc);

	void DrawCenter(HDC hdc);

	void SelectGDIObjects(HDC hdc, ETypeDrawObject type);

	HGDIOBJ m_pen_brush[EPB_QUNATITY]; // std::vector<HGDIOBJ>;

	ECarLagLeadView m_CarLagLeadView; ////YUIL 2017-10-25

	void ReadIni();

public:

	struct SAnswerUser
	{
		Leaflet::LatLng latlng;
		SPointInt pn;
		bool fFound;
		int re;
		std_string user_name;
		//
		void Draw(HDC hdc, double zoom, const SPointInt& origin, HGDIOBJ* pen_brush, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list);
		void SAnswerUser_ADD(FldsPtr fp);
	};

	SAnswerUser m_sAnswerUser;

	void PaintOp(HDC hdc);

	void DrawObjects(HDC hdc);

	void CreatePenBrush();

	void DestroyPenBrush();

	bool RegClass(HINSTANCE hInstance);  //void DrawObject(HDC hdc, int x, int y, ETypeDrawObject eType = ETDO_ROUTE_POINT); // ETDO_CENTER);

	void OnLButton(); // const POINT& pt);

	void DrawTool(HDC hdc);

	bool FindToolPointInRadius(int x, int y, int radius, int& index_point);

	void OnLButtonOp(int i_max);
	
	void EnableAllCarTypes();

	CDrawWnd(); //~CDrawWnd();

	bool Create(HINSTANCE hInstance, wchar_t* wsz_name, HWND hWndParent=0, HMENU hMenu=0, bool fVisible=true);
	
	void Destroy();	

	void WMClose(WPARAM wParam, LPARAM lParam);

	void WMDestroy(WPARAM wParam, LPARAM lParam);

	void WMSize(WPARAM wParam, LPARAM lParam);

	void Paint();

	HWND GetHWND() { return g_hwndDraw; }//

	void WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam);

	void SetPosSizeByMapWnd(); // void Shift(int dx, int dy); //void LoadStaticObject();

	void SetPlacement(UINT flag);

	void AddTextTool(wchar_t * wsz_text);

	bool GetClientCoord(const POINT& pt, SPointInt& pointClient);

	void CalcClientMouse();

	void CalcCenter(CMapAddr& mapAddr, bool fFirst=false);

	void SetViewOrigin();// int xFix = -13, int yFix = -32);

	void CalcCoordObject();               //void LoadStops();void LoadShapes();void LoadProbeStop();

	void SetDrawObject(bool fNew) { m_fDrawObject = fNew; }

	void OnMouseMove();
	
	SPointInt& GetClientMouse() { return (SPointInt&) m_clientMouse; }	

	void SetWindowXShift(int draw_wnd_x_shift_new) { m_draw_wnd_x_shift = draw_wnd_x_shift_new; }

	bool NextRoute(int& index, SRoute& o, bool fBack=false);

	bool NextStop(int& index, SStop& o);
	
	bool NextZone(int& index, SZone& o);

	bool NextShapeLine(int& index, SShapeLine& sl);
	
	void  SelectRoute(int index);
	
	void  SelectStop(int index);
	
	void  SelectZone(int index);

	void ZonePointNew();

	EDrawWndTool SetTool(EDrawWndTool eNew);

	void ZoneNewClear(char *sz_new_name);
	
	bool ZoneNewAdd(int x, int y,  double zoom) { return m_data.m_zone_new.AddPoint(x, y, zoom); }

	EDrawWndTool GetTool() { return m_tool; }
	
	bool ZoneNewSave();

	void SelectZoneDel();

	bool ZoneNameExists(char *sz_name);

	bool GetRoute(int index, SRoute& s_route);

	bool GetStop(int index, SStop& s_stop);

	bool GetStopPtr(int index, SStop* *p_stop);

	void FindNear();

	bool IsFindNearCar() { return m_f_find_near_car; } //bool IsCarLagLead() { return m_f_car_lag_lead; }
	
	void InvertFindNearCar() {m_f_find_near_car= !m_f_find_near_car;	} //void InvertCarLagLead() {m_f_car_lag_lead= !m_f_car_lag_lead;	}
	
	void SetCarLagLeadView(ECarLagLeadView eNew) { m_CarLagLeadView = eNew; } ////YUIL 2017-10-25

	void ChShow();

	bool IsSelStop() { return m_index_sel_stop >= 2; }

	void ClearSelStop() { m_index_sel_stop=0; }

	void RequestToCheckSelStop() { m_index_sel_stop = 1; }
	
	bool GetIndexSelStop(int& index_stop) 
	{ 
		if (IsSelStop()==false) { return false; }
		
		index_stop = m_index_sel_stop - 2;

		return true;
	}
	void SetDraw(bool f_draw_new) { m_DrawATE_3.SetDraw(f_draw_new); }
	bool OpDraw() { return m_DrawATE_3.OpDraw(); }
	int GetRouteSize();
	CDrawATE_3& GetDrawATE_3() { return (CDrawATE_3&)m_DrawATE_3; } //RECT& GetRect() { return (RECT&)m_rc; }
	SDrawData& GetData() { return (SDrawData&)m_data; }
	void GetLatLngOnMouse(Leaflet::LatLng& latlng);

	bool* GetDrawCarTypes() { return (bool*)m_drawCarTypes; }

	bool NextVisibleCar(int& i, SDeviceATE_3& o)
	{
		return m_DrawATE_3.NextVisible(i, o);
	}

	double GetZoom() { return m_zoom; }
	void CarTypesClear();
	void SetCarType(char *id_car_type);
};


//HWND FadeRect(RECT* prc, HDC hdc, wchar_t* wsz_name, HINSTANCE hInstance);

#endif