#ifndef _window_h_
#define _window_h_

#include <windows.h>
#include "..\\transman_srv\\std_str.h"

//typedef void(*TYPE_FUNC)(); //extern const wchar_t *cWndClassName;

////////////////////////////////////////////////////////////////////////////////////
struct SWindowCreateParam
{
	HINSTANCE hInstance;
	wchar_t* wsz_name;	
	WNDPROC wndProc;
	HWND hWndParent;
	HMENU hMenu;
	bool fVisible;	
	int w;
	int h;
	int x;
	int y;
	bool fCalc_xy;
	DWORD dwStyleEx;
	DWORD dwStyle;
	void *p_param;
	HBRUSH hbrush;
	wchar_t wzClassName[64];
	//
	void Calc_xy();

	SWindowCreateParam(); 
};

struct SSizeDelta
{
	int x, y, w, h;

	SSizeDelta();
};

struct SCWindowAttr
{
	int iThick;
	int iCaption;
};

////////////////////////////////////////////////////////////////////////////////////
class CWindow
{                                             	//const int ci_len_wns_class; //const wchar_t cwsz_wnd_class[ci_len_wns_class+1];//  wc.lpszClassName = L"transman_wnd_class";	//bool m_fInit;
	HWND m_hwnd; 

	bool RegClass(const SWindowCreateParam& sParam);
	
	SWindowCreateParam m_sParam; //TYPE_FUNC m_p_Destroy;

	public:
	CWindow(); //~CWindow();

	bool Create(const SWindowCreateParam& sParam); // HINSTANCE hInstance, wchar_t* wsz_name, TYPE_FUNC p_Destroy, HWND hWndParent=0, HMENU hMenu=0, bool fVisible=true);

	void Destroy();

	void Show(bool f_show);
	void ChShow();

	void WMClose(WPARAM wParam, LPARAM lParam);

	void WMDestroy(WPARAM wParam, LPARAM lParam);

	void WMSize(WPARAM wParam, LPARAM lParam); //void Paint();

	HWND GetHWND() { return m_hwnd; }

	void WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam);

	static bool TerminateProcessByHWND(HWND hWnd);

	static bool GetClientRectAbs(HWND hWnd, RECT& rcCleintAbs, SCWindowAttr* pAttr=0);

	static void SetIconWnd(HWND hwnd);

	static void SetWindowSize(HWND hwnd, int widthWinCtrl, int heightWinCtrl);

	
	static void ReizeWnd(HWND hwnd, const SSizeDelta& delta); // int dx, int dy, int dw, int dh); //static void SizeForBackWnd(HWND hwnd, int iStep = 20, int iQuantityStep= 20, int iSleep= 15);

		/*
	//<Widnow Map
	void Map_WM_CLOSE(WPARAM wParam, LPARAM lParam);

	void Map_WM_DESTROY(WPARAM wParam, LPARAM lParam);

	void Map_WM_SIZE(WPARAM wParam, LPARAM lParam);

	void Map_WM_LBUTTONDOWN(WPARAM wParam, LPARAM lParam);
	*/
	//>Widnow Map
	static void MouseOp(HWND hwnd);
	static void ClickLButton(HWND hwnd);
	static bool ClickKey(HWND hwnd, int  vk);		
};

void MinimizeAllWnd();
void WindowChShow(HWND hwnd);
void WindowsToFile(HWND hwndParent, char *sz_file,  bool f_del_file=false); //YUIL 2017-11-14
HWND find_window(char *sz_part_text, char *sz_class);

struct S_find_child_window_param
{
	std_string sz_part_text;
	std_string sz_class;
	HWND hwnd;
	HWND hwndParent;
};

void AddChildWndToFile(HWND hwndChild,  char *sz_file);

HWND find_child_window(S_find_child_window_param& s_param); //HWND find_child_window(HWND hwndParent, char *sz_part_text, char *sz_class); //HWND find_child_window(S_find_child_window_param& s_param);

void CloseDestroyWindowByClass(char *sz_class, HWND hwndIgnore=0);

void TerminateProcessByClass(char *sz_class, HWND hwndIgnore=0);

struct SFindThreadParam
{

};

bool FindThread();

struct SHWNDList
{
	std::vector<HWND> list;
	bool Find(HWND hwnd);
};



#endif