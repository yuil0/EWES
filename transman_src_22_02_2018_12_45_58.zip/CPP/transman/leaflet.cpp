#include <memory.h>
#include <math.h>
#include "leaflet.h"
#include <minmax.h>

namespace Leaflet
{
	
	Point::Point(double xNew, double yNew)
	{
		x = xNew;

		y = yNew;
	}

	Point Transformation::_transform(Point point, double scale)
	{
		if (scale == 0) { scale = 1; }   //scale = scale || 1;

		double xNew = scale * (_a * point.x + _b);

		double yNew = scale * (_c * point.y + _d);

		point.x = xNew;

		point.y = yNew;

		return point;
	}

	Point SphericalMercator::project(const LatLng& latlng)
	{
		double d = M_PI / 180;

		double dMax = MAX_LATITUDE;
		
		double lat = max( min(dMax, latlng.lat), - dMax);

		double dSin = sin(lat * d);

		Point point( R * latlng.lng * d
			        ,R * log((1 + dSin) / (1 - dSin)) / 2);

		return point;
	}

}