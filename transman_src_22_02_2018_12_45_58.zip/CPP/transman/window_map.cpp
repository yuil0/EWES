#include <memory.h>
#include <windows.h>
#include "window.h"
#include "main.h"


void CWindow::Map_WM_CLOSE(WPARAM wParam, LPARAM lParam)
{

}

void CWindow::Map_WM_DESTROY(WPARAM wParam, LPARAM lParam)
{

}

void CWindow::Map_WM_SIZE(WPARAM wParam, LPARAM lParam)
{

}

void CWindow::Map_WM_LBUTTONDOWN(WPARAM wParam, LPARAM lParam)
{
	MessageBox(0, L"CWindow::Map_WM_LBUTTONDOWN", g_sz_app, 0);
}

