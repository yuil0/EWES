#include <memory.h>
#include <windows.h>
#include "draw_data.h"

#include "math_e.h"
#include "MesWnd.h"
#include "main.h"
#include "ini_file.h"
#include "..\\transman_srv\time_e.h"
#include "..\\transman_srv\str.h"
#include "login_wnd.h"

const double cd_max_dist_betw_point_shape_line = 400;
const char* csz_stop_load_log = "c:\\transman\\stop_load_log.txt";
const char* csz_stop_calc_log = "c:\\transman\\stop_calc_log.txt";

void SShapeLine::Clear() { memset(this, 0, sizeof(SShapeLine)); }

void SDrawData_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState)
{
	gMesWnd.Mes("SDrawData_MSSQL_MES_ERR(). ������ MS SQL: %s", eState== EMSSQLS_START ? "��� �����. ��������� ����� ������� ����� 3 ���" : sz_text);

	if (eState == EMSSQLS_START) { Sleep(3000); DestroyExit();}
}

void SDrawData_LoadStops_ADD(void *p_param, FldsPtr fp)
{
	SDrawData* p_this = (SDrawData*)p_param;

	if (p_this) { p_this->LoadStops_ADD(fp);	}
}

void SDrawData::LoadStops_ADD(FldsPtr fp)
{
	SStop o;

	long i_fields = fp->Count;

	_bstr_t bstr_id_picas_stop(fp->Item["id_picas_stop"]->Value);

	_bstr_t bstr_stop_id(fp->Item["stop_id"]->Value);

	_bstr_t bstr_stop_name(fp->Item["stop_name"]->Value);

	VARIANT v_stop_lat = fp->Item["stop_lat"]->Value;  //.decVal.Lo32 , scale

	VARIANT v_stop_lon = fp->Item["stop_lon"]->Value;  //.decVal.Lo32 , scale

	o.f_check_point = fp->Item["f_check_point"]->Value.boolVal == VARIANT_TRUE;
																																																													//<w1
	o.id_picas_stop = (char*)bstr_id_picas_stop; // v_id_picas_stop.decVal.Lo32;

	o.stop_id = (char*)bstr_stop_id;

	o.stop_name = (char*)bstr_stop_name;

	o.latlng.lat = v_stop_lat.decVal.Lo32 / pow(10, v_stop_lat.decVal.scale);

	o.latlng.lng = v_stop_lon.decVal.Lo32 / pow(10, v_stop_lon.decVal.scale);

	m_stops.push_back(o);
	//>w1
}

//////////////////////////////////////////////////////////////////////////////
void SDrawData::LoadStops()
{
	m_stops.clear();

	bool fExec = MSSQL_Exec("SELECT s.id_picas_stop, stop_id, stop_name, stop_lat, stop_lon, CONVERT(BIT, ISNULL((SELECT TOP 1 1 FROM dbo.check_points cp WHERE s.id_picas_stop = cp.id_picas_stop),0)) f_check_point FROM dbo.picas_stops s ORDER BY stop_name", SDrawData_LoadStops_ADD, SDrawData_MSSQL_MES_ERR, this);

	if (fExec)
	{ StopsReportToFile((char*)csz_stop_load_log); }
	else
	{
		gMesWnd.Mes("SDrawData::LoadStops(). ������ MSSQL");
	}
}

void SDrawData::StopsReportToFile(char *sz_file_name)
{
	FILE *fo = 0;
	fopen_s(&fo, sz_file_name, "wb");

	if (fo)
	{
		for (int i = 0; i < m_stops.size(); i++)
		{
			SStop& o = m_stops[i];

			fprintf(fo, "i:%d id_picas_stop:%s stop_name:%s lat:%g lng:%g prj:{%g %g} point:{%d %d}\r\n", i, o.id_picas_stop.c_str(), o.stop_name.c_str(), o.latlng.lat, o.latlng.lng, o.point.xPrj, o.point.yPrj, o.point.x, o.point.y);
		}
		fclose(fo);
	}

}

void SDrawData_LoadShapeLines_ADD(void *p_param, FldsPtr fp) { SDrawData* p_this = (SDrawData*)p_param; if (p_this) { p_this->LoadShapeLines_ADD(fp); } }

void SDrawData::LoadShapeLines_ADD(FldsPtr fp)
{

	SShapeLine o;

	long i_fields = fp->Count;

	_bstr_t bstr_route_long_name(fp->Item["route_long_name"]->Value);

	VARIANT v_from_lat = fp->Item["from_lat"]->Value;  //.decVal.Lo32 , scale

	VARIANT v_from_lon = fp->Item["from_lon"]->Value;  //.decVal.Lo32 , scale

	VARIANT v_from_sequence = fp->Item["from_sequence"]->Value; //.decVal.Lo32 //VT_I4;//3

	VARIANT v_to_lat = fp->Item["to_lat"]->Value;  //.decVal.Lo32 , scale

	VARIANT v_to_lon = fp->Item["to_lon"]->Value;  //.decVal.Lo32 , scale

	VARIANT v_to_sequence = fp->Item["to_sequence"]->Value; //.decVal.Lo32 //VT_I4;//3

	VARIANT v_direct = fp->Item["direct"]->Value; //.decVal.Lo32 //VT_I4;//3

	_bstr_t bstr_route_short_name(fp->Item["route_short_name"]->Value);

	/*FILE *fo = fopen("LoadShapes.txt", "wb");
	if (fo)
	{
	VARIANT&  v = v_id_shape_id;

	fprintf(fo,  "llVal=%d lVal=%d uiVal=%u ulVal=%u intVal=%d uintVal=%u iVal=%d %c%c", v.llVal, v.lVal, v.uiVal, v.ulVal, v.intVal, v.uintVal, v.iVal, 13,10);

	fclose(fo);
	}*/

	o.Clear();

	o.route_long_name = (char*)bstr_route_long_name;

	o.from.lat = v_from_lat.decVal.Lo32 / pow(10, v_from_lat.decVal.scale);

	o.from.lng = v_from_lon.decVal.Lo32 / pow(10, v_from_lon.decVal.scale);

	o.from_sequence = v_from_sequence.intVal;

	o.to.lat = v_to_lat.decVal.Lo32 / pow(10, v_to_lat.decVal.scale);

	o.to.lng = v_to_lon.decVal.Lo32 / pow(10, v_to_lon.decVal.scale);

	o.to_sequence = v_to_sequence.intVal;

	o.direct = v_direct.boolVal == VARIANT_TRUE;

	o.route_short_name = (char*)bstr_route_short_name;

	m_shape_lines.push_back(o);
}

//////////////////////////////////////////////////////////////////////////////
void SDrawData::LoadShapeLines()
{
	m_shape_lines.clear();

	if (m_f_shape_lines == false) { return; }

	char *sz_query = "select route_long_name , from_lat ,from_lon , from_sequence , to_lat , to_lon , to_sequence, direct,  route_short_name FROM dbo.picas_shape_lines";

	bool fExec = MSSQL_Exec(sz_query, SDrawData_LoadShapeLines_ADD, SDrawData_MSSQL_MES_ERR, this);

	if (fExec==false)
	{
		gMesWnd.Mes("SDrawData::LoadShapeLines(). ������ MSSQL");
	}
}

void SDrawData_LoadRoutes_ADD(void *p_param, FldsPtr fp) { SDrawData* p_this = (SDrawData*)p_param; if (p_this) { p_this->LoadRoutes_ADD(fp); } }

void SDrawData::LoadRoutes_ADD(FldsPtr fp)
{
	SRoute o;

	VARIANT v_id_picas_route = fp->Item["id_picas_route"]->Value; //.decVal.Lo32

	_bstr_t bstr_route_id(fp->Item["route_id"]->Value);

	_bstr_t bstr_agency_id(fp->Item["agency_id"]->Value);

	_bstr_t bstr_route_short_name(fp->Item["route_short_name"]->Value);

	_bstr_t bstr_route_long_name(fp->Item["route_long_name"]->Value);

	_bstr_t bstr_route_type(fp->Item["route_type"]->Value);

	VARIANT v_id_agent = fp->Item["id_agent"]->Value; //.decVal.Lo32
	
	o.id_picas_route = v_id_picas_route.decVal.Lo32;

	o.route_id = (char*)bstr_route_id;

	o.agency_id = (char*)bstr_agency_id;

	o.route_short_name = (char*)bstr_route_short_name;

	o.route_long_name = (char*)bstr_route_long_name;

	o.route_type = (char*)bstr_route_type;

	o.f_check_points = fp->Item["f_check_points"]->Value.intVal == 1;

	o.id_agent = v_id_agent.decVal.Lo32;
	
	m_routes.push_back(o);
}

//////////////////////////////////////////////////////////////////////////////
void SDrawData::LoadRoutes()
{
	m_routes.clear();

	const int ci_max = 1024;

	char sz_query[ci_max + 1]; 
	
	set_str(sz_query, ci_max, "SELECT id_picas_route, route_id, agency_id, dbo.FN_get_short_name(route_id, route_short_name)route_short_name, route_long_name, route_type, ISNULL((SELECT TOP 1 1 FROM dbo.check_points cp WHERE cp.id_picas_route = r.id_picas_route), 0) f_check_points"
	
		                         ", (SELECT id_agent FROM dbo.picas_agents a WHERE a.id = r.agency_id) id_agent "
		                         
		                         "FROM dbo.picas_routes r");

	EUserType eUserType = gLoginWnd.GetUserType();

	if (eUserType == EUT_DISP)
	{
		add_str(sz_query, ci_max, " WHERE id_picas_route IN (SELECT id_picas_route FROM dbo.user_route_binds WHERE id_user=");

		add_str(sz_query, ci_max, (char*)gLoginWnd.GetIdUser().c_str());

		add_str(sz_query, ci_max, ")");
	}

	bool fExec = MSSQL_Exec(sz_query, SDrawData_LoadRoutes_ADD, SDrawData_MSSQL_MES_ERR, this);

	if (fExec == false)
	{
		gMesWnd.Mes("SDrawData::LoadRoutes(). ������ MSSQL");
	}

}

void SDrawData_LoadZones_ADD(void *p_param, FldsPtr fp) { SDrawData* p_this = (SDrawData*)p_param; if (p_this) { p_this->LoadZones_ADD(fp); } }

void SDrawData::LoadZones_ADD(FldsPtr fp)
{
	SZone o;

	_bstr_t bstr_name(fp->Item["name"]->Value);

	VARIANT v_quantity = fp->Item["quantity"]->Value;  //intVal

	VARIANT v_latitude_0 = fp->Item["latitude_0"]->Value;

	VARIANT v_longitude_0 = fp->Item["longitude_0"]->Value;

	VARIANT v_latitude_1 = fp->Item["latitude_1"]->Value;

	VARIANT v_longitude_1 = fp->Item["longitude_1"]->Value;

	VARIANT v_latitude_2 = fp->Item["latitude_2"]->Value;

	VARIANT v_longitude_2 = fp->Item["longitude_2"]->Value;

	VARIANT v_latitude_3 = fp->Item["latitude_3"]->Value;

	VARIANT v_longitude_3 = fp->Item["longitude_3"]->Value;

	o.name = (char*)bstr_name;

	o.quantity = v_quantity.intVal;

	o.latlng_list[0].lat = v_latitude_0.decVal.Lo32 / pow(10, v_latitude_0.decVal.scale);

	o.latlng_list[0].lng = v_longitude_0.decVal.Lo32 / pow(10, v_longitude_0.decVal.scale);

	o.latlng_list[1].lat = v_latitude_1.decVal.Lo32 / pow(10, v_latitude_1.decVal.scale);

	o.latlng_list[1].lng = v_longitude_1.decVal.Lo32 / pow(10, v_longitude_1.decVal.scale);

	o.latlng_list[2].lat = v_latitude_2.decVal.Lo32 / pow(10, v_latitude_2.decVal.scale);

	o.latlng_list[2].lng = v_longitude_2.decVal.Lo32 / pow(10, v_longitude_2.decVal.scale);

	o.latlng_list[3].lat = v_latitude_3.decVal.Lo32 / pow(10, v_latitude_3.decVal.scale);

	o.latlng_list[3].lng = v_longitude_3.decVal.Lo32 / pow(10, v_longitude_3.decVal.scale);

	m_zones.push_back(o);

}

//////////////////////////////////////////////////////////////////////////////
void SDrawData::LoadZones()
{
	m_zones.clear();

	char* sz_query = "SELECT name, quantity, latitude_0, longitude_0, latitude_1, longitude_1, latitude_2, longitude_2, latitude_3, longitude_3 FROM dbo.zones";

	bool fExec = MSSQL_Exec(sz_query, SDrawData_LoadZones_ADD, SDrawData_MSSQL_MES_ERR, this);

	if (fExec == false)
	{
		gMesWnd.Mes("SDrawData::LoadZones(). ������ MSSQL");
	}

}

void SDrawData::ReadIni()
{
	CIniFile ini;

	char sz_val[MAX_PATH+1];
	
	m_f_shape_lines = false;

	if (ini.Get("C:\\transman\\transman.ini", "shape_lines", sz_val, MAX_PATH))
	{
		if (!stricmp(sz_val, "1")) { m_f_shape_lines = true; }
	}
}

void SDrawData::Load(RECT& rcWnd)
{
	unlink(csz_stop_load_log);
	unlink(csz_stop_calc_log);

	ReadIni();
	LoadRoutes();
	LoadStops();
	LoadShapeLines();            //Fill();
	LoadZones();            //m_control_panel.SetByExpand(rcWnd);
}

void AppendText(std_string& sz_query, char *sz_val, double x)
{
	sz_query.append(", "); sprintf(sz_val, "%g", x); sz_query.append(sz_val);
}

void SZone::Save()
{
	char sz_val[MAX_PATH + 1];

	std_string sz_query = "INSERT dbo.zones(dt_created, name, quantity, latitude_0, longitude_0, x_0, y_0, latitude_1, longitude_1, x_1, y_1, latitude_2, longitude_2, x_2, y_2, latitude_3, longitude_3, x_3, y_3) SELECT GETDATE() ";

	sz_query.append(", N'"); sz_query.append(name.c_str()); sz_query.append("'");

	sz_query.append(", "); itoa(quantity, sz_val, 10); sz_query.append(sz_val);

	for (int i = 0; i < cl_max_zone_points; i++)
	{
		Leaflet::LatLng& o = latlng_list[i];

		AppendText(sz_query, sz_val, o.lat);

		AppendText(sz_query, sz_val, o.lng);

		double x, y;

		math_e::LatitudeLongitudeToXY(o.lat, o.lng, x, y);
			
		AppendText(sz_query, sz_val, x);
			
		AppendText(sz_query, sz_val, y);
	}

	FILE *fo = fopen("c:\\transman\\SZone_Save.txt", "wb");
	if (fo)
	{ fprintf(fo, "sz_query:%s", sz_query.c_str()); fclose(fo); }

	bool fExec = MSSQL_Exec((char*)sz_query.c_str(), 0, SDrawData_MSSQL_MES_ERR, this);

	if (fExec == false)
	{
		gMesWnd.Mes("SZone::Save(). ������ MSSQL");
	}

}

void SDrawData::CalcStops(double zoom)
{
	for (int i = 0; i < m_stops.size(); i++)
	{
		SStop& o = m_stops[i];

		o.point.SetByLatLng(o.latlng, zoom);
	}

	StopsReportToFile((char*)csz_stop_calc_log);
}

void SDrawData::CalcShapeLines(double zoom)
{
	for (int i = 0; i < m_shape_lines.size(); i++)
	{
		SShapeLine& o = m_shape_lines[i];

		o.from_point.SetByLatLng(o.from, zoom);

		o.to_point.SetByLatLng(o.to, zoom);
	}
}


void SDrawData::CalcZones(double zoom)
{
	for (int i = 0; i < m_zones.size(); i++)
	{
		SZone& o = m_zones[i];

		for (int z = 0; z < o.quantity; z++)
		{
			o.point_list[z].SetByLatLng(o.latlng_list[z], zoom);
		}
	}
}

void SDrawData::Calc(double zoom)
{
	CalcStops(zoom);
	CalcShapeLines(zoom);
	CalcZones(zoom);
}

void SDrawData::DrawStops(HDC hdc, const SPointInt& origin, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list, int& index_sel_stop, HGDIOBJ* pen_brush) //, HPEN hpenSel)
{
	if (m_index_sel_stop== 1) { return; } //YUIL ����

	FILE *fo=0;

	if (g_f_log_draw_objects)
	{
		fopen_s(&fo, csz_log_draw_objects,"ab");
	}

	if (fo) { fprintf(fo, "================================================================\r\n"); }

	for (int i = 0; i < m_stops.size(); i++)
	{
		SStop& o = m_stops[i];              //SetViewportOrgEx(_In_  HDC     hdc,_In_  int     X,_In_  int     Y,_Out_ LPPOINT lpPoint);

		if (m_index_sel_stop)
		{
			int sel_index = m_index_sel_stop - 2;

			if (sel_index < 0) { return; }

			const char *p_sel = m_stops[sel_index].stop_name.c_str();

			const char *p = o.stop_name.c_str();

			if (stricmp(p_sel, p)) { continue; }
		} //YUIL ���� ������  ������

		int x = o.point.x + origin.x;
		int y = o.point.y + origin.y;

		if (fo)
		{
			struct tm tm;
			time_e::GetCurLocalDateTime(tm);
			fprintf(fo, "%04d-%02d-%02dT%02d:%02d:%02d stop[%04d] stop_name:'%s' draw_point:{%d %d} src_point:{%d %d} origin:{%d %d}\r\n", tm.tm_year, tm.tm_mon, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec, i, o.stop_name.c_str(), x, y, o.point.x, o.point.y, origin.x, origin.y);
		}

		if (IsHide(x, y, sizeWnd)) { continue; }

		HPEN hpenPrev;
		
		bool fSel = index_sel_stop >= 2 && i == index_sel_stop;

		if (fSel) { hpenPrev = (HPEN)SelectObject(hdc, pen_brush[EPB_PEN_SEL]); } //hpenSel
		else
		{
			SelectObject(hdc, pen_brush[o.f_check_point ? EPB_PEN_CHECK_POINT : EPB_PEN_STOP]);

			SelectObject(hdc, pen_brush[o.f_check_point ? EPB_BRUSH_CHECK_POINT : EPB_BRUSH_STOP]);			
		}

		BOOL fRes = Ellipse(hdc, x - c_draw_radius, y - c_draw_radius, x + c_draw_radius, y + c_draw_radius);

		if (fSel) { SelectObject(hdc, hpenPrev); }

		//if (m_f_sel_mes)
		{
			bool f_in= math_e::inRectInt(clientMouse.x, clientMouse.y, x - c_draw_radius, y - c_draw_radius, x + c_draw_radius, y + c_draw_radius);

			if (f_in)
			{																	//sprintf(sz_text, "",  o.route_long_name);
				if (index_sel_stop == 1)
				{
					index_sel_stop = 2 + i;
				}

				sel_point.Set(x + 2 * c_draw_radius, y - c_draw_radius);

				char sz_val[MAX_PATH + 1];

				sprintf(sz_val, "%s : %s", o.f_check_point ? "�����. �����" : "���������", o.stop_name.c_str()); //TextOutA(hdc, xFrom + 2*c_draw_radius, yFrom - c_draw_radius, p_name, strlen(p_name));

				sel_str_list.push_back(sz_val);  //strcat(sel_text, sz_val);
			}
		}
	}

	if (fo)
	{ fclose(fo); }
}

void DrawPoint(HDC hdc, int x, int y)
{
	BOOL fRes = Ellipse(hdc, x - c_draw_radius, y - c_draw_radius, x + c_draw_radius, y + c_draw_radius);
}

void SDrawData::DrawShapeLines(HDC hdc, const SPointInt& origin, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list, HGDIOBJ PenPoint, HGDIOBJ PenLine) //char *sel_text)
{
	if (m_index_sel_route == 1) {return;} //YUIL ����

	for (int i = 0; i < m_shape_lines.size(); i++)
	{
		SShapeLine& o = m_shape_lines[i];              //SetViewportOrgEx(_In_  HDC     hdc,_In_  int     X,_In_  int     Y,_Out_ LPPOINT lpPoint);

		if (m_index_sel_route)
		{
			int sel_index = m_index_sel_route - 2;

			if (sel_index < 0) { return; }
			
			const char *p_sel= m_routes[sel_index].route_short_name.c_str();

			const char *p= o.route_short_name.c_str();

			if (stricmp(p_sel, p)) { continue; }
		} //YUIL ���� ������  ������

		int xFrom = o.from_point.x + origin.x;
		int yFrom = o.from_point.y + origin.y;

		int xTo = o.to_point.x + origin.x;
		int yTo = o.to_point.y + origin.y;

		bool fHideFrom = IsHide(xFrom, yFrom, sizeWnd);
		bool fHideTo = IsHide(xTo, yTo, sizeWnd);

		SelectObject(hdc,  PenPoint);

		if (!fHideFrom) { DrawPoint(hdc, xFrom, yFrom); }
		if (!fHideTo) { DrawPoint(hdc, xTo, yTo); }


		if (!fHideFrom && !fHideTo)
		{ 
			//double dist =  math_e::dist2D(xFrom, yFrom, xTo, yTo);
			
			if (o.to_sequence>=0)// && dist < cd_max_dist_betw_point_shape_line)
			{
				SelectObject(hdc, PenLine);
				DrawLine(hdc, xFrom, yFrom, xTo, yTo);
			}
			
		}

		if (!fHideFrom || !fHideTo) 
		{ 
			if (m_f_sel_mes)
			{
				bool f_in_from = math_e::inRectInt(clientMouse.x, clientMouse.y, xFrom - c_draw_radius, yFrom - c_draw_radius, xFrom + c_draw_radius, yFrom + c_draw_radius);
				bool f_in_to = math_e::inRectInt(clientMouse.x, clientMouse.y, xTo - c_draw_radius, yTo - c_draw_radius, xTo + c_draw_radius, yTo + c_draw_radius);

				if (f_in_from) 
				{																	//sprintf(sz_text, "",  o.route_long_name);
					sel_point.Set(xFrom + 2 * c_draw_radius, yFrom - c_draw_radius);

					char sz_val[MAX_PATH+1];

					sprintf(sz_val, "������� %s : %s %s: %d", o.route_short_name.c_str(), o.direct?"����.":"�����.",  o.route_long_name.c_str(), o.from_sequence); //TextOutA(hdc, xFrom + 2*c_draw_radius, yFrom - c_draw_radius, p_name, strlen(p_name));

					sel_str_list.push_back(sz_val);  //strcat(sel_text, sz_val);
				}
			}
		}

	}
}

void SZone::Draw(HDC hdc, const SPointInt& origin, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list)
{
	int q = quantity; // point_list.size();

	if (q > cl_max_zone_points) { q = cl_max_zone_points; }

	POINT ap[cl_max_zone_points];

	for (int i = 0; i < q; i++)
	{
		ap[i].x = point_list[i].x + origin.x;
		ap[i].y = point_list[i].y + origin.y;
	}
	
	for (int i = 0; i < q; i++)
	{
		int i_next = i == q - 1 ? 0 : i + 1;

		DrawPoint(hdc, ap[i].x, ap[i].y);

		if (q) { DrawLine(hdc, ap[i].x, ap[i].y, ap[i_next].x, ap[i_next].y); }		


		bool f_in = math_e::inRectInt(clientMouse.x, clientMouse.y, ap[i].x - c_draw_radius, ap[i].y - c_draw_radius, ap[i].x + c_draw_radius, ap[i].y + c_draw_radius);

		if (f_in)
		{		
			sel_point.Set(ap[i].x + 2 * c_draw_radius, ap[i].y - c_draw_radius);

			char sz_val[MAX_PATH + 1];

			sprintf(sz_val, "����� �������� : %s", name.c_str());

			sel_str_list.push_back(sz_val);
		}

	}
	
}

void SDrawData::DrawZones(HDC hdc, const SPointInt& origin, const SPointInt& sizeWnd, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list)
{
	//if (m_flag_no_draw_zones) { return; }

	if (m_index_sel_zone == 1) { return; } //YUIL ����

	for (int i = 0; i < m_zones.size(); i++)
	{
		if (m_index_sel_zone)
		{
			int sel_index = m_index_sel_zone - 2;

			if (sel_index < 0) { return; }

			const char *p_sel = m_zones[sel_index].name.c_str();

			const char *p = m_zones[i].name.c_str();

			if (stricmp(p_sel, p)) { continue; }
		} //YUIL ���� ������  ������

		m_zones[i].Draw(hdc, origin, sizeWnd, clientMouse, sel_point, sel_str_list);
	}

}

void DrawLine(HDC hdc, int x, int y, int xPrev, int yPrev)
{
	MoveToEx(hdc, x, y, NULL);

	LineTo(hdc, xPrev, yPrev);
}

/*void SDrawData::AddHideRect(const SHideRect& sRect)
{
	m_hide_rects.push_back(sRect);
}*/

bool SDrawData::IsHide(int x, int y, const SPointInt& sizeWnd)
{
	if (x<0 || y<0 || x>sizeWnd.x || y>sizeWnd.y) { return true; }


	//������ �����
	if (math_e::inRectInt(x, y, 0, 0, 36, sizeWnd.y)) { return true; }

	//����� ������ ������
	if (math_e::inRectInt(x, y, 0, 0, sizeWnd.x, 8)) { return true; }

	//������ ��������� ������� ������ �� ������� ����. ����� ����.
	if (math_e::inRectInt(x, y, sizeWnd.x - (1736 - 1665), 7, sizeWnd.x - (1736 - 1725), 28)) { return true; }

	//������ ����. ����� ����.
	if (math_e::inRectInt(x, y, sizeWnd.x - (1716 - 1668), 38, sizeWnd.x - (1716 - 1704), 74)) { return true; }

	//������. �������� �����. ���� ���.
	if (math_e::inRectInt(x, y, sizeWnd.x - (1716 - 1246), sizeWnd.y - (667 - 650), sizeWnd.x, sizeWnd.y)) { return true; }

	//���������� ���������. ��� ���.
	if (math_e::inRectInt(x, y, 0, sizeWnd.y - (667 - 640), 500, sizeWnd.y)) { return true; }

	//�������. ��� ���.
	if (math_e::inRectInt(x, y, 0, sizeWnd.y - (672 - 622), 70, sizeWnd.y)) { return true; }

	/*
	for (int i = 0; i < m_hide_rects.size(); i++)
	{
		SHideRect& o = m_hide_rects[i];              //SetViewportOrgEx(_In_  HDC     hdc,_In_  int     X,_In_  int     Y,_Out_ LPPOINT lpPoint);
		
		SPointInt pn = o.point;

		if (math_e::inRectInt(x, y, pn.x, pn.y, pn.x + o.size.x, pn.y + o.size.y)) { return true; }
	}*/

	return false;
}

void SZone::Clear() 
{ 
	memset(this, 0, sizeof(SZone)); 

	name = "";
}

bool SZone::FindPoint(int x, int y)
{
	bool fFound=false;

	for (int i=0; fFound==false && i<quantity; i++)
	{
		if (math_e::dist2D(x, y, point_list[i].x, point_list[i].y) <= 2*c_draw_radius) {fFound=true;}
	}

	return fFound;
}

bool SZone::AddPoint(int x, int y, double zoom)
{
	if (quantity >= cl_max_zone_points) { return false; }

	if (FindPoint(x, y))  { return false; }

	point_list[quantity].Set(x, y);

	point_list[quantity].GetLatLng(latlng_list[quantity], zoom);	

	quantity++;

	return true;
}

bool SDrawData::FindZone(char *sz_name, SZone* *p_zone)
{
	bool  fFound = false;

	for (int i = 0; fFound == false && i < m_zones.size(); i++)
	{
		if (!stricmp(m_zones[i].name.c_str(), sz_name)) 
		{ 
			fFound=true; 

			if (p_zone) { *p_zone = &m_zones[i]; } 
		}
	}

	return fFound;
}

/*
void SControlPanel::Draw(HDC hdc, HGDIOBJ *pen_brush)
{
	SelectObject(hdc, pen_brush[EPB_PEN_PANEL_BORDER]);

	SelectObject(hdc, pen_brush[EPB_BRUSH_PANEL]);

	Rectangle(hdc, point.x, point.y, point.x + size.x, point.y + size.y);
}

void SControlPanel::SetByExpand(RECT& rcWnd)
{
	point.y = cl_panel_y;

	size.y = cl_panel_h;

	if  (f_expand)
	{ 
		size.x = cl_panel_expand_w;
	}
	else
	{
		size.x = cl_panel_no_expand_w;
	}

	point.x = rcWnd.right - size.x - cl_panel_ident;
}

bool SControlPanel::In(const SPointInt& point_new, RECT& rcWnd)
{
	bool f_in = math_e::inRectInt(point_new.x, point_new.y, point.x, point.y, point.x + size.x, point.y + size.y);
	if (f_in)
	{
		f_expand = f_expand ? false : true;

		SetByExpand(rcWnd);
	}

	return f_in;
}
*/
/*
void SDrawData::Fill()
{
	for (int i = 0; i < m_shapes.size(); i++)
	{                           ////SShape& o = m_shapes[i];		
		FindPrev(i); //FindNext(o, i); , &o.p_prev
	}
}

void SDrawData::FindPrev(int index) //long id_prev, SShape* *p_prev)
{
	bool fFound = false;

	SShape& shape = m_shapes[index];

	for (int i = index + 1; fFound==false && i < m_shapes.size(); i++)
	{
		//if (i == index) { continue; }

		SShape& o = m_shapes[i];

		if (o.id_picas_shape == shape.id_prev) { fFound = true; shape.p_prev = &o; }
	}
}
*/
/*
void SDrawData::FindNext(SShape& sShape, int indexShape)
{
	for (int i = indexShape+1; i < m_shapes.size(); i++)
	{
		SShape& o = m_shapes[i];


		
		if (o.id_shape_id == sShape.id_shape_id)
		{                                                                  //if (o.shape_pt_sequence - sShape.shape_pt_sequence == 1) { sShape.p_next = &o; }
			if (sShape.shape_pt_sequence - o.shape_pt_sequence == 1)
			{
				sShape.p_prev = &o;
			}
		}
	}
}*/

/* void SDrawData::AddHideRects()
{
	SHideRect sRect;
	
	
	//sRect.Set(0, 0, 1807,  8); AddHideRect(sRect);  //������ ������
	//sRect.Set(1737, 8, 1796,  28); AddHideRect(sRect); //������  �� �������  ����, ��������� ������ ���� ������. ������ ������.
	//sRect.Set(1759, 39, 1798, 74); AddHideRect(sRect); //������  �����. ������ ������.
	//sRect.Set(1337, 625, 1809, 641); AddHideRect(sRect); //Leafet �������� ����. ����� ������.
	//sRect.Set(0, 614, 480, 640); AddHideRect(sRect); //���������� ��������� . ����� �����.
	//sRect.Set(0, 591, 68, 611); AddHideRect(sRect); //�������. ����� �����.
	//sRect.Set(0, 0, 36, 642); AddHideRect(sRect); //������ �����
}
*/