#include <memory.h>
#include <windows.h>
#include "draw_wnd.h"
#include "leaflet.h"
#include "math_e.h"
#include "main.h"
#include "ini_file.h"
#include "MesWnd.h"
#include "BookMarks.h"

#ifndef GWL_USERDATA
#define GWL_USERDATA        (-21)
#endif

#ifndef GWL_WNDPROC
#define GWL_WNDPROC         (-4)
#endif

void CDrawWnd_MSSQL_MES_ERR(void *p_param, char *sz_text, EMSSQLState eState) { gMesWnd.Mes("CDrawWnd_MSSQL_MES_ERR(). ������ MS SQL: %s", sz_text); }

HWND g_hwndDraw=0;

CDrawWnd::CDrawWnd() { memset(this, 0, sizeof(CDrawWnd)); } /*m_fInit=false;m_hInstance=hInstance;m_fInit=true;*///CDrawWnd::~CDrawWnd(){}

void CDrawWnd::Destroy()
{
	DestroyPenBrush();
	
	m_DrawATE_3.Close();

	DestroyWindow(m_hwnd);

	DestroyWindow(g_hWndMap); //YUIL 2017-10-18 //����. ����� ���� : IE
}

void CDrawWnd::WMClose(WPARAM wParam, LPARAM lParam)
{
	Destroy();	
}

void CDrawWnd::WMDestroy(WPARAM wParam, LPARAM lParam)
{
	//ExitProcess(1);
}

void CDrawWnd::WMSize(WPARAM wParam, LPARAM lParam)
{
	int new_width = lParam & 0xFFFF; //The low - order word of lParam specifies the new width of the client area.	
	int new_height= (lParam>>2) & 0xFFFF; //The high - order word of lParam specifies the new height of the client area.
	
	Paint();
}

void CDrawWnd::WM__LBUTTONDOWN(WPARAM wParam, LPARAM lParam)
{	
	 ////MessageBox(0, L"CDrawWnd::WM__LBUTTONDOWN", g_sz_app, 0);	
}

LRESULT CALLBACK DrawWndProc(
  HWND   hwnd,
  UINT   uMsg,
  WPARAM wParam,
  LPARAM lParam )
{
	CDrawWnd *p_wnd= (CDrawWnd*)GetWindowLong(hwnd, GWL_USERDATA);
	
	bool fMapWnd = uMsg & (1 << 16);
	switch (uMsg)
	{
	case WM_CLOSE: if (p_wnd) { p_wnd->WMClose(wParam, lParam); } break;
	case WM_DESTROY: if (p_wnd) { p_wnd->WMDestroy(wParam, lParam); } break;
	//case WM_SIZE: if (p_wnd) { p_wnd->WMSize(wParam, lParam); } break;
	case WM_LBUTTONDOWN: 
		if (p_wnd) 
		{ 
			p_wnd->WM__LBUTTONDOWN(wParam, lParam); 
		} 
		break;
	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}

	return 1;
}

bool CDrawWnd::RegClass(HINSTANCE hInstance)
{
	//HICON hIcon= (HICON)LoadImage(hInstance, L"transman.ico", IMAGE_ICON,  128, 128, LR_LOADFROMFILE);
	//HBRUSH hBrush=CreateSolidBrush(0xFFFFFF);

	WNDCLASS wc;

	// Register the main window class. 
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = (WNDPROC)DrawWndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = 0; // (HBRUSH)GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName = L"MainMenu";
	wc.lpszClassName = L"CDrawWnd";
	
	bool f_res = RegisterClass(&wc);

	/*
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = DrawWndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;  // wc.hbrBackground = 0;// hBrush; // (HBRUSH) GetStockObject(WHITE_BRUSH);;//wc.lpszMenuName;
	wc.lpszClassName = L"CDrawWnd";

	bool f_res = RegisterClassEx(&wc);
	*/
	//DeleteObject(hBrush);
	//DeleteObject(hIcon);

	return f_res;
}

void CDrawWnd::ReadIni()
{
	CIniFile ini;
	char sz_val[MAX_PATH+1];
	m_map_object_shift_y=0;
	if  (ini.Get("C:\\transman\\transman.ini", "map_object_shift_y", sz_val,  MAX_PATH)==false) {gMesWnd.Mes("CDrawWnd::ReadIni(). ������ ������ ini"); return;}

	m_map_object_shift_y = atoi(sz_val);
}

bool CDrawWnd::Create(HINSTANCE hInstance, wchar_t* wsz_name, HWND hWndParent, HMENU hMenu,  bool fVisible)
{
	/*if (g_i_user_interface==1) 
	{
		RECT rc_map;
		RECT crc_map;
		if (GetWindowRect(g_hWndMap, &rc_map)==FALSE) {return false;}
		if (GetClientRect(g_hWndMap, &crc_map)==FALSE) {return false;}

		//m_i_shift_origin_y  = (rc_map.bottom - rc_map.top) - (crc_map.bottom - crc_map.top);
	}*/

	RegClass(hInstance);

	RECT rcCleintAbs;
	CWindow::GetClientRectAbs(g_hWndMap, rcCleintAbs);
	
	/*
	int w = 100; // rcCleintAbs.right - rcCleintAbs.left;
	int h = 100; //rcCleintAbs.bottom - rcCleintAbs.top;
	int x = 0; // rcCleintAbs.left;
	int y = GetSystemMetrics(SM_CYSCREEN) - 400; //rcCleintAbs.top;
	*/
	int w =  rcCleintAbs.right - rcCleintAbs.left;
	int h = rcCleintAbs.bottom - rcCleintAbs.top;
	int x = rcCleintAbs.left;
	int y = rcCleintAbs.top;

	/*m_rc.left = x;
	m_rc.top = y;
	m_rc.right = x + w;
	m_rc.top = y + h;*/
	
	hWndParent = (HWND)0;
	hMenu = (HMENU)0;

	DWORD dwStyleEx = WS_EX_LAYERED | // Layered Windows
		WS_EX_TRANSPARENT | // Don't hittest this window
		WS_EX_TOOLWINDOW |
		WS_EX_TOPMOST;
	DWORD dwStyle = WS_POPUP | WS_VISIBLE;

	m_hwnd = CreateWindowEx(dwStyleEx, L"CDrawWnd", wsz_name, dwStyle, x, y, w, h, hWndParent, hMenu, hInstance, 0); //transman_wnd_class

	g_hwndDraw= m_hwnd;

	if (m_hwnd)
	{
		SetWindowLong(m_hwnd, GWL_WNDPROC, (LONG)DrawWndProc);
		SetWindowLong(m_hwnd, GWL_USERDATA, (LONG)this);		
		
		SetLayeredWindowAttributes(m_hwnd, 0, 255, LWA_ALPHA); //m_object_list=
		
		CreatePenBrush();

		ReadIni();

		m_tool = EDWT_NONE; // EDWT_LINE_MEASURE_MOUSE;  // EDWT_LINE_MEASURE;

		m_fDrawObject = true;

		RECT crc = { 0, 0, w,  h };

		m_data.Load(crc); //LoadStaticObject(); //YUIL �� ����� �������

		EnableAllCarTypes();

		m_DrawATE_3.Open();

		Paint();

		ShowWindow(m_hwnd, fVisible ? SW_SHOW : SW_HIDE);
	}	

	return m_hwnd != 0;
}

void CDrawWnd::EnableAllCarTypes()
{
	for (int i = 0; i < (int)ECT_QUANTITY; i++)
	{
		m_drawCarTypes[i] = true;
	}
}

void CDrawWnd::CreatePenBrush()
{
	m_pen_brush[EPB_PEN_SEL] = CreatePen(PS_SOLID, 0, 0xFFFFFF);

	m_pen_brush[EPB_PEN_CENTER] = CreatePen(PS_SOLID, 0, 0x0000FF);

	m_pen_brush[EPB_PEN_ROUTE_POINT] = CreatePen(PS_SOLID, 0, 0x007777);// 0x00D0D0);
	
	m_pen_brush[EPB_PEN_ROUTE_LINE] = CreatePen(PS_SOLID, 4, 0x00F0F0);// 0x00D0D0);	

	m_pen_brush[EPB_BRUSH_ROUTE_POINT] = CreateSolidBrush(0x00F0F0);

	m_pen_brush[EPB_PEN_STOP] = CreatePen(PS_SOLID, 0, 0x005555);
	
	m_pen_brush[EPB_BRUSH_STOP] = CreateSolidBrush(0x00DDDD);

	m_pen_brush[EPB_PEN_CHECK_POINT] = CreatePen(PS_SOLID, 0, 0x0000DD);

	m_pen_brush[EPB_BRUSH_CHECK_POINT] = CreateSolidBrush(0x0080DD);
	
	m_pen_brush[EPB_PEN_CAR] = CreatePen(PS_SOLID, 0, 0x400040);

	m_pen_brush[EPB_PEN_CAR_LIGHT] = CreatePen(PS_SOLID, 0, 0xC000C0);	

	m_pen_brush[EPB_BRUSH_CAR] = CreateSolidBrush(0x800080);
	
	m_pen_brush[EPB_BRUSH_CAR_LIGHT] = CreateSolidBrush(0xC000C0);	

	//<ZONE
	m_pen_brush[EPB_PEN_ZONE] = CreatePen(PS_DOT, 3, 0x009000);

	m_pen_brush[EPB_BRUSH_ZONE] = CreateSolidBrush(0x009000);
	//>ZONE

	//<ZONE_NEW
	m_pen_brush[EPB_PEN_ZONE_NEW] = CreatePen(PS_DOT, 3, 0x809000);

	m_pen_brush[EPB_BRUSH_ZONE_NEW] = CreateSolidBrush(0x809000);
	//>ZONE_NEW

	//<ANSWER_USER
	m_pen_brush[EPB_PEN_ANSWER_USER] = CreatePen(PS_SOLID, 0, 0x8080E0);

	m_pen_brush[EPB_BRUSH_ANSWER_USER] = CreateSolidBrush(0x8080E0);	
	//ANSWER_USER>

	m_pen_brush[EPB_PEN_TROL] = CreatePen(PS_SOLID, 0, 0xC06000);
	m_pen_brush[EPB_BRUSH_TROL] = CreateSolidBrush(0xE08000);

	m_pen_brush[EPB_PEN_BUS] = CreatePen(PS_SOLID, 0, 0x2020A0);
	m_pen_brush[EPB_BRUSH_BUS] = CreateSolidBrush(0x0000E0);

	m_pen_brush[EPB_PEN_TRAM] = CreatePen(PS_SOLID, 0, 0x004000);
	m_pen_brush[EPB_BRUSH_TRAM] = CreateSolidBrush(0x208040);

	m_pen_brush[EPB_PEN_MINIBUS] = CreatePen(PS_SOLID, 0, 0x202080);
	m_pen_brush[EPB_BRUSH_MINIBUS] = CreateSolidBrush(0x6060C0);

	m_pen_brush[EPB_PEN_LIM_MOB] = CreatePen(PS_SOLID, 0, 0x606000);
	m_pen_brush[EPB_BRUSH_LIM_MOB] = CreateSolidBrush(0x808000);
 
}

void CDrawWnd::DestroyPenBrush()
{
	for (int i = 0; i < (int)EPB_QUNATITY; i++)
	{
		DeleteObject(m_pen_brush[i]);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////
// YUIL ����� ������ ��� �������
void CDrawWnd::PaintOp(HDC hdc)
{
	BOOL fRes  = PrintWindow(g_hWndMap, hdc, PW_CLIENTONLY); //gWndMain.GetHWND()//hChieldTop
	
	DrawObjects(hdc);
	
	DrawObjectInfo(hdc);

	DrawTool(hdc);	
	
	//m_data.m_control_panel.Draw(hdc, m_pen_brush);

}

///////////////////////////////////////////////////////////////////////////////////////////////
void CDrawWnd::Paint()
{
	HWND hWnd = GetHWND(); 

	RECT cr;
	if (GetClientRect(hWnd, &cr) == false) { return; }
	HDC hdc = GetDC(hWnd);
	
	//PaintOp(hdc);
	
	HDC hMem = CreateCompatibleDC(hdc);
	HBITMAP memBM = CreateCompatibleBitmap(hdc, cr.right+2, cr.bottom + 2);
	SelectObject(hMem, memBM);

	
	PaintOp(hMem);

	BitBlt(hdc, -1, -1, cr.right, cr.bottom, hMem, 0, 0, SRCCOPY);

	DeleteObject(memBM);
	DeleteObject(hMem);
	
	ReleaseDC(hWnd, hdc);
}

void CDrawWnd::ReportChSizeToFile(char *sz_file)
{
	RECT rc;

	BOOL fGet = GetWindowRect(g_hWndMap, &rc);

	if (fGet == false) { return; }

	FILE *fo = fopen(sz_file,  "wb");
	if (fo)
	{		
		int w = rc.right - rc.left;
		
		int h = rc.bottom - rc.top;

		fprintf(fo, "wnd_size={%4d %4d}%c%c", w, h, 13, 10);

		fprintf(fo, "rostov_center={%4d %4d}%c%c", m_center.x, m_center.y, 13, 10);

		double kw = ((double)w) / ((double)m_center.x);
		double kh = ((double)h) / ((double)m_center.y);

		fprintf(fo, "relative_wnd_to_center={%g %g}%c%c", kw, kh, 13, 10);

		fclose(fo);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////
void CDrawWnd::SetPosSizeByMapWnd()
{
	RECT rcCleintAbs;
	CWindow::GetClientRectAbs(g_hWndMap, rcCleintAbs);

	BOOL bRepaint = TRUE;
	int w = rcCleintAbs.right - rcCleintAbs.left - m_draw_wnd_x_shift;
	int h = rcCleintAbs.bottom - rcCleintAbs.top;
	
	int x = rcCleintAbs.left + m_draw_wnd_x_shift;
	
	MoveWindow(GetHWND(), x, rcCleintAbs.top, w, h,  bRepaint);


	SetViewOrigin(); 

	CalcCoordObject();  	
}

void CDrawWnd::CalcCoordObject()
{
	m_data.Calc(m_zoom);

	m_DrawATE_3.Calc(m_zoom, m_viewOrigin);
}

//	m_centerLeaflet
void CDrawWnd::CalcCenter(CMapAddr& mapAddr, bool fFirst)
{
	Leaflet::LatLng latlng;

	latlng.lat = mapAddr.GetParam().latitude;

	latlng.lng = mapAddr.GetParam().longitude;

	double zoom = mapAddr.GetParam().magnify;

	m_centerLeaflet.SetByLatLng(latlng, zoom);
									
	if (fFirst) { m_center = m_centerLeaflet; }

	m_zoom = zoom;

	/*
	unlink("center_bounds.txt");

	FILE *fo = fopen("center_bounds.txt", "wb");
	if (fo)
	{
		fprintf(fo, "point= {%g  %g}%c%c", point.x, point.y, 13, 10); //fprintf(fo, "point= {%g  %g} {%g  %g}%c%c", bounds.min.x, bounds.min.y, bounds.max.x, bounds.max.y, 13, 10);

		fclose(fo);
	}  */
}

void CDrawWnd::SetViewOrigin() //int xFix, int yFix)
{
	RECT rc;

	GetWindowRect(GetHWND(), &rc);

	int w = rc.right - rc.left;

	int h = rc.bottom - rc.top;

	m_size.Set(w, h);

	//int wValid = (int)(((double)point.x) * 2.01763); //��� ����������� �������  ���� �����

	//int hValid = (int)(((double)point.y) * 1.96927);
	
	//SPointInt pointFix(-13, -32);  //zoom==3

	m_viewOrigin.x = w / 2 - m_centerLeaflet.x;// +xFix;

	m_viewOrigin.y = h / 2 - m_centerLeaflet.y - m_map_object_shift_y; // - m_i_shift_origin_y;// + yFix;
}


/*
void SDrawObject::Draw(HDC hdc, HGDIOBJ *pen_brush)
{
	SelectObject(hdc, pen_brush[EPB_PEN_ROUTE_POINT]);
	
	SelectObject(hdc, pen_brush[EPB_BRUSH_ROUTE_POINT]);

	int x0 = x - rc.left;

	int y0 = y - rc.top;

	BOOL fRes = Ellipse(hdc, x - c_draw_radius, y - c_draw_radius, x + c_draw_radius, y + c_draw_radius); //Rectangle(hdc, draw_pn.x - c_radius, draw_pn.y - c_radius, draw_pn.x + c_radius, draw_pn.y + c_radius);

	//Ellipse(hdc, draw_pn.x - c_draw_radius, draw_pn.y - c_draw_radius, draw_pn.x + c_draw_radius, draw_pn.y + c_draw_radius); //Rectangle(hdc, draw_pn.x - c_radius, draw_pn.y - c_radius, draw_pn.x + c_radius, draw_pn.y + c_radius);
}*/


void CDrawWnd::DrawCenter(HDC hdc)
{
	int x = m_center.x + m_viewOrigin.x;

	int y = m_center.y + m_viewOrigin.y;

	SelectObject(hdc, m_pen_brush[EPB_PEN_CENTER]);

	MoveToEx(hdc, x - 2 * c_draw_radius, y, NULL);

	LineTo(hdc, x + 2 * c_draw_radius + 1, y);

	MoveToEx(hdc, x, y - 2 * c_draw_radius, NULL);

	LineTo(hdc, x, y + 2 * c_draw_radius + 1); //BOOL fRes = Ellipse(hdc, x - c_draw_radius, y - c_draw_radius, x + c_draw_radius, y + c_draw_radius); //Rectangle(hdc, draw_pn.x - c_radius, draw_pn.y - c_radius, draw_pn.x + c_radius, draw_pn.y + c_radius);
}

void CDrawWnd::SelectGDIObjects(HDC hdc, ETypeDrawObject type)
{
	if (type == ETDO_ROUTE_POINT)
	{
		SelectObject(hdc, m_pen_brush[EPB_BRUSH_ROUTE_POINT]);
	}
	else
	/*if (type == ETDO_STOP)
	{
		SelectObject(hdc, m_pen_brush[EPB_PEN_STOP]); //SelectObject(hdc, m_pen_brush[EPB_BRUSH_STOP]);
	}
	else*/
	if (type == ETDO_CAR)
	{
		/*SelectObject(hdc, m_pen_brush[EPB_PEN_CAR]);

		SelectObject(hdc, m_pen_brush[EPB_BRUSH_CAR]);*/
	}
	else
	if (type == ETDO_ZONE)
	{
		SelectObject(hdc, m_pen_brush[EPB_PEN_ZONE]);

		SelectObject(hdc, m_pen_brush[EPB_BRUSH_ZONE]);
	}
	else
	if (type == ETDO_ZONE_NEW)
	{
		SelectObject(hdc, m_pen_brush[EPB_PEN_ZONE_NEW]);

		SelectObject(hdc, m_pen_brush[EPB_BRUSH_ZONE_NEW]);
	}

	
}


void CDrawWnd::DrawObjects(HDC hdc)
{	
	DrawCenter(hdc); //DrawObject(hdc, m_center.x, m_center.y, ETDO_CENTER);

	if (m_fDrawObject == false) { return; }	
	
	SelectGDIObjects(hdc, ETDO_ZONE);

	m_data.m_f_sel_mes =	 true; //!m_f_car_lag_lead;

	m_data.DrawZones(hdc, m_viewOrigin, m_size, m_clientMouse, m_sel_object.point, m_sel_object.str_list); 

	SelectGDIObjects(hdc, ETDO_ROUTE_POINT);         //char sz_val[MAX_PATH + 1] = {0};

	m_data.DrawShapeLines(hdc, m_viewOrigin, m_size, m_clientMouse, m_sel_object.point, m_sel_object.str_list, m_pen_brush[EPB_PEN_ROUTE_POINT], m_pen_brush[EPB_PEN_ROUTE_LINE]); //m_sel_object.text = sz_val; //SelectGDIObjects(hdc, ETDO_STOP);
	
	m_data.DrawStops(hdc, m_viewOrigin, m_size, m_clientMouse, m_sel_object.point, m_sel_object.str_list, m_index_sel_stop, m_pen_brush); // (HPEN)m_pen_brush[EPB_PEN_SEL]);

	if (IsSelStop())
	{
		gBookMarks.SelApply();
		ClearSelStop();
	}

	//< car's
	if (m_zoom)
	{
		m_DrawATE_3.Calc(m_zoom, m_viewOrigin);

		CDrawATE_3_Draw_param sDrawParam;

		sDrawParam.m_CarLagLeadView= m_CarLagLeadView; //f_car_lag_lead = m_f_car_lag_lead;
		sDrawParam.p_pen_brush = m_pen_brush;
		sDrawParam.p_drawCarTypes = m_drawCarTypes;
		/*sDrawParam.p_pen_car_light = (void*)m_pen_brush[EPB_PEN_CAR_LIGHT];
		sDrawParam.p_pen_car = (void*)m_pen_brush[EPB_PEN_CAR];
		sDrawParam.p_brush_car = (void*)m_pen_brush[EPB_BRUSH_CAR];
		sDrawParam.p_brush_car_light = (void*)m_pen_brush[EPB_BRUSH_CAR_LIGHT];*/

		m_DrawATE_3.Draw(hdc, m_size, m_clientMouse, m_sel_object.point, m_sel_object.str_list,  m_viewOrigin, sDrawParam, m_zoom);

		EBookMarkName eBookName = gBookMarks.GetActive();

		if (eBookName == EBMN_CHAT && gLoginWnd.GetUserType() == EUT_DISP)
		{
			m_sAnswerUser.Draw(hdc, m_zoom, m_viewOrigin, m_pen_brush, m_clientMouse, m_sel_object.point, m_sel_object.str_list);
		}
	}
	//>

	SelectGDIObjects(hdc, ETDO_ZONE_NEW);
	
	m_data.m_zone_new.Draw(hdc, m_viewOrigin, m_size, m_clientMouse, m_sel_object.point, m_sel_object.str_list);
}

void CDrawWnd_SAnswerUser_ADD(void *p_param, FldsPtr fp) { CDrawWnd::SAnswerUser* p_this = (CDrawWnd::SAnswerUser*)p_param; if (p_this) { p_this->SAnswerUser_ADD(fp); } }

void CDrawWnd::SAnswerUser::SAnswerUser_ADD(FldsPtr fp)
{
	_bstr_t bstr_mes(fp->Item["mes"]->Value);
	_bstr_t bstr_user_name(fp->Item["user_name"]->Value);
	
	user_name = (char*)bstr_user_name;

	char* p = (char*)bstr_mes;	
	
	enum { LAT = 0, LNG };
	int index = LAT;

	int i_pos = 0; //double val;

	for (int i=0; p[i]; i++)
	{
		char c = p[i];

		if (c == ':' || p[i + 1] == 0)
		{
			int i_size = i - i_pos;
			int i_shift = 0;

			if (c != ':' && p[i + 1] == 0) { i_size++; i_shift = 1; }

			if (i_size)
			{
				char cs = p[i]; p[i]=0;

				if (index == LAT)
				{
					latlng.lat = atof(p + i_pos); //sscanf(p + i_pos, "%f", &val);					

					index = LNG;
				}
				else
				if (index == LNG)
				{
					latlng.lng = atof(p + i_pos); // sscanf(p + i_pos, "%f", &val); val;

					fFound = true;

					break;
				}

				p[i] = cs;
			}

			i_pos = i+1;
		}
	}

}

void CDrawWnd::SAnswerUser::Draw(HDC hdc, double zoom, const SPointInt& origin, HGDIOBJ* pen_brush, const SPointInt& clientMouse, SPointInt& sel_point, std::vector<std_string>& sel_str_list)
{
	static time_t time_prev = 0;
	time_t time = clock();
	time_t delta= time - time_prev;
	time_t delta_max = 300;

	if (time_prev == 0 || delta > delta_max)
	{
		std_string sz_query = "SELECT mes, (SELECT user_name FROM dbo.users u WHERE u.id_user = h.id_user_from)user_name ";
		
		sz_query.append("FROM dbo.chat_mes m, dbo.chat_mes_head h WHERE m.id_chat_mes_head = (SELECT MAX(id_chat_mes_head) FROM dbo.chat_mes_head h WHERE id_chat_mes_type = 4 AND id_user_to = ");
		
		sz_query.append(gLoginWnd.GetIdUser().c_str());

		sz_query.append(") AND m.id_chat_mes_head = h.id_chat_mes_head");
		
		fFound = false;

		bool fExec = MSSQL_Exec((char*)sz_query.c_str(), CDrawWnd_SAnswerUser_ADD, CDrawWnd_MSSQL_MES_ERR, this);

		if (fExec &&  fFound)
		{
			pn.SetByLatLng(latlng, zoom);
			
			re = c_draw_radius+1;
		}

		time_prev = time;
	}

	if (fFound == false) { return; }
 
	//<draw
	int x = pn.x + origin.x;
	int y = pn.y + origin.y;

	SelectObject(hdc, pen_brush[EPB_PEN_ANSWER_USER]);
	SelectObject(hdc, pen_brush[EPB_BRUSH_ANSWER_USER]);

	BOOL fRes = Ellipse(hdc, x - c_draw_radius, y - c_draw_radius, x + c_draw_radius, y + c_draw_radius);

	if (re < 15 * c_draw_radius) { re++; } else { re = c_draw_radius + 1; }

	fRes = Arc(hdc, x - re, y - re, x + re, y + re, x - re, y - re, x - re, y - re);

	MoveToEx(hdc, x, y - re, 0); LineTo(hdc, x, y + re);
	MoveToEx(hdc, x - re, y, 0); LineTo(hdc, x + re, y);

	bool f_in = math_e::inRectInt(clientMouse.x, clientMouse.y, x - c_draw_radius, y - c_draw_radius, x + c_draw_radius, y + c_draw_radius);

	if (f_in)
	{
		sel_point.Set(x + 2 * c_draw_radius, y - c_draw_radius);

		char sz_val[MAX_PATH + 1];

		sprintf(sz_val, "���������: %s : %7.4f:%7.4f", user_name.c_str(), latlng.lat, latlng.lng);

		sel_str_list.push_back(sz_val);  //strcat(sel_text, sz_val);
	}

	//>draw
}

void CDrawWnd::SetPlacement(UINT flag)
{
	WINDOWPLACEMENT placement;

	placement.length = sizeof(WINDOWPLACEMENT);

	placement.showCmd = flag;

	BOOL fSet = SetWindowPlacement(GetHWND(), &placement);
}

bool CDrawWnd::FindToolPointInRadius(int x, int y, int radius, int& index_point)
{
	bool fFound = false;

	for (int i = 0; fFound ==false && i < ci_max_point_tool; i++)
	{
		SPointInt&  toolPoint = m_pointTool[i];

		if (math_e::inRectInt(x, y, toolPoint.x - radius, toolPoint.y - radius, toolPoint.x + radius, toolPoint.y + radius))
		{
			index_point = i;

			fFound = true;
		}
	}

	return fFound;
}

void CDrawWnd::OnLButtonOp(int i_max)
{
	int index_point = 0;

	if (FindToolPointInRadius(m_clientMouse.x, m_clientMouse.y, c_draw_radius, index_point) == false)
	{
		if (i_toolState < i_max)
		{
			m_pointTool[i_toolState].Set(m_clientMouse.x, m_clientMouse.y);

			i_toolState++;
		}
	}
	else
	{
		DelToolPoint(index_point);
	}
}

bool CDrawWnd::GetClientCoord(const POINT& pt, SPointInt& pointClient)
{
	RECT rc;

	BOOL fRes = GetWindowRect(GetHWND(), &rc);

	if (fRes == false) { return false; }

	pointClient.x = pt.x - rc.left;

	pointClient.y = pt.y - rc.top;

	return true;
}

void CDrawWnd::GetLatLngOnMouse(Leaflet::LatLng& latlng)
{
	SPointInt pn;
	pn.x = m_clientMouse.x - m_viewOrigin.x;
	pn.y = m_clientMouse.y - m_viewOrigin.y;

	pn.GetLatLng(latlng, m_zoom);
}

void CDrawWnd::OnLButton() //const POINT& pt)
{
	if (GetHWND() == 0) { return; } // SPointInt pointClient; if (GetClientCoord(pt, pointClient) == false) { return; }

	if (m_tool == EDWT_NONE)
	{
		RequestToCheckSelStop();
		
		Leaflet::LatLng latlng;

		GetLatLngOnMouse(latlng);

		gBookMarks.ClickOnMap(latlng);
	}
	else
	if (m_tool == EDWT_LINE_MEASURE)
	{
		OnLButtonOp(ci_max_point_tool); //pointClient, 
	}
	else
	if (m_tool == EDWT_LINE_MEASURE_MOUSE)
	{
		OnLButtonOp(1); //pointClient, 
	}
	else
	if (m_tool == EDWT_ZONE_POINT_NEW)
	{
		ZonePointNew();
	}
	
}

void CDrawWnd::DelToolPoint(int index_point)
{
	if (index_point < 0 || index_point >= i_toolState) { return; }

	if (index_point == 0)
	{
		m_pointTool[0] = m_pointTool[1];
	}

	i_toolState--;
}

void CDrawWnd::CalcClientMouse()
{
	POINT ptMouse;

	if (GetCursorPos(&ptMouse) == false) { return; }

	if (GetClientCoord(ptMouse, m_clientMouse) == false) { return; }
}

void CDrawWnd::DrawTool(HDC hdc)
{
	SelectObject(hdc, m_pen_brush[EPB_PEN_ROUTE_POINT]);

	SelectObject(hdc, m_pen_brush[EPB_BRUSH_ROUTE_POINT]);

	if (m_tool == EDWT_LINE_MEASURE)
	{
		if (i_toolState == 2) //line
		{
			MoveToEx(hdc, m_pointTool[0].x, m_pointTool[0].y, 0);

			LineTo(hdc, m_pointTool[1].x, m_pointTool[1].y);

			DrawTextToolOp(hdc, m_pointTool[1]);
		}

		for (int i = 0; i < i_toolState; i++)
		{
			int x = m_pointTool[i].x;

			int y = m_pointTool[i].y;

			BOOL fRes = Ellipse(hdc, x - c_draw_radius, y - c_draw_radius, x + c_draw_radius, y + c_draw_radius); //Rectangle(hdc, draw_pn.x - c_radius, draw_pn.y - c_radius, draw_pn.x + c_radius, draw_pn.y + c_radius);			
		}

	}else
	if (m_tool == EDWT_LINE_MEASURE_MOUSE)
	{
		if (i_toolState)
		{
			//line
			MoveToEx(hdc, m_pointTool[0].x, m_pointTool[0].y, 0);

			LineTo(hdc, m_clientMouse.x, m_clientMouse.y);

			DrawTextToolOp(hdc, m_clientMouse);

			//pint
			int x = m_pointTool[0].x;

			int y = m_pointTool[0].y;

			BOOL fRes = Ellipse(hdc, x - c_draw_radius, y - c_draw_radius, x + c_draw_radius, y + c_draw_radius); //Rectangle(hdc, draw_pn.x - c_radius, draw_pn.y - c_radius, draw_pn.x + c_radius, draw_pn.y + c_radius);
		}
	}
}

void CDrawWnd::DrawTextToolOp(HDC hdc, const SPointInt& pointLast)
{
	if (i_toolState == 0) { return; }

	double dist2D = math_e::dist2D(m_pointTool[0].x, m_pointTool[0].y, pointLast.x, pointLast.y);

	char sz_val[MAX_PATH + 1];

	sprintf(sz_val, "%g", dist2D);

	TextOutA(hdc, m_pointTool[0].x + 2 * c_draw_radius, m_pointTool[0].y, sz_val, strlen(sz_val));
}

void CDrawWnd::AddTextToolOp(wchar_t * wsz_text, const SPointInt& pointLast)
{
	if (i_toolState == 0) { return; }

	double dist2D = math_e::dist2D(m_pointTool[0].x, m_pointTool[0].y, pointLast.x, pointLast.y);

	char sz_val[MAX_PATH + 1];

	sprintf(sz_val, "%g", dist2D);

	wchar_t wz_val[MAX_PATH + 1];

	memset(wz_val, 0, (MAX_PATH + 1) * sizeof(wchar_t));

	int i_res = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, (LPCSTR)sz_val, strlen(sz_val), wz_val, MAX_PATH + 1);

	if (i_res == 0) { return; }

	lstrcat(wsz_text, L" dist2D: ");

	lstrcat(wsz_text, wz_val);
}

void CDrawWnd::AddTextTool(wchar_t * wsz_text)
{
	if (GetHWND() == 0) { return; }

	if (m_tool == EDWT_LINE_MEASURE)
	{
		if (i_toolState == 2)
		{
			AddTextToolOp(wsz_text, m_pointTool[1]);
		}		
	}
	else
	if (m_tool == EDWT_LINE_MEASURE_MOUSE)
	{
		AddTextToolOp(wsz_text, m_clientMouse);
	}
}

bool CDrawWnd::IsMouseOnObject()
{
	
	//m_sel_obj.Clear();
	/*
	bool fOn = false;

	for (int i = 0; fOn==false && i < m_object_list.size(); i++)
	{
		SDrawObject& object = m_object_list[i];
		
		int x = object.point.x + m_viewOrigin.x;
		
		int y = object.point.y + m_viewOrigin.y;

		if (math_e::inRectInt(m_clientMouse.x, m_clientMouse.y, x- c_draw_radius, y - c_draw_radius, x + c_draw_radius, y + c_draw_radius))
		{
			fOn = true;

			if (p_object) { *p_object = &object; }
		}
	}
	*/
		return false; // fOn;
}


void CDrawWnd::OnMouseMove()
{	
	FindNear();

	if (IsMouseOnObject())
	{
	}
	else
	{
		
	}
}

void CDrawWnd::DrawObjectInfo(HDC hdc)
{
	if (m_sel_object.str_list.size()==0) { return; }

	int x = m_sel_object.point.x;// +m_viewOrigin.x;

	int y = m_sel_object.point.y;// + m_viewOrigin.y;

	int w_col = 8;
	int h_row = 15;	
	
	int i_len_max= 0;
	
	int q = m_sel_object.str_list.size();

	for (int i = 0; i < q; i++)
	{
		const char *p_name = m_sel_object.str_list[i].c_str();

		if (i == 0) { i_len_max = strlen(p_name); }
		else
		{
			if (i_len_max < strlen(p_name)) { i_len_max = strlen(p_name); }
		}
	}
	
	i_len_max *= w_col;

	if (x + i_len_max > m_size.x) { x = m_size.x - i_len_max; }
	
	if (y + q*h_row > m_size.y) { y = m_size.y - q*h_row; }

	//SetBkMode(hdc, TRANSPARENT);

	for (int i = 0; i < q; i++)
	{
		const char *p_name = m_sel_object.str_list[i].c_str();

		int yn = y + i*h_row;

		/*SetTextColor(hdc, cl_info_color_back);	

		TextOutA(hdc, x, yn, p_name, strlen(p_name));*/
		
		SetTextColor(hdc, cl_info_color);

		TextOutA(hdc, x+1, yn+1, p_name, strlen(p_name));
	}
	
	m_sel_object.str_list.clear(); // m_sel_object.text = "";
}

int CDrawWnd::GetRouteSize()
{
	return m_data.m_routes.size();
}

bool CDrawWnd::NextRoute(int& index, SRoute& o, bool fBack)
{
	if (index < 0) { return false; }

	if (index >= m_data.m_routes.size()) { return false; }

	o = m_data.m_routes[index];

	if (fBack == false)
	{ index++; }
	else
	{ index--; }

	return true;
}

bool CDrawWnd::NextStop(int& index, SStop& o)
{
	if (index < 0) { return false; }

	if (index >= m_data.m_stops.size()) { return false; }

	o = m_data.m_stops[index];

	index++;

	return true;
}

bool CDrawWnd::NextZone(int& index, SZone& o)
{
	if (index < 0) { return false; }

	if (index >= m_data.m_zones.size()) { return false; }

	o = m_data.m_zones[index];

	index++;

	return true;
}

bool CDrawWnd::NextShapeLine(int& index, SShapeLine& sl)
{
	if (index < 0) { return false; }

	if (index >= m_data.m_shape_lines.size()) { return false; }

	sl = m_data.m_shape_lines[index];

	index++;

	return true;
}

void CDrawWnd::SelectRoute(int index)
{
	InterlockedExchange(&m_data.m_index_sel_route, (long)index);
}

void CDrawWnd::SelectStop(int index)
{
	InterlockedExchange(&m_data.m_index_sel_stop, (long)index);
}

void CDrawWnd::SelectZone(int index)
{
	InterlockedExchange(&m_data.m_index_sel_zone, (long)index);
}

void CDrawWnd::SelectZoneDel()
{
	//if (MessageBoxA(0, "� ����� ���� ������� ?", g_szm_app, MB_YESNO) == IDNO) { return; }

	//InterlockedExchange(&m_data.m_flag_no_draw_zones, 1);

	int index = m_data.m_index_sel_zone;

	if (index == 1) { return; } //YUIL ����.

	if (index == 0) 
	{ 

		bool fExec = MSSQL_Exec("TRUNCATE TABLE dbo.zones", 0, CDrawWnd_MSSQL_MES_ERR, this);

		m_data.m_zones.clear();

	}
	else
	{
		//<
		int sel_index = m_data.m_index_sel_zone - 2;

		SelectZone(0); //YUIL ������ �� "���"

		std_string sz_query = "DELETE FROM dbo.zones WHERE name=N'";

		sz_query.append(m_data.m_zones[sel_index].name);

		sz_query.append("'");

		bool fExec = MSSQL_Exec((char*)sz_query.c_str(), 0, CDrawWnd_MSSQL_MES_ERR, this);
		//>

		m_data.LoadZones();

		m_data.CalcZones(m_zoom);
	}

	//InterlockedExchange(&m_data.m_flag_no_draw_zones, 0);
	/*std::vector<SZone>::iterator it = m_data.m_zones.begin();

	std::advance(it, sel_index);

	m_data.m_zones.erase(it);*/
}


EDrawWndTool CDrawWnd::SetTool(EDrawWndTool eNew)
{
	if (m_tool == eNew)
	{ m_tool = EDWT_NONE; }
	else
	{ m_tool = eNew; }

	return m_tool;
}

void CDrawWnd::ZonePointNew()
{
	//m_clientMouse
	//SPointInt point_to_DB;
	//point_to_DB.Set(m_clientMouse.x - m_viewOrigin.x, m_clientMouse.y - m_viewOrigin.y);
	
	//m_data.m_zones.

	if (m_data.m_zone_new.AddPoint(m_clientMouse.x - m_viewOrigin.x, m_clientMouse.y - m_viewOrigin.y, m_zoom))
	{
		if (m_data.m_zone_new.quantity == cl_max_zone_points) 
		{ 
			if (gControlPanelWnd.GetHWND())
			{
			 gControlPanelWnd.Set_but_cr_zone_text_close(); 
			}
		}
	}
}

void CDrawWnd::ZoneNewClear(char *sz_new_name) 
{ 
	m_data.m_zone_new.Clear(); 

	m_data.m_zone_new.name = sz_new_name;
}

bool CDrawWnd::ZoneNewSave()
{
	if (m_data.m_zone_new.quantity == 0) { return false; }

	m_data.m_zone_new.Save();

	m_data.LoadZones();

	m_data.CalcZones(m_zoom);

	m_data.m_zone_new.quantity = 0;

	return true;
}

bool CDrawWnd::ZoneNameExists(char *sz_name)
{
	return m_data.FindZone(sz_name);
}

bool CDrawWnd::GetRoute(int index, SRoute& s_route)
{
	if (index < 0 || index >= m_data.m_routes.size()) { return false; }

	s_route = m_data.m_routes[index];

	return true;
}

bool CDrawWnd::GetStop(int index, SStop& s_stop)
{
	if (index < 0 || index >= m_data.m_stops.size()) { return false; }

	s_stop = m_data.m_stops[index];

	return true;
}

bool CDrawWnd::GetStopPtr(int index, SStop* *p_stop)
{
	if (index < 0 || index >= m_data.m_stops.size()) { return false; }

	*p_stop = &m_data.m_stops[index];

	return true;
}

void CDrawWnd::FindNear()
{
	if (m_f_find_near_car==false) {return;}

	double x, y;
	SDeviceATE_3 sDev;

	//1. ����� ������ ��������� ����� �� ����
	SPointInt p;
	p.x = m_clientMouse.x - m_viewOrigin.x;
	p.y = m_clientMouse.y - m_viewOrigin.y;

	//2. �����
	math_e::ScreenPointToXY(p.x, p.y, m_zoom, x, y); 

	//3.
	bool f_found=m_DrawATE_3.FindNear(x, y, sDev);

	if (f_found)
	{
		char *p_text = (char*)sDev.name;

		if (g_i_user_interface == 0)
		{
			if (gControlPanelWnd.GetHWND()) { gControlPanelWnd.SetStaticText(p_text); }
		}
		else
		if (g_i_user_interface == 1)
		{
			gBookMarks.set_edit_find_near_car(p_text);
		}
	}
}

void CDrawWnd::ChShow() 
{
	WindowChShow(m_hwnd);
}

void CDrawWnd::CarTypesClear()
{
	memset(m_drawCarTypes, 0, sizeof(bool)*(int)ECT_QUANTITY);
}

void CDrawWnd::SetCarType(char *id_car_type)
{
	bool fFound = false;

	int i_id_car_type = atoi(id_car_type)-1;

	int q = (int)ECT_QUANTITY;

	if (i_id_car_type < 0 || i_id_car_type >= q) { return; }

	m_drawCarTypes[i_id_car_type] = true;
}