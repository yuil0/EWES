#ifndef _car_zone_h_
#define _car_zone_h_

#include <windows.h>
#include "..\\transman_srv\\std_str.h"
#include <vector>

class CCarZone
{
	//bool m_fInit;

	//std::vector<S_new_thread_Row> m_list;

	//SMSSQLAgentRow m_row;
	
public:
	CCarZone();
	~CCarZone();
	bool Open();
	void Close() {}
	
	bool Exec();	
};

extern CCarZone gCarZone;

#endif