#ifndef _MapAddr_h_
#define _MapAddr_h_

#include  <windows.h>

typedef enum
{
	EMAP_MAGNIFY=0,    //YUIL ����������� ����������  
	EMAP_LATITUDE , //YUIL ������
	EMAP_LONGITUDE , //YUIL �������
	//
	EMAP_QUANTITY,
}EMapAddrParam;

struct SMapAddrParam
{
	int magnify;     // http://openstreetmap.ru/#map=11/47.2352/39.6802&layer=H

	double latitude;

	double longitude;
};

class CMapAddr
{   
	SMapAddrParam m_param;	

	bool m_fRead;

	bool m_event[EMAP_QUANTITY];              

	bool Parse(wchar_t *wsz_addr, SMapAddrParam& param);

	void ClearEvent();     //bool DeltaIsOver();

	public:

	CMapAddr();

	void Clear();

	void Read(wchar_t *wsz_addr);

	bool GetEvent(EMapAddrParam eEvent) { return m_event[eEvent]; }
	
	bool GetEventAny() 
	{ 
		for (int i=0; i<(int)EMAP_QUANTITY; i++)
		{
			if (m_event[i]) { return true; }
		}

		return false; 
	}

	SMapAddrParam& GetParam() { return (SMapAddrParam&)m_param; }
};

#endif